// Gera uma senha nova para um usuário (ex.: o administrador esqueceu a dele).
// No servidor, dentro de deploy/:
//   docker compose exec app node scripts/redefinir-senha.js natan@natanmotos.com.br
// A senha nova aparece na tela uma vez; a pessoa troca em Configurações › Minha senha.
// Também encerra as sessões abertas dessa pessoa e reativa o acesso, se estava desativado.
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { db } from '../src/lib/db.js';

const email = (process.argv[2] || '').trim().toLowerCase();
if (!email) {
  console.error('Uso: node scripts/redefinir-senha.js <e-mail do usuário>');
  process.exit(2);
}
try {
  const user = await db('users').whereRaw('lower(email) = ?', [email]).first();
  if (!user) {
    const all = await db('users').select('email', 'role').orderBy('id');
    console.error(`Nenhum usuário com o e-mail ${email}. Usuários: ${all.map((u) => `${u.email} (${u.role})`).join(', ')}`);
    process.exitCode = 1;
  } else {
    const password = crypto.randomBytes(9).toString('base64url');
    await db('users').where({ id: user.id }).update({
      passwordHash: await bcrypt.hash(password, 12), tokenVersion: user.tokenVersion + 1, active: true,
    });
    console.log(`Senha nova de ${user.name} (${user.email}): ${password}`);
  }
} finally {
  await db.destroy();
}
