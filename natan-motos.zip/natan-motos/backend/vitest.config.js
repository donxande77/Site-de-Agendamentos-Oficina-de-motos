import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    fileParallelism: false,
    globalSetup: ['./tests/global-setup.js'],
    env: {
      NODE_ENV: 'test',
      DATABASE_URL: process.env.TEST_DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/natanmotos_test',
      JWT_SECRET: 'test-secret-test-secret-test-secret-123',
      JWT_REFRESH_SECRET: 'test-refresh-test-refresh-test-refresh-1',
      SEED_OWNER_EMAIL: 'dono@teste.com',
      SEED_OWNER_PASSWORD: 'SenhaDono123',
      PUBLIC_BASE_URL: 'https://natanmotos.test',
      UPLOADS_DIR: './tests/.uploads',
    },
    testTimeout: 20000,
  },
});
