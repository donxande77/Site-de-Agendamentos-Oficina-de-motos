import knexLib from 'knex';

// Recreates the test database schema and seed data once per test run.
export default async function setup() {
  const url = process.env.TEST_DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/natanmotos_test';
  Object.assign(process.env, { SEED_OWNER_EMAIL: 'dono@teste.com', SEED_OWNER_PASSWORD: 'SenhaDono123', PUBLIC_BASE_URL: 'https://natanmotos.test' });
  const knex = knexLib({ client: 'pg', connection: url, migrations: { directory: './db/migrations' }, seeds: { directory: './db/seeds' } });
  await knex.raw('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  await knex.migrate.latest();
  await knex.seed.run();
  await knex.destroy();
}
