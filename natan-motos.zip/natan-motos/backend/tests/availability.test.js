import { describe, it, expect } from 'vitest';
import { DateTime } from 'luxon';
import { computeDaySlots, totalDuration, fitsPublicRules } from '../src/services/availability.js';

const TZ = 'America/Sao_Paulo';
const DATE = '2030-03-12'; // a Tuesday
const at = (hm) => DateTime.fromISO(`${DATE}T${hm}`, { zone: TZ }).toJSDate();
const weekday = { closed: false, opensAt: '08:00', closesAt: '18:00', breakStart: '12:00', breakEnd: '13:00' };
const bays = [{ id: 1 }, { id: 2 }];
const base = { date: DATE, hours: weekday, bays, slotMinutes: 30, minNoticeHours: 2, now: new Date('2030-01-01T00:00:00Z') };
const times = (slots) => slots.map((s) => s.time);

describe('totalDuration', () => {
  it('soma os serviços e arredonda para o tamanho do horário', () => {
    expect(totalDuration([{ durationMinutes: 30 }, { durationMinutes: 45 }], 30)).toBe(90);
    expect(totalDuration([{ durationMinutes: 10 }], 30)).toBe(30);
    expect(totalDuration([{ durationMinutes: 180 }, { durationMinutes: 30 }], 30)).toBe(210);
  });
});

describe('computeDaySlots', () => {
  it('dia fechado não tem horários', () => {
    expect(computeDaySlots({ ...base, durationMinutes: 30, hours: { ...weekday, closed: true } })).toEqual([]);
  });

  it('serviço de 30 min: 08:00 até 17:30, sem o almoço', () => {
    const t = times(computeDaySlots({ ...base, durationMinutes: 30 }));
    expect(t[0]).toBe('08:00');
    expect(t.at(-1)).toBe('17:30');
    expect(t).not.toContain('12:00');
    expect(t).not.toContain('12:30');
    expect(t).toContain('11:30');
    expect(t).toContain('13:00');
    expect(t).toHaveLength(18);
  });

  it('serviço longo não atravessa o almoço nem o fim do dia', () => {
    const t = times(computeDaySlots({ ...base, durationMinutes: 180 }));
    expect(t).toEqual(['08:00', '08:30', '09:00', '13:00', '13:30', '14:00', '14:30', '15:00']);
  });

  it('respeita a antecedência mínima', () => {
    const now = DateTime.fromISO(`${DATE}T09:10`, { zone: TZ }).toJSDate();
    const t = times(computeDaySlots({ ...base, durationMinutes: 30, now }));
    expect(t[0]).toBe('11:30'); // 09:10 + 2h = 11:10 → next slot 11:30
  });

  it('horário some só quando os dois elevadores estão ocupados', () => {
    const bookings = [{ bayId: 1, startAt: at('08:00'), endAt: at('09:00') }];
    let s = computeDaySlots({ ...base, durationMinutes: 30, bookings });
    expect(s.find((x) => x.time === '08:00').bayIds).toEqual([2]);
    bookings.push({ bayId: 2, startAt: at('08:30'), endAt: at('09:30') });
    s = computeDaySlots({ ...base, durationMinutes: 30, bookings });
    expect(times(s)).not.toContain('08:30');
    expect(s.find((x) => x.time === '08:00').bayIds).toEqual([2]);
    expect(s.find((x) => x.time === '09:00').bayIds).toEqual([1]);
  });

  it('bloqueio da oficina inteira tira todos os elevadores; bloqueio de um elevador só tira ele', () => {
    const all = computeDaySlots({ ...base, durationMinutes: 30, blocks: [{ bayId: null, userId: null, startAt: at('14:00'), endAt: at('16:00') }] });
    expect(times(all)).not.toContain('14:00');
    expect(times(all)).not.toContain('15:30');
    expect(times(all)).toContain('16:00');
    const one = computeDaySlots({ ...base, durationMinutes: 30, blocks: [{ bayId: 1, userId: null, startAt: at('14:00'), endAt: at('16:00') }] });
    expect(one.find((x) => x.time === '14:00').bayIds).toEqual([2]);
  });

  it('folga de mecânico não bloqueia elevador', () => {
    const s = computeDaySlots({ ...base, durationMinutes: 30, blocks: [{ bayId: null, userId: 5, startAt: at('08:00'), endAt: at('18:00') }] });
    expect(s).toHaveLength(18);
  });

  it('dia sem pausa para almoço', () => {
    const t = times(computeDaySlots({ ...base, durationMinutes: 60, hours: { closed: false, opensAt: '08:00', closesAt: '12:00' } }));
    expect(t).toEqual(['08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00']);
  });
});

describe('fitsPublicRules', () => {
  const settings = { minNoticeHours: 2, maxDaysAhead: 30, slotMinutes: 30 };
  const now = DateTime.fromISO(`${DATE}T07:00`, { zone: TZ }).toJSDate();
  it('aceita horário dentro das regras', () => {
    expect(fitsPublicRules({ start: at('10:00'), end: at('10:30'), hours: weekday, settings, now })).toBe(true);
  });
  it('recusa fora do expediente, no almoço, fora da grade e em cima da hora', () => {
    expect(fitsPublicRules({ start: at('17:45'), end: at('18:15'), hours: weekday, settings, now })).toBe(false);
    expect(fitsPublicRules({ start: at('11:30'), end: at('12:30'), hours: weekday, settings, now })).toBe(false);
    expect(fitsPublicRules({ start: at('10:10'), end: at('10:40'), hours: weekday, settings, now })).toBe(false);
    expect(fitsPublicRules({ start: at('08:00'), end: at('08:30'), hours: weekday, settings, now })).toBe(false);
  });
  it('recusa além do limite de dias', () => {
    const far = DateTime.fromISO(`${DATE}T10:00`, { zone: TZ }).plus({ days: 40 });
    expect(fitsPublicRules({ start: far.toJSDate(), end: far.plus({ minutes: 30 }).toJSDate(), hours: weekday, settings, now })).toBe(false);
  });
});
