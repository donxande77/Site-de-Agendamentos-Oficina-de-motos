import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { DateTime } from 'luxon';
import { createApp } from '../src/app.js';
import { db } from '../src/lib/db.js';
import { markNoShows } from '../src/jobs/tasks.js';

const TZ = 'America/Sao_Paulo';
const app = createApp();

// Next Tuesday at least 3 days from now (always open in the seed hours)
function nextTuesday(weeksAhead = 0) {
  let d = DateTime.now().setZone(TZ).plus({ days: 3 }).startOf('day');
  while (d.weekday !== 2) d = d.plus({ days: 1 });
  return d.plus({ weeks: weeksAhead }).toISODate();
}
const DAY = nextTuesday();
const iso = (hm, day = DAY) => DateTime.fromISO(`${day}T${hm}`, { zone: TZ }).toISO();

let ownerToken;
const auth = (t = ownerToken) => ({ Authorization: `Bearer ${t}` });

function bookingBody(over = {}) {
  return {
    serviceIds: [1],
    startAt: iso('09:00'),
    source: 'instagram',
    privacyAck: true,
    reminderConsent: true,
    customer: { name: 'João da Silva', phone: '(21) 99999-0001', email: 'joao@example.com' },
    motorcycle: { brand: 'Honda', model: 'CG 160 Fan', year: 2021, plate: 'ABC1D23', mileage: 18000 },
    ...over,
  };
}

beforeAll(async () => {
  const r = await request(app).post('/api/v1/auth/login').send({ email: 'dono@teste.com', password: 'SenhaDono123' });
  ownerToken = r.body.accessToken;
  // Give the oil change a price so totals are meaningful
  await db('services').where({ id: 1 }).update({ basePriceCents: 8000 });
});

afterAll(async () => { await db.destroy(); });

describe('público', () => {
  it('mostra as informações da oficina', async () => {
    const r = await request(app).get('/api/v1/public/info');
    expect(r.status).toBe(200);
    expect(r.body.shopName).toBe('Natan Motos');
    expect(r.body.bays).toBe(2);
    expect(r.body.services.length).toBeGreaterThan(5);
  });

  it('cria agendamento pelo link do Instagram e o cliente consulta pelo link privado', async () => {
    const r = await request(app).post('/api/v1/public/bookings').send(bookingBody());
    expect(r.status).toBe(201);
    expect(r.body.token).toMatch(/^[\w-]{30,}$/);
    expect(r.body.booking.status).toBe('CONFIRMED');
    expect(r.body.booking.source).toBe('instagram');
    const g = await request(app).get(`/api/v1/public/bookings/${r.body.token}`);
    expect(g.status).toBe(200);
    expect(g.body.booking.code).toBe(r.body.booking.code);
    expect(g.body.booking).not.toHaveProperty('customerPhone');
    const ics = await request(app).get(`/api/v1/public/bookings/${r.body.token}/ics`);
    expect(ics.text).toContain('BEGIN:VEVENT');
  });

  it('exige aceite do aviso de privacidade', async () => {
    const r = await request(app).post('/api/v1/public/bookings').send(bookingBody({ privacyAck: false, startAt: iso('10:00') }));
    expect(r.status).toBe(400);
  });

  it('recusa placa inválida com mensagem em português', async () => {
    const r = await request(app).post('/api/v1/public/bookings').send(bookingBody({ startAt: iso('10:00'), motorcycle: { brand: 'Honda', model: 'Biz', plate: 'XX12' } }));
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/placa/i);
  });

  it('bloqueia robôs pelo campo invisível', async () => {
    const r = await request(app).post('/api/v1/public/bookings').send(bookingBody({ startAt: iso('10:00'), website: 'spam.com' }));
    expect(r.status).toBe(400);
  });

  it('recusa horário no almoço ou fora da grade', async () => {
    const r1 = await request(app).post('/api/v1/public/bookings').send(bookingBody({ startAt: iso('12:00'), customer: { name: 'Ana', phone: '21999990002' }, motorcycle: { brand: 'Yamaha', model: 'Fazer', plate: 'DEF1G23' } }));
    expect(r1.status).toBe(409);
    const r2 = await request(app).post('/api/v1/public/bookings').send(bookingBody({ startAt: iso('10:10'), customer: { name: 'Ana', phone: '21999990002' }, motorcycle: { brand: 'Yamaha', model: 'Fazer', plate: 'DEF1G23' } }));
    expect(r2.status).toBe(409);
  });

  it('nunca agenda duas motos no mesmo elevador: 3 pedidos simultâneos, 2 elevadores', async () => {
    const reqs = [1, 2, 3].map((i) => request(app).post('/api/v1/public/bookings').send(bookingBody({
      startAt: iso('14:00'),
      customer: { name: `Cliente ${i}`, phone: `2198888000${i}` },
      motorcycle: { brand: 'Honda', model: 'Pop', plate: `GHI${i}J45` },
    })));
    const res = await Promise.all(reqs);
    const codes = res.map((r) => r.status).sort();
    expect(codes).toEqual([201, 201, 409]);
    const slots = await request(app).get(`/api/v1/public/slots?date=${DAY}&services=1`);
    expect(slots.body.slots.map((s) => s.time)).not.toContain('14:00');
  });

  it('o banco recusa sobreposição mesmo se a regra da aplicação falhar', async () => {
    const b = await db('bookings').where({ status: 'CONFIRMED' }).first();
    await expect(db('bookings').insert({ ...b, id: undefined, code: 'NM-TESTE', manageToken: 'x'.repeat(32) })).rejects.toMatchObject({ code: '23P01' });
  });

  it('cliente remarca e cancela pelo link', async () => {
    const r = await request(app).post('/api/v1/public/bookings').send(bookingBody({ startAt: iso('15:00'), customer: { name: 'Maria', phone: '21977770001' }, motorcycle: { brand: 'Suzuki', model: 'Yes', plate: 'JKL2M34' } }));
    const token = r.body.token;
    const re = await request(app).post(`/api/v1/public/bookings/${token}/reschedule`).send({ startAt: iso('16:00') });
    expect(re.status).toBe(200);
    expect(DateTime.fromISO(re.body.booking.startAt).setZone(TZ).toFormat('HH:mm')).toBe('16:00');
    const c = await request(app).post(`/api/v1/public/bookings/${token}/cancel`);
    expect(c.body.booking.status).toBe('CANCELLED');
  });
});

describe('autenticação e permissões', () => {
  it('senha errada não entra', async () => {
    const r = await request(app).post('/api/v1/auth/login').send({ email: 'dono@teste.com', password: 'errada' });
    expect(r.status).toBe(401);
    expect(r.body.error).toBe('E-mail ou senha incorretos.');
  });

  it('painel sem login é bloqueado', async () => {
    expect((await request(app).get('/api/v1/admin/dashboard')).status).toBe(401);
  });

  it('mecânico não vê financeiro nem configurações sensíveis', async () => {
    await request(app).post('/api/v1/admin/users').set(auth()).send({ name: 'Zé Mecânico', email: 'ze@teste.com', role: 'MECHANIC', password: 'SenhaMec123', commissionPercent: 30 });
    const login = await request(app).post('/api/v1/auth/login').send({ email: 'ze@teste.com', password: 'SenhaMec123' });
    const t = login.body.accessToken;
    expect((await request(app).get('/api/v1/admin/dashboard').set(auth(t))).status).toBe(403);
    expect((await request(app).get(`/api/v1/admin/finance/summary?from=${DAY}&to=${DAY}`).set(auth(t))).status).toBe(403);
    expect((await request(app).patch('/api/v1/admin/settings').set(auth(t)).send({ shopName: 'X' })).status).toBe(403);
    expect((await request(app).get(`/api/v1/admin/agenda?from=${DAY}&to=${DAY}`).set(auth(t))).status).toBe(200);
  });

  it('usuário desativado perde o acesso na hora', async () => {
    const u = await db('users').where({ email: 'ze@teste.com' }).first();
    const login = await request(app).post('/api/v1/auth/login').send({ email: 'ze@teste.com', password: 'SenhaMec123' });
    await request(app).patch(`/api/v1/admin/users/${u.id}`).set(auth()).send({ active: false });
    expect((await request(app).get(`/api/v1/admin/agenda?from=${DAY}&to=${DAY}`).set(auth(login.body.accessToken))).status).toBe(401);
    await request(app).patch(`/api/v1/admin/users/${u.id}`).set(auth()).send({ active: true });
  });
});

describe('fluxo da oficina: check-in → orçamento → aprovação → entrega', () => {
  it('funciona de ponta a ponta, com estoque, pagamento, garantia e lembrete de óleo', async () => {
    const part = (await request(app).post('/api/v1/admin/parts').set(auth()).send({ name: 'Óleo 10W30 1L', costCents: 2500, priceCents: 4500, stock: 10, minStock: 3 })).body.part;
    const booking = await db('bookings').where({ status: 'CONFIRMED' }).orderBy('id').first();

    const ci = await request(app).post(`/api/v1/admin/bookings/${booking.id}/checkin`).set(auth()).send({ checkInMileage: 18500, fuelLevel: 'half', checklist: { items: ['helmet'] } });
    expect(ci.status).toBe(201);
    const id = ci.body.orderId;

    const add = await request(app).post(`/api/v1/admin/orders/${id}/items`).set(auth()).send({ type: 'PART', partId: part.id, quantity: 2 });
    expect(add.status).toBe(201);
    let o = (await request(app).get(`/api/v1/admin/orders/${id}`).set(auth())).body.order;
    expect(o.totalCents).toBe(8000 + 2 * 4500);

    const sq = await request(app).post(`/api/v1/admin/orders/${id}/send-quote`).set(auth());
    expect(sq.body.order.status).toBe('WAITING_APPROVAL');

    const pub = await request(app).get(`/api/v1/public/quotes/${o.approvalToken}`);
    expect(pub.body.quote.totalCents).toBe(17000);
    expect(pub.body.quote).not.toHaveProperty('customerPhone');
    const ap = await request(app).post(`/api/v1/public/quotes/${o.approvalToken}/approve`);
    expect(ap.status).toBe(200);
    expect((await request(app).post(`/api/v1/public/quotes/${o.approvalToken}/approve`)).status).toBe(400);
    expect((await db('parts').where({ id: part.id }).first()).stock).toBe(8);

    await request(app).post(`/api/v1/admin/orders/${id}/status`).set(auth()).send({ status: 'IN_PROGRESS' });
    await request(app).post(`/api/v1/admin/orders/${id}/status`).set(auth()).send({ status: 'READY' });
    const unpaid = await request(app).post(`/api/v1/admin/orders/${id}/status`).set(auth()).send({ status: 'DELIVERED' });
    expect(unpaid.status).toBe(400);
    expect(unpaid.body.code).toBe('UNPAID');

    await request(app).post(`/api/v1/admin/orders/${id}/payments`).set(auth()).send({ amountCents: 10000, method: 'PIX' });
    await request(app).post(`/api/v1/admin/orders/${id}/payments`).set(auth()).send({ amountCents: 7000, method: 'CREDIT', installments: 2 });
    const del = await request(app).post(`/api/v1/admin/orders/${id}/status`).set(auth()).send({ status: 'DELIVERED' });
    expect(del.status).toBe(200);
    o = del.body.order;
    expect(o.status).toBe('DELIVERED');
    expect(o.balanceCents).toBe(0);
    expect(o.warrantyUntil).toBeTruthy();

    const rem = await db('maintenance_reminders').where({ serviceOrderId: id }).first();
    expect(rem.type).toBe('OIL_CHANGE');
    expect(rem.dueMileage).toBe(18500 + 3000);

    const pdf = await request(app).get(`/api/v1/admin/orders/${id}/pdf`).set(auth());
    expect(pdf.headers['content-type']).toBe('application/pdf');
    expect(pdf.body.length).toBeGreaterThan(1000);

    const today = DateTime.now().setZone(TZ).toISODate();
    const fin = await request(app).get(`/api/v1/admin/finance/summary?from=${today}&to=${today}`).set(auth());
    expect(fin.body.revenueCents).toBe(17000);
    expect(fin.body.partsCostCents).toBe(5000);

    const dash = await request(app).get('/api/v1/admin/dashboard').set(auth());
    expect(dash.status).toBe(200);
    expect(dash.body.revenueTodayCents).toBe(17000);
  });

  it('cancelar OS devolve as peças ao estoque', async () => {
    const c = await db('customers').first();
    const m = await db('motorcycles').where({ customerId: c.id }).first();
    const part = await db('parts').first();
    const before = part.stock;
    const id = (await request(app).post('/api/v1/admin/orders').set(auth()).send({ customerId: c.id, motorcycleId: m.id })).body.orderId;
    await request(app).post(`/api/v1/admin/orders/${id}/items`).set(auth()).send({ type: 'PART', partId: part.id, quantity: 3 });
    await request(app).post(`/api/v1/admin/orders/${id}/status`).set(auth()).send({ status: 'IN_PROGRESS' });
    expect((await db('parts').where({ id: part.id }).first()).stock).toBe(before - 3);
    await request(app).post(`/api/v1/admin/orders/${id}/status`).set(auth()).send({ status: 'CANCELLED' });
    expect((await db('parts').where({ id: part.id }).first()).stock).toBe(before);
  });

  it('marca falta de quem não apareceu', async () => {
    const past = DateTime.now().minus({ hours: 3 });
    const c = await db('customers').first();
    const m = await db('motorcycles').where({ customerId: c.id }).first();
    await db('bookings').insert({ code: 'NM-PASSA', customerId: c.id, motorcycleId: m.id, bayId: 1, startAt: past.toJSDate(), endAt: past.plus({ minutes: 30 }).toJSDate(), status: 'CONFIRMED', manageToken: 'p'.repeat(32) });
    const n = await markNoShows();
    expect(n).toBeGreaterThanOrEqual(1);
    expect((await db('bookings').where({ code: 'NM-PASSA' }).first()).status).toBe('NO_SHOW');
  });
});

describe('LGPD', () => {
  it('exporta e depois apaga os dados de um cliente, mantendo o financeiro sem identificação', async () => {
    const c = await db('customers').where({ phone: '5521999990001' }).first();
    const exp = await request(app).get(`/api/v1/admin/customers/${c.id}/export`).set(auth());
    expect(exp.status).toBe(200);
    expect(exp.body.customer.phone).toBe('5521999990001');
    expect(exp.body.motorcycles[0].plate).toBe('ABC1D23');
    expect(exp.body.serviceOrders.length).toBeGreaterThan(0);

    const del = await request(app).delete(`/api/v1/admin/customers/${c.id}`).set(auth());
    expect(del.status).toBe(200);
    const after = await db('customers').where({ id: c.id }).first();
    expect(after.name).toBe('Cliente removido');
    expect(after.phone).not.toContain('99999');
    expect(after.email).toBeNull();
    expect(await db('motorcycles').where({ plate: 'ABC1D23' }).first()).toBeUndefined();
    expect((await db('service_orders').where({ customerId: c.id })).length).toBeGreaterThan(0);
  });

  it('respostas de erro não vazam detalhes internos', async () => {
    const r = await request(app).get('/api/v1/public/bookings/nao-existe-token-aaaaaaaaaaaa');
    expect(r.status).toBe(404);
    expect(JSON.stringify(r.body)).not.toMatch(/stack|select|knex/i);
  });

  it('CSV não permite injeção de fórmula', async () => {
    await request(app).post('/api/v1/admin/expenses').set(auth()).send({ category: 'OTHER', description: '=HYPERLINK("http://x")', amountCents: 100, dueDate: DAY });
    const r = await request(app).get(`/api/v1/admin/finance/export.csv?from=${DAY}&to=${DAY}&kind=expenses`).set(auth());
    expect(r.text).toContain("'=HYPERLINK");
  });
});

describe('peças: oficina que não vende peças', () => {
  it('o site avisa quais peças trazer, menos nos serviços de avaliação', async () => {
    const info = (await request(app).get('/api/v1/public/info')).body;
    expect(info.sellsParts).toBe(false);
    expect(info.partsNotice).toMatch(/não vende peças/);
    const oil = info.services.find((s) => s.name === 'Troca de óleo e filtro');
    const diag = info.services.find((s) => s.name.startsWith('Diagnóstico geral'));
    expect(oil.partsToBring).toMatch(/filtro/i);
    expect(diag.partsToBring).toBeNull();
  });

  it('o catálogo tem as peças da moto com imagem', async () => {
    const r = await request(app).get('/api/v1/admin/parts-catalog').set(auth());
    expect(r.body.parts.length).toBeGreaterThan(50);
    expect(r.body.categories).toContain('Freios');
    const pad = r.body.parts.find((p) => p.slug === 'pastilha-freio');
    expect(pad.imageUrl).toBe('/parts-img/pastilha-freio.png');
    const img = await request(app).get(pad.imageUrl);
    expect(img.status).toBe(200);
    expect(img.headers['content-type']).toBe('image/png');
  });

  it('peça que o cliente compra entra no orçamento e no PDF, mas não soma no valor do serviço', async () => {
    const c = await db('customers').whereNull('anonymizedAt').first();
    const m = await db('motorcycles').where({ customerId: c.id }).first();
    const id = (await request(app).post('/api/v1/admin/orders').set(auth()).send({ customerId: c.id, motorcycleId: m.id })).body.orderId;
    await request(app).post(`/api/v1/admin/orders/${id}/items`).set(auth()).send({ type: 'LABOR', description: 'Troca das pastilhas', unitPriceCents: 6000 });
    const pad = await db('catalog_parts').where({ slug: 'pastilha-freio' }).first();
    const add = await request(app).post(`/api/v1/admin/orders/${id}/items`).set(auth()).send({ type: 'CUSTOMER_PART', catalogPartId: pad.id, quantity: 1, notes: 'Dianteira, CG 160', estimatedPriceCents: 4500, unitPriceCents: 99999 });
    expect(add.status).toBe(201);
    const o = (await request(app).get(`/api/v1/admin/orders/${id}`).set(auth())).body.order;
    expect(o.totalCents).toBe(6000);
    expect(o.customerParts).toHaveLength(1);
    expect(o.customerParts[0].imageUrl).toBe('/parts-img/pastilha-freio.png');
    expect(o.customerPartsEstimateCents).toBe(4500);

    await request(app).post(`/api/v1/admin/orders/${id}/send-quote`).set(auth());
    const pub = (await request(app).get(`/api/v1/public/quotes/${o.approvalToken}`)).body.quote;
    expect(pub.totalCents).toBe(6000);
    expect(pub.customerParts[0].description).toBe('Pastilhas de freio');
    expect(pub.items.every((i) => i.type !== 'CUSTOMER_PART')).toBe(true);
    const pdf = await request(app).get(pub.pdfUrl);
    expect(pdf.status).toBe(200);
    expect(pdf.headers['content-type']).toBe('application/pdf');
    expect(pdf.body.length).toBeGreaterThan(3000);
  });

  it('a confirmação do WhatsApp lembra de trazer as peças', async () => {
    const b = await db('bookings').where({ status: 'CONFIRMED' }).first();
    const r = await request(app).post('/api/v1/admin/notify').set(auth()).send({ template: 'confirmation', bookingId: b.id });
    expect(r.body.text).toMatch(/Traga as peças/);
  });
});

describe('backup no painel', () => {
  const get = () => request(app).get('/api/v1/admin/system/backups').set(auth());
  const ago = (h) => new Date(Date.now() - h * 3600_000);

  it('sem backup ligado, o painel avisa que não está configurado', async () => {
    await db('backup_runs').del();
    const r = await get();
    expect(r.status).toBe(200);
    expect(r.body.configured).toBe(false);
    expect((await request(app).get('/api/v1/admin/dashboard').set(auth())).body.backup.configured).toBe(false);
  });

  it('backups em dia e com cópia no Drive: tudo verde', async () => {
    await db('backup_runs').insert([
      { kind: 'db', status: 'ok', finishedAt: ago(2), sizeBytes: 120000, offsite: true },
      { kind: 'full', status: 'ok', finishedAt: ago(10), sizeBytes: 5_000_000, offsite: true },
      { kind: 'verify', status: 'ok', finishedAt: ago(48), offsite: true },
    ]);
    const r = await get();
    expect(r.body).toMatchObject({ configured: true, healthy: true, problems: [] });
    expect(r.body.recent[0].sizeBytes).toBe(120000);
  });

  it('falha, atraso e falta de cópia externa aparecem como alerta', async () => {
    await db('backup_runs').insert({ kind: 'db', status: 'error', finishedAt: ago(0), message: 'Google Drive recusou o envio' });
    let r = await get();
    expect(r.body.healthy).toBe(false);
    expect(r.body.problems.join(' ')).toMatch(/falhou.*Google Drive recusou/);
    await db('backup_runs').del();
    await db('backup_runs').insert([
      { kind: 'db', status: 'ok', finishedAt: ago(20), offsite: false },
      { kind: 'full', status: 'ok', finishedAt: ago(10), offsite: false },
      { kind: 'verify', status: 'ok', finishedAt: ago(1), offsite: false },
    ]);
    r = await get();
    expect(r.body.problems.some((p) => /Backup do banco está atrasado/.test(p))).toBe(true);
    expect(r.body.problems.some((p) => /só no servidor/.test(p))).toBe(true);
    const dash = await request(app).get('/api/v1/admin/dashboard').set(auth());
    expect(dash.body.backup.healthy).toBe(false);
  });

  it('só o dono vê o status do backup', async () => {
    const login = await request(app).post('/api/v1/auth/login').send({ email: 'ze@teste.com', password: 'SenhaMec123' });
    expect((await request(app).get('/api/v1/admin/system/backups').set(auth(login.body.accessToken))).status).toBe(403);
  });
});

describe('acessos: administrador da oficina x mecânico', () => {
  let mec; let mec2; let bookingId; let orderId;
  const login = async (email) => (await request(app).post('/api/v1/auth/login').send({ email, password: 'SenhaMec123' })).body.accessToken;
  const day = nextTuesday(2);

  beforeAll(async () => {
    for (const [name, email] of [['Beto Mecânico', 'beto@teste.com'], ['Caio Mecânico', 'caio@teste.com']]) {
      await request(app).post('/api/v1/admin/users').set(auth()).send({ name, email, role: 'MECHANIC', password: 'SenhaMec123' });
    }
    mec = await login('beto@teste.com');
    mec2 = await login('caio@teste.com');
    const r = await request(app).post('/api/v1/public/bookings').send(bookingBody({
      startAt: iso('16:00', day),
      customer: { name: 'Carla Souza', phone: '(21) 98888-7777' },
      motorcycle: { brand: 'Yamaha', model: 'Fazer 250', year: 2020, plate: 'XYZ9A88', mileage: 30000 },
    }));
    if (!r.body.booking) throw new Error(JSON.stringify(r.body));
    bookingId = (await db('bookings').where({ code: r.body.booking.code }).first()).id;
  });

  it('o mecânico vê a agenda inteira, inclusive o que chegou pelo link sem mecânico', async () => {
    const a = await request(app).get(`/api/v1/admin/agenda?from=${day}&to=${day}`).set(auth(mec));
    expect(a.status).toBe(200);
    expect(a.body.bookings.some((b) => b.id === bookingId && b.mechanicId === null)).toBe(true);
    expect((await request(app).get(`/api/v1/admin/bookings/${bookingId}`).set(auth(mec))).status).toBe(200);
  });

  it('o mecânico não agenda, não remarca, não cancela e não mexe em serviços e preços', async () => {
    expect((await request(app).post(`/api/v1/admin/bookings/${bookingId}/cancel`).set(auth(mec))).status).toBe(403);
    expect((await request(app).patch(`/api/v1/admin/bookings/${bookingId}`).set(auth(mec)).send({ startAt: iso('17:00', day) })).status).toBe(403);
    expect((await request(app).post('/api/v1/admin/services').set(auth(mec)).send({ name: 'Serviço X', category: 'Geral', durationMinutes: 30 })).status).toBe(403);
    expect((await request(app).patch('/api/v1/admin/services/1').set(auth(mec)).send({ basePriceCents: 1 })).status).toBe(403);
    expect((await request(app).patch('/api/v1/admin/settings').set(auth(mec)).send({ mechanicCanQuote: true })).status).toBe(403);
  });

  it('"Moto chegou" pelo mecânico abre a OS no nome dele', async () => {
    const r = await request(app).post(`/api/v1/admin/bookings/${bookingId}/checkin`).set(auth(mec)).send({ checkInMileage: 30100 });
    expect(r.status).toBe(201);
    orderId = r.body.orderId;
    const o = await request(app).get(`/api/v1/admin/orders/${orderId}`).set(auth(mec));
    expect(o.body.order.mechanic.name).toBe('Beto Mecânico');
    expect(o.body.permissions).toMatchObject({ work: true, quote: false, pay: false });
  });

  it('o mecânico trabalha na OS, mas serviços, valores e o envio do orçamento são do administrador', async () => {
    const base = `/api/v1/admin/orders/${orderId}`;
    expect((await request(app).patch(base).set(auth(mec)).send({ diagnosis: 'Pastilha no fim' })).status).toBe(200);
    expect((await request(app).post(`${base}/status`).set(auth(mec)).send({ status: 'DIAGNOSIS' })).status).toBe(200);
    const pad = await db('catalog_parts').where({ slug: 'pastilha-freio' }).first();
    expect((await request(app).post(`${base}/items`).set(auth(mec)).send({ type: 'CUSTOMER_PART', catalogPartId: pad?.id ?? null, description: 'Pastilha', quantity: 1 })).status).toBe(201);

    const labor = await request(app).post(`${base}/items`).set(auth(mec)).send({ type: 'LABOR', description: 'Diagnóstico', unitPriceCents: 5000 });
    expect(labor.status).toBe(403);
    expect(labor.body.error).toMatch(/dono da oficina/);
    const item = await db('service_order_items').where({ serviceOrderId: orderId, type: 'LABOR' }).first();
    expect((await request(app).patch(`${base}/items/${item.id}`).set(auth(mec)).send({ unitPriceCents: 1 })).status).toBe(403);
    expect((await request(app).delete(`${base}/items/${item.id}`).set(auth(mec))).status).toBe(403);
    expect((await request(app).post(`${base}/send-quote`).set(auth(mec))).status).toBe(403);
    expect((await request(app).post(`${base}/payments`).set(auth(mec)).send({ amountCents: 100, method: 'PIX' })).status).toBe(403);
    expect((await request(app).post('/api/v1/admin/notify').set(auth(mec)).send({ template: 'quoteReady', orderId })).status).toBe(403);
    // the administrator prices and sends it
    expect((await request(app).patch(`${base}/items/${item.id}`).set(auth()).send({ unitPriceCents: 8000 })).status).toBe(200);
    expect((await request(app).post(`${base}/send-quote`).set(auth())).status).toBe(200);
  });

  it('outro mecânico só olha a OS do colega', async () => {
    const o = await request(app).get(`/api/v1/admin/orders/${orderId}`).set(auth(mec2));
    expect(o.status).toBe(200);
    expect(o.body.permissions.work).toBe(false);
    const r = await request(app).patch(`/api/v1/admin/orders/${orderId}`).set(auth(mec2)).send({ diagnosis: 'x' });
    expect(r.status).toBe(403);
    expect(r.body.error).toMatch(/Beto Mecânico/);
    const mine = await request(app).get('/api/v1/admin/orders?mine=1').set(auth(mec2));
    expect(mine.body.orders.some((x) => x.id === orderId)).toBe(false);
    const all = await request(app).get('/api/v1/admin/orders').set(auth(mec2));
    expect(all.body.orders.some((x) => x.id === orderId)).toBe(true);
  });

  it('OS de balcão sem mecânico fica com quem começar a trabalhar nela', async () => {
    const c = await db('customers').where({ phone: '5521988887777' }).first();
    const m = await db('motorcycles').where({ customerId: c.id }).first();
    const r = await request(app).post('/api/v1/admin/orders').set(auth()).send({ customerId: c.id, motorcycleId: m.id });
    const id = r.body.orderId;
    expect((await request(app).post(`/api/v1/admin/orders/${id}/status`).set(auth(mec2)).send({ status: 'DIAGNOSIS' })).status).toBe(200);
    expect((await db('service_orders').where({ id }).first()).mechanicId).toBe((await db('users').where({ email: 'caio@teste.com' }).first()).id);
  });

  it('o administrador pode liberar o mecânico para lançar valores', async () => {
    await request(app).patch('/api/v1/admin/settings').set(auth()).send({ mechanicCanQuote: true });
    const base = `/api/v1/admin/orders/${orderId}`;
    expect((await request(app).get(base).set(auth(mec))).body.permissions.quote).toBe(true);
    expect((await request(app).post(`${base}/items`).set(auth(mec)).send({ type: 'LABOR', description: 'Diagnóstico', unitPriceCents: 5000 })).status).toBe(201);
    await request(app).patch('/api/v1/admin/settings').set(auth()).send({ mechanicCanQuote: false });
  });

  it('"Hoje" mostra o movimento do dia para o mecânico, sem valores', async () => {
    const r = await request(app).get('/api/v1/admin/today').set(auth(mec));
    expect(r.status).toBe(200);
    expect(r.body.orders.some((o) => o.id === orderId)).toBe(true);
    expect(JSON.stringify(r.body)).not.toMatch(/Cents/);
    expect((await request(app).get('/api/v1/admin/dashboard').set(auth(mec))).status).toBe(403);
  });
});

describe('mecânico: agenda de todos os dias e valor do diagnóstico', () => {
  let mec; let orderId;
  beforeAll(async () => {
    await request(app).post('/api/v1/admin/users').set(auth()).send({ name: 'Davi Mecânico', email: 'davi@teste.com', role: 'MECHANIC', password: 'SenhaMec123' });
    mec = (await request(app).post('/api/v1/auth/login').send({ email: 'davi@teste.com', password: 'SenhaMec123' })).body.accessToken;
  });

  it('vê agendamentos de dias passados e futuros', async () => {
    const past = await db('bookings').orderBy('startAt').first();
    const pastDay = DateTime.fromJSDate(past.startAt).setZone('America/Sao_Paulo').toISODate();
    const yesterdayBooking = { ...past };
    // move one booking to 10 days ago to be sure it is in the past
    const tenDaysAgo = DateTime.now().setZone('America/Sao_Paulo').minus({ days: 10 }).set({ hour: 9, minute: 0 });
    await db('bookings').where({ id: past.id }).update({ startAt: tenDaysAgo.toJSDate(), endAt: tenDaysAgo.plus({ minutes: 30 }).toJSDate() });
    const a = await request(app).get(`/api/v1/admin/agenda?from=${tenDaysAgo.toISODate()}&to=${tenDaysAgo.toISODate()}`).set(auth(mec));
    expect(a.status).toBe(200);
    expect(a.body.bookings.some((b) => b.id === past.id)).toBe(true);
    expect((await request(app).get(`/api/v1/admin/bookings/${past.id}`).set(auth(mec))).status).toBe(200);
    const future = DateTime.now().setZone('America/Sao_Paulo').plus({ days: 60 }).toISODate();
    expect((await request(app).get(`/api/v1/admin/agenda?from=${future}&to=${DateTime.fromISO(future).plus({ days: 6 }).toISODate()}`).set(auth(mec))).status).toBe(200);
    await db('bookings').where({ id: past.id }).update({ startAt: yesterdayBooking.startAt, endAt: yesterdayBooking.endAt });
    expect(pastDay).toBeTruthy();
  });

  it('o mecânico lança o valor do diagnóstico e ele entra no orçamento', async () => {
    const c = await db('customers').first();
    const m = await db('motorcycles').where({ customerId: c.id }).first();
    orderId = (await request(app).post('/api/v1/admin/orders').set(auth()).send({ customerId: c.id, motorcycleId: m.id })).body.orderId;
    const base = `/api/v1/admin/orders/${orderId}`;
    let r = await request(app).put(`${base}/diagnosis-fee`).set(auth(mec)).send({ amountCents: 8000 });
    expect(r.status).toBe(200);
    expect(r.body.order.diagnosisFeeCents).toBe(8000);
    expect(r.body.order.totalCents).toBe(8000);
    expect(r.body.order.items.find((i) => i.isDiagnosisFee)).toMatchObject({ description: 'Diagnóstico', type: 'LABOR' });
    expect(r.body.order.mechanic.name).toBe('Davi Mecânico'); // OS sem mecânico ficou com ele
    // ajustar na hora
    r = await request(app).put(`${base}/diagnosis-fee`).set(auth(mec)).send({ amountCents: 6500 });
    expect(r.body.order.totalCents).toBe(6500);
    expect(r.body.order.items.filter((i) => i.isDiagnosisFee)).toHaveLength(1);
    // continua sem poder lançar outros serviços
    expect((await request(app).post(`${base}/items`).set(auth(mec)).send({ type: 'LABOR', description: 'Outro', unitPriceCents: 100 })).status).toBe(403);
    // aparece no orçamento do cliente e no PDF
    await request(app).post(`${base}/send-quote`).set(auth());
    const o = await db('service_orders').where({ id: orderId }).first();
    const pub = await request(app).get(`/api/v1/public/quotes/${o.approvalToken}`);
    expect(JSON.stringify(pub.body)).toMatch(/Diagnóstico/);
    expect(JSON.stringify(pub.body)).toMatch(/6500/);
  });

  it('depois que o cliente aprova, só o administrador ajusta', async () => {
    const o = await db('service_orders').where({ id: orderId }).first();
    await request(app).post(`/api/v1/public/quotes/${o.approvalToken}/approve`).send({});
    const r = await request(app).put(`/api/v1/admin/orders/${orderId}/diagnosis-fee`).set(auth(mec)).send({ amountCents: 1 });
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/dono da oficina/);
  });

  it('serviço de diagnóstico agendado vira o valor do diagnóstico no check-in', async () => {
    const diag = await db('services').where({ category: 'Diagnóstico' }).first();
    const day = nextTuesday(3);
    const r = await request(app).post('/api/v1/public/bookings').send(bookingBody({
      serviceIds: [diag.id], startAt: iso('10:00', day),
      customer: { name: 'Elisa Prado', phone: '(21) 97777-1212' },
      motorcycle: { brand: 'Honda', model: 'Pop 110i', year: 2022, plate: 'POP1A10', mileage: 5000 },
    }));
    if (!r.body.booking) throw new Error(JSON.stringify(r.body));
    const b = await db('bookings').where({ code: r.body.booking.code }).first();
    const ci = await request(app).post(`/api/v1/admin/bookings/${b.id}/checkin`).set(auth(mec)).send({});
    const o = await request(app).get(`/api/v1/admin/orders/${ci.body.orderId}`).set(auth(mec));
    expect(o.body.order.items.filter((i) => i.isDiagnosisFee)).toHaveLength(1);
    expect(o.body.order.diagnosisFeeCents).toBe(0);
    const put = await request(app).put(`/api/v1/admin/orders/${ci.body.orderId}/diagnosis-fee`).set(auth(mec)).send({ amountCents: 7000 });
    expect(put.body.order.items.filter((i) => i.type === 'LABOR')).toHaveLength(1);
    expect(put.body.order.totalCents).toBe(7000);
  });
});

describe('4 acessos: administrador do sistema, dono da oficina, mecânico e cliente', () => {
  let dono;
  beforeAll(async () => {
    const r = await request(app).post('/api/v1/admin/users').set(auth()).send({ name: 'Natan Dono', email: 'natan.dono@teste.com', role: 'MANAGER', password: 'SenhaDono123' });
    expect(r.status).toBe(201);
    dono = (await request(app).post('/api/v1/auth/login').send({ email: 'natan.dono@teste.com', password: 'SenhaDono123' })).body.accessToken;
  });

  it('o dono da oficina opera o dia a dia e vê o dinheiro', async () => {
    const range = '?from=2026-11-01&to=2026-11-30';
    for (const path of ['/api/v1/admin/dashboard', `/api/v1/admin/finance/summary${range}`, '/api/v1/admin/finance/receivables', `/api/v1/admin/finance/commissions${range}`, `/api/v1/admin/expenses${range}`]) {
      expect((await request(app).get(path).set(auth(dono))).status, path).toBe(200);
    }
    const exp = await request(app).post('/api/v1/admin/expenses').set(auth(dono)).send({ description: 'Conta de luz', amountCents: 25000, category: 'UTILITIES', dueDate: '2026-11-10' });
    expect(exp.status).toBe(201);
    // OS completa: lança serviço com valor, envia orçamento e recebe
    const c = await db('customers').first();
    const m = await db('motorcycles').where({ customerId: c.id }).first();
    const id = (await request(app).post('/api/v1/admin/orders').set(auth(dono)).send({ customerId: c.id, motorcycleId: m.id })).body.orderId;
    expect((await request(app).post(`/api/v1/admin/orders/${id}/items`).set(auth(dono)).send({ type: 'LABOR', description: 'Troca de óleo', unitPriceCents: 6000 })).status).toBe(201);
    expect((await request(app).post(`/api/v1/admin/orders/${id}/send-quote`).set(auth(dono))).status).toBe(200);
    expect((await request(app).post(`/api/v1/admin/orders/${id}/payments`).set(auth(dono)).send({ amountCents: 6000, method: 'PIX' })).status).toBe(201);
    expect((await request(app).get(`/api/v1/admin/orders/${id}`).set(auth(dono))).body.permissions).toMatchObject({ work: true, quote: true, pay: true });
    // agenda: agenda e bloqueia
    expect((await request(app).post('/api/v1/admin/blocks').set(auth(dono)).send({ startAt: iso('08:00', nextTuesday(5)), endAt: iso('09:00', nextTuesday(5)), reason: 'Folga' })).status).toBe(201);
    // pedidos LGPD
    expect((await request(app).get(`/api/v1/admin/customers/${c.id}/export`).set(auth(dono))).status).toBe(200);
    // aparece como mecânico disponível na agenda
    const ag = await request(app).get(`/api/v1/admin/agenda?from=${nextTuesday(1)}&to=${nextTuesday(1)}`).set(auth(dono));
    expect(ag.body.mechanics.some((x) => x.name === 'Natan Dono')).toBe(true);
  });

  it('o dono da oficina não altera nenhuma configuração do sistema', async () => {
    const svc = await db('services').first();
    const bay = await db('bays').first();
    const part = await db('catalog_parts').first();
    const denied = [
      ['post', '/api/v1/admin/services', { name: 'Serviço X', category: 'Geral', durationMinutes: 30 }],
      ['patch', `/api/v1/admin/services/${svc.id}`, { basePriceCents: 1 }],
      ['patch', '/api/v1/admin/settings', { shopName: 'Outra' }],
      ['patch', '/api/v1/admin/settings', { mechanicCanQuote: true }],
      ['put', '/api/v1/admin/settings/hours', { hours: [] }],
      ['post', '/api/v1/admin/bays', { name: 'Elevador 3' }],
      ['patch', `/api/v1/admin/bays/${bay.id}`, { name: 'X' }],
      ['post', '/api/v1/admin/users', { name: 'Novo', email: 'novo@teste.com', role: 'MECHANIC', password: 'SenhaNova123' }],
      ['patch', '/api/v1/admin/users/1', { active: false }],
      ['post', '/api/v1/admin/parts-catalog', { name: 'Peça X', category: 'Motor' }],
      ['patch', `/api/v1/admin/parts-catalog/${part.id}`, { name: 'X' }],
      ['delete', `/api/v1/admin/parts-catalog/${part.id}/photo`, null],
      ['get', '/api/v1/admin/system/backups', null],
    ];
    for (const [verb, path, body] of denied) {
      const req = request(app)[verb](path).set(auth(dono));
      const r = body ? await req.send(body) : await req;
      expect(r.status, `${verb} ${path}`).toBe(403);
    }
    // continua lendo o que precisa para trabalhar
    expect((await request(app).get('/api/v1/admin/settings').set(auth(dono))).status).toBe(200);
    expect((await request(app).get('/api/v1/admin/users').set(auth(dono))).status).toBe(200);
    expect((await request(app).get('/api/v1/admin/parts-catalog').set(auth(dono))).status).toBe(200);
  });

  it('o administrador do sistema cadastra o dono e continua com as configurações', async () => {
    const r = await request(app).get('/api/v1/admin/users').set(auth());
    expect(r.body.users.find((u) => u.email === 'natan.dono@teste.com').role).toBe('MANAGER');
    expect((await request(app).patch('/api/v1/admin/settings').set(auth()).send({ mechanicCanQuote: false })).status).toBe(200);
  });
});

describe('prontuário da moto', () => {
  let mec; let bikeId; let customerId; let first; let second;
  const day = nextTuesday(3);

  beforeAll(async () => {
    await request(app).post('/api/v1/admin/users').set(auth()).send({ name: 'Davi Mecânico', email: 'davi@teste.com', role: 'MECHANIC', password: 'SenhaMec123' });
    mec = (await request(app).post('/api/v1/auth/login').send({ email: 'davi@teste.com', password: 'SenhaMec123' })).body.accessToken;
    const r = await request(app).post('/api/v1/public/bookings').send(bookingBody({
      startAt: iso('11:00', day), problemDescription: 'Barulho no freio dianteiro',
      customer: { name: 'Pedro Prontuário', phone: '(21) 97777-1234' },
      motorcycle: { brand: 'Honda', model: 'Titan 160', year: 2019, plate: 'PRT1A23', mileage: 40000 },
    }));
    const b = await db('bookings').where({ code: r.body.booking.code }).first();
    bikeId = b.motorcycleId; customerId = b.customerId;
    first = (await request(app).post(`/api/v1/admin/bookings/${b.id}/checkin`).set(auth()).send({ checkInMileage: 40100 })).body.orderId;
  });

  it('o mecânico registra o que foi feito e o que encontrou além do pedido', async () => {
    // a OS ainda não tem mecânico: ao escrever o relatório, ela fica com quem escreveu
    const p = await request(app).patch(`/api/v1/admin/orders/${first}`).set(auth(mec))
      .send({ diagnosis: 'Pastilha dianteira gasta.', workDone: 'Troca das pastilhas dianteiras e regulagem do freio traseiro.', internalNotes: 'Cliente pede para ligar antes de qualquer serviço extra.' });
    expect(p.status).toBe(200);
    expect(p.body.order.workDone).toMatch(/pastilhas/);
    expect(p.body.order.mechanicId).not.toBeNull();

    const a = await request(app).post(`/api/v1/admin/orders/${first}/findings`).set(auth(mec))
      .send({ description: 'Pneu traseiro no limite do TWI', severity: 'URGENT', decision: 'DECLINED', informed: true, informedVia: 'WHATSAPP' });
    expect(a.status).toBe(201);
    const f = a.body.order.findings[0];
    expect(f).toMatchObject({ severity: 'URGENT', decision: 'DECLINED', informedVia: 'WHATSAPP', informedByName: 'Davi Mecânico' });
    expect(f.informedAt).toBeTruthy();

    await request(app).post(`/api/v1/admin/orders/${first}/findings`).set(auth(mec)).send({ description: 'Relação com folga, vai precisar trocar', severity: 'SOON', decision: 'LATER', checkMileage: 42000 });
    const fixed = await request(app).post(`/api/v1/admin/orders/${first}/findings`).set(auth(mec)).send({ description: 'Lâmpada do farol queimada', severity: 'WATCH', decision: 'FIXED' });
    expect(fixed.body.order.findings).toHaveLength(3);
    expect(fixed.body.order.findings.find((x) => x.decision === 'FIXED').resolvedOrderId).toBe(first);

    expect((await request(app).post(`/api/v1/admin/orders/${first}/findings`).set(auth(mec)).send({ description: 'x' })).status).toBe(400);
    const pdf = await request(app).get(`/api/v1/admin/orders/${first}/pdf`).set(auth());
    expect(pdf.headers['content-type']).toBe('application/pdf');
  });

  it('depois de entregue, só o dono corrige o relatório', async () => {
    await request(app).post(`/api/v1/admin/orders/${first}/status`).set(auth()).send({ status: 'IN_PROGRESS' });
    await request(app).post(`/api/v1/admin/orders/${first}/status`).set(auth()).send({ status: 'READY' });
    expect((await request(app).post(`/api/v1/admin/orders/${first}/status`).set(auth()).send({ status: 'DELIVERED', receivable: true })).status).toBe(200);
    expect((await request(app).patch(`/api/v1/admin/orders/${first}`).set(auth(mec)).send({ workDone: 'mudou' })).status).toBe(403);
    expect((await request(app).post(`/api/v1/admin/orders/${first}/findings`).set(auth(mec)).send({ description: 'Outra coisa' })).status).toBe(403);
    expect((await request(app).patch(`/api/v1/admin/orders/${first}`).set(auth()).send({ internalNotes: 'Corrigido pelo dono.' })).status).toBe(200);
  });

  it('quando a moto volta, as pendências aparecem na agenda e na OS nova', async () => {
    const r = await request(app).post('/api/v1/admin/bookings').set(auth()).send({
      serviceIds: [1], startAt: iso('14:00', day),
      customer: { name: 'Pedro Prontuário', phone: '21977771234' },
      motorcycle: { brand: 'Honda', model: 'Titan 160', plate: 'prt-1a23' },
    });
    expect(r.status, JSON.stringify(r.body)).toBe(201);
    const bookingId = r.body.booking.id;
    expect(r.body.booking.customerId).toBe(customerId);
    expect(r.body.booking.motorcycleId).toBe(bikeId);
    const bk = await request(app).get(`/api/v1/admin/bookings/${bookingId}`).set(auth(mec));
    expect(bk.body.booking.bikeHistory.visits).toBe(1);
    expect(bk.body.booking.bikeHistory.lastVisit.workDone).toMatch(/pastilhas/);
    expect(bk.body.booking.bikeHistory.pendingFindings.map((x) => x.severity)).toEqual(['URGENT', 'SOON']);

    second = (await request(app).post(`/api/v1/admin/bookings/${bookingId}/checkin`).set(auth()).send({ checkInMileage: 41800 })).body.orderId;
    const o = (await request(app).get(`/api/v1/admin/orders/${second}`).set(auth())).body.order;
    expect(o.bikeHistory.pendingFindings).toHaveLength(2);
    expect(o.findings).toHaveLength(0);

    const tire = o.bikeHistory.pendingFindings.find((x) => x.severity === 'URGENT');
    const res = await request(app).post(`/api/v1/admin/orders/${second}/findings/${tire.id}/resolve`).set(auth()).send({ resolved: true });
    expect(res.status).toBe(200);
    expect(res.body.order.bikeHistory.pendingFindings).toHaveLength(1);
    // não dá para resolver pela OS de outra moto
    const other = await db('service_orders').whereNot({ motorcycleId: bikeId }).first();
    expect((await request(app).post(`/api/v1/admin/orders/${other.id}/findings/${tire.id}/resolve`).set(auth()).send({})).status).toBe(404);
  });

  it('o prontuário mostra todas as visitas; o mecânico não vê valores', async () => {
    const h = await request(app).get(`/api/v1/admin/motorcycles/${bikeId}/history`).set(auth());
    expect(h.status).toBe(200);
    expect(h.body.visits.map((v) => v.id)).toEqual([second, first]);
    expect(h.body.stats.visits).toBe(2);
    expect(h.body.pendingFindings).toHaveLength(1);
    const v1 = h.body.visits.find((v) => v.id === first);
    expect(v1.problemDescription).toBe('Barulho no freio dianteiro');
    expect(v1.findings).toHaveLength(3);
    expect(h.body.visits.find((v) => v.id === second).resolvedHere).toHaveLength(1);
    expect(typeof v1.totalCents).toBe('number');

    const hm = await request(app).get(`/api/v1/admin/motorcycles/${bikeId}/history`).set(auth(mec));
    expect(hm.status).toBe(200);
    expect(hm.body.visits[0]).not.toHaveProperty('totalCents');
    expect(hm.body.stats).not.toHaveProperty('totalCents');

    const today = await request(app).get('/api/v1/admin/today').set(auth());
    expect(today.status).toBe(200);
    const exp = await request(app).get(`/api/v1/admin/customers/${customerId}/export`).set(auth());
    expect(exp.body.serviceOrders.find((s) => s.number === v1.number).findings).toHaveLength(3);
  });
});

describe('cadastro único: cliente pelo WhatsApp, moto pela placa', () => {
  const day = nextTuesday(1);
  const body = (over) => bookingBody({
    customer: { name: 'Marcos Único', phone: '(21) 96666-5555' },
    motorcycle: { brand: 'Yamaha', model: 'Factor 150', year: 2022, plate: 'UNI2B34', mileage: 12000 },
    ...over,
  });

  it('o cliente que volta é reconhecido pelo WhatsApp + placa, sem cadastro repetido', async () => {
    const first = await request(app).post('/api/v1/public/bookings').send(body({ startAt: iso('09:00', day) }));
    expect(first.status, JSON.stringify(first.body)).toBe(201);
    const lk = await request(app).post('/api/v1/public/customers/lookup').send({ phone: '21966665555', plate: 'uni-2b34' });
    expect(lk.body).toMatchObject({ found: true, customer: { name: 'Marcos Único' }, motorcycle: { model: 'Factor 150', plate: 'UNI2B34', lastMileage: 12000 } });
    expect(lk.body.customer).not.toHaveProperty('phone');
    // só o telefone ou só a placa não revela nada
    expect((await request(app).post('/api/v1/public/customers/lookup').send({ phone: '21966665555', plate: 'AAA1A11' })).body).toEqual({ found: false });
    expect((await request(app).post('/api/v1/public/customers/lookup').send({ phone: '21900000000', plate: 'UNI2B34' })).body).toEqual({ found: false });
    expect((await request(app).post('/api/v1/public/customers/lookup').send({ phone: 'x', plate: 'y' })).body).toEqual({ found: false });

    // volta com outro jeito de escrever o número e o nome: mesmo cliente, mesma moto, nome mantido
    const again = await request(app).post('/api/v1/public/bookings').send(body({ startAt: iso('10:00', day), customer: { name: 'marcos', phone: '+55 21 96666-5555' } }));
    expect(again.status).toBe(201);
    expect(await db('customers').where({ phone: '5521966665555' }).count({ n: '*' }).first()).toMatchObject({ n: 1 });
    expect(await db('motorcycles').where({ plate: 'UNI2B34' }).count({ n: '*' }).first()).toMatchObject({ n: 1 });
    expect((await db('customers').where({ phone: '5521966665555' }).first()).name).toBe('Marcos Único');
  });

  it('placa de outro cliente não troca o dono sozinha: avisa a oficina', async () => {
    const r = await request(app).post('/api/v1/public/bookings').send(body({
      startAt: iso('13:00', day), customer: { name: 'Fulano Outro', phone: '(21) 95555-4444' },
    }));
    expect(r.status).toBe(201);
    const bike = await db('motorcycles').where({ plate: 'UNI2B34' }).first();
    const marcos = await db('customers').where({ phone: '5521966665555' }).first();
    expect(bike.customerId).toBe(marcos.id);
    const bk = await db('bookings').where({ code: r.body.booking.code }).first();
    expect(bk.motorcycleId).toBe(bike.id);
    expect(bk.notes).toMatch(/já está cadastrada para Marcos Único/);
  });

  it('na oficina: avisa WhatsApp e placa repetidos, transfere moto vendida e junta cadastros', async () => {
    const marcos = await db('customers').where({ phone: '5521966665555' }).first();
    const fulano = await db('customers').where({ phone: '5521955554444' }).first();
    const dupPhone = await request(app).post('/api/v1/admin/customers').set(auth()).send({ name: 'Marcos', phone: '21966665555' });
    expect(dupPhone.status).toBe(409);
    expect(dupPhone.body).toMatchObject({ code: 'CUSTOMER_EXISTS', customer: { id: marcos.id } });
    const chk = await request(app).get('/api/v1/admin/customers/check?phone=21966665555&plate=UNI2B34').set(auth());
    expect(chk.body.customer.id).toBe(marcos.id);
    expect(chk.body.motorcycle.ownerName).toBe('Marcos Único');
    const dupPlate = await request(app).post(`/api/v1/admin/customers/${fulano.id}/motorcycles`).set(auth()).send({ brand: 'Yamaha', model: 'Factor', plate: 'UNI-2B34' });
    expect(dupPlate.status).toBe(409);
    expect(dupPlate.body.code).toBe('PLATE_EXISTS');
    expect((await request(app).patch(`/api/v1/admin/customers/${fulano.id}`).set(auth()).send({ phone: '21966665555' })).status).toBe(409);

    // moto vendida para o Fulano: o histórico vai junto
    const bike = await db('motorcycles').where({ plate: 'UNI2B34' }).first();
    expect((await request(app).post(`/api/v1/admin/motorcycles/${bike.id}/transfer`).set(auth()).send({ customerId: fulano.id })).status).toBe(200);
    expect((await db('motorcycles').where({ id: bike.id }).first()).customerId).toBe(fulano.id);

    // placa digitada errada virou outra moto: junta as duas
    const wrong = (await request(app).post(`/api/v1/admin/customers/${fulano.id}/motorcycles`).set(auth()).send({ brand: 'Yamaha', model: 'Factor', plate: 'UNI2B43', lastMileage: 15000 })).body.motorcycle;
    const ord = (await request(app).post('/api/v1/admin/orders').set(auth()).send({ customerId: fulano.id, motorcycleId: wrong.id })).body.orderId;
    expect((await request(app).post(`/api/v1/admin/motorcycles/${bike.id}/merge`).set(auth()).send({ duplicateId: wrong.id })).status).toBe(200);
    expect((await db('service_orders').where({ id: ord }).first()).motorcycleId).toBe(bike.id);
    expect((await db('motorcycles').where({ id: bike.id }).first()).lastMileage).toBe(15000);
    expect(await db('motorcycles').where({ id: wrong.id }).first()).toBeUndefined();

    // Marcos trocou de número e fez outro cadastro: junta no antigo
    const novo = (await request(app).post('/api/v1/admin/customers').set(auth()).send({ name: 'Marcos Único', phone: '21944443333' })).body.customer;
    const dups = await request(app).get('/api/v1/admin/customers/duplicates').set(auth());
    expect(dups.body.pairs.some((p) => [p.aId, p.bId].includes(novo.id) && [p.aId, p.bId].includes(marcos.id))).toBe(true);
    const bk = await db('bookings').where({ customerId: marcos.id }).first();
    await db('bookings').where({ id: bk.id }).update({ customerId: novo.id });
    const m = await request(app).post(`/api/v1/admin/customers/${marcos.id}/merge`).set(auth()).send({ duplicateId: novo.id });
    expect(m.status).toBe(200);
    expect((await db('bookings').where({ id: bk.id }).first()).customerId).toBe(marcos.id);
    expect(await db('customers').where({ id: novo.id }).first()).toBeUndefined();
    expect((await db('customers').where({ id: marcos.id }).first()).notes).toMatch(/\(21\) 94444-3333/);

    // o mecânico não junta cadastros
    await request(app).post('/api/v1/admin/users').set(auth()).send({ name: 'Eli Mecânico', email: 'eli@teste.com', role: 'MECHANIC', password: 'SenhaMec123' });
    const mec = (await request(app).post('/api/v1/auth/login').send({ email: 'eli@teste.com', password: 'SenhaMec123' })).body.accessToken;
    expect((await request(app).post(`/api/v1/admin/customers/${marcos.id}/merge`).set(auth(mec)).send({ duplicateId: fulano.id })).status).toBe(403);
  });
});

describe('calendário do mês da agenda', () => {
  it('conta os agendamentos de cada dia, sem cancelados', async () => {
    const day = nextTuesday(0);
    const month = day.slice(0, 7);
    const r = await request(app).get(`/api/v1/admin/agenda/month?month=${month}`).set(auth());
    expect(r.status).toBe(200);
    const expected = await db('bookings').whereNotIn('status', ['CANCELLED', 'NO_SHOW'])
      .whereRaw(`to_char("startAt" AT TIME ZONE 'America/Sao_Paulo', 'YYYY-MM-DD') = ?`, [day]).count({ n: '*' }).first();
    expect(r.body.days[day] || 0).toBe(Number(expected.n));
    expect(Number(expected.n)).toBeGreaterThan(0);
    expect(Array.isArray(r.body.closedWeekdays)).toBe(true);
    expect((await request(app).get('/api/v1/admin/agenda/month?month=2026-13').set(auth())).status).toBe(400);
  });
});
