import { Router } from 'express';
import { config } from '../config.js';
import { db } from '../lib/db.js';
import { verifySignature } from '../services/whatsapp/cloudApi.js';
import { sendRawText } from '../services/whatsapp/index.js';
import { getSettings } from '../services/availability.js';
import { messageTexts, render, baseVars, bookingUrl } from '../services/messages.js';

const router = Router();

// Meta calls this once to verify the webhook URL
router.get('/whatsapp', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  if (mode === 'subscribe' && config.whatsapp.verifyToken && token === config.whatsapp.verifyToken) {
    return res.status(200).send(String(req.query['hub.challenge'] || ''));
  }
  return res.sendStatus(403);
});

/**
 * Incoming WhatsApp messages (Level 2). Replies with the booking link
 * if this number did not receive it in the last 24 hours.
 */
router.post('/whatsapp', async (req, res) => {
  if (!verifySignature(req.rawBody, req.headers['x-hub-signature-256'], config.whatsapp.appSecret)) {
    return res.sendStatus(401);
  }
  res.sendStatus(200); // answer Meta quickly; process after
  try {
    const settings = await getSettings(db);
    if (!settings.whatsappLevel2Enabled) return;
    const messages = (req.body?.entry || []).flatMap((e) => e.changes || []).flatMap((c) => c.value?.messages || []);
    const senders = [...new Set(messages.map((m) => String(m.from || '')).filter((f) => /^\d{10,15}$/.test(f)))];
    for (const from of senders) {
      const recent = await db('notification_logs')
        .where({ to: from, template: 'greeting', status: 'sent' })
        .where('createdAt', '>', new Date(Date.now() - 24 * 60 * 60 * 1000))
        .first();
      if (recent) continue;
      const text = render(messageTexts(settings).greeting, { ...baseVars(settings), link: bookingUrl(settings, 'whatsapp') });
      await sendRawText(from, text, 'greeting');
    }
  } catch (err) {
    console.error('[webhook] erro ao processar mensagem:', err.message);
  }
  return undefined;
});

export default router;
