import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import { z } from 'zod';
import { DateTime } from 'luxon';
import { db } from '../lib/db.js';
import { config } from '../config.js';
import { badRequest, notFound } from '../lib/errors.js';
import { TZ, normalizePhone, normalizePlate } from '../lib/util.js';
import { getSettings, getAvailableDays, getDaySlots, totalDuration } from '../services/availability.js';
import {
  createBooking, getBookingFull, publicBookingView, rescheduleBooking, cancelBooking,
} from '../services/bookings.js';
import { getOrderFull, decideQuote } from '../services/orders.js';
import { storage } from '../services/storage.js';
import { DEFAULT_PARTS_NOTICE } from '../services/messages.js';
import { orderPdf } from '../services/pdf.js';

const router = Router();

const writeLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: config.isTest ? 1000 : 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Muitas tentativas seguidas. Espere alguns minutos e tente de novo.', code: 'RATE_LIMIT' },
});

// Reconhecer cliente: poucas tentativas, para ninguém sair testando números
const lookupLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: config.isTest ? 1000 : 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Muitas tentativas seguidas. Espere alguns minutos ou preencha os dados normalmente.', code: 'RATE_LIMIT' },
});

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 3 } });

const SOURCES = ['instagram', 'whatsapp', 'direct'];

router.get('/info', async (_req, res) => {
  const [settings, hours, services, bays] = await Promise.all([
    getSettings(db),
    db('business_hours').orderBy('weekday'),
    db('services').where({ active: true, onlineVisible: true }).orderBy(['order', 'name']),
    db('bays').where({ active: true }).count({ c: '*' }).first(),
  ]);
  res.set('Cache-Control', 'public, max-age=60');
  res.json({
    shopName: settings.shopName,
    address: settings.address,
    city: settings.city,
    mapQuery: settings.mapQuery,
    whatsappNumber: settings.whatsappNumber,
    instagram: settings.instagram,
    privacyContact: settings.privacyContact,
    slotMinutes: settings.slotMinutes,
    maxDaysAhead: settings.maxDaysAhead,
    cancelNoticeHours: settings.cancelNoticeHours,
    forceDropOffMinutes: settings.forceDropOffMinutes,
    bays: bays.c,
    sellsParts: settings.sellsParts,
    partsNotice: settings.sellsParts ? null : settings.partsNotice || DEFAULT_PARTS_NOTICE,
    hours: hours.map((h) => ({ weekday: h.weekday, closed: h.closed, opensAt: h.opensAt, closesAt: h.closesAt, breakStart: h.breakStart, breakEnd: h.breakEnd })),
    services: services.map((s) => ({
      id: s.id, name: s.name, description: s.description, category: s.category, durationMinutes: s.durationMinutes,
      basePriceCents: s.basePriceCents, priceOnEvaluation: s.priceOnEvaluation, dropOffRequired: s.dropOffRequired,
      partsToBring: settings.sellsParts ? null : s.partsToBring || null,
    })),
  });
});

const idsParam = z.string().regex(/^\d+(,\d+)*$/, 'Escolha pelo menos um serviço.').transform((s) => [...new Set(s.split(',').map(Number))]);

async function durationFor(serviceIds) {
  const settings = await getSettings(db);
  const services = await db('services').whereIn('id', serviceIds).where({ active: true, onlineVisible: true });
  if (!services.length || services.length !== serviceIds.length) throw badRequest('Algum serviço escolhido não está disponível.');
  return totalDuration(services, settings.slotMinutes);
}

async function bookingByToken(token) {
  if (!/^[\w-]{20,64}$/.test(token)) throw notFound('Agendamento não encontrado.');
  return getBookingFull({ manageToken: token });
}

// For rescheduling, the duration comes from the existing booking and it does not block itself.
async function availabilityParams(query) {
  const q = z.object({ services: idsParam.optional(), token: z.string().optional() }).parse(query);
  if (q.token) {
    const b = await bookingByToken(q.token);
    return { durationMinutes: Math.round((new Date(b.endAt) - new Date(b.startAt)) / 60000), excludeBookingId: b.id };
  }
  if (!q.services) throw badRequest('Escolha pelo menos um serviço.');
  return { durationMinutes: await durationFor(q.services) };
}

router.get('/available-days', async (req, res) => {
  res.json({ days: await getAvailableDays(db, await availabilityParams(req.query)) });
});

router.get('/slots', async (req, res) => {
  const { date } = z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida.') }).parse(req.query);
  const slots = await getDaySlots(db, { date, ...(await availabilityParams(req.query)) });
  res.json({ date, slots: slots.map((s) => ({ startAt: s.startAt, time: s.time })) });
});

const bookingSchema = z.object({
  serviceIds: z.array(z.number().int().positive()).min(1, 'Escolha pelo menos um serviço.').max(8),
  startAt: z.string().min(10),
  source: z.string().optional(),
  dropOff: z.boolean().optional(),
  problemDescription: z.string().max(1000).optional(),
  privacyAck: z.literal(true, { error: 'Confirme que leu o aviso de privacidade.' }),
  reminderConsent: z.boolean().optional(),
  website: z.string().max(0, 'Envio bloqueado.').optional(), // honeypot: real people never fill it
  customer: z.object({
    name: z.string().trim().min(2, 'Informe seu nome.').max(80),
    phone: z.string().min(10, 'Informe seu WhatsApp com DDD.').max(20),
    email: z.union([z.literal(''), z.email('E-mail inválido.')]).optional(),
  }),
  motorcycle: z.object({
    brand: z.string().trim().min(2, 'Informe a marca da moto.').max(40),
    model: z.string().trim().min(1, 'Informe o modelo da moto.').max(60),
    year: z.number().int().min(1950).max(new Date().getFullYear() + 1).optional().nullable(),
    plate: z.string().min(7, 'Informe a placa.').max(8),
    mileage: z.number().int().min(0).max(999999).optional().nullable(),
  }),
});

/**
 * "Já sou cliente": WhatsApp + placa. Só reconhece quando os DOIS batem com o mesmo cadastro,
 * para que ninguém descubra o nome de outra pessoa só pelo número. Devolve o mínimo para
 * preencher o agendamento.
 */
router.post('/customers/lookup', lookupLimiter, async (req, res) => {
  const body = z.object({ phone: z.string().max(25), plate: z.string().max(10) }).parse(req.body);
  let phone; let plate;
  try { phone = normalizePhone(body.phone); plate = normalizePlate(body.plate); } catch { return res.json({ found: false }); }
  const row = await db('customers as c').join('motorcycles as m', 'm.customerId', 'c.id')
    .select('c.name', 'm.brand', 'm.model', 'm.year', 'm.plate', 'm.lastMileage')
    .where({ 'c.phone': phone, 'm.plate': plate }).whereNull('c.anonymizedAt').first();
  if (!row) return res.json({ found: false });
  res.json({
    found: true,
    customer: { name: row.name },
    motorcycle: { brand: row.brand, model: row.model, year: row.year, plate: row.plate, lastMileage: row.lastMileage },
  });
});

router.post('/bookings', writeLimiter, async (req, res) => {
  const input = bookingSchema.parse(req.body);
  const source = SOURCES.includes(input.source) ? input.source : 'direct';
  const settings = await getSettings(db);
  const booking = await createBooking(input, { source });
  res.status(201).json({ token: booking.manageToken, booking: publicBookingView(booking, settings) });
});

router.post('/bookings/:token/photos', writeLimiter, upload.array('photos', 3), async (req, res) => {
  const booking = await bookingByToken(req.params.token);
  const existing = booking.photos.length;
  const files = req.files || [];
  if (!files.length) throw badRequest('Nenhuma foto enviada.');
  if (existing + files.length > 3) throw badRequest('Você pode enviar no máximo 3 fotos.');
  for (const f of files) {
    const url = await storage.save(f.buffer);
    await db('photos').insert({ url, kind: 'booking', bookingId: booking.id });
  }
  res.status(201).json({ ok: true, count: existing + files.length });
});

router.get('/bookings/:token', async (req, res) => {
  const booking = await bookingByToken(req.params.token);
  const settings = await getSettings(db);
  res.set('Cache-Control', 'no-store');
  res.json({ booking: publicBookingView(booking, settings) });
});

router.post('/bookings/:token/cancel', writeLimiter, async (req, res) => {
  const booking = await bookingByToken(req.params.token);
  const updated = await cancelBooking(booking);
  res.json({ booking: publicBookingView(updated, await getSettings(db)) });
});

router.post('/bookings/:token/reschedule', writeLimiter, async (req, res) => {
  const { startAt } = z.object({ startAt: z.string().min(10) }).parse(req.body);
  const booking = await bookingByToken(req.params.token);
  const updated = await rescheduleBooking(booking, { startAt });
  res.json({ booking: publicBookingView(updated, await getSettings(db)) });
});

// LGPD: the customer can stop maintenance reminders from their private page
router.post('/bookings/:token/reminders-optout', writeLimiter, async (req, res) => {
  const booking = await bookingByToken(req.params.token);
  await db('customers').where({ id: booking.customerId }).update({ reminderConsentRevokedAt: new Date(), updatedAt: new Date() });
  res.json({ ok: true });
});

const icsDate = (d) => DateTime.fromJSDate(new Date(d)).toUTC().toFormat("yyyyLLdd'T'HHmmss'Z'");
const icsEscape = (s) => String(s).replace(/[\\;,]/g, (m) => `\\${m}`).replace(/\n/g, '\\n');

router.get('/bookings/:token/ics', async (req, res) => {
  const b = await bookingByToken(req.params.token);
  const settings = await getSettings(db);
  const summary = `${settings.shopName}: ${b.services.map((s) => s.nameSnapshot).join(', ')}`;
  const ics = [
    'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Natan Motos//Agenda//PT-BR', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${b.code}@natanmotos`,
    `DTSTAMP:${icsDate(new Date())}`,
    `DTSTART:${icsDate(b.startAt)}`,
    `DTEND:${icsDate(b.endAt)}`,
    `SUMMARY:${icsEscape(summary)}`,
    `LOCATION:${icsEscape(settings.address)}`,
    `DESCRIPTION:${icsEscape(`Código ${b.code} · Moto ${b.motorcycle.brand} ${b.motorcycle.model}`)}`,
    'BEGIN:VALARM', 'TRIGGER:-PT2H', 'ACTION:DISPLAY', 'DESCRIPTION:Lembrete', 'END:VALARM',
    'END:VEVENT', 'END:VCALENDAR',
  ].join('\r\n');
  res.set('Content-Type', 'text/calendar; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="agendamento-${b.code}.ics"`);
  res.send(ics);
});

async function orderByToken(token) {
  if (!/^[\w-]{20,64}$/.test(token)) throw notFound('Orçamento não encontrado.');
  return getOrderFull({ approvalToken: token });
}

router.get('/quotes/:token', async (req, res) => {
  const o = await orderByToken(req.params.token);
  if (o.quoteStatus === 'DRAFT') throw notFound('Orçamento ainda não foi enviado.');
  const settings = await getSettings(db);
  res.set('Cache-Control', 'no-store');
  res.json({
    quote: {
      number: o.number,
      status: o.status,
      quoteStatus: o.quoteStatus,
      approvedAt: o.approvedAt,
      customerName: o.customer.name,
      motorcycle: { brand: o.motorcycle.brand, model: o.motorcycle.model, plate: o.motorcycle.plate },
      diagnosis: o.diagnosis,
      items: o.items.filter((i) => i.type !== 'CUSTOMER_PART').map((i) => ({ type: i.type, description: i.description, quantity: i.quantity, unitPriceCents: i.unitPriceCents })),
      customerParts: o.customerParts.map((i) => ({ description: i.description, quantity: i.quantity, notes: i.notes, estimatedPriceCents: i.estimatedPriceCents, imageUrl: i.imageUrl })),
      customerPartsEstimateCents: o.customerPartsEstimateCents,
      pdfUrl: `/api/v1/public/quotes/${o.approvalToken}/pdf`,
      laborCents: o.laborCents,
      partsCents: o.partsCents,
      totalCents: o.totalCents,
      shopName: settings.shopName,
      whatsappNumber: settings.whatsappNumber,
    },
  });
});

router.get('/quotes/:token/pdf', async (req, res) => {
  const o = await orderByToken(req.params.token);
  if (o.quoteStatus === 'DRAFT') throw notFound('Orçamento ainda não foi enviado.');
  const settings = await getSettings(db);
  res.set('Content-Type', 'application/pdf');
  res.set('Content-Disposition', `inline; filename="orcamento-${o.number}.pdf"`);
  res.set('Cache-Control', 'no-store');
  orderPdf(res, { order: o, settings, type: 'quote' });
});

router.post('/quotes/:token/:decision', writeLimiter, async (req, res) => {
  const { decision } = z.object({ decision: z.enum(['approve', 'reject']) }).parse(req.params);
  const o = await orderByToken(req.params.token);
  await decideQuote(o, { approve: decision === 'approve', ip: req.ip });
  res.json({ ok: true });
});

// Today in the shop timezone, used by the client for calendars
router.get('/now', (_req, res) => res.json({ now: new Date().toISOString(), today: DateTime.now().setZone(TZ).toISODate() }));

export default router;
