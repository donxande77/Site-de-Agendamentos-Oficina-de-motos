import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { db } from '../lib/db.js';
import { config } from '../config.js';
import { HttpError } from '../lib/errors.js';
import {
  REFRESH_COOKIE, signAccess, signRefresh, refreshCookieOptions, publicUser, requireAuth,
} from '../middleware/auth.js';
import { audit } from '../services/audit.js';

const router = Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: config.isTest ? 1000 : 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Muitas tentativas de login. Espere 15 minutos e tente de novo.', code: 'RATE_LIMIT' },
});

// Constant-time-ish dummy hash so unknown e-mails take as long as wrong passwords
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing', 10);

router.post('/login', loginLimiter, async (req, res) => {
  const { email, password } = z.object({
    email: z.string().trim().toLowerCase().min(3, 'Informe o e-mail.'),
    password: z.string().min(1, 'Informe a senha.'),
  }).parse(req.body);
  const user = await db('users').where({ email }).first();
  const ok = await bcrypt.compare(password, user?.passwordHash || DUMMY_HASH);
  if (!user || !ok || !user.active) throw new HttpError(401, 'E-mail ou senha incorretos.', 'INVALID_LOGIN');
  res.cookie(REFRESH_COOKIE, signRefresh(user), refreshCookieOptions());
  await audit(user.id, 'auth.login', 'user', user.id);
  res.json({ accessToken: signAccess(user), user: publicUser(user) });
});

router.post('/refresh', async (req, res) => {
  const token = req.cookies?.[REFRESH_COOKIE];
  if (!token) throw new HttpError(401, 'Sessão encerrada.', 'UNAUTHENTICATED');
  let payload;
  try {
    payload = jwt.verify(token, config.jwtRefreshSecret);
  } catch {
    throw new HttpError(401, 'Sessão encerrada.', 'UNAUTHENTICATED');
  }
  const user = await db('users').where({ id: payload.sub }).first();
  if (!user || !user.active || user.tokenVersion !== payload.tv) throw new HttpError(401, 'Sessão encerrada.', 'UNAUTHENTICATED');
  res.cookie(REFRESH_COOKIE, signRefresh(user), refreshCookieOptions());
  res.json({ accessToken: signAccess(user), user: publicUser(user) });
});

router.post('/logout', (req, res) => {
  res.clearCookie(REFRESH_COOKIE, { ...refreshCookieOptions(), maxAge: undefined });
  res.json({ ok: true });
});

router.get('/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

router.post('/change-password', requireAuth, async (req, res) => {
  const { currentPassword, newPassword } = z.object({
    currentPassword: z.string().min(1),
    newPassword: z.string().min(8, 'A nova senha precisa ter pelo menos 8 caracteres.'),
  }).parse(req.body);
  const ok = await bcrypt.compare(currentPassword, req.user.passwordHash);
  if (!ok) throw new HttpError(400, 'A senha atual não confere.', 'INVALID_PASSWORD');
  const tokenVersion = req.user.tokenVersion + 1;
  await db('users').where({ id: req.user.id }).update({ passwordHash: await bcrypt.hash(newPassword, 12), tokenVersion, updatedAt: new Date() });
  const user = { ...req.user, tokenVersion };
  res.cookie(REFRESH_COOKIE, signRefresh(user), refreshCookieOptions());
  await audit(req.user.id, 'auth.password', 'user', req.user.id);
  res.json({ accessToken: signAccess(user), user: publicUser(user) });
});

export default router;
