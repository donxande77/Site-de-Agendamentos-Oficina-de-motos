import { Router } from 'express';
import { z } from 'zod';
import { db } from '../../lib/db.js';
import { normalizePhone, normalizePlate } from '../../lib/util.js';
import { notFound } from '../../lib/errors.js';
import { requireRole, STAFF, BUSINESS } from '../../middleware/auth.js';
import { audit } from '../../services/audit.js';
import { storage } from '../../services/storage.js';
import { motorcycleHistory } from '../../services/motoRecord.js';
import { transferMotorcycle, mergeCustomers, mergeMotorcycles, possibleDuplicates } from '../../services/customerRecords.js';

const router = Router();

router.get('/customers', async (req, res) => {
  const { q = '', page = 1 } = z.object({ q: z.string().max(60).optional(), page: z.coerce.number().int().min(1).optional() }).parse(req.query);
  const term = q.trim();
  const digits = term.replace(/\D/g, '');
  const plate = term.toUpperCase().replace(/[^A-Z0-9]/g, '');
  const base = db('customers as c')
    .whereNull('c.anonymizedAt')
    .modify((qb) => {
      if (!term) return;
      qb.where((w) => {
        w.whereILike('c.name', `%${term}%`);
        if (digits.length >= 4) w.orWhere('c.phone', 'like', `%${digits}%`);
        if (plate.length >= 3) w.orWhereExists(db('motorcycles as m').whereRaw('m."customerId" = c.id').where('m.plate', 'like', `%${plate}%`));
      });
    });
  const [{ total }] = await base.clone().count({ total: '*' });
  const rows = await base.clone()
    .select('c.id', 'c.name', 'c.phone', 'c.email', 'c.noShowCount', 'c.lastServiceAt', 'c.createdAt', 'c.reminderConsentAt', 'c.reminderConsentRevokedAt')
    .orderBy('c.name')
    .limit(30)
    .offset((page - 1) * 30);
  const ids = rows.map((r) => r.id);
  const bikes = ids.length ? await db('motorcycles').select('id', 'customerId', 'brand', 'model', 'plate').whereIn('customerId', ids) : [];
  res.json({ total, page, customers: rows.map((r) => ({ ...r, motorcycles: bikes.filter((b) => b.customerId === r.id) })) });
});

// Cadastros que parecem repetidos (mesmo nome ou e-mail), para o dono juntar
router.get('/customers/duplicates', requireRole(...STAFF), async (_req, res) => {
  res.json({ pairs: await possibleDuplicates() });
});

// Antes de cadastrar: esse WhatsApp ou essa placa já existem?
router.get('/customers/check', requireRole(...STAFF), async (req, res) => {
  const q = z.object({ phone: z.string().max(20).optional(), plate: z.string().max(10).optional() }).parse(req.query);
  const out = { customer: null, motorcycle: null };
  const digits = (q.phone || '').replace(/\D/g, '');
  if (digits.length >= 10) {
    out.customer = await db('customers').select('id', 'name', 'phone').where({ phone: normalizePhone(digits) }).whereNull('anonymizedAt').first() || null;
  }
  const plate = (q.plate || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (plate.length === 7) {
    out.motorcycle = await db('motorcycles as m').join('customers as c', 'c.id', 'm.customerId')
      .select('m.id', 'm.brand', 'm.model', 'm.year', 'm.plate', 'm.lastMileage', 'm.customerId', 'c.name as ownerName', 'c.phone as ownerPhone')
      .where('m.plate', plate).first() || null;
  }
  res.json(out);
});

router.get('/customers/:id', async (req, res) => {
  const id = Number(req.params.id);
  const customer = await db('customers').where({ id }).first();
  if (!customer) throw notFound('Cliente não encontrado.');
  const [motorcycles, bookings, orders] = await Promise.all([
    db('motorcycles').where({ customerId: id }).orderBy('createdAt'),
    db('bookings').where({ customerId: id }).orderBy('startAt', 'desc').limit(50),
    db('service_orders as o').join('motorcycles as m', 'm.id', 'o.motorcycleId')
      .select('o.id', 'o.number', 'o.status', 'o.totalCents', 'o.createdAt', 'o.deliveredAt', 'o.warrantyUntil', 'o.motorcycleId', 'm.brand', 'm.model', 'm.plate')
      .where('o.customerId', id).orderBy('o.createdAt', 'desc'),
  ]);
  res.json({ customer, motorcycles, bookings, orders });
});

const customerSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome.').max(80),
  phone: z.string().min(10, 'Informe o WhatsApp com DDD.'),
  email: z.union([z.literal(''), z.email('E-mail inválido.')]).nullable().optional(),
  notes: z.string().max(2000).nullable().optional(),
});

async function phoneTaken(phone, exceptId = null) {
  return db('customers').select('id', 'name').where({ phone }).modify((q) => { if (exceptId) q.whereNot({ id: exceptId }); }).first();
}
const phoneConflict = (res, other) => res.status(409).json({
  error: `Esse WhatsApp já é do cliente ${other.name}. Abra o cadastro dele em vez de criar outro.`, code: 'CUSTOMER_EXISTS', customer: other,
});

router.post('/customers', requireRole(...STAFF), async (req, res) => {
  const body = customerSchema.parse(req.body);
  const existing = await phoneTaken(normalizePhone(body.phone));
  if (existing) return phoneConflict(res, existing);
  const [row] = await db('customers').insert({ ...body, phone: normalizePhone(body.phone), email: body.email || null }).returning('*');
  await audit(req.user.id, 'customer.create', 'customer', row.id);
  res.status(201).json({ customer: row });
});

router.patch('/customers/:id', requireRole(...STAFF), async (req, res) => {
  const body = customerSchema.partial().parse(req.body);
  if (body.phone) {
    body.phone = normalizePhone(body.phone);
    const other = await phoneTaken(body.phone, Number(req.params.id));
    if (other) return phoneConflict(res, other);
  }
  if (body.email === '') body.email = null;
  const [row] = await db('customers').where({ id: Number(req.params.id) }).update({ ...body, updatedAt: new Date() }).returning('*');
  if (!row) throw notFound('Cliente não encontrado.');
  await audit(req.user.id, 'customer.update', 'customer', row.id, { fields: Object.keys(body) });
  res.json({ customer: row });
});

// Staff records consent given in person (or its revocation)
router.post('/customers/:id/reminder-consent', requireRole(...STAFF), async (req, res) => {
  const { consent } = z.object({ consent: z.boolean() }).parse(req.body);
  const patch = consent ? { reminderConsentAt: new Date(), reminderConsentRevokedAt: null } : { reminderConsentRevokedAt: new Date() };
  await db('customers').where({ id: Number(req.params.id) }).update({ ...patch, updatedAt: new Date() });
  await audit(req.user.id, consent ? 'consent.grant' : 'consent.revoke', 'customer', Number(req.params.id));
  res.json({ ok: true });
});

const bikeSchema = z.object({
  brand: z.string().trim().min(2, 'Informe a marca.').max(40),
  model: z.string().trim().min(1, 'Informe o modelo.').max(60),
  year: z.number().int().min(1950).max(2100).nullable().optional(),
  plate: z.string().min(7, 'Informe a placa.'),
  color: z.string().max(30).nullable().optional(),
  lastMileage: z.number().int().min(0).nullable().optional(),
});

const plateTaken = (plate, exceptId = null) => db('motorcycles as m').join('customers as c', 'c.id', 'm.customerId')
  .select('m.id', 'm.brand', 'm.model', 'm.plate', 'm.customerId', 'c.name as ownerName')
  .where('m.plate', plate).modify((q) => { if (exceptId) q.whereNot('m.id', exceptId); }).first();
const plateConflict = (res, bike, customerId = null) => res.status(409).json({
  error: bike.customerId === customerId
    ? `Essa placa já está no cadastro deste cliente (${bike.brand} ${bike.model}).`
    : `Essa placa já está cadastrada para ${bike.ownerName} (${bike.brand} ${bike.model}). Se a moto foi vendida, use "Transferir moto".`,
  code: 'PLATE_EXISTS', motorcycle: bike,
});

router.post('/customers/:id/motorcycles', requireRole(...STAFF), async (req, res) => {
  const body = bikeSchema.parse(req.body);
  const plate = normalizePlate(body.plate);
  const owned = await plateTaken(plate);
  if (owned) return plateConflict(res, owned, Number(req.params.id));
  const [row] = await db('motorcycles').insert({ ...body, plate, customerId: Number(req.params.id) }).returning('*');
  await audit(req.user.id, 'motorcycle.create', 'motorcycle', row.id);
  res.status(201).json({ motorcycle: row });
});

router.patch('/motorcycles/:id', requireRole(...STAFF), async (req, res) => {
  const body = bikeSchema.partial().parse(req.body);
  if (body.plate) {
    body.plate = normalizePlate(body.plate);
    const owned = await plateTaken(body.plate, Number(req.params.id));
    if (owned) return plateConflict(res, owned);
  }
  const [row] = await db('motorcycles').where({ id: Number(req.params.id) }).update({ ...body, updatedAt: new Date() }).returning('*');
  if (!row) throw notFound('Moto não encontrada.');
  res.json({ motorcycle: row });
});

// Moto vendida: passa para o cadastro do novo dono, com todo o histórico
router.post('/motorcycles/:id/transfer', requireRole(...STAFF), async (req, res) => {
  const { customerId } = z.object({ customerId: z.number().int().positive() }).parse(req.body);
  await transferMotorcycle(Number(req.params.id), customerId, req.user.id);
  res.json({ ok: true });
});

// Mesma moto cadastrada duas vezes (placa digitada errada): junta na que fica
router.post('/motorcycles/:id/merge', requireRole(...BUSINESS), async (req, res) => {
  const { duplicateId } = z.object({ duplicateId: z.number().int().positive() }).parse(req.body);
  await mergeMotorcycles(Number(req.params.id), duplicateId, req.user.id);
  res.json({ ok: true });
});

// Mesmo cliente com dois cadastros (trocou de número): junta no que fica
router.post('/customers/:id/merge', requireRole(...BUSINESS), async (req, res) => {
  const { duplicateId } = z.object({ duplicateId: z.number().int().positive() }).parse(req.body);
  const moved = await mergeCustomers(Number(req.params.id), duplicateId, req.user.id);
  res.json({ ok: true, moved });
});

// Prontuário da moto: todas as visitas, o que foi feito e o que ficou pendente
router.get('/motorcycles/:id/history', async (req, res) => {
  const id = z.coerce.number().int().parse(req.params.id);
  res.json(await motorcycleHistory(id, { showMoney: req.user.role !== 'MECHANIC' }));
});

// LGPD art. 18: portability — every record about the customer, in JSON
router.get('/customers/:id/export', requireRole(...BUSINESS), async (req, res) => {
  const id = Number(req.params.id);
  const customer = await db('customers').where({ id }).first();
  if (!customer) throw notFound('Cliente não encontrado.');
  const motorcycles = await db('motorcycles').where({ customerId: id });
  const bookings = await db('bookings').where({ customerId: id }).select('code', 'startAt', 'endAt', 'status', 'source', 'problemDescription', 'createdAt');
  const orders = await db('service_orders').where({ customerId: id });
  const orderIds = orders.map((o) => o.id);
  const items = orderIds.length ? await db('service_order_items').whereIn('serviceOrderId', orderIds) : [];
  const findings = orderIds.length ? await db('order_findings').whereIn('serviceOrderId', orderIds).orderBy('id') : [];
  const payments = orderIds.length ? await db('payments').whereIn('serviceOrderId', orderIds).select('serviceOrderId', 'amountCents', 'method', 'installments', 'paidAt') : [];
  const data = {
    exportedAt: new Date().toISOString(),
    customer: {
      name: customer.name, phone: customer.phone, email: customer.email, createdAt: customer.createdAt,
      privacyAckAt: customer.privacyAckAt, reminderConsentAt: customer.reminderConsentAt, reminderConsentRevokedAt: customer.reminderConsentRevokedAt,
    },
    motorcycles: motorcycles.map(({ brand, model, year, plate, color, lastMileage }) => ({ brand, model, year, plate, color, lastMileage })),
    bookings,
    serviceOrders: orders.map((o) => ({
      number: o.number, status: o.status, createdAt: o.createdAt, deliveredAt: o.deliveredAt, diagnosis: o.diagnosis, workDone: o.workDone, internalNotes: o.internalNotes, totalCents: o.totalCents,
      approvedAt: o.approvedAt, items: items.filter((i) => i.serviceOrderId === o.id).map(({ type, description, quantity, unitPriceCents }) => ({ type, description, quantity, unitPriceCents })),
      findings: findings.filter((f) => f.serviceOrderId === o.id).map(({ description, severity, decision, informedAt, informedVia, resolvedAt }) => ({ description, severity, decision, informedAt, informedVia, resolvedAt })),
      payments: payments.filter((p) => p.serviceOrderId === o.id).map(({ amountCents, method, installments, paidAt }) => ({ amountCents, method, installments, paidAt })),
    })),
  };
  await audit(req.user.id, 'customer.export', 'customer', id);
  res.set('Content-Disposition', `attachment; filename="dados-cliente-${id}.json"`);
  res.json(data);
});

/**
 * LGPD art. 18: elimination. Personal data is anonymised; financial records stay
 * (legal obligation) but no longer identify the person. Photos are deleted.
 */
router.delete('/customers/:id', requireRole(...BUSINESS), async (req, res) => {
  const id = Number(req.params.id);
  const customer = await db('customers').where({ id }).first();
  if (!customer) throw notFound('Cliente não encontrado.');
  const photos = await db('photos as p')
    .leftJoin('bookings as b', 'b.id', 'p.bookingId')
    .leftJoin('service_orders as o', 'o.id', 'p.serviceOrderId')
    .where((w) => w.where('b.customerId', id).orWhere('o.customerId', id))
    .select('p.id', 'p.url');
  await db.transaction(async (trx) => {
    await trx('customers').where({ id }).update({
      name: 'Cliente removido', phone: `anon-${id}`, email: null, notes: null, privacyAckAt: null,
      reminderConsentAt: null, reminderConsentRevokedAt: null, anonymizedAt: new Date(), updatedAt: new Date(),
    });
    const bikes = await trx('motorcycles').where({ customerId: id });
    for (const b of bikes) {
      await trx('motorcycles').where({ id: b.id }).update({ plate: `X${String(b.id).padStart(6, '0')}`, color: null, updatedAt: new Date() });
    }
    await trx('bookings').where({ customerId: id }).update({ problemDescription: null, notes: null });
    await trx('maintenance_reminders').whereIn('motorcycleId', bikes.map((b) => b.id)).del();
    if (photos.length) await trx('photos').whereIn('id', photos.map((p) => p.id)).del();
    await audit(req.user.id, 'customer.anonymize', 'customer', id, null, trx);
  });
  for (const p of photos) await storage.remove(p.url);
  res.json({ ok: true });
});

export default router;
