import { Router } from 'express';
import { z } from 'zod';
import { db } from '../../lib/db.js';
import { notFound } from '../../lib/errors.js';
import { requireRole, STAFF } from '../../middleware/auth.js';
import { audit } from '../../services/audit.js';

const router = Router();

const cents = z.number().int().min(0).max(100_000_000);

const serviceSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome do serviço.').max(80),
  description: z.string().max(300).nullable().optional(),
  category: z.string().trim().max(40).optional(),
  durationMinutes: z.number().int().min(15, 'Duração mínima de 15 minutos.').max(720),
  basePriceCents: cents.nullable().optional(),
  priceOnEvaluation: z.boolean().optional(),
  dropOffRequired: z.boolean().optional(),
  warrantyDays: z.number().int().min(0).max(3650).nullable().optional(),
  isOilChange: z.boolean().optional(),
  partsToBring: z.string().trim().max(300).nullable().optional(),
  active: z.boolean().optional(),
  onlineVisible: z.boolean().optional(),
  order: z.number().int().optional(),
});

router.get('/services', async (_req, res) => {
  res.json({ services: await db('services').orderBy(['order', 'name']) });
});

router.post('/services', requireRole('OWNER'), async (req, res) => {
  const body = serviceSchema.parse(req.body);
  const [row] = await db('services').insert(body).returning('*');
  await audit(req.user.id, 'service.create', 'service', row.id);
  res.status(201).json({ service: row });
});

router.patch('/services/:id', requireRole('OWNER'), async (req, res) => {
  const body = serviceSchema.partial().parse(req.body);
  const [row] = await db('services').where({ id: Number(req.params.id) }).update(body).returning('*');
  if (!row) throw notFound('Serviço não encontrado.');
  await audit(req.user.id, 'service.update', 'service', row.id, { fields: Object.keys(body) });
  res.json({ service: row });
});

const partSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome da peça.').max(80),
  code: z.string().trim().max(40).nullable().optional(),
  costCents: cents.optional(),
  priceCents: cents.optional(),
  stock: z.number().int().min(-9999).max(99999).optional(),
  minStock: z.number().int().min(0).max(99999).optional(),
  active: z.boolean().optional(),
});

router.get('/parts', async (req, res) => {
  const { q = '', low } = z.object({ q: z.string().max(60).optional(), low: z.string().optional() }).parse(req.query);
  const rows = await db('parts')
    .modify((qb) => q && qb.where((w) => w.whereILike('name', `%${q}%`).orWhereILike('code', `%${q}%`)))
    .modify((qb) => low && qb.whereRaw('"stock" <= "minStock"').where({ active: true }))
    .orderBy('name');
  res.json({ parts: rows });
});

router.post('/parts', requireRole(...STAFF), async (req, res) => {
  const body = partSchema.parse(req.body);
  const [row] = await db('parts').insert(body).returning('*');
  await audit(req.user.id, 'part.create', 'part', row.id);
  res.status(201).json({ part: row });
});

router.patch('/parts/:id', requireRole(...STAFF), async (req, res) => {
  const body = partSchema.partial().parse(req.body);
  const [row] = await db('parts').where({ id: Number(req.params.id) }).update({ ...body, updatedAt: new Date() }).returning('*');
  if (!row) throw notFound('Peça não encontrada.');
  await audit(req.user.id, 'part.update', 'part', row.id, { fields: Object.keys(body) });
  res.json({ part: row });
});

export default router;
