import { Router } from 'express';
import { z } from 'zod';
import { DateTime } from 'luxon';
import { db } from '../../lib/db.js';
import { TZ, formatPlate } from '../../lib/util.js';
import { notFound } from '../../lib/errors.js';
import { requireRole, BUSINESS } from '../../middleware/auth.js';
import { audit } from '../../services/audit.js';
import { backupStatus } from '../../services/backups.js';

const router = Router();
const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const utcRange = (from, to) => [
  DateTime.fromISO(from, { zone: TZ }).startOf('day').toUTC().toJSDate(),
  DateTime.fromISO(to, { zone: TZ }).endOf('day').toUTC().toJSDate(),
];
const localDay = (col) => db.raw(`to_char(("${col}" AT TIME ZONE '${TZ}'), 'YYYY-MM-DD')`);

async function sumPayments(from, to) {
  const [{ s }] = await db('payments').whereBetween('paidAt', [from, to]).select(db.raw('COALESCE(SUM("amountCents"),0) AS s'));
  return s;
}

async function summary(fromDate, toDate) {
  const [from, to] = utcRange(fromDate, toDate);
  const [revenueCents, byMethod, expenses, partsCost, daily, dailyOut, pendingExpenses] = await Promise.all([
    sumPayments(from, to),
    db('payments').whereBetween('paidAt', [from, to]).select('method').sum({ total: 'amountCents' }).count({ n: '*' }).groupBy('method'),
    db('expenses').whereBetween('paidAt', [fromDate, toDate]).select(db.raw('COALESCE(SUM("amountCents"),0) AS s')).first(),
    db('service_order_items as i').join('service_orders as o', 'o.id', 'i.serviceOrderId')
      .where('i.type', 'PART').whereBetween('o.deliveredAt', [from, to])
      .select(db.raw('COALESCE(SUM(i."quantity" * i."unitCostCents"),0) AS s')).first(),
    db('payments').whereBetween('paidAt', [from, to]).select(localDay('paidAt').wrap('', ' AS day')).sum({ total: 'amountCents' }).groupByRaw('1').orderByRaw('1'),
    db('expenses').whereBetween('paidAt', [fromDate, toDate]).select(db.raw('"paidAt"::text AS day')).sum({ total: 'amountCents' }).groupByRaw('1').orderByRaw('1'),
    db('expenses').whereNull('paidAt').where('dueDate', '<=', toDate).select(db.raw('COALESCE(SUM("amountCents"),0) AS s')).count({ n: '*' }).first(),
  ]);
  const days = new Map();
  for (const d of daily) days.set(d.day, { day: d.day, inCents: Number(d.total), outCents: 0 });
  for (const d of dailyOut) days.set(d.day, { ...(days.get(d.day) || { day: d.day, inCents: 0 }), outCents: Number(d.total) });
  return {
    from: fromDate,
    to: toDate,
    revenueCents,
    expensesCents: expenses.s,
    partsCostCents: partsCost.s,
    profitCents: revenueCents - expenses.s - partsCost.s,
    byMethod: byMethod.map((m) => ({ method: m.method, totalCents: Number(m.total), count: m.n })),
    cashFlow: [...days.values()].sort((a, b) => a.day.localeCompare(b.day)),
    pendingExpenses: { totalCents: pendingExpenses.s, count: pendingExpenses.n },
  };
}

router.get('/dashboard', requireRole(...BUSINESS), async (_req, res) => {
  const now = DateTime.now().setZone(TZ);
  const today = now.toISODate();
  const [todayStart, todayEnd] = utcRange(today, today);
  const monthStart = now.startOf('month');
  const lastMonthStart = monthStart.minus({ months: 1 });
  const weekStart = now.startOf('week');
  const weekEnd = weekStart.plus({ days: 6 });
  const thirtyAgo = now.minus({ days: 30 }).toJSDate();

  const [month, revenueToday, revenueLastMonth, todayBookings, inShop, avgTicket, topServices, bySource, noShow, history, remindersDue, lowStock, noPrice] = await Promise.all([
    summary(monthStart.toISODate(), today),
    sumPayments(todayStart, todayEnd),
    sumPayments(lastMonthStart.toJSDate(), DateTime.min(lastMonthStart.plus(now.diff(monthStart)), monthStart).toJSDate()),
    db('bookings as b').join('customers as c', 'c.id', 'b.customerId').join('motorcycles as m', 'm.id', 'b.motorcycleId')
      .leftJoin('bays as y', 'y.id', 'b.bayId')
      .select('b.id', 'b.code', 'b.startAt', 'b.endAt', 'b.status', 'b.source', 'c.name as customerName', 'm.brand', 'm.model', 'm.plate', 'y.name as bayName')
      .whereBetween('b.startAt', [todayStart, todayEnd]).whereNot('b.status', 'CANCELLED').orderBy('b.startAt'),
    db('service_orders').whereIn('status', ['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL', 'APPROVED', 'IN_PROGRESS', 'WAITING_PARTS', 'READY'])
      .select('status').count({ n: '*' }).groupBy('status'),
    db('service_orders').where('deliveredAt', '>=', monthStart.toJSDate()).avg({ v: 'totalCents' }).count({ n: '*' }).first(),
    db('booking_services as s').join('bookings as b', 'b.id', 's.bookingId')
      .where('b.startAt', '>=', monthStart.toJSDate()).whereNot('b.status', 'CANCELLED')
      .select('s.nameSnapshot as name').count({ n: '*' }).groupBy('s.nameSnapshot').orderBy('n', 'desc').limit(5),
    db('bookings').where('createdAt', '>=', thirtyAgo).select('source').count({ n: '*' }).groupBy('source'),
    db('bookings').where('startAt', '>=', thirtyAgo).where('startAt', '<', new Date()).whereNot('status', 'CANCELLED')
      .select(db.raw(`COUNT(*) FILTER (WHERE status = 'NO_SHOW') AS "noShow"`), db.raw('COUNT(*) AS total')).first(),
    db('payments').where('paidAt', '>=', monthStart.minus({ months: 5 }).toJSDate())
      .select(db.raw(`to_char(date_trunc('month', "paidAt" AT TIME ZONE '${TZ}'), 'YYYY-MM') AS month`))
      .sum({ total: 'amountCents' }).groupByRaw('1').orderByRaw('1'),
    db('maintenance_reminders').whereNull('doneAt').whereNull('sentAt').where('dueDate', '<=', now.plus({ days: 7 }).toISODate()).count({ n: '*' }).first(),
    db('parts').where({ active: true }).whereRaw('"stock" <= "minStock"').count({ n: '*' }).first(),
    db('services').where({ active: true, priceOnEvaluation: false }).whereNull('basePriceCents').count({ n: '*' }).first(),
  ]);

  // Bay occupancy this week: booked minutes / open minutes × active bays
  const [hours, bays, weekBookings] = await Promise.all([
    db('business_hours'),
    db('bays').where({ active: true }).count({ n: '*' }).first(),
    db('bookings').whereIn('status', ['CONFIRMED', 'CHECKED_IN', 'PENDING'])
      .whereBetween('startAt', utcRange(weekStart.toISODate(), weekEnd.toISODate()))
      .select(db.raw('COALESCE(SUM(EXTRACT(EPOCH FROM ("endAt" - "startAt")) / 60), 0) AS minutes')).first(),
  ]);
  const toMin = (hm) => { const [h, m] = hm.split(':').map(Number); return h * 60 + m; };
  const openMinutes = hours.filter((h) => !h.closed).reduce((acc, h) => {
    const brk = h.breakStart && h.breakEnd ? toMin(h.breakEnd) - toMin(h.breakStart) : 0;
    return acc + toMin(h.closesAt) - toMin(h.opensAt) - brk;
  }, 0);
  const capacity = openMinutes * Number(bays.n);
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const key = monthStart.minus({ months: i }).toFormat('yyyy-MM');
    months.push({ month: key, totalCents: Number(history.find((h) => h.month === key)?.total || 0) });
  }

  res.json({
    today,
    todayBookings,
    inShop: Object.fromEntries(inShop.map((r) => [r.status, r.n])),
    revenueTodayCents: revenueToday,
    revenueMonthCents: month.revenueCents,
    revenueLastMonthCents: revenueLastMonth,
    profitMonthCents: month.profitCents,
    avgTicketCents: Math.round(Number(avgTicket.v || 0)),
    deliveredThisMonth: avgTicket.n,
    topServices,
    bySource: Object.fromEntries(bySource.map((r) => [r.source, r.n])),
    noShowRate: noShow.total ? noShow.noShow / noShow.total : 0,
    occupancy: capacity ? Math.min(1, Number(weekBookings.minutes) / capacity) : 0,
    revenueHistory: months,
    remindersDue: remindersDue.n,
    lowStock: (await db('settings').where({ id: 1 }).first()).sellsParts ? lowStock.n : 0,
    servicesWithoutPrice: noPrice.n,
    backup: await backupStatus(db).then(({ configured, healthy, problems }) => ({ configured, healthy, problems })),
  });
});

router.get('/finance/summary', requireRole(...BUSINESS), async (req, res) => {
  const q = z.object({ from: dateStr, to: dateStr }).parse(req.query);
  res.json(await summary(q.from, q.to));
});

router.get('/finance/payments', requireRole(...BUSINESS), async (req, res) => {
  const q = z.object({ from: dateStr, to: dateStr }).parse(req.query);
  const rows = await db('payments as p').join('service_orders as o', 'o.id', 'p.serviceOrderId').join('customers as c', 'c.id', 'o.customerId')
    .select('p.*', 'o.number as orderNumber', 'c.name as customerName')
    .whereBetween('p.paidAt', utcRange(q.from, q.to)).orderBy('p.paidAt', 'desc');
  res.json({ payments: rows });
});

router.get('/finance/receivables', requireRole(...BUSINESS), async (_req, res) => {
  const rows = await db('service_orders as o').join('customers as c', 'c.id', 'o.customerId').join('motorcycles as m', 'm.id', 'o.motorcycleId')
    .select('o.id', 'o.number', 'o.status', 'o.totalCents', 'o.deliveredAt', 'c.name as customerName', 'c.phone as customerPhone', 'm.brand', 'm.model', 'm.plate')
    .select(db.raw('(SELECT COALESCE(SUM("amountCents"),0) FROM payments p WHERE p."serviceOrderId" = o.id) AS "paidCents"'))
    .where('o.receivable', true).orderBy('o.deliveredAt');
  res.json({ receivables: rows.map((r) => ({ ...r, balanceCents: r.totalCents - r.paidCents })) });
});

router.get('/finance/commissions', requireRole(...BUSINESS), async (req, res) => {
  const q = z.object({ from: dateStr, to: dateStr }).parse(req.query);
  const rows = await db('service_orders as o').join('users as u', 'u.id', 'o.mechanicId').join('service_order_items as i', 'i.serviceOrderId', 'o.id')
    .where('i.type', 'LABOR').whereBetween('o.deliveredAt', utcRange(q.from, q.to))
    .select('u.id', 'u.name', 'u.commissionPercent')
    .select(db.raw('SUM(i."quantity" * i."unitPriceCents") AS "laborCents"'), db.raw('COUNT(DISTINCT o.id) AS orders'))
    .groupBy('u.id', 'u.name', 'u.commissionPercent').orderBy('u.name');
  res.json({ commissions: rows.map((r) => ({ ...r, commissionCents: Math.round((r.laborCents * r.commissionPercent) / 100) })) });
});

const CATEGORIES = ['RENT', 'PARTS', 'TOOLS', 'UTILITIES', 'SALARIES', 'OTHER'];
const expenseSchema = z.object({
  category: z.enum(CATEGORIES),
  description: z.string().trim().min(2, 'Descreva a despesa.').max(120),
  amountCents: z.number().int().min(1, 'Informe o valor.').max(100_000_000),
  dueDate: dateStr,
  paidAt: dateStr.nullable().optional(),
});

router.get('/expenses', requireRole(...BUSINESS), async (req, res) => {
  const q = z.object({ from: dateStr, to: dateStr, status: z.enum(['all', 'open', 'paid']).default('all') }).parse(req.query);
  const rows = await db('expenses')
    .where((w) => w.whereBetween('dueDate', [q.from, q.to]).orWhereBetween('paidAt', [q.from, q.to]))
    .modify((qb) => { if (q.status === 'open') qb.whereNull('paidAt'); if (q.status === 'paid') qb.whereNotNull('paidAt'); })
    .orderBy('dueDate');
  res.json({ expenses: rows });
});

router.post('/expenses', requireRole(...BUSINESS), async (req, res) => {
  const [row] = await db('expenses').insert(expenseSchema.parse(req.body)).returning('*');
  await audit(req.user.id, 'expense.create', 'expense', row.id);
  res.status(201).json({ expense: row });
});

router.patch('/expenses/:id', requireRole(...BUSINESS), async (req, res) => {
  const [row] = await db('expenses').where({ id: Number(req.params.id) }).update(expenseSchema.partial().parse(req.body)).returning('*');
  if (!row) throw notFound('Despesa não encontrada.');
  res.json({ expense: row });
});

router.delete('/expenses/:id', requireRole(...BUSINESS), async (req, res) => {
  await db('expenses').where({ id: Number(req.params.id) }).del();
  await audit(req.user.id, 'expense.delete', 'expense', Number(req.params.id));
  res.json({ ok: true });
});

// CSV for Excel (semicolon + BOM so accents and columns open correctly in pt-BR Excel)
const csvCell = (v) => {
  let s = v === null || v === undefined ? '' : String(v);
  if (/^[=+\-@]/.test(s)) s = `'${s}`; // avoid spreadsheet formula injection
  return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const money = (c) => (c / 100).toFixed(2).replace('.', ',');
const METHOD_PT = { PIX: 'Pix', CASH: 'Dinheiro', DEBIT: 'Débito', CREDIT: 'Crédito' };
const CAT_PT = { RENT: 'Aluguel', PARTS: 'Compra de peças', TOOLS: 'Ferramentas', UTILITIES: 'Contas (luz, água, internet)', SALARIES: 'Salários', OTHER: 'Outros' };

router.get('/finance/export.csv', requireRole(...BUSINESS), async (req, res) => {
  const q = z.object({ from: dateStr, to: dateStr, kind: z.enum(['payments', 'expenses']).default('payments') }).parse(req.query);
  let lines;
  if (q.kind === 'payments') {
    const rows = await db('payments as p').join('service_orders as o', 'o.id', 'p.serviceOrderId').join('motorcycles as m', 'm.id', 'o.motorcycleId')
      .select('p.paidAt', 'p.amountCents', 'p.method', 'p.installments', 'o.number', 'm.plate')
      .whereBetween('p.paidAt', utcRange(q.from, q.to)).orderBy('p.paidAt');
    lines = [['Data', 'OS', 'Placa', 'Forma', 'Parcelas', 'Valor (R$)'],
      ...rows.map((r) => [DateTime.fromJSDate(r.paidAt).setZone(TZ).toFormat('dd/MM/yyyy HH:mm'), r.number, formatPlate(r.plate), METHOD_PT[r.method], r.installments, money(r.amountCents)])];
  } else {
    const rows = await db('expenses').whereBetween('dueDate', [q.from, q.to]).orderBy('dueDate');
    lines = [['Vencimento', 'Pago em', 'Categoria', 'Descrição', 'Valor (R$)'],
      ...rows.map((r) => [r.dueDate.split('-').reverse().join('/'), r.paidAt ? r.paidAt.split('-').reverse().join('/') : '', CAT_PT[r.category], r.description, money(r.amountCents)])];
  }
  const csv = `\uFEFF${lines.map((l) => l.map(csvCell).join(';')).join('\r\n')}`;
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="${q.kind === 'payments' ? 'recebimentos' : 'despesas'}-${q.from}-a-${q.to}.csv"`);
  res.send(csv);
});

export default router;
