import { Router } from 'express';
import { z } from 'zod';
import { DateTime } from 'luxon';
import { db } from '../../lib/db.js';
import { TZ } from '../../lib/util.js';
import { badRequest } from '../../lib/errors.js';
import { requireRole, STAFF } from '../../middleware/auth.js';
import {
  createBooking, getBookingFull, rescheduleBooking, cancelBooking, checkInBooking,
} from '../../services/bookings.js';
import { loadContext, computeDaySlots, weekdayOf, totalDuration } from '../../services/availability.js';
import { audit } from '../../services/audit.js';
import { bikeSummary } from '../../services/motoRecord.js';

const router = Router();
const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const range = (from, to) => ({
  from: DateTime.fromISO(from, { zone: TZ }).startOf('day').toUTC().toJSDate(),
  to: DateTime.fromISO(to, { zone: TZ }).endOf('day').toUTC().toJSDate(),
});

router.get('/agenda', async (req, res) => {
  const q = z.object({ from: dateStr, to: dateStr }).parse(req.query);
  const { from, to } = range(q.from, q.to);
  const [bays, hours, bookings, blocks, mechanics] = await Promise.all([
    db('bays').orderBy('order'),
    db('business_hours').orderBy('weekday'),
    db('bookings as b')
      .join('customers as c', 'c.id', 'b.customerId')
      .join('motorcycles as m', 'm.id', 'b.motorcycleId')
      .leftJoin('users as u', 'u.id', 'b.mechanicId')
      .leftJoin('service_orders as o', 'o.bookingId', 'b.id')
      .select(
        'b.id', 'b.code', 'b.startAt', 'b.endAt', 'b.status', 'b.source', 'b.bayId', 'b.mechanicId', 'b.dropOff', 'b.problemDescription', 'b.notes',
        'c.name as customerName', 'c.phone as customerPhone', 'c.noShowCount',
        'm.brand', 'm.model', 'm.plate', 'u.name as mechanicName', 'o.id as orderId', 'o.status as orderStatus', 'o.number as orderNumber',
      )
      .where('b.startAt', '<', to)
      .where('b.endAt', '>', from)
      .orderBy('b.startAt'),
    db('time_blocks').where('startAt', '<', to).where('endAt', '>', from).orderBy('startAt'),
    db('users').select('id', 'name', 'role').where({ active: true }).whereIn('role', ['MECHANIC', 'MANAGER']).orderBy('name'),
  ]);
  const ids = bookings.map((b) => b.id);
  const services = ids.length ? await db('booking_services').whereIn('bookingId', ids) : [];
  const settings = await db('settings').select('noShowFlagThreshold', 'slotMinutes', 'scheduleView').where({ id: 1 }).first();
  res.json({
    bays,
    hours,
    blocks,
    mechanics,
    settings,
    bookings: bookings.map((b) => ({ ...b, services: services.filter((s) => s.bookingId === b.id).map((s) => s.nameSnapshot) })),
  });
});

// Calendário do mês: quantos agendamentos tem cada dia (as bolinhas azuis do calendário)
router.get('/agenda/month', async (req, res) => {
  const { month } = z.object({ month: z.string().regex(/^\d{4}-\d{2}$/) }).parse(req.query);
  const start = DateTime.fromISO(`${month}-01`, { zone: TZ });
  if (!start.isValid) throw badRequest('Mês inválido.');
  const rows = await db('bookings')
    .select(db.raw(`to_char("startAt" AT TIME ZONE ?, 'YYYY-MM-DD') AS day`, [TZ]))
    .count({ n: '*' })
    .whereNotIn('status', ['CANCELLED', 'NO_SHOW'])
    .where('startAt', '>=', start.toUTC().toJSDate())
    .where('startAt', '<', start.plus({ months: 1 }).toUTC().toJSDate())
    .groupBy('day');
  const closed = (await db('business_hours').select('weekday').where({ closed: true })).map((h) => h.weekday);
  res.json({ month, days: Object.fromEntries(rows.map((r) => [r.day, Number(r.n)])), closedWeekdays: closed });
});

router.get('/bookings/:id', async (req, res) => {
  const booking = await getBookingFull({ id: Number(req.params.id) });
  booking.bikeHistory = await bikeSummary(booking.motorcycleId, { excludeOrderId: booking.order?.id });
  res.json({ booking });
});

// Free start times for staff (no minimum notice; opening hours still apply)
router.get('/staff-slots', requireRole(...STAFF), async (req, res) => {
  const q = z.object({
    date: dateStr,
    services: z.string().regex(/^\d+(,\d+)*$/).optional(),
    duration: z.coerce.number().int().min(15).max(600).optional(),
    excludeId: z.coerce.number().int().optional(),
  }).parse(req.query);
  const ctx = await loadContext(db, q.date, q.date, { excludeBookingId: q.excludeId });
  let duration = q.duration;
  if (!duration && q.services) {
    const svcs = await db('services').whereIn('id', q.services.split(',').map(Number));
    duration = totalDuration(svcs, ctx.settings.slotMinutes);
  }
  if (!duration) throw badRequest('Informe os serviços ou a duração.');
  const dt = DateTime.fromISO(q.date, { zone: TZ });
  const slots = computeDaySlots({
    date: q.date, durationMinutes: duration, hours: ctx.hoursByWeekday[weekdayOf(dt)], bays: ctx.bays,
    bookings: ctx.bookings, blocks: ctx.blocks, slotMinutes: ctx.settings.slotMinutes, minNoticeHours: 0,
  });
  res.json({ duration, slots });
});

const staffBooking = z.object({
  serviceIds: z.array(z.number().int().positive()).min(1, 'Escolha pelo menos um serviço.'),
  startAt: z.string().min(10),
  durationMinutes: z.number().int().min(15).max(720).optional(),
  source: z.enum(['instagram', 'whatsapp', 'direct', 'walk_in']).default('walk_in'),
  bayId: z.number().int().optional(),
  mechanicId: z.number().int().nullable().optional(),
  dropOff: z.boolean().optional(),
  problemDescription: z.string().max(1000).optional(),
  notes: z.string().max(1000).optional(),
  reminderConsent: z.boolean().optional(),
  customer: z.object({
    name: z.string().trim().min(2, 'Informe o nome do cliente.').max(80),
    phone: z.string().min(10, 'Informe o WhatsApp com DDD.'),
    email: z.union([z.literal(''), z.email('E-mail inválido.')]).optional(),
  }),
  motorcycle: z.object({
    brand: z.string().trim().min(2, 'Informe a marca.'),
    model: z.string().trim().min(1, 'Informe o modelo.'),
    year: z.number().int().min(1950).max(2100).nullable().optional(),
    plate: z.string().min(7, 'Informe a placa.'),
    mileage: z.number().int().min(0).nullable().optional(),
  }),
});

router.post('/bookings', requireRole(...STAFF), async (req, res) => {
  const input = staffBooking.parse(req.body);
  const booking = await createBooking(input, { source: input.source, isStaff: true, userId: req.user.id });
  res.status(201).json({ booking });
});

router.patch('/bookings/:id', requireRole(...STAFF), async (req, res) => {
  const body = z.object({
    startAt: z.string().optional(),
    bayId: z.number().int().optional(),
    mechanicId: z.number().int().nullable().optional(),
    notes: z.string().max(1000).nullable().optional(),
    status: z.enum(['CONFIRMED', 'NO_SHOW']).optional(),
  }).parse(req.body);
  let booking = await getBookingFull({ id: Number(req.params.id) });
  if (body.startAt || body.bayId) {
    booking = await rescheduleBooking(booking, body, { isStaff: true, userId: req.user.id });
  }
  const patch = {};
  if (body.mechanicId !== undefined) patch.mechanicId = body.mechanicId;
  if (body.notes !== undefined) patch.notes = body.notes;
  if (body.status) {
    if (!['PENDING', 'CONFIRMED', 'NO_SHOW'].includes(booking.status)) throw badRequest('Status não pode ser alterado.');
    patch.status = body.status;
    if (body.status === 'NO_SHOW' && booking.status !== 'NO_SHOW') await db('customers').where({ id: booking.customerId }).increment('noShowCount', 1);
    if (body.status === 'CONFIRMED' && booking.status === 'NO_SHOW') await db('customers').where({ id: booking.customerId }).where('noShowCount', '>', 0).decrement('noShowCount', 1);
  }
  if (Object.keys(patch).length) {
    await db('bookings').where({ id: booking.id }).update({ ...patch, updatedAt: new Date() });
    await audit(req.user.id, 'booking.update', 'booking', booking.id, { fields: Object.keys(patch) });
  }
  res.json({ booking: await getBookingFull({ id: booking.id }) });
});

router.post('/bookings/:id/cancel', requireRole(...STAFF), async (req, res) => {
  const booking = await getBookingFull({ id: Number(req.params.id) });
  res.json({ booking: await cancelBooking(booking, { isStaff: true, userId: req.user.id }) });
});

// "Moto chegou": administrator or mechanic. A mechanic doing the check-in of a booking without a
// mechanic gets the OS in his name.
router.post('/bookings/:id/checkin', requireRole(...STAFF, 'MECHANIC'), async (req, res) => {
  const body = z.object({
    checkInMileage: z.number().int().min(0).nullable().optional(),
    fuelLevel: z.enum(['reserve', 'quarter', 'half', 'three_quarters', 'full']).nullable().optional(),
    checklist: z.object({ items: z.array(z.string()).optional(), damage: z.string().max(500).optional() }).optional(),
  }).parse(req.body || {});
  const booking = await getBookingFull({ id: Number(req.params.id) });
  if (req.user.role === 'MECHANIC' && !booking.mechanicId) {
    await db('bookings').where({ id: booking.id }).update({ mechanicId: req.user.id });
    booking.mechanicId = req.user.id;
  }
  const orderId = await checkInBooking(booking, { userId: req.user.id, ...body });
  res.status(201).json({ orderId });
});

// "Hoje": the day's movement for everyone in the shop, without money.
router.get('/today', async (req, res) => {
  const day = DateTime.now().setZone(TZ).toISODate();
  const { from, to } = range(day, day);
  const [bookings, orders] = await Promise.all([
    db('bookings as b')
      .join('customers as c', 'c.id', 'b.customerId')
      .join('motorcycles as m', 'm.id', 'b.motorcycleId')
      .leftJoin('bays as y', 'y.id', 'b.bayId')
      .leftJoin('users as u', 'u.id', 'b.mechanicId')
      .leftJoin('service_orders as o', 'o.bookingId', 'b.id')
      .select('b.id', 'b.code', 'b.startAt', 'b.endAt', 'b.status', 'b.dropOff', 'b.problemDescription', 'b.mechanicId',
        'c.name as customerName', 'm.brand', 'm.model', 'm.plate', 'y.name as bayName', 'u.name as mechanicName', 'o.id as orderId', 'b.motorcycleId')
      .select(db.raw(`(SELECT count(*)::int FROM order_findings f JOIN service_orders fo ON fo.id = f."serviceOrderId"
        WHERE f."motorcycleId" = b."motorcycleId" AND f.decision IN ('OPEN','LATER','DECLINED') AND f."resolvedAt" IS NULL
          AND fo.status <> 'CANCELLED' AND fo.id IS DISTINCT FROM o.id) AS "pendingFindings"`))
      .select(db.raw(`(SELECT string_agg(s."nameSnapshot", ', ') FROM booking_services s WHERE s."bookingId" = b.id) AS services`))
      .where('b.startAt', '<', to).where('b.endAt', '>', from)
      .whereNot('b.status', 'CANCELLED')
      .orderBy('b.startAt'),
    db('service_orders as o')
      .join('customers as c', 'c.id', 'o.customerId')
      .join('motorcycles as m', 'm.id', 'o.motorcycleId')
      .leftJoin('users as u', 'u.id', 'o.mechanicId')
      .select('o.id', 'o.number', 'o.status', 'o.quoteStatus', 'o.mechanicId', 'o.createdAt', 'o.updatedAt',
        'c.name as customerName', 'm.brand', 'm.model', 'm.plate', 'u.name as mechanicName')
      .whereIn('o.status', ['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL', 'APPROVED', 'IN_PROGRESS', 'WAITING_PARTS', 'READY'])
      .orderBy('o.createdAt'),
  ]);
  res.json({ day, me: req.user.id, bookings, orders });
});

router.get('/blocks', async (req, res) => {
  const q = z.object({ from: dateStr, to: dateStr }).parse(req.query);
  const { from, to } = range(q.from, q.to);
  res.json({ blocks: await db('time_blocks').where('startAt', '<', to).where('endAt', '>', from).orderBy('startAt') });
});

router.post('/blocks', requireRole(...STAFF), async (req, res) => {
  const body = z.object({
    startAt: z.string().min(10),
    endAt: z.string().min(10),
    reason: z.string().trim().min(2, 'Informe o motivo.').max(120),
    bayId: z.number().int().nullable().optional(),
    userId: z.number().int().nullable().optional(),
  }).parse(req.body);
  const startAt = new Date(body.startAt);
  const endAt = new Date(body.endAt);
  if (!(endAt > startAt)) throw badRequest('O fim do bloqueio precisa ser depois do início.');
  const [row] = await db('time_blocks').insert({ startAt, endAt, reason: body.reason, bayId: body.bayId || null, userId: body.userId || null }).returning('*');
  await audit(req.user.id, 'block.create', 'time_block', row.id);
  res.status(201).json({ block: row });
});

router.delete('/blocks/:id', requireRole(...STAFF), async (req, res) => {
  await db('time_blocks').where({ id: Number(req.params.id) }).del();
  await audit(req.user.id, 'block.delete', 'time_block', Number(req.params.id));
  res.json({ ok: true });
});

export default router;
