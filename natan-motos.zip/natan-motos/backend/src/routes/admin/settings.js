import { Router } from 'express';
import bcrypt from 'bcryptjs';
import QRCode from 'qrcode';
import { z } from 'zod';
import { DateTime } from 'luxon';
import { db } from '../../lib/db.js';
import { TZ, normalizePhone } from '../../lib/util.js';
import { badRequest, notFound, forbidden } from '../../lib/errors.js';
import { requireRole, STAFF } from '../../middleware/auth.js';
import { audit } from '../../services/audit.js';
import { getSettings } from '../../services/availability.js';
import { getBookingFull } from '../../services/bookings.js';
import { getOrderFull } from '../../services/orders.js';
import {
  messageTexts, bookingUrl, bookingVars, orderVars, reminderVars, baseVars, render, TEMPLATE_KEYS,
} from '../../services/messages.js';
import { notify, isApiConfigured } from '../../services/whatsapp/index.js';
import { backupStatus } from '../../services/backups.js';

const router = Router();
const hm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Use o formato HH:MM.');

router.get('/settings', async (_req, res) => {
  const [settings, hours, bays] = await Promise.all([
    getSettings(db),
    db('business_hours').orderBy('weekday'),
    db('bays').orderBy('order'),
  ]);
  const texts = messageTexts(settings);
  const vars = { ...baseVars(settings), link: bookingUrl(settings, 'whatsapp') };
  res.json({
    settings: { ...settings, messageTexts: texts },
    hours,
    bays,
    whatsappApiConfigured: isApiConfigured(),
    links: {
      instagram: bookingUrl(settings, 'instagram'),
      whatsapp: bookingUrl(settings, 'whatsapp'),
      direct: bookingUrl(settings),
    },
    whatsappBusinessTexts: { greeting: render(texts.greeting, vars), away: render(texts.away, vars) },
  });
});

// Backup log written by the backup container on the server (see docs/BACKUP-E-SEGURANCA.md)
router.get('/system/backups', requireRole('OWNER'), async (_req, res) => {
  res.json(await backupStatus(db));
});

const settingsSchema = z.object({
  shopName: z.string().trim().min(2).max(60),
  ownerName: z.string().trim().min(2).max(60),
  address: z.string().trim().min(5).max(200),
  city: z.string().trim().min(2).max(80),
  mapQuery: z.string().trim().min(5).max(200),
  whatsappNumber: z.string().min(10),
  instagram: z.string().trim().max(40).transform((s) => s.replace(/^@/, '')),
  privacyContact: z.string().trim().min(3).max(120),
  publicBaseUrl: z.url('Informe o endereço completo do site, com https://'),
  slotMinutes: z.union([z.literal(15), z.literal(30), z.literal(60)]),
  minNoticeHours: z.number().int().min(0).max(72),
  maxDaysAhead: z.number().int().min(1).max(120),
  cancelNoticeHours: z.number().int().min(0).max(72),
  noShowAfterMinutes: z.number().int().min(5).max(240),
  noShowFlagThreshold: z.number().int().min(1).max(10),
  forceDropOffMinutes: z.number().int().min(30).max(720),
  autoConfirm: z.boolean(),
  defaultWarrantyDays: z.number().int().min(0).max(3650),
  oilReminderKm: z.number().int().min(500).max(20000),
  oilReminderDays: z.number().int().min(15).max(365),
  scheduleView: z.enum(['bay', 'mechanic']),
  whatsappLevel2Enabled: z.boolean(),
  sellsParts: z.boolean(),
  mechanicCanQuote: z.boolean(),
  partsNotice: z.string().trim().max(400).nullable(),
  messageTexts: z.partialRecord(z.enum(TEMPLATE_KEYS), z.string().min(5).max(1000)),
}).partial();

router.patch('/settings', requireRole('OWNER'), async (req, res) => {
  const body = settingsSchema.parse(req.body);
  if (body.whatsappNumber) body.whatsappNumber = normalizePhone(body.whatsappNumber);
  if (body.messageTexts) {
    const current = messageTexts(await getSettings(db));
    body.messageTexts = JSON.stringify({ ...current, ...body.messageTexts });
  }
  if (body.whatsappLevel2Enabled && !isApiConfigured()) {
    throw badRequest('Para ligar o Nível 2, configure antes as chaves da API do WhatsApp no servidor (veja o guia de implantação).');
  }
  await db('settings').where({ id: 1 }).update({ ...body, updatedAt: new Date() });
  await audit(req.user.id, 'settings.update', 'settings', 1, { fields: Object.keys(body) });
  res.json({ ok: true });
});

router.put('/settings/hours', requireRole('OWNER'), async (req, res) => {
  const rows = z.array(z.object({
    weekday: z.number().int().min(0).max(6),
    closed: z.boolean(),
    opensAt: hm,
    closesAt: hm,
    breakStart: hm.nullable().optional(),
    breakEnd: hm.nullable().optional(),
  })).length(7).parse(req.body.hours);
  for (const r of rows) {
    if (!r.closed && r.closesAt <= r.opensAt) throw badRequest('O horário de fechamento precisa ser depois da abertura.');
    if ((r.breakStart && !r.breakEnd) || (!r.breakStart && r.breakEnd)) throw badRequest('Informe início e fim do intervalo, ou deixe os dois vazios.');
    if (r.breakStart && (r.breakStart <= r.opensAt || r.breakEnd >= r.closesAt || r.breakEnd <= r.breakStart)) {
      throw badRequest('O intervalo precisa ficar dentro do horário de funcionamento.');
    }
  }
  await db.transaction(async (trx) => {
    for (const r of rows) {
      await trx('business_hours').where({ weekday: r.weekday }).update({ ...r, breakStart: r.breakStart || null, breakEnd: r.breakEnd || null });
    }
  });
  await audit(req.user.id, 'settings.hours', 'settings', 1);
  res.json({ ok: true });
});

router.post('/bays', requireRole('OWNER'), async (req, res) => {
  const { name } = z.object({ name: z.string().trim().min(2).max(40) }).parse(req.body);
  const max = await db('bays').max({ m: 'order' }).first();
  const [row] = await db('bays').insert({ name, order: (max.m || 0) + 1 }).returning('*');
  res.status(201).json({ bay: row });
});

router.patch('/bays/:id', requireRole('OWNER'), async (req, res) => {
  const body = z.object({ name: z.string().trim().min(2).max(40).optional(), active: z.boolean().optional(), order: z.number().int().optional() }).parse(req.body);
  const [row] = await db('bays').where({ id: Number(req.params.id) }).update(body).returning('*');
  if (!row) throw notFound('Elevador não encontrado.');
  res.json({ bay: row });
});

router.get('/users', requireRole(...STAFF), async (_req, res) => {
  res.json({ users: await db('users').select('id', 'name', 'email', 'role', 'commissionPercent', 'active', 'createdAt').orderBy('name') });
});

const userSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome.').max(60),
  email: z.email('E-mail inválido.').transform((s) => s.toLowerCase()),
  role: z.enum(['OWNER', 'MANAGER', 'ATTENDANT', 'MECHANIC']),
  commissionPercent: z.number().int().min(0).max(100).optional(),
  active: z.boolean().optional(),
  password: z.string().min(8, 'A senha precisa ter pelo menos 8 caracteres.').optional(),
});

router.post('/users', requireRole('OWNER'), async (req, res) => {
  const { password, ...body } = userSchema.parse(req.body);
  if (!password) throw badRequest('Defina uma senha inicial.');
  const [row] = await db('users').insert({ ...body, passwordHash: await bcrypt.hash(password, 12) }).returning(['id', 'name', 'email', 'role', 'commissionPercent', 'active']);
  await audit(req.user.id, 'user.create', 'user', row.id);
  res.status(201).json({ user: row });
});

router.patch('/users/:id', requireRole('OWNER'), async (req, res) => {
  const id = Number(req.params.id);
  const { password, ...body } = userSchema.partial().parse(req.body);
  const target = await db('users').where({ id }).first();
  if (!target) throw notFound('Usuário não encontrado.');
  if (target.role === 'OWNER' && ((body.role && body.role !== 'OWNER') || body.active === false)) {
    const owners = await db('users').where({ role: 'OWNER', active: true }).count({ n: '*' }).first();
    if (owners.n <= 1) throw badRequest('Precisa existir pelo menos um administrador ativo.');
  }
  const patch = { ...body, updatedAt: new Date() };
  if (password) Object.assign(patch, { passwordHash: await bcrypt.hash(password, 12), tokenVersion: target.tokenVersion + 1 });
  if (body.active === false || body.role) patch.tokenVersion = target.tokenVersion + 1; // ends their sessions
  await db('users').where({ id }).update(patch);
  await audit(req.user.id, 'user.update', 'user', id, { fields: Object.keys(body).concat(password ? ['password'] : []) });
  res.json({ ok: true });
});

router.get('/qrcode.png', requireRole(...STAFF), async (req, res) => {
  const { src } = z.object({ src: z.enum(['instagram', 'whatsapp', 'direct']).default('direct') }).parse(req.query);
  const settings = await getSettings(db);
  const png = await QRCode.toBuffer(bookingUrl(settings, src === 'direct' ? 'direct' : src), {
    width: 800, margin: 2, color: { dark: '#0C0C0C', light: '#FFFFFF' }, errorCorrectionLevel: 'M',
  });
  res.set('Content-Type', 'image/png');
  res.set('Content-Disposition', 'attachment; filename="qrcode-agendamento.png"');
  res.send(png);
});

// ---------- Customer messages (WhatsApp Level 1 link or Level 2 API) ----------
router.post('/notify', async (req, res) => {
  const body = z.object({
    template: z.enum(['confirmation', 'reminder24h', 'quoteReady', 'bikeReady', 'maintenance']),
    bookingId: z.number().int().optional(),
    orderId: z.number().int().optional(),
    reminderId: z.number().int().optional(),
  }).parse(req.body);
  const settings = await getSettings(db);
  let phone;
  let vars;
  if (body.template === 'confirmation' || body.template === 'reminder24h') {
    if (!body.bookingId) throw badRequest('Informe o agendamento.');
    const b = await getBookingFull({ id: body.bookingId });
    if (req.user.role === 'MECHANIC' && b.mechanicId !== req.user.id) throw forbidden();
    phone = b.customer.phone;
    vars = bookingVars(settings, b, b.customer, b.motorcycle, b.services);
    if (body.template === 'reminder24h') await db('bookings').where({ id: b.id }).update({ reminderSentAt: new Date() });
  } else if (body.template === 'maintenance') {
    if (req.user.role === 'MECHANIC') throw forbidden();
    const r = await db('maintenance_reminders').where({ id: body.reminderId || 0 }).first();
    if (!r) throw notFound('Lembrete não encontrado.');
    const bike = await db('motorcycles').where({ id: r.motorcycleId }).first();
    const customer = await db('customers').where({ id: bike.customerId }).first();
    if (!customer.reminderConsentAt || customer.reminderConsentRevokedAt) {
      throw badRequest('Esse cliente não autorizou lembretes de revisão. Registre o consentimento no cadastro antes de enviar.', 'NO_CONSENT');
    }
    phone = customer.phone;
    vars = reminderVars(settings, r, customer, bike);
    await db('maintenance_reminders').where({ id: r.id }).update({ sentAt: new Date() });
  } else {
    if (!body.orderId) throw badRequest('Informe a OS.');
    const o = await getOrderFull({ id: body.orderId });
    if (req.user.role === 'MECHANIC') {
      if (o.mechanicId !== req.user.id) throw forbidden();
      if (body.template === 'quoteReady' && !settings.mechanicCanQuote) throw forbidden('Quem envia o orçamento é o dono da oficina.');
    }
    phone = o.customer.phone;
    vars = orderVars(settings, o, o.customer, o.motorcycle);
  }
  if (!/^\d{12,13}$/.test(phone)) throw badRequest('Esse cliente não tem um WhatsApp válido.');
  const result = await notify({ settings, template: body.template, phone, vars });
  await audit(req.user.id, 'notify', body.template, body.bookingId || body.orderId || body.reminderId, { mode: result.mode });
  res.json(result);
});

// ---------- Maintenance reminders ----------
router.get('/reminders', requireRole(...STAFF), async (req, res) => {
  const { scope } = z.object({ scope: z.enum(['due', 'upcoming', 'sent']).default('due') }).parse(req.query);
  const today = DateTime.now().setZone(TZ);
  const rows = await db('maintenance_reminders as r').join('motorcycles as m', 'm.id', 'r.motorcycleId').join('customers as c', 'c.id', 'm.customerId')
    .select('r.*', 'm.brand', 'm.model', 'm.plate', 'm.lastMileage', 'c.id as customerId', 'c.name as customerName', 'c.phone as customerPhone',
      'c.reminderConsentAt', 'c.reminderConsentRevokedAt')
    .whereNull('r.doneAt').whereNull('c.anonymizedAt')
    .modify((qb) => {
      if (scope === 'due') qb.whereNull('r.sentAt').where('r.dueDate', '<=', today.plus({ days: 7 }).toISODate());
      if (scope === 'upcoming') qb.whereNull('r.sentAt').where('r.dueDate', '>', today.plus({ days: 7 }).toISODate());
      if (scope === 'sent') qb.whereNotNull('r.sentAt');
    })
    .orderBy('r.dueDate');
  res.json({ reminders: rows.map((r) => ({ ...r, consent: Boolean(r.reminderConsentAt && !r.reminderConsentRevokedAt) })) });
});

router.post('/reminders', requireRole(...STAFF), async (req, res) => {
  const body = z.object({
    motorcycleId: z.number().int(),
    type: z.enum(['OIL_CHANGE', 'REVIEW']),
    dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    dueMileage: z.number().int().min(0).nullable().optional(),
  }).parse(req.body);
  const [row] = await db('maintenance_reminders').insert(body).returning('*');
  res.status(201).json({ reminder: row });
});

router.post('/reminders/:id/done', requireRole(...STAFF), async (req, res) => {
  await db('maintenance_reminders').where({ id: Number(req.params.id) }).update({ doneAt: new Date() });
  res.json({ ok: true });
});

export default router;
