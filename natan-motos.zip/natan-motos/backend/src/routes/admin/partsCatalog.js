import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db } from '../../lib/db.js';
import { badRequest, notFound } from '../../lib/errors.js';
import { requireRole, SYSTEM } from '../../middleware/auth.js';
import { audit } from '../../services/audit.js';
import { storage, detectImage } from '../../services/storage.js';
import { catalogImageUrl } from '../../services/orders.js';

// Catalog of motorcycle parts (with an image each) used to build quotes.
const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1 } });
const view = (p) => ({ ...p, imageUrl: catalogImageUrl(p), hasPhoto: Boolean(p.photoUrl) });

router.get('/parts-catalog', async (req, res) => {
  const q = z.object({ q: z.string().max(60).optional(), category: z.string().max(60).optional(), all: z.string().optional() }).parse(req.query);
  const term = (q.q || '').trim();
  const rows = await db('catalog_parts')
    .modify((qb) => {
      if (!q.all) qb.where({ active: true });
      if (q.category) qb.where({ category: q.category });
      if (term) qb.where((w) => w.whereILike('name', `%${term}%`).orWhereILike('description', `%${term}%`));
    })
    .orderBy(['order', 'name']);
  const categories = await db('catalog_parts').distinct('category').orderBy('category');
  res.json({ parts: rows.map(view), categories: categories.map((c) => c.category) });
});

const schema = z.object({
  name: z.string().trim().min(2, 'Informe o nome da peça.').max(80),
  category: z.string().trim().min(2, 'Informe o sistema da moto.').max(40),
  description: z.string().trim().max(300).nullable().optional(),
  active: z.boolean().optional(),
});

router.post('/parts-catalog', requireRole(...SYSTEM), async (req, res) => {
  const body = schema.parse(req.body);
  const max = await db('catalog_parts').max({ m: 'order' }).first();
  const [row] = await db('catalog_parts').insert({ ...body, order: (max.m || 0) + 1 }).returning('*');
  await audit(req.user.id, 'catalog.create', 'catalog_part', row.id);
  res.status(201).json({ part: view(row) });
});

router.patch('/parts-catalog/:id', requireRole(...SYSTEM), async (req, res) => {
  const body = schema.partial().parse(req.body);
  const [row] = await db('catalog_parts').where({ id: Number(req.params.id) }).update({ ...body, updatedAt: new Date() }).returning('*');
  if (!row) throw notFound('Peça não encontrada.');
  res.json({ part: view(row) });
});

// Real photo of the part (JPG or PNG, so it can also go into the PDF)
router.post('/parts-catalog/:id/photo', requireRole(...SYSTEM), upload.single('photo'), async (req, res) => {
  const part = await db('catalog_parts').where({ id: Number(req.params.id) }).first();
  if (!part) throw notFound('Peça não encontrada.');
  if (!req.file) throw badRequest('Escolha uma foto.');
  if (!['jpg', 'png'].includes(detectImage(req.file.buffer))) throw badRequest('Envie a foto em JPG ou PNG.');
  const url = await storage.save(req.file.buffer);
  if (part.photoUrl) await storage.remove(part.photoUrl);
  const [row] = await db('catalog_parts').where({ id: part.id }).update({ photoUrl: url, updatedAt: new Date() }).returning('*');
  await audit(req.user.id, 'catalog.photo', 'catalog_part', part.id);
  res.json({ part: view(row) });
});

// Back to the built-in illustration
router.delete('/parts-catalog/:id/photo', requireRole(...SYSTEM), async (req, res) => {
  const part = await db('catalog_parts').where({ id: Number(req.params.id) }).first();
  if (!part) throw notFound('Peça não encontrada.');
  if (part.photoUrl) await storage.remove(part.photoUrl);
  const [row] = await db('catalog_parts').where({ id: part.id }).update({ photoUrl: null, updatedAt: new Date() }).returning('*');
  res.json({ part: view(row) });
});

export default router;
