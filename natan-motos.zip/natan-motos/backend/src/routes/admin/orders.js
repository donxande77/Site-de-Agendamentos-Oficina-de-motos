import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db } from '../../lib/db.js';
import { badRequest, forbidden, notFound } from '../../lib/errors.js';
import { requireRole, STAFF, BUSINESS } from '../../middleware/auth.js';
import {
  createOrder, getOrderFull, addItem, updateItem, removeItem, sendQuote, changeStatus, addPayment, ORDER_FLOW, setDiagnosisFee,
} from '../../services/orders.js';
import { orderPdf } from '../../services/pdf.js';
import { storage } from '../../services/storage.js';
import { audit } from '../../services/audit.js';
import { getSettings } from '../../services/availability.js';
import { addFinding, updateFinding, removeFinding, resolveFinding } from '../../services/motoRecord.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 6 * 1024 * 1024, files: 10 } });
const MECHANIC_STATUSES = ['DIAGNOSIS', 'IN_PROGRESS', 'WAITING_PARTS', 'READY'];
const CLOSED = ['DELIVERED', 'CANCELLED'];
const CLOSED_MSG = 'Esta OS já foi finalizada. Peça ao dono da oficina para corrigir o relatório.';
const ACTIVE = ['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL', 'APPROVED', 'IN_PROGRESS', 'WAITING_PARTS', 'READY'];

// What the logged-in person may do on this OS.
//   Administrator: everything.
//   Mechanic: sees every OS; works (diagnosis, photos, customer parts, progress) on his own or on one
//   without a mechanic, which then becomes his; services, prices and sending the quote only when the
//   administrator turned on "Mecânico pode lançar serviços e valores no orçamento".
export function orderPermissions(user, order, settings) {
  if (user.role !== 'MECHANIC') return { work: true, quote: true, pay: true, manage: true, claim: false };
  const free = order.mechanicId == null;
  const work = free || order.mechanicId === user.id;
  return { work, quote: work && Boolean(settings.mechanicCanQuote), pay: false, manage: false, claim: free };
}

const DENIED = {
  work: (o) => `Esta OS é do ${o.mechanic?.name || 'outro mecânico'}. Você pode ver, mas não alterar.`,
  quote: () => 'Serviços e valores do orçamento são lançados pelo dono da oficina.',
  pay: () => 'Só o dono da oficina registra pagamentos.',
};

// need: null (just view) | 'work' | 'quote'. A mechanic who works on an OS without a mechanic takes it.
async function loadOrder(req, need = null) {
  const order = await getOrderFull({ id: Number(req.params.id) });
  if (!need) return order;
  const perms = orderPermissions(req.user, order, await getSettings(db));
  if (!perms[need]) throw forbidden(DENIED[need](order));
  if (perms.claim) {
    const n = await db('service_orders').where({ id: order.id }).whereNull('mechanicId').update({ mechanicId: req.user.id });
    if (n) await audit(req.user.id, 'order.claim', 'service_order', order.id, {});
    order.mechanicId = req.user.id;
  }
  return order;
}

async function itemNeed(req) {
  const item = await db('service_order_items').where({ id: Number(req.params.itemId), serviceOrderId: Number(req.params.id) }).first();
  if (!item) throw notFound('Item não encontrado.');
  return item.type === 'CUSTOMER_PART' ? 'work' : 'quote';
}

router.get('/orders', async (req, res) => {
  const q = z.object({
    status: z.string().optional(),
    scope: z.enum(['active', 'all', 'receivable']).default('active'),
    mine: z.enum(['1']).optional(),
    q: z.string().max(60).optional(),
  }).parse(req.query);
  const term = (q.q || '').trim();
  const rows = await db('service_orders as o')
    .join('customers as c', 'c.id', 'o.customerId')
    .join('motorcycles as m', 'm.id', 'o.motorcycleId')
    .leftJoin('users as u', 'u.id', 'o.mechanicId')
    .select('o.id', 'o.number', 'o.status', 'o.quoteStatus', 'o.totalCents', 'o.createdAt', 'o.updatedAt', 'o.deliveredAt', 'o.receivable', 'o.mechanicId',
      'c.name as customerName', 'c.phone as customerPhone', 'm.brand', 'm.model', 'm.plate', 'u.name as mechanicName')
    .select(db.raw('(SELECT COALESCE(SUM("amountCents"),0) FROM payments p WHERE p."serviceOrderId" = o.id) AS "paidCents"'))
    .modify((qb) => {
      if (q.status) qb.whereIn('o.status', q.status.split(','));
      else if (q.scope === 'active') qb.whereIn('o.status', ACTIVE);
      else if (q.scope === 'receivable') qb.where('o.receivable', true);
      if (q.mine) qb.where('o.mechanicId', req.user.id);
      if (q.scope === 'receivable' && req.user.role === 'MECHANIC') qb.whereRaw('false');
      if (term) {
        const plate = term.toUpperCase().replace(/[^A-Z0-9]/g, '');
        qb.where((w) => {
          w.whereILike('c.name', `%${term}%`).orWhere('m.plate', 'like', `%${plate || term}%`);
          if (/^\d+$/.test(term)) w.orWhere('o.number', Number(term));
        });
      }
    })
    .orderBy('o.updatedAt', 'desc')
    .limit(200);
  res.json({ orders: rows, flow: ORDER_FLOW });
});

router.post('/orders', requireRole(...STAFF), async (req, res) => {
  const body = z.object({
    customerId: z.number().int(),
    motorcycleId: z.number().int(),
    mechanicId: z.number().int().nullable().optional(),
    checkInMileage: z.number().int().min(0).nullable().optional(),
    fuelLevel: z.enum(['reserve', 'quarter', 'half', 'three_quarters', 'full']).nullable().optional(),
    checklist: z.object({ items: z.array(z.string()).optional(), damage: z.string().max(500).optional() }).optional(),
    diagnosis: z.string().max(4000).optional(),
  }).parse(req.body);
  const id = await createOrder(body, req.user.id);
  res.status(201).json({ orderId: id });
});

router.get('/orders/:id', async (req, res) => {
  const order = await loadOrder(req);
  const settings = await getSettings(db);
  res.json({ order, flow: ORDER_FLOW, publicBaseUrl: settings.publicBaseUrl, permissions: orderPermissions(req.user, order, settings) });
});

router.patch('/orders/:id', async (req, res) => {
  const order = await loadOrder(req, 'work');
  const isMechanic = req.user.role === 'MECHANIC';
  const body = z.object({
    diagnosis: z.string().max(4000).nullable().optional(),
    checkInMileage: z.number().int().min(0).nullable().optional(),
    fuelLevel: z.enum(['reserve', 'quarter', 'half', 'three_quarters', 'full']).nullable().optional(),
    checklist: z.object({ items: z.array(z.string()).optional(), damage: z.string().max(500).optional() }).nullable().optional(),
    mechanicId: z.number().int().nullable().optional(),
    workDone: z.string().trim().max(4000).nullable().optional(),
    internalNotes: z.string().trim().max(4000).nullable().optional(),
  }).parse(req.body);
  if (isMechanic && body.mechanicId !== undefined) throw forbidden('Só o dono da oficina troca o mecânico.');
  if (isMechanic && CLOSED.includes(order.status)) throw forbidden(CLOSED_MSG);
  for (const k of ['workDone', 'internalNotes', 'diagnosis']) if (body[k] === '') body[k] = null;
  const patch = { ...body, updatedAt: new Date() };
  if (body.checklist !== undefined) patch.checklist = body.checklist ? JSON.stringify(body.checklist) : null;
  await db('service_orders').where({ id: order.id }).update(patch);
  if (body.checkInMileage) await db('motorcycles').where({ id: order.motorcycleId }).update({ lastMileage: body.checkInMileage });
  await audit(req.user.id, 'order.update', 'service_order', order.id, { fields: Object.keys(body) });
  res.json({ order: await getOrderFull({ id: order.id }) });
});

const itemSchema = z.object({
  type: z.enum(['LABOR', 'PART', 'CUSTOMER_PART']),
  catalogPartId: z.number().int().nullable().optional(),
  notes: z.string().trim().max(200).nullable().optional(),
  estimatedPriceCents: z.number().int().min(0).max(100_000_000).nullable().optional(),
  description: z.string().trim().max(200).optional(),
  serviceId: z.number().int().nullable().optional(),
  partId: z.number().int().nullable().optional(),
  quantity: z.number().int().min(1).max(999).default(1),
  unitPriceCents: z.number().int().min(0).max(100_000_000).optional(),
  unitCostCents: z.number().int().min(0).max(100_000_000).optional(),
});

router.post('/orders/:id/items', async (req, res) => {
  const body = itemSchema.parse(req.body);
  const order = await loadOrder(req, body.type === 'CUSTOMER_PART' ? 'work' : 'quote');
  const item = await addItem(order.id, body, req.user.id);
  res.status(201).json({ item });
});

router.patch('/orders/:id/items/:itemId', async (req, res) => {
  const order = await loadOrder(req, await itemNeed(req));
  const body = itemSchema.pick({ description: true, quantity: true, unitPriceCents: true, unitCostCents: true, notes: true, estimatedPriceCents: true }).partial().parse(req.body);
  await updateItem(order.id, Number(req.params.itemId), body, req.user.id);
  res.json({ ok: true });
});

router.delete('/orders/:id/items/:itemId', async (req, res) => {
  const order = await loadOrder(req, await itemNeed(req));
  await removeItem(order.id, Number(req.params.itemId), req.user.id);
  res.json({ ok: true });
});

// Valor do diagnóstico: the mechanic may set it (his OS or one without a mechanic), even without
// permission to add services and prices.
router.put('/orders/:id/diagnosis-fee', async (req, res) => {
  const { amountCents } = z.object({ amountCents: z.number().int().min(0).max(10_000_000).nullable() }).parse(req.body);
  const order = await loadOrder(req, 'work');
  await setDiagnosisFee(order.id, amountCents, req.user.id);
  res.json({ order: await getOrderFull({ id: order.id }) });
});

// Prontuário: defeitos e pontos de atenção encontrados além do que o cliente pediu
const findingSchema = z.object({
  description: z.string().trim().min(3, 'Descreva o que foi encontrado.').max(500),
  severity: z.enum(['URGENT', 'SOON', 'WATCH']).default('SOON'),
  decision: z.enum(['OPEN', 'FIXED', 'LATER', 'DECLINED']).default('OPEN'),
  informed: z.boolean().optional(),
  informedVia: z.enum(['IN_PERSON', 'WHATSAPP', 'PHONE']).nullable().optional(),
  checkMileage: z.number().int().min(0).max(9_999_999).nullable().optional(),
});

async function loadForReport(req) {
  const order = await loadOrder(req, 'work');
  if (req.user.role === 'MECHANIC' && CLOSED.includes(order.status)) throw forbidden(CLOSED_MSG);
  if (order.status === 'CANCELLED') throw badRequest('Esta OS foi cancelada.');
  return order;
}

router.post('/orders/:id/findings', async (req, res) => {
  const body = findingSchema.parse(req.body);
  const order = await loadForReport(req);
  await addFinding(order, body, req.user.id);
  res.status(201).json({ order: await getOrderFull({ id: order.id }) });
});

router.patch('/orders/:id/findings/:findingId', async (req, res) => {
  const body = findingSchema.partial().parse(req.body);
  const order = await loadForReport(req);
  await updateFinding(order, Number(req.params.findingId), body, req.user.id);
  res.json({ order: await getOrderFull({ id: order.id }) });
});

router.delete('/orders/:id/findings/:findingId', async (req, res) => {
  const order = await loadForReport(req);
  await removeFinding(order, Number(req.params.findingId), req.user.id);
  res.json({ order: await getOrderFull({ id: order.id }) });
});

// Pendência de uma visita anterior: "resolvido nesta OS" (ou desfazer)
router.post('/orders/:id/findings/:findingId/resolve', async (req, res) => {
  const { resolved } = z.object({ resolved: z.boolean().default(true) }).parse(req.body || {});
  const order = await loadForReport(req);
  await resolveFinding(order, Number(req.params.findingId), resolved, req.user.id);
  res.json({ order: await getOrderFull({ id: order.id }) });
});

router.post('/orders/:id/send-quote', async (req, res) => {
  await loadOrder(req, 'quote');
  await sendQuote(Number(req.params.id), req.user.id);
  res.json({ order: await getOrderFull({ id: Number(req.params.id) }) });
});

router.post('/orders/:id/status', async (req, res) => {
  const order = await loadOrder(req, 'work');
  const { status, receivable } = z.object({
    status: z.enum(Object.keys(ORDER_FLOW)),
    receivable: z.boolean().optional(),
  }).parse(req.body);
  if (req.user.role === 'MECHANIC' && !MECHANIC_STATUSES.includes(status)) throw forbidden('Esse passo é do dono da oficina.');
  await changeStatus(order.id, status, { userId: req.user.id, receivable });
  res.json({ order: await getOrderFull({ id: order.id }) });
});

router.post('/orders/:id/payments', requireRole(...STAFF), async (req, res) => {
  const body = z.object({
    amountCents: z.number().int().min(1, 'Informe o valor.').max(100_000_000),
    method: z.enum(['PIX', 'CASH', 'DEBIT', 'CREDIT']),
    installments: z.number().int().min(1).max(24).optional(),
    notes: z.string().max(200).optional(),
    paidAt: z.string().optional(),
  }).parse(req.body);
  const payment = await addPayment(Number(req.params.id), body, req.user.id);
  res.status(201).json({ payment });
});

router.delete('/orders/:id/payments/:paymentId', requireRole(...BUSINESS), async (req, res) => {
  const n = await db('payments').where({ id: Number(req.params.paymentId), serviceOrderId: Number(req.params.id) }).del();
  if (!n) throw notFound('Pagamento não encontrado.');
  await audit(req.user.id, 'payment.delete', 'service_order', Number(req.params.id), { paymentId: Number(req.params.paymentId) });
  res.json({ ok: true });
});

router.post('/orders/:id/photos', upload.array('photos', 10), async (req, res) => {
  const order = await loadOrder(req, 'work');
  const files = req.files || [];
  if (!files.length) throw badRequest('Nenhuma foto enviada.');
  if (order.photos.length + files.length > 20) throw badRequest('Limite de 20 fotos por OS.');
  for (const f of files) {
    const url = await storage.save(f.buffer);
    await db('photos').insert({ url, kind: 'checkin', serviceOrderId: order.id });
  }
  res.status(201).json({ order: await getOrderFull({ id: order.id }) });
});

router.delete('/orders/:id/photos/:photoId', requireRole(...STAFF), async (req, res) => {
  const photo = await db('photos').where({ id: Number(req.params.photoId), serviceOrderId: Number(req.params.id) }).first();
  if (!photo) throw notFound('Foto não encontrada.');
  await db('photos').where({ id: photo.id }).del();
  await storage.remove(photo.url);
  res.json({ ok: true });
});

router.get('/orders/:id/pdf', async (req, res) => {
  const order = await loadOrder(req);
  const { type } = z.object({ type: z.enum(['os', 'quote']).default('os') }).parse(req.query);
  const settings = await getSettings(db);
  res.set('Content-Type', 'application/pdf');
  res.set('Content-Disposition', `inline; filename="${type === 'quote' ? 'orcamento' : 'os'}-${order.number}.pdf"`);
  res.set('Cache-Control', 'no-store');
  orderPdf(res, { order, settings, type });
});

export default router;
