import { DateTime } from 'luxon';
import { db } from '../lib/db.js';
import { TZ, randomToken } from '../lib/util.js';
import { badRequest, notFound } from '../lib/errors.js';
import { audit } from './audit.js';
import { findingsOfOrder, bikeSummary } from './motoRecord.js';

// Built-in illustration unless the shop uploaded a real photo
export const catalogImageUrl = (p) => p.photoUrl || (p.slug ? `/parts-img/${p.slug}.png` : null);

export const ORDER_FLOW = {
  OPEN: ['DIAGNOSIS', 'WAITING_APPROVAL', 'APPROVED', 'IN_PROGRESS', 'CANCELLED'],
  DIAGNOSIS: ['WAITING_APPROVAL', 'APPROVED', 'IN_PROGRESS', 'CANCELLED'],
  WAITING_APPROVAL: ['APPROVED', 'DIAGNOSIS', 'CANCELLED'],
  APPROVED: ['IN_PROGRESS', 'WAITING_PARTS', 'READY', 'CANCELLED'],
  IN_PROGRESS: ['WAITING_PARTS', 'READY', 'CANCELLED'],
  WAITING_PARTS: ['IN_PROGRESS', 'READY', 'CANCELLED'],
  READY: ['DELIVERED', 'IN_PROGRESS'],
  DELIVERED: [],
  CANCELLED: [],
};

// Statuses where work was authorised → parts must be taken from stock.
const WORK_STATUSES = ['APPROVED', 'IN_PROGRESS', 'WAITING_PARTS', 'READY', 'DELIVERED'];
const EDITABLE_STATUSES = ['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL', 'APPROVED', 'IN_PROGRESS', 'WAITING_PARTS', 'READY'];

export async function nextOrderNumber(trx = db) {
  const { rows } = await trx.raw("SELECT nextval('service_order_number_seq') AS n");
  return Number(rows[0].n);
}

export async function createOrder({ customerId, motorcycleId, mechanicId, checkInMileage, fuelLevel, checklist, diagnosis }, userId) {
  const bike = await db('motorcycles').where({ id: motorcycleId, customerId }).first();
  if (!bike) throw badRequest('Essa moto não pertence a esse cliente.');
  return db.transaction(async (trx) => {
    const number = await nextOrderNumber(trx);
    const [row] = await trx('service_orders')
      .insert({
        number,
        customerId,
        motorcycleId,
        mechanicId: mechanicId || null,
        checkInMileage: checkInMileage || null,
        fuelLevel: fuelLevel || null,
        checklist: checklist ? JSON.stringify(checklist) : null,
        diagnosis: diagnosis || null,
        approvalToken: randomToken(24),
      })
      .returning('id');
    if (checkInMileage) await trx('motorcycles').where({ id: motorcycleId }).update({ lastMileage: checkInMileage });
    await audit(userId, 'order.create', 'service_order', row.id, { walkIn: true }, trx);
    return row.id;
  });
}

export async function getOrderFull(where) {
  const order = await db('service_orders').where(where).first();
  if (!order) throw notFound('Ordem de serviço não encontrada.');
  const [customer, motorcycle, items, payments, photos, mechanic, booking, findings, bikeHistory] = await Promise.all([
    db('customers').where({ id: order.customerId }).first(),
    db('motorcycles').where({ id: order.motorcycleId }).first(),
    db('service_order_items as i').leftJoin('catalog_parts as c', 'c.id', 'i.catalogPartId')
      .select('i.*', 'c.slug as catalogSlug', 'c.photoUrl as catalogPhotoUrl', 'c.category as catalogCategory')
      .where('i.serviceOrderId', order.id).orderBy('i.id'),
    db('payments as p').leftJoin('users as u', 'u.id', 'p.receivedById').select('p.*', 'u.name as receivedByName').where({ serviceOrderId: order.id }).orderBy('paidAt'),
    db('photos').where({ serviceOrderId: order.id }).orderBy('id'),
    order.mechanicId ? db('users').select('id', 'name').where({ id: order.mechanicId }).first() : null,
    order.bookingId ? db('bookings').select('id', 'code', 'startAt', 'source', 'problemDescription').where({ id: order.bookingId }).first() : null,
    findingsOfOrder(order.id),
    bikeSummary(order.motorcycleId, { excludeOrderId: order.id }),
  ]);
  for (const it of items) {
    it.imageUrl = it.type === 'CUSTOMER_PART' ? catalogImageUrl({ slug: it.catalogSlug, photoUrl: it.catalogPhotoUrl }) : null;
    delete it.catalogSlug; delete it.catalogPhotoUrl;
  }
  const customerParts = items.filter((i) => i.type === 'CUSTOMER_PART');
  const customerPartsEstimateCents = customerParts.reduce((a, i) => a + (i.estimatedPriceCents || 0) * i.quantity, 0);
  const paidCents = payments.reduce((a, p) => a + p.amountCents, 0);
  const laborCents = items.filter((i) => i.type === 'LABOR').reduce((a, i) => a + i.quantity * i.unitPriceCents, 0);
  const partsCents = items.filter((i) => i.type === 'PART').reduce((a, i) => a + i.quantity * i.unitPriceCents, 0);
  return {
    ...order, customer, motorcycle, items, payments, photos, mechanic, booking, findings, bikeHistory, paidCents, laborCents, partsCents,
    customerParts, customerPartsEstimateCents, balanceCents: order.totalCents - paidCents,
    diagnosisFeeCents: items.find((i) => i.isDiagnosisFee)?.unitPriceCents ?? null,
    diagnosisFeeEditable: DIAGNOSIS_FEE_STATUSES.includes(order.status),
  };
}

export async function recalcTotal(trx, orderId) {
  const [{ total }] = await trx('service_order_items')
    .where({ serviceOrderId: orderId })
    .whereNot('type', 'CUSTOMER_PART')
    .select(trx.raw('COALESCE(SUM("quantity" * "unitPriceCents"), 0) AS total'));
  await trx('service_orders').where({ id: orderId }).update({ totalCents: Number(total), updatedAt: new Date() });
}

async function moveStock(trx, partId, delta) {
  if (!partId || !delta) return;
  await trx('parts').where({ id: partId }).update({ stock: trx.raw('"stock" + ?', [delta]), updatedAt: new Date() });
}

async function deductAllStock(trx, order) {
  if (order.stockDeducted) return;
  const items = await trx('service_order_items').where({ serviceOrderId: order.id, type: 'PART' }).whereNotNull('partId');
  for (const i of items) await moveStock(trx, i.partId, -i.quantity);
  await trx('service_orders').where({ id: order.id }).update({ stockDeducted: true });
}

async function returnAllStock(trx, order) {
  if (!order.stockDeducted) return;
  const items = await trx('service_order_items').where({ serviceOrderId: order.id, type: 'PART' }).whereNotNull('partId');
  for (const i of items) await moveStock(trx, i.partId, i.quantity);
  await trx('service_orders').where({ id: order.id }).update({ stockDeducted: false });
}

function assertEditable(order) {
  if (!EDITABLE_STATUSES.includes(order.status)) throw badRequest('Essa OS já foi finalizada e não pode ser alterada.');
}

export async function addItem(orderId, item, userId) {
  return db.transaction(async (trx) => {
    const order = await trx('service_orders').where({ id: orderId }).forUpdate().first();
    if (!order) throw notFound('Ordem de serviço não encontrada.');
    assertEditable(order);
    let { description, unitPriceCents, unitCostCents = 0 } = item;
    if (item.type === 'PART' && item.partId) {
      const part = await trx('parts').where({ id: item.partId }).first();
      if (!part) throw badRequest('Peça não encontrada.');
      description = description || part.name;
      unitPriceCents = unitPriceCents ?? part.priceCents;
      unitCostCents = item.unitCostCents ?? part.costCents;
    }
    let catalogPartId = null;
    if (item.type === 'CUSTOMER_PART') {
      // Part the customer buys elsewhere: listed in the quote, never charged or taken from stock
      if (item.catalogPartId) {
        const cp = await trx('catalog_parts').where({ id: item.catalogPartId }).first();
        if (!cp) throw badRequest('Peça não encontrada no catálogo.');
        catalogPartId = cp.id;
        description = description || cp.name;
      }
      unitPriceCents = 0;
      unitCostCents = 0;
    }
    if (item.type === 'LABOR' && item.serviceId) {
      const svc = await trx('services').where({ id: item.serviceId }).first();
      if (!svc) throw badRequest('Serviço não encontrado.');
      description = description || svc.name;
      unitPriceCents = unitPriceCents ?? svc.basePriceCents ?? 0;
    }
    if (!description) throw badRequest('Descreva o item.');
    const [row] = await trx('service_order_items')
      .insert({
        serviceOrderId: orderId,
        type: item.type,
        description,
        serviceId: item.serviceId || null,
        partId: item.type === 'PART' ? item.partId || null : null,
        catalogPartId,
        notes: item.notes?.trim() || null,
        estimatedPriceCents: item.type === 'CUSTOMER_PART' ? item.estimatedPriceCents ?? null : null,
        quantity: item.quantity || 1,
        unitPriceCents: unitPriceCents ?? 0,
        unitCostCents,
      })
      .returning('*');
    if (order.stockDeducted && row.partId) await moveStock(trx, row.partId, -row.quantity);
    await recalcTotal(trx, orderId);
    await audit(userId, 'order.item.add', 'service_order', orderId, { itemId: row.id }, trx);
    return row;
  });
}

export async function updateItem(orderId, itemId, patch, userId) {
  return db.transaction(async (trx) => {
    const order = await trx('service_orders').where({ id: orderId }).forUpdate().first();
    if (!order) throw notFound('Ordem de serviço não encontrada.');
    assertEditable(order);
    const item = await trx('service_order_items').where({ id: itemId, serviceOrderId: orderId }).first();
    if (!item) throw notFound('Item não encontrado.');
    if (order.stockDeducted && item.partId && patch.quantity !== undefined) {
      await moveStock(trx, item.partId, item.quantity - patch.quantity);
    }
    if (item.type === 'CUSTOMER_PART') { delete patch.unitPriceCents; delete patch.unitCostCents; } else delete patch.estimatedPriceCents;
    await trx('service_order_items').where({ id: itemId }).update(patch);
    await recalcTotal(trx, orderId);
    await audit(userId, 'order.item.update', 'service_order', orderId, { itemId, fields: Object.keys(patch) }, trx);
  });
}

export async function removeItem(orderId, itemId, userId) {
  return db.transaction(async (trx) => {
    const order = await trx('service_orders').where({ id: orderId }).forUpdate().first();
    if (!order) throw notFound('Ordem de serviço não encontrada.');
    assertEditable(order);
    const item = await trx('service_order_items').where({ id: itemId, serviceOrderId: orderId }).first();
    if (!item) throw notFound('Item não encontrado.');
    if (order.stockDeducted && item.partId) await moveStock(trx, item.partId, item.quantity);
    await trx('service_order_items').where({ id: itemId }).del();
    await recalcTotal(trx, orderId);
    await audit(userId, 'order.item.remove', 'service_order', orderId, { itemId }, trx);
  });
}

// Diagnosis fee: the mechanic types it on the spot and it goes into the quote as "Diagnóstico".
// Only before the customer approves; after that, the administrator adjusts it in the services list.
export const DIAGNOSIS_FEE_STATUSES = ['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL'];
export async function setDiagnosisFee(orderId, amountCents, userId) {
  return db.transaction(async (trx) => {
    const order = await trx('service_orders').where({ id: orderId }).forUpdate().first();
    if (!order) throw notFound('Ordem de serviço não encontrada.');
    if (!DIAGNOSIS_FEE_STATUSES.includes(order.status)) {
      throw badRequest('O orçamento já foi decidido. Peça ao dono da oficina para ajustar o valor.');
    }
    const item = await trx('service_order_items').where({ serviceOrderId: orderId, isDiagnosisFee: true }).orderBy('id').first();
    if (item) {
      await trx('service_order_items').where({ id: item.id }).update({ unitPriceCents: amountCents ?? 0 });
    } else if (amountCents) {
      await trx('service_order_items').insert({
        serviceOrderId: orderId, type: 'LABOR', description: 'Diagnóstico', quantity: 1, unitPriceCents: amountCents, isDiagnosisFee: true,
      });
    }
    await recalcTotal(trx, orderId);
    await audit(userId, 'order.diagnosis_fee', 'service_order', orderId, { amountCents }, trx);
  });
}

export async function sendQuote(orderId, userId) {
  const order = await db('service_orders').where({ id: orderId }).first();
  if (!order) throw notFound('Ordem de serviço não encontrada.');
  if (!['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL'].includes(order.status)) throw badRequest('O orçamento dessa OS já foi decidido.');
  const items = await db('service_order_items').where({ serviceOrderId: orderId }).count({ c: '*' }).first();
  if (!items.c) throw badRequest('Adicione pelo menos um item ao orçamento antes de enviar.');
  await db('service_orders').where({ id: orderId }).update({ status: 'WAITING_APPROVAL', quoteStatus: 'SENT', quoteSentAt: new Date(), updatedAt: new Date() });
  await audit(userId, 'order.quote.send', 'service_order', orderId);
}

export async function decideQuote(order, { approve, ip, userId = null }) {
  if (order.quoteStatus === 'APPROVED' || order.quoteStatus === 'REJECTED') {
    throw badRequest('Esse orçamento já foi respondido.');
  }
  if (order.status !== 'WAITING_APPROVAL') throw badRequest('Esse orçamento não está aguardando aprovação.');
  await db.transaction(async (trx) => {
    if (approve) {
      await trx('service_orders').where({ id: order.id }).update({ status: 'APPROVED', quoteStatus: 'APPROVED', approvedAt: new Date(), approvedIp: ip || null, updatedAt: new Date() });
      await deductAllStock(trx, order);
    } else {
      await trx('service_orders').where({ id: order.id }).update({ status: 'DIAGNOSIS', quoteStatus: 'REJECTED', rejectedAt: new Date(), updatedAt: new Date() });
    }
    await audit(userId, approve ? 'order.quote.approve' : 'order.quote.reject', 'service_order', order.id, { by: userId ? 'staff' : 'customer' }, trx);
  });
}

export async function changeStatus(orderId, nextStatus, { userId, receivable = false } = {}) {
  return db.transaction(async (trx) => {
    const order = await trx('service_orders').where({ id: orderId }).forUpdate().first();
    if (!order) throw notFound('Ordem de serviço não encontrada.');
    if (order.status === nextStatus) return;
    if (!ORDER_FLOW[order.status].includes(nextStatus)) {
      throw badRequest('Essa mudança de status não é permitida.', 'INVALID_TRANSITION');
    }
    const patch = { status: nextStatus, updatedAt: new Date() };

    if (nextStatus === 'APPROVED' && order.quoteStatus !== 'APPROVED') {
      Object.assign(patch, { quoteStatus: 'APPROVED', approvedAt: new Date(), approvedIp: 'balcao' });
    }
    if (WORK_STATUSES.includes(nextStatus)) await deductAllStock(trx, order);
    if (nextStatus === 'CANCELLED') await returnAllStock(trx, order);

    if (nextStatus === 'DELIVERED') {
      const [{ paid }] = await trx('payments').where({ serviceOrderId: orderId }).select(trx.raw('COALESCE(SUM("amountCents"),0) AS paid'));
      const owes = order.totalCents - Number(paid);
      if (owes > 0 && !receivable) {
        throw badRequest('Ainda falta receber parte do valor. Registre o pagamento ou marque como "a receber".', 'UNPAID');
      }
      const settings = await trx('settings').where({ id: 1 }).first();
      const items = await trx('service_order_items as i').leftJoin('services as s', 's.id', 'i.serviceId').select('s.warrantyDays', 's.isOilChange').where('i.serviceOrderId', orderId);
      const warrantyDays = Math.max(settings.defaultWarrantyDays, ...items.map((i) => i.warrantyDays || 0));
      const now = DateTime.now().setZone(TZ);
      Object.assign(patch, { deliveredAt: now.toJSDate(), warrantyUntil: now.plus({ days: warrantyDays }).toJSDate(), receivable: owes > 0 });
      await trx('customers').where({ id: order.customerId }).update({ lastServiceAt: now.toJSDate() });
      if (items.some((i) => i.isOilChange)) {
        const bike = await trx('motorcycles').where({ id: order.motorcycleId }).first();
        const baseKm = order.checkInMileage || bike.lastMileage;
        await trx('maintenance_reminders').insert({
          motorcycleId: order.motorcycleId,
          serviceOrderId: order.id,
          type: 'OIL_CHANGE',
          dueDate: now.plus({ days: settings.oilReminderDays }).toISODate(),
          dueMileage: baseKm ? baseKm + settings.oilReminderKm : null,
        });
      }
    }
    await trx('service_orders').where({ id: orderId }).update(patch);
    await audit(userId, 'order.status', 'service_order', orderId, { from: order.status, to: nextStatus }, trx);
  });
}

export async function addPayment(orderId, { amountCents, method, installments = 1, notes, paidAt }, userId) {
  const order = await db('service_orders').where({ id: orderId }).first();
  if (!order) throw notFound('Ordem de serviço não encontrada.');
  if (order.status === 'CANCELLED') throw badRequest('Essa OS foi cancelada.');
  const [row] = await db('payments')
    .insert({
      serviceOrderId: orderId,
      amountCents,
      method,
      installments: method === 'CREDIT' ? installments : 1,
      notes: notes || null,
      paidAt: paidAt ? new Date(paidAt) : new Date(),
      receivedById: userId,
    })
    .returning('*');
  // If it was delivered as receivable and is now fully paid, clear the flag
  const [{ paid }] = await db('payments').where({ serviceOrderId: orderId }).select(db.raw('COALESCE(SUM("amountCents"),0) AS paid'));
  if (order.receivable && Number(paid) >= order.totalCents) await db('service_orders').where({ id: orderId }).update({ receivable: false });
  await audit(userId, 'payment.create', 'service_order', orderId, { paymentId: row.id });
  return row;
}
