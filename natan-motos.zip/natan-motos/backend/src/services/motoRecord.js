// Prontuário da moto: tudo o que a oficina já fez e encontrou numa moto, visita por visita.
import { db } from '../lib/db.js';
import { badRequest, notFound } from '../lib/errors.js';
import { audit } from './audit.js';

const ACTIVE = ['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL', 'APPROVED', 'IN_PROGRESS', 'WAITING_PARTS', 'READY'];
// Pendência = algo que ficou para depois ou o cliente não quis, e ainda não foi resolvido em outra visita
const PENDING = ['OPEN', 'LATER', 'DECLINED'];

const findingCols = [
  'f.*', 'u.name as informedByName', 'o.number as orderNumber', 'o.createdAt as orderDate', 'r.number as resolvedOrderNumber',
];
const findingsQuery = () => db('order_findings as f')
  .join('service_orders as o', 'o.id', 'f.serviceOrderId')
  .leftJoin('service_orders as r', 'r.id', 'f.resolvedOrderId')
  .leftJoin('users as u', 'u.id', 'f.informedById')
  .select(findingCols);

export const findingsOfOrder = (orderId) => findingsQuery().where('f.serviceOrderId', orderId).orderBy('f.id');

// Pendências de visitas anteriores (não as desta OS), da mais grave para a menos grave
export function pendingFindings(motorcycleId, { excludeOrderId = null } = {}) {
  return findingsQuery()
    .where('f.motorcycleId', motorcycleId)
    .whereIn('f.decision', PENDING)
    .whereNull('f.resolvedAt')
    .whereNot('o.status', 'CANCELLED')
    .modify((qb) => { if (excludeOrderId) qb.whereNot('f.serviceOrderId', excludeOrderId); })
    .orderByRaw(`CASE f.severity WHEN 'URGENT' THEN 0 WHEN 'SOON' THEN 1 ELSE 2 END, f."createdAt" DESC`);
}

// Resumo para a agenda e a OS: quantas visitas, a última e o que ficou pendente
export async function bikeSummary(motorcycleId, { excludeOrderId = null } = {}) {
  const [visits, last, pending] = await Promise.all([
    db('service_orders').where({ motorcycleId }).whereNot('status', 'CANCELLED').count({ n: '*' }).first(),
    db('service_orders as o').leftJoin('users as u', 'u.id', 'o.mechanicId')
      .select('o.id', 'o.number', 'o.createdAt', 'o.deliveredAt', 'o.checkInMileage', 'o.workDone', 'o.diagnosis', 'u.name as mechanicName')
      .where('o.motorcycleId', motorcycleId).where('o.status', 'DELIVERED')
      .modify((qb) => { if (excludeOrderId) qb.whereNot('o.id', excludeOrderId); })
      .orderBy('o.deliveredAt', 'desc').first(),
    pendingFindings(motorcycleId, { excludeOrderId }),
  ]);
  return { visits: Number(visits.n), lastVisit: last || null, pendingFindings: pending };
}

// Prontuário completo. Quem é mecânico não vê valores.
export async function motorcycleHistory(motorcycleId, { showMoney }) {
  const motorcycle = await db('motorcycles').where({ id: motorcycleId }).first();
  if (!motorcycle) throw notFound('Moto não encontrada.');
  const [customer, orders, findings, reminders] = await Promise.all([
    db('customers').select('id', 'name', 'phone', 'anonymizedAt').where({ id: motorcycle.customerId }).first(),
    db('service_orders as o').leftJoin('users as u', 'u.id', 'o.mechanicId').leftJoin('bookings as b', 'b.id', 'o.bookingId')
      .select('o.id', 'o.number', 'o.status', 'o.createdAt', 'o.deliveredAt', 'o.warrantyUntil', 'o.checkInMileage', 'o.diagnosis', 'o.workDone',
        'o.internalNotes', 'o.totalCents', 'u.name as mechanicName', 'b.problemDescription')
      .where('o.motorcycleId', motorcycleId).whereNot('o.status', 'CANCELLED')
      .orderBy('o.createdAt', 'desc'),
    findingsQuery().where('f.motorcycleId', motorcycleId).orderBy('f.id'),
    db('maintenance_reminders').where({ motorcycleId }).whereNull('doneAt').orderBy('dueDate'),
  ]);
  const ids = orders.map((o) => o.id);
  const [items, photos] = ids.length ? await Promise.all([
    db('service_order_items').select('serviceOrderId', 'type', 'description', 'quantity').whereIn('serviceOrderId', ids).orderBy('id'),
    db('photos').select('id', 'serviceOrderId', 'url').whereIn('serviceOrderId', ids).orderBy('id'),
  ]) : [[], []];
  const visits = orders.map((o) => ({
    ...o,
    totalCents: showMoney ? o.totalCents : undefined,
    services: items.filter((i) => i.serviceOrderId === o.id && i.type !== 'CUSTOMER_PART').map((i) => (i.quantity > 1 ? `${i.quantity}x ${i.description}` : i.description)),
    customerParts: items.filter((i) => i.serviceOrderId === o.id && i.type === 'CUSTOMER_PART').map((i) => (i.quantity > 1 ? `${i.quantity}x ${i.description}` : i.description)),
    photos: photos.filter((p) => p.serviceOrderId === o.id),
    findings: findings.filter((f) => f.serviceOrderId === o.id),
    resolvedHere: findings.filter((f) => f.resolvedOrderId === o.id && f.serviceOrderId !== o.id),
    active: ACTIVE.includes(o.status),
  }));
  const pending = findings.filter((f) => PENDING.includes(f.decision) && !f.resolvedAt
    && orders.some((o) => o.id === f.serviceOrderId))
    .sort((a, b) => ['URGENT', 'SOON', 'WATCH'].indexOf(a.severity) - ['URGENT', 'SOON', 'WATCH'].indexOf(b.severity));
  const kms = orders.map((o) => o.checkInMileage).filter(Boolean);
  return {
    motorcycle, customer, visits, pendingFindings: pending, reminders,
    stats: {
      visits: orders.length,
      firstVisit: orders.at(-1)?.createdAt || null,
      lastVisit: orders[0]?.createdAt || null,
      lastMileage: motorcycle.lastMileage || (kms.length ? Math.max(...kms) : null),
      totalCents: showMoney ? orders.filter((o) => o.status === 'DELIVERED').reduce((a, o) => a + o.totalCents, 0) : undefined,
    },
  };
}

function informedPatch(body, userId, current = null) {
  if (body.informed === undefined) return {};
  if (!body.informed) return { informedAt: null, informedVia: null, informedById: null };
  if (current?.informedAt && !body.informedVia) return {};
  return { informedAt: new Date(), informedVia: body.informedVia || 'IN_PERSON', informedById: userId };
}

export async function addFinding(order, body, userId) {
  const decision = body.decision || 'OPEN';
  const [row] = await db('order_findings').insert({
    serviceOrderId: order.id,
    motorcycleId: order.motorcycleId,
    description: body.description,
    severity: body.severity || 'SOON',
    decision,
    checkMileage: body.checkMileage ?? null,
    ...informedPatch(body, userId),
    ...(decision === 'FIXED' ? { resolvedAt: new Date(), resolvedOrderId: order.id } : {}),
    createdById: userId,
  }).returning('id');
  await audit(userId, 'finding.create', 'service_order', order.id, { findingId: row.id, severity: body.severity, decision });
  return row.id;
}

export async function updateFinding(order, findingId, body, userId) {
  const f = await db('order_findings').where({ id: findingId, serviceOrderId: order.id }).first();
  if (!f) throw notFound('Item não encontrado nesta OS.');
  const patch = { updatedAt: new Date() };
  for (const k of ['description', 'severity', 'checkMileage']) if (body[k] !== undefined) patch[k] = body[k];
  Object.assign(patch, informedPatch(body, userId, f));
  if (body.decision && body.decision !== f.decision) {
    patch.decision = body.decision;
    if (body.decision === 'FIXED') Object.assign(patch, { resolvedAt: new Date(), resolvedOrderId: order.id });
    else if (f.resolvedOrderId === order.id) Object.assign(patch, { resolvedAt: null, resolvedOrderId: null });
  }
  await db('order_findings').where({ id: f.id }).update(patch);
  await audit(userId, 'finding.update', 'service_order', order.id, { findingId: f.id, fields: Object.keys(body) });
}

export async function removeFinding(order, findingId, userId) {
  const n = await db('order_findings').where({ id: findingId, serviceOrderId: order.id }).del();
  if (!n) throw notFound('Item não encontrado nesta OS.');
  await audit(userId, 'finding.delete', 'service_order', order.id, { findingId });
}

// Pendência de uma visita anterior consertada (ou desfeita) nesta OS
export async function resolveFinding(order, findingId, resolved, userId) {
  const f = await db('order_findings').where({ id: findingId, motorcycleId: order.motorcycleId }).first();
  if (!f) throw notFound('Pendência não encontrada para esta moto.');
  if (f.serviceOrderId === order.id) throw badRequest('Esse item é desta OS: mude a situação dele no próprio item.');
  if (resolved) {
    await db('order_findings').where({ id: f.id }).update({ resolvedAt: new Date(), resolvedOrderId: order.id, updatedAt: new Date() });
  } else {
    if (f.resolvedOrderId !== order.id) throw badRequest('Essa pendência foi resolvida em outra OS.');
    await db('order_findings').where({ id: f.id }).update({ resolvedAt: null, resolvedOrderId: null, updatedAt: new Date() });
  }
  await audit(userId, resolved ? 'finding.resolve' : 'finding.reopen', 'service_order', order.id, { findingId: f.id });
}
