import { config } from '../../config.js';
import { db } from '../../lib/db.js';
import { CloudApiProvider } from './cloudApi.js';
import { messageTexts, render, waLink } from '../messages.js';

let provider = null;
let customProvider = null;

// Lets tests (or a future Z-API / Evolution provider) plug in another implementation.
export function setProvider(p) {
  customProvider = p;
}

export function isApiConfigured() {
  return Boolean(customProvider || (config.whatsapp.token && config.whatsapp.phoneNumberId));
}

function getProvider() {
  if (customProvider) return customProvider;
  if (!provider && isApiConfigured()) provider = new CloudApiProvider(config.whatsapp);
  return provider;
}

// Ordered parameters used when a Meta-approved template is configured for a message.
const TEMPLATE_PARAMS = {
  confirmation: ['nome', 'servicos', 'moto', 'data', 'hora', 'codigo', 'link'],
  reminder24h: ['nome', 'data', 'hora', 'moto', 'endereco', 'link'],
  quoteReady: ['nome', 'moto', 'valor', 'link'],
  bikeReady: ['nome', 'moto', 'valor'],
  maintenance: ['nome', 'tipo', 'moto', 'link'],
};

/**
 * Sends (Level 2) or prepares (Level 1) a customer message.
 * Level 1 returns a wa.me link the staff opens; Level 2 sends through the API.
 * Returns { mode: 'link' | 'sent' | 'failed', waUrl, text }.
 */
export async function notify({ settings, template, phone, vars }) {
  const text = render(messageTexts(settings)[template], vars);
  const url = waLink(phone, text);
  const p = settings.whatsappLevel2Enabled ? getProvider() : null;
  if (!p) return { mode: 'link', waUrl: url, text };

  try {
    const templateName = process.env[`WHATSAPP_TEMPLATE_${template.toUpperCase()}`];
    const result = templateName
      ? await p.sendTemplate(phone, templateName, (TEMPLATE_PARAMS[template] || []).map((k) => vars[k] ?? ''))
      : await p.sendText(phone, text);
    await db('notification_logs').insert({ channel: 'whatsapp', to: phone, template, status: 'sent', payload: JSON.stringify({ id: result?.id || null }) });
    return { mode: 'sent', waUrl: url, text };
  } catch (err) {
    await db('notification_logs').insert({ channel: 'whatsapp', to: phone, template, status: 'failed', error: String(err.message).slice(0, 500) });
    return { mode: 'failed', waUrl: url, text, error: 'Não foi possível enviar pela API. Use o botão do WhatsApp.' };
  }
}

export async function sendRawText(phone, text, template) {
  const p = getProvider();
  if (!p) return false;
  try {
    await p.sendText(phone, text);
    await db('notification_logs').insert({ channel: 'whatsapp', to: phone, template, status: 'sent' });
    return true;
  } catch (err) {
    await db('notification_logs').insert({ channel: 'whatsapp', to: phone, template, status: 'failed', error: String(err.message).slice(0, 500) });
    return false;
  }
}
