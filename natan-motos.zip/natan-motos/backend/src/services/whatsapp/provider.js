/**
 * WhatsAppProvider interface. Any provider (Meta Cloud API, Z-API, Evolution API...)
 * must implement these two methods; business code only talks to this interface.
 *
 *   sendText(to: string, body: string): Promise<{ id?: string }>
 *   sendTemplate(to: string, name: string, params: string[]): Promise<{ id?: string }>
 */
export class WhatsAppProvider {
  // eslint-disable-next-line no-unused-vars
  async sendText(to, body) {
    throw new Error('not implemented');
  }

  // eslint-disable-next-line no-unused-vars
  async sendTemplate(to, name, params) {
    throw new Error('not implemented');
  }
}
