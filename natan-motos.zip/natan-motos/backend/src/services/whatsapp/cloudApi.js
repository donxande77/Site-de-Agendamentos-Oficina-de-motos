import crypto from 'node:crypto';
import { WhatsAppProvider } from './provider.js';

// Official WhatsApp Business Cloud API (Meta).
export class CloudApiProvider extends WhatsAppProvider {
  constructor({ token, phoneNumberId, apiVersion, templateLanguage }) {
    super();
    this.token = token;
    this.url = `https://graph.facebook.com/${apiVersion}/${phoneNumberId}/messages`;
    this.lang = templateLanguage;
  }

  async #post(payload) {
    const res = await fetch(this.url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${this.token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', ...payload }),
      signal: AbortSignal.timeout(10000),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error?.message || `WhatsApp API HTTP ${res.status}`);
    return { id: data?.messages?.[0]?.id };
  }

  sendText(to, body) {
    return this.#post({ to, type: 'text', text: { preview_url: true, body } });
  }

  sendTemplate(to, name, params) {
    return this.#post({
      to,
      type: 'template',
      template: {
        name,
        language: { code: this.lang },
        components: params.length ? [{ type: 'body', parameters: params.map((p) => ({ type: 'text', text: String(p) })) }] : [],
      },
    });
  }
}

// Validates the X-Hub-Signature-256 header sent by Meta on webhook calls.
export function verifySignature(rawBody, header, appSecret) {
  if (!appSecret || !header || !rawBody) return false;
  const expected = `sha256=${crypto.createHmac('sha256', appSecret).update(rawBody).digest('hex')}`;
  const a = Buffer.from(expected);
  const b = Buffer.from(String(header));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
