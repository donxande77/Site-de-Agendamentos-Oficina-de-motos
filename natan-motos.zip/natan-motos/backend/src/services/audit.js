import { db } from '../lib/db.js';

// Records who did what. Never store full personal data here — ids and changed field names only.
export async function audit(userId, action, entity, entityId, data, trx = db) {
  await trx('audit_logs').insert({
    userId: userId ?? null,
    action,
    entity,
    entityId: entityId ?? null,
    data: data ? JSON.stringify(data) : null,
  });
}
