import { formatBRL, formatDate, formatTime, formatPlate } from '../lib/util.js';
import { DEFAULT_MESSAGES } from '../../db/seeds/01_initial.js';

export const TEMPLATE_KEYS = Object.keys(DEFAULT_MESSAGES);

export function messageTexts(settings) {
  const saved = typeof settings.messageTexts === 'string' ? JSON.parse(settings.messageTexts) : settings.messageTexts;
  return { ...DEFAULT_MESSAGES, ...(saved || {}) };
}

export function render(template, vars) {
  return template.replace(/\{(\w+)\}/g, (m, key) => (vars[key] !== undefined && vars[key] !== null ? String(vars[key]) : m));
}

export const bookingUrl = (settings, source) => `${settings.publicBaseUrl.replace(/\/$/, '')}/agendar${source ? `?src=${source}` : ''}`;
export const manageUrl = (settings, token) => `${settings.publicBaseUrl.replace(/\/$/, '')}/meu-agendamento/${token}`;
export const quoteUrl = (settings, token) => `${settings.publicBaseUrl.replace(/\/$/, '')}/orcamento/${token}`;

export const DEFAULT_PARTS_NOTICE = 'A oficina não vende peças. Traga as peças do serviço no dia do agendamento. Se não souber quais comprar, agende um diagnóstico e o mecânico passa a lista.';

// " Traga as peças: óleo e filtro." — empty when the shop sells parts or nothing is needed
export function partsLine(settings, services) {
  if (settings.sellsParts) return '';
  const hints = services.map((s) => s.partsToBring).filter(Boolean);
  return hints.length ? ` Traga as peças: ${hints.join(' ')}` : '';
}

export const waLink = (phone, text) => `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;

const bikeLabel = (m) => (m ? `${m.brand} ${m.model}${m.plate ? ` (${formatPlate(m.plate)})` : ''}` : '');

export function baseVars(settings) {
  return { oficina: settings.shopName, endereco: settings.address, link: bookingUrl(settings, 'whatsapp') };
}

export function bookingVars(settings, booking, customer, motorcycle, services) {
  return {
    ...baseVars(settings),
    nome: customer.name.split(' ')[0],
    moto: bikeLabel(motorcycle),
    data: formatDate(booking.startAt),
    hora: formatTime(booking.startAt),
    codigo: booking.code,
    servicos: services.map((s) => s.nameSnapshot || s.name).join(', '),
    pecas: partsLine(settings, services),
    link: manageUrl(settings, booking.manageToken),
  };
}

export function orderVars(settings, order, customer, motorcycle) {
  return {
    ...baseVars(settings),
    nome: customer.name.split(' ')[0],
    moto: bikeLabel(motorcycle),
    valor: formatBRL(order.totalCents),
    link: quoteUrl(settings, order.approvalToken),
  };
}

export function reminderVars(settings, reminder, customer, motorcycle) {
  return {
    ...baseVars(settings),
    nome: customer.name.split(' ')[0],
    moto: bikeLabel(motorcycle),
    tipo: reminder.type === 'OIL_CHANGE' ? 'troca de óleo' : 'revisão',
    link: bookingUrl(settings, 'whatsapp'),
  };
}
