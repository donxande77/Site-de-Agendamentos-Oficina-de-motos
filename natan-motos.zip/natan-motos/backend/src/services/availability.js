import { DateTime } from 'luxon';
import { TZ } from '../lib/util.js';

export const ACTIVE_BOOKING_STATUSES = ['PENDING', 'CONFIRMED', 'CHECKED_IN'];

const ms = (d) => (d instanceof DateTime ? d.toMillis() : new Date(d).getTime());
export const overlaps = (aStart, aEnd, bStart, bEnd) => ms(aStart) < ms(bEnd) && ms(bStart) < ms(aEnd);

// Total duration of the selected services, rounded up to the slot size.
export function totalDuration(services, slotMinutes) {
  const sum = services.reduce((acc, s) => acc + (s.durationMinutes || s.durationSnapshot || 0), 0);
  return Math.max(slotMinutes, Math.ceil(sum / slotMinutes) * slotMinutes);
}

// 0 = Sunday ... 6 = Saturday (luxon uses 1 = Monday ... 7 = Sunday)
export const weekdayOf = (dt) => dt.weekday % 7;

// A block applies to a bay when it targets that bay, or the whole shop (no bay and no person).
const blockHitsBay = (block, bayId) => block.bayId === bayId || (block.bayId == null && block.userId == null);

/**
 * Pure slot calculation for one day (unit-tested).
 * Returns [{ startAt: ISO UTC, endAt, time: 'HH:mm', bayIds: [..] }] for every start time
 * where at least one bay is free for the whole duration.
 */
export function computeDaySlots({
  date, durationMinutes, hours, bays, bookings = [], blocks = [], slotMinutes, minNoticeHours = 0, now = new Date(),
}) {
  if (!hours || hours.closed) return [];
  const day = DateTime.fromISO(date, { zone: TZ });
  if (!day.isValid) return [];
  const at = (hm) => DateTime.fromISO(`${date}T${hm}`, { zone: TZ });
  const open = at(hours.opensAt);
  const close = at(hours.closesAt);
  const breakStart = hours.breakStart && hours.breakEnd ? at(hours.breakStart) : null;
  const breakEnd = breakStart ? at(hours.breakEnd) : null;
  const earliest = DateTime.fromJSDate(new Date(now)).plus({ hours: minNoticeHours });

  const slots = [];
  for (let t = open; t.plus({ minutes: durationMinutes }) <= close; t = t.plus({ minutes: slotMinutes })) {
    const end = t.plus({ minutes: durationMinutes });
    if (t < earliest) continue;
    if (breakStart && overlaps(t, end, breakStart, breakEnd)) continue;
    const bayIds = bays
      .filter((bay) => !bookings.some((b) => b.bayId === bay.id && overlaps(t, end, b.startAt, b.endAt)))
      .filter((bay) => !blocks.some((bl) => blockHitsBay(bl, bay.id) && overlaps(t, end, bl.startAt, bl.endAt)))
      .map((bay) => bay.id);
    if (bayIds.length) {
      slots.push({ startAt: t.toUTC().toISO(), endAt: end.toUTC().toISO(), time: t.toFormat('HH:mm'), bayIds });
    }
  }
  return slots;
}

export async function getSettings(db) {
  return db('settings').where({ id: 1 }).first();
}

// Loads everything needed to compute availability between two local dates (inclusive).
export async function loadContext(db, fromDate, toDate, { excludeBookingId } = {}) {
  const from = DateTime.fromISO(fromDate, { zone: TZ }).startOf('day').toUTC().toJSDate();
  const to = DateTime.fromISO(toDate, { zone: TZ }).endOf('day').toUTC().toJSDate();
  const [settings, hoursRows, bays, bookings, blocks] = await Promise.all([
    getSettings(db),
    db('business_hours'),
    db('bays').where({ active: true }).orderBy('order'),
    db('bookings')
      .select('id', 'bayId', 'startAt', 'endAt')
      .whereIn('status', ACTIVE_BOOKING_STATUSES)
      .where('startAt', '<', to)
      .where('endAt', '>', from)
      .modify((q) => excludeBookingId && q.whereNot('id', excludeBookingId)),
    db('time_blocks').where('startAt', '<', to).where('endAt', '>', from),
  ]);
  const hoursByWeekday = Object.fromEntries(hoursRows.map((h) => [h.weekday, h]));
  return { settings, hoursByWeekday, bays, bookings, blocks };
}

export async function getDaySlots(db, { date, durationMinutes, excludeBookingId, now = new Date() }) {
  const ctx = await loadContext(db, date, date, { excludeBookingId });
  const dt = DateTime.fromISO(date, { zone: TZ });
  const today = DateTime.now().setZone(TZ).startOf('day');
  if (!dt.isValid || dt < today || dt > today.plus({ days: ctx.settings.maxDaysAhead })) return [];
  return computeDaySlots({
    date,
    durationMinutes,
    hours: ctx.hoursByWeekday[weekdayOf(dt)],
    bays: ctx.bays,
    bookings: ctx.bookings,
    blocks: ctx.blocks,
    slotMinutes: ctx.settings.slotMinutes,
    minNoticeHours: ctx.settings.minNoticeHours,
    now,
  });
}

// Days (from today up to maxDaysAhead) that have at least one free slot.
export async function getAvailableDays(db, { durationMinutes, excludeBookingId, now = new Date() }) {
  const settings = await getSettings(db);
  const today = DateTime.fromJSDate(now).setZone(TZ).startOf('day');
  const last = today.plus({ days: settings.maxDaysAhead });
  const ctx = await loadContext(db, today.toISODate(), last.toISODate(), { excludeBookingId });
  const days = [];
  for (let d = today; d <= last; d = d.plus({ days: 1 })) {
    const slots = computeDaySlots({
      date: d.toISODate(),
      durationMinutes,
      hours: ctx.hoursByWeekday[weekdayOf(d)],
      bays: ctx.bays,
      bookings: ctx.bookings,
      blocks: ctx.blocks,
      slotMinutes: settings.slotMinutes,
      minNoticeHours: settings.minNoticeHours,
      now,
    });
    if (slots.length) days.push({ date: d.toISODate(), slots: slots.length });
  }
  return days;
}

/**
 * Finds a bay free between startAt and endAt (bookings + blocks), inside a transaction.
 * Returns the bay id or null.
 */
export async function findFreeBay(trx, startAt, endAt, { preferredBayId, excludeBookingId } = {}) {
  const bays = await trx('bays').where({ active: true }).orderBy('order');
  const busy = await trx('bookings')
    .select('bayId')
    .whereIn('status', ACTIVE_BOOKING_STATUSES)
    .where('startAt', '<', endAt)
    .where('endAt', '>', startAt)
    .modify((q) => excludeBookingId && q.whereNot('id', excludeBookingId));
  const blocks = await trx('time_blocks').where('startAt', '<', endAt).where('endAt', '>', startAt);
  const free = bays
    .map((b) => b.id)
    .filter((id) => !busy.some((b) => b.bayId === id))
    .filter((id) => !blocks.some((bl) => blockHitsBay(bl, id)));
  if (preferredBayId && free.includes(preferredBayId)) return preferredBayId;
  return free[0] ?? null;
}

// Is [start, end) inside opening hours, outside the break, respecting notice and horizon?
export function fitsPublicRules({ start, end, hours, settings, now = new Date() }) {
  const s = DateTime.fromJSDate(new Date(start)).setZone(TZ);
  const e = DateTime.fromJSDate(new Date(end)).setZone(TZ);
  const date = s.toISODate();
  if (!hours || hours.closed) return false;
  const at = (hm) => DateTime.fromISO(`${date}T${hm}`, { zone: TZ });
  if (s < at(hours.opensAt) || e > at(hours.closesAt)) return false;
  if (hours.breakStart && hours.breakEnd && overlaps(s, e, at(hours.breakStart), at(hours.breakEnd))) return false;
  const nowDt = DateTime.fromJSDate(new Date(now)).setZone(TZ);
  if (s < nowDt.plus({ hours: settings.minNoticeHours })) return false;
  if (s > nowDt.startOf('day').plus({ days: settings.maxDaysAhead + 1 })) return false;
  // must also align with the slot grid
  const minutesFromOpen = s.diff(at(hours.opensAt), 'minutes').minutes;
  return minutesFromOpen % settings.slotMinutes === 0;
}
