import { DateTime } from 'luxon';
import { db } from '../lib/db.js';
import { TZ, bookingCode, randomToken, normalizePhone, normalizePlate } from '../lib/util.js';
import { badRequest, conflict, notFound, HttpError } from '../lib/errors.js';
import { totalDuration, findFreeBay, fitsPublicRules, weekdayOf, getSettings } from './availability.js';
import { audit } from './audit.js';
import { nextOrderNumber } from './orders.js';
import { DEFAULT_PARTS_NOTICE } from './messages.js';

const BOOKING_LOCK_KEY = 7710; // serialises booking writes (the DB constraint is the final guard)

async function upsertCustomer(trx, { name, phone, email, privacyAck, reminderConsent }, { isStaff = false } = {}) {
  const now = new Date();
  const existing = await trx('customers').where({ phone }).first();
  const patch = { name: name.trim(), updatedAt: now };
  // Pelo link público, o nome já cadastrado não é trocado (só a oficina corrige o cadastro)
  if (existing && !isStaff) delete patch.name;
  if (email) patch.email = email.trim().toLowerCase();
  if (privacyAck) patch.privacyAckAt = now;
  if (reminderConsent === true) Object.assign(patch, { reminderConsentAt: now, reminderConsentRevokedAt: null });
  if (existing) {
    await trx('customers').where({ id: existing.id }).update(patch);
    return existing.id;
  }
  const [row] = await trx('customers').insert({ phone, ...patch }).returning('id');
  return row.id;
}

async function upsertMotorcycle(trx, customerId, { brand, model, year, plate, mileage, color }) {
  const now = new Date();
  const data = {
    customerId,
    brand: brand.trim(),
    model: model.trim(),
    ...(year ? { year } : {}),
    updatedAt: now,
    ...(color ? { color } : {}),
    ...(mileage ? { lastMileage: mileage } : {}),
  };
  const existing = await trx('motorcycles').where({ plate }).first();
  if (existing) {
    if (existing.customerId !== customerId) {
      // Placa no cadastro de outra pessoa: não muda o dono sozinho (pode ser placa digitada errada).
      // O agendamento usa a moto que já existe e a oficina confirma na chegada.
      const owner = await trx('customers').select('name', 'phone').where({ id: existing.customerId }).first();
      return { id: existing.id, otherOwner: owner };
    }
    await trx('motorcycles').where({ id: existing.id }).update(data);
    return { id: existing.id };
  }
  const [row] = await trx('motorcycles').insert({ plate, ...data }).returning('id');
  return { id: row.id };
}

/**
 * Creates a booking. Public bookings must respect opening hours, notice and horizon;
 * staff bookings (walk-in / phone) only need a free bay.
 */
export async function createBooking(input, { source = 'direct', isStaff = false, userId = null } = {}) {
  const settings = await getSettings(db);
  const services = await db('services')
    .whereIn('id', input.serviceIds)
    .where({ active: true })
    .modify((q) => !isStaff && q.where({ onlineVisible: true }));
  if (services.length !== new Set(input.serviceIds).size) throw badRequest('Algum serviço escolhido não está disponível.');

  const phone = normalizePhone(input.customer.phone);
  const plate = normalizePlate(input.motorcycle.plate);
  if (!isStaff && !input.privacyAck) throw badRequest('Confirme que leu o aviso de privacidade para continuar.', 'PRIVACY_REQUIRED');

  const duration = input.durationMinutes && isStaff ? input.durationMinutes : totalDuration(services, settings.slotMinutes);
  const start = DateTime.fromISO(input.startAt, { setZone: true }).setZone(TZ);
  if (!start.isValid) throw badRequest('Data ou horário inválido.');
  const end = start.plus({ minutes: duration });

  if (!isStaff) {
    const hours = await db('business_hours').where({ weekday: weekdayOf(start) }).first();
    if (!fitsPublicRules({ start: start.toJSDate(), end: end.toJSDate(), hours, settings })) {
      throw conflict('Esse horário não está mais disponível. Escolha outro, por favor.', 'SLOT_UNAVAILABLE');
    }
  }

  const dropOff = Boolean(
    input.dropOff || duration >= settings.forceDropOffMinutes || services.some((s) => s.dropOffRequired),
  );

  const bookingId = await db.transaction(async (trx) => {
    await trx.raw('SELECT pg_advisory_xact_lock(?)', [BOOKING_LOCK_KEY]);
    const customerId = await upsertCustomer(trx, { ...input.customer, phone, privacyAck: input.privacyAck, reminderConsent: input.reminderConsent }, { isStaff });
    const { id: motorcycleId, otherOwner } = await upsertMotorcycle(trx, customerId, { ...input.motorcycle, plate });
    const ownerWarning = otherOwner
      ? `⚠ Esta placa já está cadastrada para ${otherOwner.name} (WhatsApp final ${otherOwner.phone.slice(-4)}). Confira na chegada: se a moto foi vendida, use "Transferir moto" no cadastro do cliente.`
      : null;
    const bayId = await findFreeBay(trx, start.toJSDate(), end.toJSDate(), { preferredBayId: input.bayId });
    if (!bayId) throw conflict('Esse horário acabou de ser ocupado. Escolha outro, por favor.', 'SLOT_TAKEN');

    const [row] = await trx('bookings')
      .insert({
        code: bookingCode(),
        customerId,
        motorcycleId,
        bayId,
        mechanicId: input.mechanicId || null,
        startAt: start.toJSDate(),
        endAt: end.toJSDate(),
        status: isStaff || settings.autoConfirm ? 'CONFIRMED' : 'PENDING',
        source,
        dropOff,
        problemDescription: input.problemDescription?.trim() || null,
        notes: [isStaff ? input.notes?.trim() : null, ownerWarning].filter(Boolean).join('\n') || null,
        manageToken: randomToken(24),
        createdById: userId,
      })
      .returning('id');

    await trx('booking_services').insert(
      services.map((s) => ({
        bookingId: row.id,
        serviceId: s.id,
        nameSnapshot: s.name,
        priceSnapshotCents: s.basePriceCents,
        priceOnEvaluationSnapshot: s.priceOnEvaluation,
        durationSnapshot: s.durationMinutes,
      })),
    );
    await audit(userId, 'booking.create', 'booking', row.id, { source }, trx);
    return row.id;
  });

  return getBookingFull({ id: bookingId });
}

export async function getBookingFull(where) {
  const booking = await db('bookings').where(where).first();
  if (!booking) throw notFound('Agendamento não encontrado.');
  const [customer, motorcycle, services, bay, order, photos, mechanic] = await Promise.all([
    db('customers').where({ id: booking.customerId }).first(),
    db('motorcycles').where({ id: booking.motorcycleId }).first(),
    db('booking_services as bs').leftJoin('services as s', 's.id', 'bs.serviceId').select('bs.*', 's.partsToBring').where('bs.bookingId', booking.id).orderBy('bs.id'),
    db('bays').where({ id: booking.bayId }).first(),
    db('service_orders').where({ bookingId: booking.id }).first(),
    db('photos').where({ bookingId: booking.id }),
    booking.mechanicId ? db('users').select('id', 'name').where({ id: booking.mechanicId }).first() : null,
  ]);
  return { ...booking, customer, motorcycle, services, bay, order: order || null, photos, mechanic };
}

// Only what the customer needs to see on their private page.
export function publicBookingView(b, settings) {
  const statusLabel = b.order ? b.order.status : b.status;
  return {
    code: b.code,
    status: b.status,
    orderStatus: b.order?.status || null,
    statusLabel,
    startAt: b.startAt,
    endAt: b.endAt,
    dropOff: b.dropOff,
    source: b.source,
    customerName: b.customer.name,
    motorcycle: { brand: b.motorcycle.brand, model: b.motorcycle.model, plate: b.motorcycle.plate, year: b.motorcycle.year },
    services: b.services.map((s) => ({
      serviceId: s.serviceId,
      name: s.nameSnapshot,
      priceCents: s.priceSnapshotCents,
      priceOnEvaluation: s.priceOnEvaluationSnapshot,
      durationMinutes: s.durationSnapshot,
      partsToBring: settings.sellsParts ? null : s.partsToBring || null,
    })),
    partsNotice: settings.sellsParts ? null : settings.partsNotice || DEFAULT_PARTS_NOTICE,
    quoteToken: b.order && ['SENT', 'APPROVED', 'REJECTED'].includes(b.order.quoteStatus) ? b.order.approvalToken : null,
    canChange: canCustomerChange(b, settings),
    cancelNoticeHours: settings.cancelNoticeHours,
  };
}

export function canCustomerChange(b, settings) {
  if (!['PENDING', 'CONFIRMED'].includes(b.status)) return false;
  const limit = DateTime.fromJSDate(new Date(b.startAt)).minus({ hours: settings.cancelNoticeHours });
  return DateTime.now() < limit;
}

export async function rescheduleBooking(booking, { startAt, bayId, mechanicId }, { isStaff = false, userId = null } = {}) {
  const settings = await getSettings(db);
  if (!isStaff && !canCustomerChange(booking, settings)) {
    throw new HttpError(403, `Remarcações pelo site só até ${settings.cancelNoticeHours} h antes. Fale com a gente pelo WhatsApp.`, 'TOO_LATE');
  }
  if (!['PENDING', 'CONFIRMED'].includes(booking.status)) throw badRequest('Esse agendamento não pode mais ser remarcado.');

  const durationMs = new Date(booking.endAt) - new Date(booking.startAt);
  const start = startAt ? DateTime.fromISO(startAt, { setZone: true }).setZone(TZ) : DateTime.fromJSDate(new Date(booking.startAt)).setZone(TZ);
  if (!start.isValid) throw badRequest('Data ou horário inválido.');
  const end = start.plus({ milliseconds: durationMs });

  if (!isStaff) {
    const hours = await db('business_hours').where({ weekday: weekdayOf(start) }).first();
    if (!fitsPublicRules({ start: start.toJSDate(), end: end.toJSDate(), hours, settings })) {
      throw conflict('Esse horário não está disponível. Escolha outro, por favor.', 'SLOT_UNAVAILABLE');
    }
  }

  await db.transaction(async (trx) => {
    await trx.raw('SELECT pg_advisory_xact_lock(?)', [BOOKING_LOCK_KEY]);
    let targetBay = bayId || null;
    if (targetBay) {
      const free = await findFreeBay(trx, start.toJSDate(), end.toJSDate(), { preferredBayId: targetBay, excludeBookingId: booking.id });
      if (free !== targetBay) throw conflict('Esse elevador está ocupado nesse horário.', 'SLOT_TAKEN');
    } else {
      targetBay = await findFreeBay(trx, start.toJSDate(), end.toJSDate(), { preferredBayId: booking.bayId, excludeBookingId: booking.id });
      if (!targetBay) throw conflict('Esse horário acabou de ser ocupado. Escolha outro, por favor.', 'SLOT_TAKEN');
    }
    await trx('bookings')
      .where({ id: booking.id })
      .update({
        startAt: start.toJSDate(),
        endAt: end.toJSDate(),
        bayId: targetBay,
        ...(mechanicId !== undefined ? { mechanicId } : {}),
        reminderSentAt: null,
        updatedAt: new Date(),
      });
    await audit(userId, 'booking.reschedule', 'booking', booking.id, { by: isStaff ? 'staff' : 'customer' }, trx);
  });
  return getBookingFull({ id: booking.id });
}

export async function cancelBooking(booking, { isStaff = false, userId = null } = {}) {
  const settings = await getSettings(db);
  if (!isStaff && !canCustomerChange(booking, settings)) {
    throw new HttpError(403, `Cancelamentos pelo site só até ${settings.cancelNoticeHours} h antes. Fale com a gente pelo WhatsApp.`, 'TOO_LATE');
  }
  if (!['PENDING', 'CONFIRMED'].includes(booking.status)) throw badRequest('Esse agendamento não pode ser cancelado.');
  await db('bookings').where({ id: booking.id }).update({ status: 'CANCELLED', cancelledAt: new Date(), updatedAt: new Date() });
  await audit(userId, 'booking.cancel', 'booking', booking.id, { by: isStaff ? 'staff' : 'customer' });
  return getBookingFull({ id: booking.id });
}

// Check-in: the bike arrived → create the service order from the booking.
export async function checkInBooking(booking, { userId, checkInMileage, fuelLevel, checklist } = {}) {
  if (!['PENDING', 'CONFIRMED'].includes(booking.status)) throw badRequest('Esse agendamento não pode receber check-in.');
  const orderId = await db.transaction(async (trx) => {
    const number = await nextOrderNumber(trx);
    const services = await trx('booking_services').where({ bookingId: booking.id });
    const [order] = await trx('service_orders')
      .insert({
        number,
        bookingId: booking.id,
        customerId: booking.customerId,
        motorcycleId: booking.motorcycleId,
        mechanicId: booking.mechanicId,
        checkInMileage: checkInMileage || null,
        fuelLevel: fuelLevel || null,
        checklist: checklist ? JSON.stringify(checklist) : null,
        diagnosis: booking.problemDescription ? `Relato do cliente: ${booking.problemDescription}` : null,
        approvalToken: randomToken(24),
      })
      .returning('id');
    if (services.length) {
      // the first diagnosis service becomes the "Valor do diagnóstico" the mechanic fills in
      const diagIds = await trx('services').whereIn('id', services.map((s) => s.serviceId).filter(Boolean))
        .where((qb) => qb.where('category', 'Diagnóstico').orWhereILike('name', 'diagnóstico%')).pluck('id');
      let flagged = false;
      await trx('service_order_items').insert(
        services.map((s) => {
          const isDiagnosisFee = !flagged && diagIds.includes(s.serviceId);
          if (isDiagnosisFee) flagged = true;
          return {
            serviceOrderId: order.id,
            type: 'LABOR',
            description: s.nameSnapshot,
            serviceId: s.serviceId,
            quantity: 1,
            unitPriceCents: s.priceSnapshotCents || 0,
            isDiagnosisFee,
          };
        }),
      );
    }
    const total = services.reduce((a, s) => a + (s.priceSnapshotCents || 0), 0);
    await trx('service_orders').where({ id: order.id }).update({ totalCents: total });
    await trx('bookings').where({ id: booking.id }).update({ status: 'CHECKED_IN', updatedAt: new Date() });
    if (checkInMileage) await trx('motorcycles').where({ id: booking.motorcycleId }).update({ lastMileage: checkInMileage });
    await trx('photos').where({ bookingId: booking.id }).update({ serviceOrderId: order.id });
    await audit(userId, 'order.create', 'service_order', order.id, { fromBooking: booking.id }, trx);
    return order.id;
  });
  return orderId;
}
