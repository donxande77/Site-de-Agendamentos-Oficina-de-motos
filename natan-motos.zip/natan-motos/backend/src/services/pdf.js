import PDFDocument from 'pdfkit';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { config } from '../config.js';
import { formatBRL, formatDate, formatDateTime, formatPhone, formatPlate } from '../lib/util.js';

const LOGO = fileURLToPath(new URL('../../assets/logo.png', import.meta.url));
const PARTS_DIR = fileURLToPath(new URL('../../assets/parts/', import.meta.url));

// Local file for a catalog image URL (built-in PNG or uploaded JPG/PNG)
function imagePath(url) {
  if (!url) return null;
  const name = path.basename(url);
  if (url.startsWith('/parts-img/') && /^[\w-]+\.png$/.test(name)) return path.join(PARTS_DIR, name);
  if (url.startsWith('/uploads/') && /^[\w-]+\.(jpg|png)$/.test(name)) return path.join(config.uploadsDir, name);
  return null;
}
const BLUE = '#3358D4';
const DARK = '#0C0C0C';
const GRAY = '#555555';

const STATUS_PT = {
  OPEN: 'Aberta', DIAGNOSIS: 'Em diagnóstico', WAITING_APPROVAL: 'Aguardando aprovação', APPROVED: 'Aprovada',
  IN_PROGRESS: 'Em serviço', WAITING_PARTS: 'Aguardando peças', READY: 'Pronta para retirada', DELIVERED: 'Entregue', CANCELLED: 'Cancelada',
};
const SEVERITY_PT = { URGENT: 'URGENTE', SOON: 'EM BREVE', WATCH: 'ACOMPANHAR' };
const SEVERITY_COLOR = { URGENT: '#C62828', SOON: '#B26A00', WATCH: GRAY };
const DECISION_PT = { OPEN: 'a combinar com o cliente', LATER: 'o cliente vai fazer depois', DECLINED: 'o cliente preferiu não fazer agora' };
const VIA_PT = { IN_PERSON: 'pessoalmente', WHATSAPP: 'pelo WhatsApp', PHONE: 'por telefone' };
const FUEL_PT = { reserve: 'Reserva', quarter: '1/4', half: '1/2', three_quarters: '3/4', full: 'Cheio' };
const CHECK_PT = { helmet: 'Capacete', documents: 'Documento', keys: 'Chave', bag: 'Bolsa / baú', other: 'Outro' };

/**
 * Writes the service order (type = 'os') or the quote (type = 'quote') as an A4 PDF to `stream`.
 */
export function orderPdf(stream, { order, settings, type = 'os' }) {
  const doc = new PDFDocument({ size: 'A4', margin: 40, info: { Title: `${type === 'quote' ? 'Orçamento' : 'OS'} ${order.number}` } });
  doc.pipe(stream);
  const W = doc.page.width - 80;

  // Header
  doc.rect(0, 0, doc.page.width, 110).fill(DARK);
  try { doc.image(LOGO, 40, 15, { width: 80 }); } catch { /* logo optional */ }
  doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(20).text(settings.shopName.toUpperCase(), 135, 28);
  doc.font('Helvetica').fontSize(9).fillColor('#CCCCCC')
    .text(settings.address, 135, 54, { width: 300 })
    .text(`WhatsApp ${formatPhone(settings.whatsappNumber)}  ·  @${settings.instagram}`, 135, 80);
  doc.fillColor(BLUE).font('Helvetica-Bold').fontSize(16)
    .text(type === 'quote' ? 'ORÇAMENTO' : 'ORDEM DE SERVIÇO', 380, 30, { width: W - 340, align: 'right' });
  doc.fillColor('#FFFFFF').fontSize(22).text(`Nº ${String(order.number).padStart(5, '0')}`, 380, 52, { width: W - 340, align: 'right' });
  doc.fillColor('#CCCCCC').font('Helvetica').fontSize(9).text(`Emitida em ${formatDateTime(new Date())}`, 380, 82, { width: W - 340, align: 'right' });

  let y = 130;
  const box = (title, lines, x, w) => {
    doc.fillColor(BLUE).font('Helvetica-Bold').fontSize(10).text(title, x, y);
    doc.fillColor(DARK).font('Helvetica').fontSize(10);
    lines.forEach((l, i) => doc.text(l, x, y + 16 + i * 14, { width: w }));
  };
  const c = order.customer;
  const m = order.motorcycle;
  box('CLIENTE', [c.name, formatPhone(c.phone), c.email || ''].filter(Boolean), 40, W / 2 - 10);
  box('MOTO', [
    `${m.brand} ${m.model}${m.year ? ` ${m.year}` : ''}`,
    `Placa ${formatPlate(m.plate)}`,
    order.checkInMileage ? `KM na entrada: ${order.checkInMileage.toLocaleString('pt-BR')}` : '',
  ].filter(Boolean), 40 + W / 2 + 10, W / 2 - 10);
  y += 76;

  doc.fillColor(GRAY).fontSize(9).text(
    `Status: ${STATUS_PT[order.status]}   ·   Abertura: ${formatDate(order.createdAt)}${order.mechanic ? `   ·   Mecânico: ${order.mechanic.name}` : ''}`,
    40, y,
  );
  y += 20;

  if (type === 'os') {
    const checklist = order.checklist || {};
    const items = (checklist.items || []).map((k) => CHECK_PT[k] || k).join(', ');
    const lines = [
      order.fuelLevel ? `Combustível: ${FUEL_PT[order.fuelLevel] || order.fuelLevel}` : null,
      items ? `Itens deixados com a moto: ${items}` : null,
      checklist.damage ? `Avarias visíveis: ${checklist.damage}` : null,
    ].filter(Boolean);
    if (lines.length) {
      doc.fillColor(BLUE).font('Helvetica-Bold').fontSize(10).text('CHECK-IN', 40, y);
      doc.fillColor(DARK).font('Helvetica').fontSize(10);
      y += 16;
      lines.forEach((l) => { doc.text(l, 40, y, { width: W }); y = doc.y + 2; });
      y += 8;
    }
  }
  if (order.diagnosis) {
    doc.fillColor(BLUE).font('Helvetica-Bold').fontSize(10).text('DIAGNÓSTICO', 40, y);
    doc.fillColor(DARK).font('Helvetica').fontSize(10).text(order.diagnosis, 40, y + 16, { width: W });
    y = doc.y + 12;
  }
  if (type === 'os' && order.workDone) {
    if (y > doc.page.height - 120) { doc.addPage(); y = 40; }
    doc.fillColor(BLUE).font('Helvetica-Bold').fontSize(10).text('SERVIÇO REALIZADO', 40, y);
    doc.fillColor(DARK).font('Helvetica').fontSize(10).text(order.workDone, 40, y + 16, { width: W });
    y = doc.y + 12;
  }

  // Items table
  const cols = [40, 330, 380, 470];
  doc.rect(40, y, W, 20).fill(BLUE);
  doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(9);
  doc.text('DESCRIÇÃO', cols[0] + 6, y + 6).text('QTD', cols[1], y + 6, { width: 40, align: 'right' })
    .text('UNITÁRIO', cols[2], y + 6, { width: 80, align: 'right' }).text('TOTAL', cols[3], y + 6, { width: W - 436, align: 'right' });
  y += 24;
  doc.font('Helvetica').fontSize(9).fillColor(DARK);
  const charged = order.items.filter((it) => it.type !== 'CUSTOMER_PART');
  charged.forEach((it, i) => {
    if (y > doc.page.height - 160) { doc.addPage(); y = 40; }
    if (i % 2 === 0) doc.rect(40, y - 3, W, 18).fill('#F2F4FB').fillColor(DARK);
    doc.text(`${it.type === 'PART' ? 'Peça' : 'Serviço'} · ${it.description}`, cols[0] + 6, y, { width: 280 })
      .text(String(it.quantity), cols[1], y, { width: 40, align: 'right' })
      .text(it.unitPriceCents ? formatBRL(it.unitPriceCents) : 'a definir', cols[2], y, { width: 80, align: 'right' })
      .text(it.unitPriceCents ? formatBRL(it.unitPriceCents * it.quantity) : 'a definir', cols[3], y, { width: W - 436, align: 'right' });
    y += 18;
  });
  if (!charged.length) { doc.fillColor(GRAY).text('Nenhum serviço lançado.', 46, y); y += 18; }

  y += 6;
  const totalLine = (label, value, bold) => {
    doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(bold ? 12 : 10).fillColor(bold ? BLUE : DARK)
      .text(label, 330, y, { width: 130, align: 'right' }).text(value, cols[3], y, { width: W - 436, align: 'right' });
    y += bold ? 20 : 15;
  };
  totalLine(order.partsCents ? 'Mão de obra' : 'Serviços', formatBRL(order.laborCents));
  if (order.partsCents) totalLine('Peças', formatBRL(order.partsCents));
  totalLine(order.customerParts?.length ? 'TOTAL DO SERVIÇO' : 'TOTAL', formatBRL(order.totalCents), true);
  if (type === 'os' && order.paidCents) {
    totalLine('Pago', formatBRL(order.paidCents));
    totalLine('Saldo', formatBRL(Math.max(0, order.balanceCents)));
  }

  // Parts the customer buys and brings (the shop doesn't sell them)
  const parts = order.customerParts || [];
  if (parts.length) {
    y += 14;
    if (y > doc.page.height - 140) { doc.addPage(); y = 40; }
    doc.rect(40, y, W, 22).fill(DARK);
    doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(10).text('PEÇAS PARA COMPRAR', 48, y + 6);
    doc.font('Helvetica').fontSize(8.5).fillColor('#CCCCCC').text('compradas pelo cliente e trazidas para a oficina', 190, y + 7);
    y += 30;
    for (const it of parts) {
      if (y > doc.page.height - 90) { doc.addPage(); y = 40; }
      const img = imagePath(it.imageUrl);
      doc.roundedRect(40, y, 46, 46, 6).fill('#EEF2FB');
      if (img) { try { doc.image(img, 42, y + 2, { width: 42, height: 42 }); } catch { /* skip broken image */ } }
      doc.fillColor(DARK).font('Helvetica-Bold').fontSize(10.5).text(`${it.quantity > 1 ? `${it.quantity}x ` : ''}${it.description}`, 96, y + 6, { width: W - 200 });
      if (it.notes) doc.font('Helvetica').fontSize(9).fillColor(GRAY).text(it.notes, 96, doc.y + 2, { width: W - 200 });
      if (it.estimatedPriceCents) {
        doc.font('Helvetica').fontSize(9).fillColor(GRAY).text('valor estimado', 40 + W - 100, y + 6, { width: 100, align: 'right' });
        doc.font('Helvetica-Bold').fontSize(10).fillColor(DARK).text(formatBRL(it.estimatedPriceCents * it.quantity), 40 + W - 100, y + 18, { width: 100, align: 'right' });
      }
      y = Math.max(y + 54, doc.y + 8);
    }
    if (order.customerPartsEstimateCents) {
      doc.font('Helvetica').fontSize(9.5).fillColor(GRAY).text(`Estimativa das peças (pago na loja de peças, não à oficina): ${formatBRL(order.customerPartsEstimateCents)}`, 40, y, { width: W });
      y = doc.y + 4;
    }
    doc.font('Helvetica-Bold').fontSize(9.5).fillColor(BLUE).text('Traga as peças no dia do serviço. Na dúvida sobre marca ou medida, mostre esta lista na loja ou fale com a gente.', 40, y, { width: W });
    y = doc.y;
  }

  // Other problems found beyond what the customer asked: written record that the customer was told
  const extra = (order.findings || []).filter((f) => f.decision !== 'FIXED');
  if (extra.length) {
    y += 14;
    if (y > doc.page.height - 120) { doc.addPage(); y = 40; }
    doc.rect(40, y, W, 22).fill(DARK);
    doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(10).text('OUTROS PONTOS ENCONTRADOS NA MOTO', 48, y + 6);
    doc.font('Helvetica').fontSize(8.5).fillColor('#CCCCCC').text('além do que foi pedido · não incluídos no valor acima', 270, y + 7);
    y += 30;
    for (const f of extra) {
      if (y > doc.page.height - 70) { doc.addPage(); y = 40; }
      doc.font('Helvetica-Bold').fontSize(8.5).fillColor(SEVERITY_COLOR[f.severity]).text(SEVERITY_PT[f.severity], 40, y + 1, { width: 70 });
      doc.font('Helvetica-Bold').fontSize(10).fillColor(DARK).text(f.description, 112, y, { width: W - 72 });
      const parts = [
        f.checkMileage ? `verificar até ${f.checkMileage.toLocaleString('pt-BR')} km` : null,
        f.informedAt ? `cliente avisado em ${formatDate(f.informedAt)}${f.informedVia ? ` ${VIA_PT[f.informedVia]}` : ''}` : null,
        DECISION_PT[f.decision],
      ].filter(Boolean);
      doc.font('Helvetica').fontSize(8.5).fillColor(GRAY).text(parts.join('  ·  '), 112, doc.y + 1, { width: W - 72 });
      y = doc.y + 8;
    }
    if (extra.some((f) => f.severity === 'URGENT')) {
      doc.font('Helvetica-Bold').fontSize(9).fillColor(SEVERITY_COLOR.URGENT)
        .text('Itens marcados como URGENTE podem afetar a sua segurança. Recomendamos resolver o quanto antes.', 40, y, { width: W });
      y = doc.y + 4;
    }
  }

  y += 10;
  doc.font('Helvetica').fontSize(8.5).fillColor(GRAY);
  if (type === 'quote') {
    doc.text(settings.sellsParts ? 'Orçamento válido por 7 dias. Peças sujeitas à disponibilidade.' : 'Orçamento válido por 7 dias.', 40, y, { width: W });
    if (order.approvedAt) doc.text(`Aprovado em ${formatDateTime(order.approvedAt)}.`, 40, doc.y + 2, { width: W });
  } else {
    if (order.warrantyUntil) doc.text(`Garantia dos serviços até ${formatDate(order.warrantyUntil)}.`, 40, y, { width: W });
    doc.text('Motos não retiradas em até 30 dias após o aviso de "pronta" poderão ter cobrança de estadia.', 40, doc.y + 2, { width: W });
    if (extra.length) doc.text('Ao assinar, o cliente declara que foi informado dos outros pontos encontrados na moto, listados acima.', 40, doc.y + 2, { width: W });
    y = Math.max(doc.y + 50, y + 60);
    if (y < doc.page.height - 80) {
      doc.moveTo(60, y).lineTo(260, y).strokeColor('#999').stroke();
      doc.moveTo(W - 180, y).lineTo(W + 20, y).stroke();
      doc.fontSize(8).text('Assinatura do cliente', 60, y + 4, { width: 200, align: 'center' })
        .text(settings.shopName, W - 180, y + 4, { width: 200, align: 'center' });
    }
  }
  doc.end();
}
