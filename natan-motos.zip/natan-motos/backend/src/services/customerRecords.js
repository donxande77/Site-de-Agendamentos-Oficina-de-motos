// Cadastro único: um cliente por WhatsApp, uma moto por placa. Aqui ficam as ferramentas para
// corrigir quando algo escapou (cliente que trocou de número, placa digitada errada, moto vendida).
import { db } from '../lib/db.js';
import { badRequest, notFound } from '../lib/errors.js';
import { formatPhone } from '../lib/util.js';
import { audit } from './audit.js';

const live = (id, trx = db) => trx('customers').where({ id }).whereNull('anonymizedAt').first();

/** A moto passa para outro cliente (vendida). O histórico continua com a moto. */
export async function transferMotorcycle(motorcycleId, customerId, userId) {
  return db.transaction(async (trx) => {
    const bike = await trx('motorcycles').where({ id: motorcycleId }).forUpdate().first();
    if (!bike) throw notFound('Moto não encontrada.');
    if (!(await live(customerId, trx))) throw notFound('Cliente não encontrado.');
    if (bike.customerId === customerId) throw badRequest('A moto já está no cadastro desse cliente.');
    await trx('motorcycles').where({ id: bike.id }).update({ customerId, updatedAt: new Date() });
    // Lembretes de manutenção eram para o dono antigo
    await trx('maintenance_reminders').where({ motorcycleId: bike.id }).whereNull('doneAt').whereNull('sentAt').del();
    await audit(userId, 'motorcycle.transfer', 'motorcycle', bike.id, { from: bike.customerId, to: customerId }, trx);
  });
}

/**
 * Junta dois cadastros do mesmo cliente: tudo do `duplicateId` passa para o `keepId`
 * (motos, agendamentos, OS). O telefone do cadastro repetido fica anotado nas observações.
 */
export async function mergeCustomers(keepId, duplicateId, userId) {
  if (keepId === duplicateId) throw badRequest('Escolha dois cadastros diferentes.');
  return db.transaction(async (trx) => {
    const [keep, dup] = await Promise.all([live(keepId, trx), live(duplicateId, trx)]);
    if (!keep || !dup) throw notFound('Cliente não encontrado.');
    const moved = {
      motorcycles: await trx('motorcycles').where({ customerId: dup.id }).update({ customerId: keep.id, updatedAt: new Date() }),
      bookings: await trx('bookings').where({ customerId: dup.id }).update({ customerId: keep.id }),
      orders: await trx('service_orders').where({ customerId: dup.id }).update({ customerId: keep.id }),
    };
    const note = `Cadastro juntado com "${dup.name}" (WhatsApp ${formatPhone(dup.phone)}) em ${new Date().toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })}.`;
    const latest = (a, b) => (!a ? b : !b ? a : new Date(a) > new Date(b) ? a : b);
    const consentStamp = (c) => latest(c.reminderConsentAt, c.reminderConsentRevokedAt);
    await trx('customers').where({ id: keep.id }).update({
      email: keep.email || dup.email,
      notes: [keep.notes, dup.notes, note].filter(Boolean).join('\n'),
      noShowCount: keep.noShowCount + dup.noShowCount,
      privacyAckAt: latest(keep.privacyAckAt, dup.privacyAckAt),
      lastServiceAt: latest(keep.lastServiceAt, dup.lastServiceAt),
      // Consentimento de lembretes: vale a decisão mais recente (dada ou revogada)
      ...(new Date(consentStamp(dup) || 0) > new Date(consentStamp(keep) || 0)
        ? { reminderConsentAt: dup.reminderConsentAt, reminderConsentRevokedAt: dup.reminderConsentRevokedAt }
        : {}),
      updatedAt: new Date(),
    });
    await trx('customers').where({ id: dup.id }).del();
    await audit(userId, 'customer.merge', 'customer', keep.id, { removed: dup.id, ...moved }, trx);
    return moved;
  });
}

/** Duas motos que são a mesma (placa digitada errada): tudo vai para `keepId`. */
export async function mergeMotorcycles(keepId, duplicateId, userId) {
  if (keepId === duplicateId) throw badRequest('Escolha duas motos diferentes.');
  return db.transaction(async (trx) => {
    const [keep, dup] = await Promise.all([
      trx('motorcycles').where({ id: keepId }).forUpdate().first(),
      trx('motorcycles').where({ id: duplicateId }).forUpdate().first(),
    ]);
    if (!keep || !dup) throw notFound('Moto não encontrada.');
    if (keep.customerId !== dup.customerId) throw badRequest('As duas motos precisam estar no mesmo cliente. Junte os cadastros ou transfira a moto antes.');
    for (const table of ['bookings', 'service_orders', 'maintenance_reminders', 'order_findings']) {
      await trx(table).where({ motorcycleId: dup.id }).update({ motorcycleId: keep.id });
    }
    await trx('motorcycles').where({ id: keep.id }).update({
      year: keep.year || dup.year,
      color: keep.color || dup.color,
      lastMileage: Math.max(keep.lastMileage || 0, dup.lastMileage || 0) || null,
      updatedAt: new Date(),
    });
    await trx('motorcycles').where({ id: dup.id }).del();
    await audit(userId, 'motorcycle.merge', 'motorcycle', keep.id, { removed: dup.id, plate: dup.plate }, trx);
  });
}

/** Cadastros que parecem ser da mesma pessoa: mesmo nome ou mesmo e-mail. */
export async function possibleDuplicates() {
  const rows = await db.raw(`
    SELECT a.id AS "aId", a.name AS "aName", a.phone AS "aPhone", b.id AS "bId", b.name AS "bName", b.phone AS "bPhone",
      CASE WHEN lower(a.email) = lower(b.email) THEN 'email' ELSE 'name' END AS reason
    FROM customers a JOIN customers b ON a.id < b.id
    WHERE a."anonymizedAt" IS NULL AND b."anonymizedAt" IS NULL
      AND (lower(btrim(a.name)) = lower(btrim(b.name)) OR (a.email IS NOT NULL AND lower(a.email) = lower(b.email)))
    ORDER BY a.name LIMIT 30`);
  return rows.rows;
}
