import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from '../config.js';
import { randomToken } from '../lib/util.js';
import { badRequest } from '../lib/errors.js';

// Detects the real image type from the file header (never trust the client's mimetype).
export function detectImage(buffer) {
  if (buffer.length > 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'jpg';
  if (buffer.length > 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buffer.length > 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  return null;
}

/**
 * StorageProvider: local disk implementation. Files get unguessable names (192-bit).
 * To use S3/R2 later, implement the same save/remove methods and swap it here.
 */
export const storage = {
  async save(buffer) {
    const ext = detectImage(buffer);
    if (!ext) throw badRequest('Envie fotos em JPG, PNG ou WEBP.', 'INVALID_IMAGE');
    await fs.mkdir(config.uploadsDir, { recursive: true });
    const name = `${randomToken(24)}.${ext}`;
    await fs.writeFile(path.join(config.uploadsDir, name), buffer);
    return `/uploads/${name}`;
  },
  async remove(url) {
    const name = path.basename(String(url || ''));
    if (!/^[\w-]+\.(jpg|png|webp)$/.test(name)) return;
    await fs.rm(path.join(config.uploadsDir, name), { force: true });
  },
};
