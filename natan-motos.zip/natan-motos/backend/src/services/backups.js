// Reads the backup log (table backup_runs, written by deploy/backup) and turns it into
// plain-language status for the owner. Nothing here runs backups: that is the backup container.

const HOUR = 3600_000;
// How old the last good run of each kind may be before the panel warns.
// Database every 6 h → warn after two missed runs; full daily; restore test weekly.
export const LIMITS = { db: 13 * HOUR, full: 30 * HOUR, verify: 8 * 24 * HOUR };

const LABEL = {
  db: 'Backup do banco',
  full: 'Backup completo (banco + fotos)',
  verify: 'Teste de restauração',
};

export async function backupStatus(db, now = new Date()) {
  const recent = await db('backup_runs').orderBy('finishedAt', 'desc').orderBy('id', 'desc').limit(20)
    .select('id', 'kind', 'status', 'startedAt', 'finishedAt', 'sizeBytes', 'offsite', 'message');
  if (!recent.length) return { configured: false, healthy: false, problems: [], last: {}, recent: [] };

  const last = {};
  const problems = [];
  for (const kind of ['db', 'full', 'verify']) {
    const [lastOk, lastAny] = await Promise.all([
      db('backup_runs').where({ kind, status: 'ok' }).orderBy('finishedAt', 'desc').first(),
      db('backup_runs').where({ kind }).orderBy('finishedAt', 'desc').first(),
    ]);
    last[kind] = { ok: lastOk || null, latest: lastAny || null };
    if (lastAny?.status === 'error') {
      problems.push(`${LABEL[kind]} falhou na última tentativa: ${lastAny.message || 'erro sem detalhe'}.`);
    } else if (!lastOk || now - new Date(lastOk.finishedAt) > LIMITS[kind]) {
      problems.push(lastOk
        ? `${LABEL[kind]} está atrasado: o último deu certo em ${new Date(lastOk.finishedAt).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}.`
        : `${LABEL[kind]} ainda não rodou nenhuma vez.`);
    }
  }
  const lastDb = last.db.ok;
  if (lastDb && !lastDb.offsite) problems.push('O backup está só no servidor: a cópia no Google Drive não está configurada ou falhou.');

  return {
    configured: true,
    healthy: problems.length === 0,
    problems,
    last,
    recent: recent.map((r) => ({ ...r, sizeBytes: r.sizeBytes == null ? null : Number(r.sizeBytes) })),
  };
}
