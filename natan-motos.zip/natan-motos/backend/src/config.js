import { fileURLToPath } from 'node:url';

// Central configuration read from environment variables.
const env = process.env;

export const config = {
  env: env.NODE_ENV || 'development',
  isProd: env.NODE_ENV === 'production',
  isTest: env.NODE_ENV === 'test',
  port: Number(env.PORT || 3333),
  databaseUrl: env.DATABASE_URL,
  jwtSecret: env.JWT_SECRET,
  jwtRefreshSecret: env.JWT_REFRESH_SECRET,
  accessTtl: '15m',
  refreshTtlDays: 7,
  corsOrigin: env.CORS_ORIGIN || '',
  publicBaseUrl: env.PUBLIC_BASE_URL || 'http://localhost:5173',
  uploadsDir: env.UPLOADS_DIR || fileURLToPath(new URL('../uploads/', import.meta.url)),
  frontendDist: env.FRONTEND_DIST || fileURLToPath(new URL('../../frontend/dist/', import.meta.url)),
  trustProxy: env.TRUST_PROXY ? Number(env.TRUST_PROXY) : 1,
  cronEnabled: env.CRON_ENABLED !== 'false' && env.NODE_ENV !== 'test',
  whatsapp: {
    token: env.WHATSAPP_TOKEN || '',
    phoneNumberId: env.WHATSAPP_PHONE_NUMBER_ID || '',
    verifyToken: env.WHATSAPP_VERIFY_TOKEN || '',
    appSecret: env.WHATSAPP_APP_SECRET || '',
    apiVersion: env.WHATSAPP_API_VERSION || 'v21.0',
    templateLanguage: env.WHATSAPP_TEMPLATE_LANG || 'pt_BR',
  },
};

export function assertConfig() {
  const missing = ['DATABASE_URL', 'JWT_SECRET', 'JWT_REFRESH_SECRET'].filter((k) => !env[k]);
  if (missing.length) {
    throw new Error(`Variáveis de ambiente faltando: ${missing.join(', ')}. Veja o arquivo .env.example.`);
  }
  if (config.isProd && (config.jwtSecret.length < 32 || config.jwtRefreshSecret.length < 32)) {
    throw new Error('JWT_SECRET e JWT_REFRESH_SECRET precisam ter pelo menos 32 caracteres em produção.');
  }
}
