import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { db } from '../lib/db.js';
import { HttpError, forbidden } from '../lib/errors.js';

export const REFRESH_COOKIE = 'nm_refresh';

export function signAccess(user) {
  return jwt.sign({ sub: user.id, role: user.role, tv: user.tokenVersion }, config.jwtSecret, { expiresIn: config.accessTtl });
}

export function signRefresh(user) {
  return jwt.sign({ sub: user.id, tv: user.tokenVersion }, config.jwtRefreshSecret, { expiresIn: `${config.refreshTtlDays}d` });
}

export function refreshCookieOptions() {
  return {
    httpOnly: true,
    secure: config.isProd,
    sameSite: 'strict',
    path: '/api/v1/auth',
    maxAge: config.refreshTtlDays * 24 * 60 * 60 * 1000,
  };
}

export const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });

export async function requireAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next(new HttpError(401, 'Faça login para continuar.', 'UNAUTHENTICATED'));
  try {
    const payload = jwt.verify(token, config.jwtSecret);
    const user = await db('users').where({ id: payload.sub }).first();
    if (!user || !user.active || user.tokenVersion !== payload.tv) throw new Error('revoked');
    req.user = user;
    return next();
  } catch {
    return next(new HttpError(401, 'Sua sessão expirou. Entre de novo.', 'UNAUTHENTICATED'));
  }
}

export const requireRole = (...roles) => (req, _res, next) => {
  if (!roles.includes(req.user?.role)) return next(forbidden());
  return next();
};

// OWNER   = administrador do sistema: configurations (services and prices, shop settings, team, parts catalog, backup)
// MANAGER = dono da oficina: everything in the day to day, money included, no configuration
// STAFF   = run the front desk (agenda, OS, payments, customers)
// BUSINESS = see and handle the money (dashboard, finance, expenses, LGPD requests)
export const STAFF = ['OWNER', 'MANAGER', 'ATTENDANT'];
export const BUSINESS = ['OWNER', 'MANAGER'];
export const SYSTEM = ['OWNER'];
