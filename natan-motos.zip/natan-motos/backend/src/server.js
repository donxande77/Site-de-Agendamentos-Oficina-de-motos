import { assertConfig, config } from './config.js';
import { createApp } from './app.js';
import { startCron } from './jobs/cron.js';
import { db } from './lib/db.js';

assertConfig();

const app = createApp();
const server = app.listen(config.port, () => {
  console.log(`Natan Motos API rodando em http://localhost:${config.port}`);
});

if (config.cronEnabled) startCron();

const shutdown = async () => {
  server.close();
  await db.destroy();
  process.exit(0);
};
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
