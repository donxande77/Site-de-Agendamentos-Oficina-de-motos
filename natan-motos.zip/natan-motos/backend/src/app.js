import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { config } from './config.js';
import { errorHandler, notFound } from './lib/errors.js';
import { requireAuth } from './middleware/auth.js';
import publicRoutes from './routes/public.js';
import authRoutes from './routes/auth.js';
import webhookRoutes from './routes/webhooks.js';
import agendaRoutes from './routes/admin/agenda.js';
import partsCatalogRoutes from './routes/admin/partsCatalog.js';
import customerRoutes from './routes/admin/customers.js';
import catalogRoutes from './routes/admin/catalog.js';
import orderRoutes from './routes/admin/orders.js';
import financeRoutes from './routes/admin/finance.js';
import settingsRoutes from './routes/admin/settings.js';
import { db } from './lib/db.js';

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);

  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'"],
        'style-src': ["'self'", "'unsafe-inline'"],
        'font-src': ["'self'", 'data:'],
        'img-src': ["'self'", 'data:', 'blob:'],
        'frame-src': ['https://www.google.com', 'https://maps.google.com'],
        'connect-src': ["'self'"],
        'form-action': ["'self'"],
        'frame-ancestors': ["'none'"],
        'upgrade-insecure-requests': config.isProd ? [] : null,
      },
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  }));

  if (config.corsOrigin) {
    app.use('/api', cors({ origin: config.corsOrigin.split(','), credentials: true }));
  }

  // Raw body is kept only for the WhatsApp webhook signature check
  app.use(express.json({
    limit: '200kb',
    verify: (req, _res, buf) => { if (req.originalUrl.startsWith('/api/v1/webhooks')) req.rawBody = buf; },
  }));
  app.use(cookieParser());

  app.get('/api/health', async (_req, res) => {
    await db.raw('SELECT 1');
    res.json({ ok: true, time: new Date().toISOString() });
  });

  app.use('/api/v1/public', (req, res, next) => { res.set('X-Robots-Tag', 'noindex'); next(); }, publicRoutes);
  app.use('/api/v1/auth', authRoutes);
  app.use('/api/v1/webhooks', webhookRoutes);

  const admin = express.Router();
  admin.use(requireAuth);
  admin.use((_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
  admin.use(agendaRoutes, customerRoutes, catalogRoutes, partsCatalogRoutes, orderRoutes, financeRoutes, settingsRoutes);
  app.use('/api/v1/admin', admin);

  app.use('/api', (_req, _res, next) => next(notFound('Rota não encontrada.')));

  // Built-in illustrations of the parts catalog
  app.use('/parts-img', express.static(fileURLToPath(new URL('../assets/parts/', import.meta.url)), { maxAge: '30d', fallthrough: false }));

  // Uploaded photos: unguessable names, never indexed, never cached publicly
  app.use('/uploads', express.static(config.uploadsDir, {
    fallthrough: false,
    setHeaders: (res) => { res.set('X-Robots-Tag', 'noindex'); res.set('Cache-Control', 'private, max-age=86400'); },
  }));

  // Production: the backend also serves the built frontend (single service deploy)
  const indexFile = path.join(config.frontendDist, 'index.html');
  if (fs.existsSync(indexFile)) {
    // Link previews (Instagram, WhatsApp) need absolute image URLs
    const base = config.publicBaseUrl.replace(/\/$/, '');
    const html = fs.readFileSync(indexFile, 'utf8').replace('content="/og.png"', `content="${base}/og.png"`);
    app.use(express.static(config.frontendDist, { index: false, maxAge: '1h' }));
    app.get(/^\/(?!api|uploads).*/, (_req, res) => {
      res.set('Cache-Control', 'no-cache');
      res.type('html').send(html);
    });
  }

  app.use(errorHandler);
  return app;
}
