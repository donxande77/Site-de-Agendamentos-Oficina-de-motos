import cron from 'node-cron';
import { markNoShows, send24hReminders, runRetention } from './tasks.js';

const safe = (name, fn) => async () => {
  try {
    const r = await fn();
    if (r && (typeof r === 'number' ? r > 0 : true)) console.log(`[cron] ${name}:`, r);
  } catch (err) {
    console.error(`[cron] ${name} falhou:`, err.message);
  }
};

export function startCron() {
  const opts = { timezone: 'America/Sao_Paulo' };
  cron.schedule('*/5 * * * *', safe('faltas', markNoShows), opts);
  cron.schedule('10 * * * *', safe('lembretes 24h', send24hReminders), opts);
  cron.schedule('30 3 * * *', safe('retenção LGPD', runRetention), opts);
  console.log('[cron] rotinas agendadas: faltas (5 min), lembretes 24 h (hora em hora), retenção (03:30)');
}
