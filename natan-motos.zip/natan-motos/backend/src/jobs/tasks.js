import { DateTime } from 'luxon';
import { db } from '../lib/db.js';
import { TZ } from '../lib/util.js';
import { getSettings } from '../services/availability.js';
import { storage } from '../services/storage.js';
import { notify } from '../services/whatsapp/index.js';
import { bookingVars } from '../services/messages.js';
import { getBookingFull } from '../services/bookings.js';

// Bookings not checked in X minutes after start become NO_SHOW.
export async function markNoShows(now = new Date()) {
  const settings = await getSettings(db);
  const limit = DateTime.fromJSDate(now).minus({ minutes: settings.noShowAfterMinutes }).toJSDate();
  const rows = await db('bookings').whereIn('status', ['PENDING', 'CONFIRMED']).where('startAt', '<', limit).select('id', 'customerId');
  for (const b of rows) {
    await db.transaction(async (trx) => {
      await trx('bookings').where({ id: b.id }).update({ status: 'NO_SHOW', updatedAt: new Date() });
      await trx('customers').where({ id: b.customerId }).increment('noShowCount', 1);
    });
  }
  return rows.length;
}

// Level 2 only: automatic reminder ~24 h before the booking.
export async function send24hReminders(now = new Date()) {
  const settings = await getSettings(db);
  if (!settings.whatsappLevel2Enabled) return 0;
  const from = DateTime.fromJSDate(now).plus({ hours: 23 }).toJSDate();
  const to = DateTime.fromJSDate(now).plus({ hours: 25 }).toJSDate();
  const rows = await db('bookings').where({ status: 'CONFIRMED' }).whereNull('reminderSentAt').whereBetween('startAt', [from, to]).select('id');
  for (const { id } of rows) {
    const b = await getBookingFull({ id });
    const result = await notify({ settings, template: 'reminder24h', phone: b.customer.phone, vars: bookingVars(settings, b, b.customer, b.motorcycle, b.services) });
    if (result.mode === 'sent') await db('bookings').where({ id }).update({ reminderSentAt: new Date() });
  }
  return rows.length;
}

/**
 * Data retention (LGPD arts. 15 and 16):
 * - check-in photos: deleted 1 year after delivery
 * - booking photos without a service order: deleted after 1 year
 * - notification logs: deleted after 180 days
 * - customers with no service for 5 years: anonymised (financial records stay, unidentified)
 */
export async function runRetention(now = new Date()) {
  const n = DateTime.fromJSDate(now).setZone(TZ);
  const oneYear = n.minus({ years: 1 }).toJSDate();
  const photos = await db('photos as p')
    .leftJoin('service_orders as o', 'o.id', 'p.serviceOrderId')
    .where((w) => w.where('o.deliveredAt', '<', oneYear).orWhere((w2) => w2.whereNull('p.serviceOrderId').where('p.createdAt', '<', oneYear)))
    .select('p.id', 'p.url');
  for (const p of photos) {
    await db('photos').where({ id: p.id }).del();
    await storage.remove(p.url);
  }
  const logs = await db('notification_logs').where('createdAt', '<', n.minus({ days: 180 }).toJSDate()).del();

  const fiveYears = n.minus({ years: 5 }).toJSDate();
  const stale = await db('customers').whereNull('anonymizedAt')
    .where((w) => w.where('lastServiceAt', '<', fiveYears).orWhere((w2) => w2.whereNull('lastServiceAt').where('updatedAt', '<', fiveYears)))
    .select('id');
  for (const { id } of stale) {
    await db.transaction(async (trx) => {
      await trx('customers').where({ id }).update({ name: 'Cliente removido', phone: `anon-${id}`, email: null, notes: null, anonymizedAt: new Date() });
      const bikes = await trx('motorcycles').where({ customerId: id });
      for (const b of bikes) await trx('motorcycles').where({ id: b.id }).update({ plate: `X${String(b.id).padStart(6, '0')}` });
      await trx('bookings').where({ customerId: id }).update({ problemDescription: null, notes: null });
    });
  }
  return { photos: photos.length, logs, customers: stale.length };
}
