// Three accesses: shop administrator, mechanic and customer.
// The administrator decides whether mechanics may add services and prices to a quote (off by default).
export async function up(knex) {
  await knex.schema.alterTable('settings', (t) => {
    t.boolean('mechanicCanQuote').notNullable().defaultTo(false);
  });
}

export async function down(knex) {
  await knex.schema.alterTable('settings', (t) => {
    t.dropColumn('mechanicCanQuote');
  });
}
