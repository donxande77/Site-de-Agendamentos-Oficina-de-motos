// Initial schema for Natan Motos.
// Money = integer cents. Timestamps = timestamptz (UTC).

const BOOKING_STATUS = ['PENDING', 'CONFIRMED', 'CHECKED_IN', 'CANCELLED', 'NO_SHOW'];
const BOOKING_SOURCE = ['instagram', 'whatsapp', 'direct', 'walk_in'];
const ORDER_STATUS = [
  'OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL', 'APPROVED', 'IN_PROGRESS',
  'WAITING_PARTS', 'READY', 'DELIVERED', 'CANCELLED',
];
const QUOTE_STATUS = ['DRAFT', 'SENT', 'APPROVED', 'REJECTED'];

export async function up(knex) {
  await knex.raw('CREATE EXTENSION IF NOT EXISTS btree_gist');

  await knex.schema.createTable('settings', (t) => {
    t.integer('id').primary().defaultTo(1);
    t.string('shopName').notNullable();
    t.string('ownerName').notNullable();
    t.string('address').notNullable();
    t.string('city').notNullable();
    t.string('mapQuery').notNullable();
    t.string('whatsappNumber').notNullable();
    t.string('instagram').notNullable();
    t.string('privacyContact').notNullable();
    t.string('publicBaseUrl').notNullable();
    t.integer('slotMinutes').notNullable().defaultTo(30);
    t.integer('minNoticeHours').notNullable().defaultTo(2);
    t.integer('maxDaysAhead').notNullable().defaultTo(30);
    t.integer('cancelNoticeHours').notNullable().defaultTo(2);
    t.integer('noShowAfterMinutes').notNullable().defaultTo(30);
    t.integer('noShowFlagThreshold').notNullable().defaultTo(2);
    t.integer('forceDropOffMinutes').notNullable().defaultTo(180);
    t.boolean('autoConfirm').notNullable().defaultTo(true);
    t.integer('defaultWarrantyDays').notNullable().defaultTo(90);
    t.integer('oilReminderKm').notNullable().defaultTo(3000);
    t.integer('oilReminderDays').notNullable().defaultTo(90);
    t.string('scheduleView').notNullable().defaultTo('bay');
    t.boolean('whatsappLevel2Enabled').notNullable().defaultTo(false);
    t.jsonb('messageTexts').notNullable();
    t.timestamp('updatedAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('users', (t) => {
    t.increments('id');
    t.string('name').notNullable();
    t.string('email').notNullable().unique();
    t.string('passwordHash').notNullable();
    t.enu('role', ['OWNER', 'ATTENDANT', 'MECHANIC']).notNullable();
    t.integer('commissionPercent').notNullable().defaultTo(0);
    t.boolean('active').notNullable().defaultTo(true);
    t.integer('tokenVersion').notNullable().defaultTo(0);
    t.timestamps(true, true, true);
  });

  await knex.schema.createTable('bays', (t) => {
    t.increments('id');
    t.string('name').notNullable();
    t.boolean('active').notNullable().defaultTo(true);
    t.integer('order').notNullable().defaultTo(0);
  });

  await knex.schema.createTable('business_hours', (t) => {
    t.increments('id');
    t.integer('weekday').notNullable().unique(); // 0 = Sunday ... 6 = Saturday
    t.boolean('closed').notNullable().defaultTo(false);
    t.string('opensAt', 5).notNullable().defaultTo('08:00');
    t.string('closesAt', 5).notNullable().defaultTo('18:00');
    t.string('breakStart', 5);
    t.string('breakEnd', 5);
  });

  await knex.schema.createTable('time_blocks', (t) => {
    t.increments('id');
    t.timestamp('startAt', { useTz: true }).notNullable();
    t.timestamp('endAt', { useTz: true }).notNullable();
    t.string('reason').notNullable();
    t.integer('bayId').references('bays.id').onDelete('CASCADE');
    t.integer('userId').references('users.id').onDelete('CASCADE');
    t.timestamp('createdAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['startAt', 'endAt']);
  });

  await knex.schema.createTable('customers', (t) => {
    t.increments('id');
    t.string('name').notNullable();
    t.string('phone').notNullable().unique();
    t.string('email');
    t.timestamp('privacyAckAt', { useTz: true });
    t.timestamp('reminderConsentAt', { useTz: true });
    t.timestamp('reminderConsentRevokedAt', { useTz: true });
    t.integer('noShowCount').notNullable().defaultTo(0);
    t.text('notes');
    t.timestamp('anonymizedAt', { useTz: true });
    t.timestamp('lastServiceAt', { useTz: true });
    t.timestamps(true, true, true);
  });

  await knex.schema.createTable('motorcycles', (t) => {
    t.increments('id');
    t.integer('customerId').notNullable().references('customers.id');
    t.string('brand').notNullable();
    t.string('model').notNullable();
    t.integer('year');
    t.string('plate', 10).notNullable().unique();
    t.string('color');
    t.integer('lastMileage');
    t.timestamps(true, true, true);
  });

  await knex.schema.createTable('services', (t) => {
    t.increments('id');
    t.string('name').notNullable();
    t.text('description');
    t.string('category').notNullable().defaultTo('Geral');
    t.integer('durationMinutes').notNullable();
    t.integer('basePriceCents');
    t.boolean('priceOnEvaluation').notNullable().defaultTo(false);
    t.boolean('dropOffRequired').notNullable().defaultTo(false);
    t.integer('warrantyDays');
    t.boolean('isOilChange').notNullable().defaultTo(false);
    t.boolean('active').notNullable().defaultTo(true);
    t.boolean('onlineVisible').notNullable().defaultTo(true);
    t.integer('order').notNullable().defaultTo(0);
  });

  await knex.schema.createTable('bookings', (t) => {
    t.increments('id');
    t.string('code', 12).notNullable().unique();
    t.integer('customerId').notNullable().references('customers.id');
    t.integer('motorcycleId').notNullable().references('motorcycles.id');
    t.integer('bayId').notNullable().references('bays.id');
    t.integer('mechanicId').references('users.id');
    t.timestamp('startAt', { useTz: true }).notNullable();
    t.timestamp('endAt', { useTz: true }).notNullable();
    t.enu('status', BOOKING_STATUS).notNullable().defaultTo('CONFIRMED');
    t.enu('source', BOOKING_SOURCE).notNullable().defaultTo('direct');
    t.boolean('dropOff').notNullable().defaultTo(false);
    t.text('problemDescription');
    t.text('notes');
    t.string('manageToken').notNullable().unique();
    t.timestamp('reminderSentAt', { useTz: true });
    t.timestamp('cancelledAt', { useTz: true });
    t.integer('createdById').references('users.id');
    t.timestamps(true, true, true);
    t.index(['startAt']);
    t.index(['status']);
  });

  // Database-level guarantee: two active bookings can never overlap on the same bay.
  await knex.raw(`
    ALTER TABLE bookings ADD CONSTRAINT bookings_no_overlap
    EXCLUDE USING gist ("bayId" WITH =, tstzrange("startAt", "endAt", '[)') WITH &&)
    WHERE (status IN ('PENDING', 'CONFIRMED', 'CHECKED_IN'))
  `);
  await knex.raw(`ALTER TABLE bookings ADD CONSTRAINT bookings_valid_range CHECK ("endAt" > "startAt")`);

  await knex.schema.createTable('booking_services', (t) => {
    t.increments('id');
    t.integer('bookingId').notNullable().references('bookings.id').onDelete('CASCADE');
    t.integer('serviceId').notNullable().references('services.id');
    t.string('nameSnapshot').notNullable();
    t.integer('priceSnapshotCents');
    t.boolean('priceOnEvaluationSnapshot').notNullable().defaultTo(false);
    t.integer('durationSnapshot').notNullable();
  });

  await knex.schema.createTable('parts', (t) => {
    t.increments('id');
    t.string('name').notNullable();
    t.string('code');
    t.integer('costCents').notNullable().defaultTo(0);
    t.integer('priceCents').notNullable().defaultTo(0);
    t.integer('stock').notNullable().defaultTo(0);
    t.integer('minStock').notNullable().defaultTo(0);
    t.boolean('active').notNullable().defaultTo(true);
    t.timestamps(true, true, true);
  });

  await knex.schema.createTable('service_orders', (t) => {
    t.increments('id');
    t.integer('number').notNullable().unique();
    t.integer('bookingId').unique().references('bookings.id');
    t.integer('customerId').notNullable().references('customers.id');
    t.integer('motorcycleId').notNullable().references('motorcycles.id');
    t.integer('mechanicId').references('users.id');
    t.integer('checkInMileage');
    t.string('fuelLevel');
    t.jsonb('checklist');
    t.text('diagnosis');
    t.enu('status', ORDER_STATUS).notNullable().defaultTo('OPEN');
    t.enu('quoteStatus', QUOTE_STATUS).notNullable().defaultTo('DRAFT');
    t.string('approvalToken').notNullable().unique();
    t.timestamp('quoteSentAt', { useTz: true });
    t.timestamp('approvedAt', { useTz: true });
    t.string('approvedIp');
    t.timestamp('rejectedAt', { useTz: true });
    t.boolean('stockDeducted').notNullable().defaultTo(false);
    t.timestamp('deliveredAt', { useTz: true });
    t.timestamp('warrantyUntil', { useTz: true });
    t.boolean('receivable').notNullable().defaultTo(false);
    t.integer('totalCents').notNullable().defaultTo(0);
    t.timestamps(true, true, true);
    t.index(['status']);
  });
  await knex.raw('CREATE SEQUENCE service_order_number_seq START 1');

  await knex.schema.createTable('service_order_items', (t) => {
    t.increments('id');
    t.integer('serviceOrderId').notNullable().references('service_orders.id').onDelete('CASCADE');
    t.enu('type', ['LABOR', 'PART']).notNullable();
    t.string('description').notNullable();
    t.integer('serviceId').references('services.id');
    t.integer('partId').references('parts.id');
    t.integer('quantity').notNullable().defaultTo(1);
    t.integer('unitPriceCents').notNullable();
    t.integer('unitCostCents').notNullable().defaultTo(0);
  });

  await knex.schema.createTable('payments', (t) => {
    t.increments('id');
    t.integer('serviceOrderId').notNullable().references('service_orders.id').onDelete('CASCADE');
    t.integer('amountCents').notNullable();
    t.enu('method', ['PIX', 'CASH', 'DEBIT', 'CREDIT']).notNullable();
    t.integer('installments').notNullable().defaultTo(1);
    t.timestamp('paidAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.string('notes');
    t.integer('receivedById').references('users.id');
    t.index(['paidAt']);
  });

  await knex.schema.createTable('expenses', (t) => {
    t.increments('id');
    t.enu('category', ['RENT', 'PARTS', 'TOOLS', 'UTILITIES', 'SALARIES', 'OTHER']).notNullable();
    t.string('description').notNullable();
    t.integer('amountCents').notNullable();
    t.date('dueDate').notNullable();
    t.date('paidAt');
    t.timestamp('createdAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['dueDate']);
  });

  await knex.schema.createTable('photos', (t) => {
    t.increments('id');
    t.string('url').notNullable();
    t.string('kind').notNullable().defaultTo('checkin');
    t.integer('serviceOrderId').references('service_orders.id').onDelete('CASCADE');
    t.integer('bookingId').references('bookings.id').onDelete('CASCADE');
    t.timestamp('createdAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('maintenance_reminders', (t) => {
    t.increments('id');
    t.integer('motorcycleId').notNullable().references('motorcycles.id').onDelete('CASCADE');
    t.integer('serviceOrderId').references('service_orders.id').onDelete('SET NULL');
    t.enu('type', ['OIL_CHANGE', 'REVIEW']).notNullable();
    t.date('dueDate').notNullable();
    t.integer('dueMileage');
    t.timestamp('sentAt', { useTz: true });
    t.timestamp('doneAt', { useTz: true });
    t.timestamp('createdAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.index(['dueDate']);
  });

  await knex.schema.createTable('notification_logs', (t) => {
    t.increments('id');
    t.string('channel').notNullable();
    t.string('to').notNullable();
    t.string('template').notNullable();
    t.jsonb('payload');
    t.string('status').notNullable();
    t.text('error');
    t.timestamp('createdAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('audit_logs', (t) => {
    t.increments('id');
    t.integer('userId').references('users.id').onDelete('SET NULL');
    t.string('action').notNullable();
    t.string('entity').notNullable();
    t.integer('entityId');
    t.jsonb('data');
    t.timestamp('createdAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
  });
}

export async function down(knex) {
  const tables = [
    'audit_logs', 'notification_logs', 'maintenance_reminders', 'photos', 'expenses', 'payments',
    'service_order_items', 'service_orders', 'parts', 'booking_services', 'bookings', 'services',
    'motorcycles', 'customers', 'time_blocks', 'business_hours', 'bays', 'users', 'settings',
  ];
  for (const t of tables) await knex.schema.dropTableIfExists(t);
  await knex.raw('DROP SEQUENCE IF EXISTS service_order_number_seq');
}
