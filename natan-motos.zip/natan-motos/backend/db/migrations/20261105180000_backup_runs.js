// Log written by the backup container (deploy/backup) so the owner sees in the panel
// whether backups are running and whether the copy outside the server is working.
export async function up(knex) {
  await knex.schema.createTable('backup_runs', (t) => {
    t.increments('id');
    t.string('kind', 16).notNullable(); // db | full | verify | restore
    t.string('status', 8).notNullable(); // ok | error
    t.timestamp('startedAt', { useTz: true });
    t.timestamp('finishedAt', { useTz: true }).notNullable().defaultTo(knex.fn.now());
    t.bigInteger('sizeBytes');
    t.boolean('offsite').notNullable().defaultTo(false);
    t.text('message');
    t.index(['kind', 'finishedAt']);
  });
  await knex.raw(`ALTER TABLE backup_runs ADD CONSTRAINT backup_runs_kind_chk CHECK (kind IN ('db', 'full', 'verify', 'restore'))`);
  await knex.raw(`ALTER TABLE backup_runs ADD CONSTRAINT backup_runs_status_chk CHECK (status IN ('ok', 'error'))`);
}

export async function down(knex) {
  await knex.schema.dropTable('backup_runs');
}
