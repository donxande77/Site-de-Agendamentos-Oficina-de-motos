// Prontuário da moto: relatório técnico de cada OS e os defeitos encontrados além do que o cliente pediu.
//   service_orders.workDone       o que foi feito (vai no PDF da OS, o cliente vê)
//   service_orders.internalNotes  observações só da oficina (nunca vão para o cliente)
//   order_findings                cada defeito/atenção encontrado, com gravidade, o que o cliente decidiu,
//                                 quando e como ele foi avisado, e em qual OS foi resolvido depois
export async function up(knex) {
  await knex.schema.alterTable('service_orders', (t) => {
    t.text('workDone');
    t.text('internalNotes');
  });
  await knex.schema.createTable('order_findings', (t) => {
    t.increments('id');
    t.integer('serviceOrderId').notNullable().references('service_orders.id').onDelete('CASCADE');
    t.integer('motorcycleId').notNullable().references('motorcycles.id').onDelete('CASCADE');
    t.string('description', 500).notNullable();
    t.enu('severity', ['URGENT', 'SOON', 'WATCH'], { useNative: false }).notNullable().defaultTo('SOON');
    // OPEN = ainda não falou com o cliente · FIXED = consertado nesta visita
    // LATER = cliente vai fazer depois · DECLINED = cliente não quis fazer
    t.enu('decision', ['OPEN', 'FIXED', 'LATER', 'DECLINED'], { useNative: false }).notNullable().defaultTo('OPEN');
    t.integer('checkMileage');
    t.timestamp('informedAt', { useTz: true });
    t.enu('informedVia', ['IN_PERSON', 'WHATSAPP', 'PHONE'], { useNative: false });
    t.integer('informedById').references('users.id').onDelete('SET NULL');
    t.timestamp('resolvedAt', { useTz: true });
    t.integer('resolvedOrderId').references('service_orders.id').onDelete('SET NULL');
    t.integer('createdById').references('users.id').onDelete('SET NULL');
    t.timestamps(true, true, true);
    t.index(['motorcycleId']);
    t.index(['serviceOrderId']);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('order_findings');
  await knex.schema.alterTable('service_orders', (t) => {
    t.dropColumn('workDone');
    t.dropColumn('internalNotes');
  });
}
