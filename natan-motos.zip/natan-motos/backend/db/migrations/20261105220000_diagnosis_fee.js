// "Valor do diagnóstico": one LABOR item per OS that the mechanic can price, even when he cannot
// touch the other services. Items created at check-in from a diagnosis service are marked too.
export async function up(knex) {
  await knex.schema.alterTable('service_order_items', (t) => {
    t.boolean('isDiagnosisFee').notNullable().defaultTo(false);
  });
  await knex.raw(`
    UPDATE service_order_items i SET "isDiagnosisFee" = true
    FROM (
      SELECT DISTINCT ON (i2."serviceOrderId") i2.id
      FROM service_order_items i2 JOIN services s ON s.id = i2."serviceId"
      WHERE i2.type = 'LABOR' AND (s.category = 'Diagnóstico' OR s.name ILIKE 'diagnóstico%')
      ORDER BY i2."serviceOrderId", i2.id
    ) d
    WHERE i.id = d.id`);
}

export async function down(knex) {
  await knex.schema.alterTable('service_order_items', (t) => {
    t.dropColumn('isDiagnosisFee');
  });
}
