// Four accesses: system administrator (OWNER, does all configuration), shop owner (MANAGER: runs the
// shop day to day, money included, but changes no configuration), mechanic and the customer.
export async function up(knex) {
  await knex.raw('ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check');
  await knex.raw(`ALTER TABLE users ADD CONSTRAINT users_role_check CHECK (role IN ('OWNER', 'MANAGER', 'ATTENDANT', 'MECHANIC'))`);
}

export async function down(knex) {
  await knex('users').where({ role: 'MANAGER' }).update({ role: 'OWNER' });
  await knex.raw('ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check');
  await knex.raw(`ALTER TABLE users ADD CONSTRAINT users_role_check CHECK (role IN ('OWNER', 'ATTENDANT', 'MECHANIC'))`);
}
