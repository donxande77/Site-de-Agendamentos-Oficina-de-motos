// Parts catalog (with images), "parts the customer buys" in quotes,
// and the "bring your parts" notice for shops that don't sell parts.
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const CATALOG = require('../data/catalog-parts.json');

const OLD_CONFIRMATION = 'Olá, {nome}! Seu agendamento na {oficina} está confirmado: {servicos} para a moto {moto}, dia {data} às {hora}. Código: {codigo}. Para remarcar ou cancelar: {link}';
const NEW_CONFIRMATION = 'Olá, {nome}! Seu agendamento na {oficina} está confirmado: {servicos} para a moto {moto}, dia {data} às {hora}. Código: {codigo}.{pecas} Para remarcar ou cancelar: {link}';
const OLD_REMINDER = 'Olá, {nome}! Lembrete: amanhã, {data} às {hora}, sua moto {moto} tem horário na {oficina}. Endereço: {endereco}. Precisa remarcar? {link}';
const NEW_REMINDER = 'Olá, {nome}! Lembrete: amanhã, {data} às {hora}, sua moto {moto} tem horário na {oficina}. Endereço: {endereco}.{pecas} Precisa remarcar? {link}';

export const PARTS_HINTS = {
  'Troca de óleo e filtro': 'Óleo do motor (confira a quantidade no manual da moto) e filtro de óleo.',
  'Revisão completa': 'Óleo do motor e filtro de óleo. Se precisar de outras peças, o mecânico passa a lista.',
  'Kit relação (corrente, coroa e pinhão)': 'Kit relação (corrente, coroa e pinhão) do modelo da sua moto.',
  'Pastilhas / lonas de freio': 'Pastilhas ou lonas de freio do modelo da sua moto.',
  'Troca de pneu': 'Pneu na medida certa e câmara de ar, se a moto usar câmara.',
};

export async function up(knex) {
  await knex.schema.createTable('catalog_parts', (t) => {
    t.increments('id');
    t.string('slug').unique();
    t.string('name').notNullable();
    t.string('category').notNullable();
    t.text('description');
    t.string('photoUrl'); // uploaded real photo; null = built-in illustration
    t.boolean('active').notNullable().defaultTo(true);
    t.integer('order').notNullable().defaultTo(0);
    t.timestamps(true, true, true);
    t.index(['category']);
  });
  await knex('catalog_parts').insert(CATALOG.map((p, i) => ({ ...p, order: i + 1 })));

  await knex.schema.alterTable('service_order_items', (t) => {
    t.integer('catalogPartId').references('catalog_parts.id');
    t.string('notes');
    t.integer('estimatedPriceCents');
  });
  await knex.raw('ALTER TABLE service_order_items DROP CONSTRAINT IF EXISTS service_order_items_type_check');
  await knex.raw(`ALTER TABLE service_order_items ADD CONSTRAINT service_order_items_type_check CHECK ("type" IN ('LABOR', 'PART', 'CUSTOMER_PART'))`);

  await knex.schema.alterTable('services', (t) => { t.text('partsToBring'); });
  for (const [name, hint] of Object.entries(PARTS_HINTS)) {
    await knex('services').where({ name }).whereNull('partsToBring').update({ partsToBring: hint });
  }

  await knex.schema.alterTable('settings', (t) => {
    t.boolean('sellsParts').notNullable().defaultTo(false);
    t.text('partsNotice');
  });
  const s = await knex('settings').where({ id: 1 }).first();
  if (s) {
    const texts = typeof s.messageTexts === 'string' ? JSON.parse(s.messageTexts) : s.messageTexts;
    if (texts.confirmation === OLD_CONFIRMATION) texts.confirmation = NEW_CONFIRMATION;
    if (texts.reminder24h === OLD_REMINDER) texts.reminder24h = NEW_REMINDER;
    await knex('settings').where({ id: 1 }).update({ messageTexts: JSON.stringify(texts) });
  }
}

export async function down(knex) {
  await knex.schema.alterTable('settings', (t) => { t.dropColumn('sellsParts'); t.dropColumn('partsNotice'); });
  await knex.schema.alterTable('services', (t) => { t.dropColumn('partsToBring'); });
  await knex('service_order_items').where({ type: 'CUSTOMER_PART' }).del();
  await knex.raw('ALTER TABLE service_order_items DROP CONSTRAINT IF EXISTS service_order_items_type_check');
  await knex.raw(`ALTER TABLE service_order_items ADD CONSTRAINT service_order_items_type_check CHECK ("type" IN ('LABOR', 'PART'))`);
  await knex.schema.alterTable('service_order_items', (t) => { t.dropColumn('catalogPartId'); t.dropColumn('notes'); t.dropColumn('estimatedPriceCents'); });
  await knex.schema.dropTable('catalog_parts');
}
