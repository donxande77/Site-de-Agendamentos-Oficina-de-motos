// Initial data for Natan Motos. Safe to run more than once: it only fills an empty database.
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { PARTS_HINTS } from '../migrations/20261105150000_parts_catalog.js';

export const DEFAULT_MESSAGES = {
  greeting:
    'Olá! Aqui é a {oficina}. Para agendar revisão ou serviço na sua moto, é só clicar no link: {link} — leva menos de 1 minuto. Se preferir falar com a gente, responda esta mensagem.',
  away:
    'Olá! A {oficina} está fechada agora, mas você já pode agendar pelo link: {link}. Respondemos assim que abrirmos.',
  confirmation:
    'Olá, {nome}! Seu agendamento na {oficina} está confirmado: {servicos} para a moto {moto}, dia {data} às {hora}. Código: {codigo}.{pecas} Para remarcar ou cancelar: {link}',
  reminder24h:
    'Olá, {nome}! Lembrete: amanhã, {data} às {hora}, sua moto {moto} tem horário na {oficina}. Endereço: {endereco}.{pecas} Precisa remarcar? {link}',
  quoteReady:
    'Olá, {nome}! O orçamento da sua moto {moto} ficou em {valor}. Veja os detalhes e aprove por aqui: {link}',
  bikeReady:
    'Olá, {nome}! Sua moto {moto} está pronta para retirada na {oficina}. Total: {valor}. Até já!',
  maintenance:
    'Olá, {nome}! Está chegando a hora da {tipo} da sua moto {moto}. Agende em menos de 1 minuto: {link}',
};

export async function seed(knex) {
  const existing = await knex('settings').first();
  if (existing) {
    console.log('Seed: o banco já tem dados, nada foi alterado.');
    return;
  }

  await knex('settings').insert({
    id: 1,
    shopName: 'Natan Motos',
    ownerName: 'Natan',
    address: 'Av. Canal 1, nº 11 - Santa Cruz, Rio de Janeiro - RJ, 23595-382',
    city: 'Rio de Janeiro - RJ',
    mapQuery: 'Av. Canal 1, 11 - Santa Cruz, Rio de Janeiro - RJ, 23595-382',
    whatsappNumber: '5521981939129',
    instagram: 'natann_motos',
    privacyContact: 'WhatsApp (21) 98193-9129',
    publicBaseUrl: process.env.PUBLIC_BASE_URL || 'http://localhost:5173',
    messageTexts: JSON.stringify(DEFAULT_MESSAGES),
  });

  // Assumed opening hours — the owner edits them in Configurações.
  const hours = [
    { weekday: 0, closed: true, opensAt: '08:00', closesAt: '12:00' },
    ...[1, 2, 3, 4, 5].map((weekday) => ({
      weekday, closed: false, opensAt: '08:00', closesAt: '18:00', breakStart: '12:00', breakEnd: '13:00',
    })),
    { weekday: 6, closed: false, opensAt: '08:00', closesAt: '12:00' },
  ];
  await knex('business_hours').insert(hours);

  await knex('bays').insert([
    { name: 'Elevador 1', order: 1 },
    { name: 'Elevador 2', order: 2 },
  ]);

  // Prices start empty ("sob consulta") until the owner fills them in.
  const services = [
    { name: 'Troca de óleo e filtro', category: 'Manutenção', durationMinutes: 30, isOilChange: true, description: 'Óleo novo e filtro, com checagem rápida da moto.' },
    { name: 'Revisão completa', category: 'Manutenção', durationMinutes: 180, dropOffRequired: true, description: 'Revisão geral: óleo, freios, relação, elétrica, suspensão e ajustes.' },
    { name: 'Kit relação (corrente, coroa e pinhão)', category: 'Transmissão', durationMinutes: 60, description: 'Troca do kit relação e ajuste da corrente.' },
    { name: 'Pastilhas / lonas de freio', category: 'Freios', durationMinutes: 60, description: 'Troca de pastilhas ou lonas e verificação do sistema de freio.' },
    { name: 'Troca de pneu', category: 'Pneus', durationMinutes: 30, description: 'Montagem e balanceamento do pneu.' },
    { name: 'Limpeza de carburador / bicos injetores', category: 'Motor', durationMinutes: 120, priceOnEvaluation: true, description: 'Limpeza e regulagem da alimentação.' },
    { name: 'Diagnóstico elétrico', category: 'Elétrica', durationMinutes: 60, priceOnEvaluation: true, description: 'Bateria, carga, partida, luzes e chicote.' },
    { name: 'Suspensão (retentor, óleo de bengala)', category: 'Suspensão', durationMinutes: 120, priceOnEvaluation: true, description: 'Troca de retentores e óleo da suspensão dianteira.' },
    { name: 'Diagnóstico geral / barulho estranho', category: 'Diagnóstico', durationMinutes: 60, priceOnEvaluation: true, description: 'A gente descobre o que a moto tem e passa o orçamento.' },
  ].map((s, i) => ({ ...s, partsToBring: PARTS_HINTS[s.name] || null, order: i + 1 }));
  await knex('services').insert(services);

  // First login = the system administrator (configures everything). The shop owner (Natan, role
  // MANAGER) is added afterwards in Configurações › Equipe.
  const email = (process.env.SEED_OWNER_EMAIL || 'admin@natanmotos.com.br').toLowerCase();
  const generated = !process.env.SEED_OWNER_PASSWORD;
  const password = process.env.SEED_OWNER_PASSWORD || crypto.randomBytes(9).toString('base64url');
  await knex('users').insert({
    name: process.env.SEED_OWNER_NAME || 'Administrador',
    email,
    passwordHash: await bcrypt.hash(password, 12),
    role: 'OWNER',
  });

  console.log('\n=== Natan Motos: banco criado ===');
  console.log(`Login do administrador do sistema: ${email}`);
  if (generated) console.log(`Senha gerada: ${password}  (anote e troque depois em Configurações > Minha senha)`);
  console.log('Depois, em Configurações > Equipe, cadastre o Natan como "Dono" e os mecânicos.');
  console.log('================================\n');
}
