import { lazy, Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Spinner } from './components/ui.jsx';
import { DEMO } from './lib/demo.js';
import DemoChrome from './components/DemoChrome.jsx';
import Home from './pages/public/Home.jsx';
import Booking from './pages/public/Booking.jsx';

const ManageBooking = lazy(() => import('./pages/public/ManageBooking.jsx'));
const Quote = lazy(() => import('./pages/public/Quote.jsx'));
const Privacy = lazy(() => import('./pages/public/Privacy.jsx'));
const NotFound = lazy(() => import('./pages/public/NotFound.jsx'));
const AdminApp = lazy(() => import('./pages/admin/AdminApp.jsx'));

export default function App() {
  return (
    <Suspense fallback={<Spinner className="min-h-dvh" />}>
      {DEMO && <DemoChrome />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/agendar" element={<Booking />} />
        <Route path="/meu-agendamento/:token" element={<ManageBooking />} />
        <Route path="/orcamento/:token" element={<Quote />} />
        <Route path="/privacidade" element={<Privacy />} />
        <Route path="/admin/*" element={<AdminApp />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
