import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Check, X, MessageCircle, CheckCircle2, Download } from 'lucide-react';
import { showDemoModal } from '../../lib/demo.js';
import { api } from '../../lib/api.js';
import { PublicHeader } from '../../components/public.jsx';
import { Button, LinkButton, Card, Spinner, Empty, ConfirmModal, useToast } from '../../components/ui.jsx';
import { money, plateMask, waUrl, fmtDateTime } from '../../lib/format.js';

export default function Quote() {
  const { token } = useParams();
  const qc = useQueryClient();
  const toast = useToast();
  const [ask, setAsk] = useState(null);
  const [busy, setBusy] = useState(false);
  const { data, isLoading, error } = useQuery({ queryKey: ['quote', token], queryFn: () => api.get(`/public/quotes/${token}`) });

  async function decide() {
    setBusy(true);
    try {
      await api.post(`/public/quotes/${token}/${ask}`);
      toast(ask === 'approve' ? 'Orçamento aprovado! Já vamos começar.' : 'Tudo bem, avisamos a oficina.');
      setAsk(null);
      qc.invalidateQueries({ queryKey: ['quote', token] });
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }

  return (
    <div className="min-h-dvh backdrop-garage">
      <PublicHeader />
      <main className="mx-auto max-w-2xl px-4 py-6 pb-36">
        {isLoading && <Spinner />}
        {error && <Empty title="Orçamento não encontrado">Confira se o link está completo ou fale com a oficina.</Empty>}
        {data && (() => {
          const q = data.quote;
          const pending = q.quoteStatus === 'SENT' && q.status === 'WAITING_APPROVAL';
          return (
            <div className="grid gap-4 animate-rise">
              <div>
                <p className="text-xs uppercase font-semibold tracking-wide text-muted">Orçamento nº {String(q.number).padStart(5, '0')}</p>
                <h1 className="font-display text-4xl font-bold uppercase">{q.motorcycle.brand} {q.motorcycle.model}</h1>
                <p className="text-steel">{plateMask(q.motorcycle.plate)} · {q.customerName}</p>
              </div>
              {q.quoteStatus === 'APPROVED' && (
                <Card className="flex items-center gap-3 border-ok/40"><CheckCircle2 className="h-6 w-6 text-ok" /><div><p className="font-semibold">Orçamento aprovado</p>{q.approvedAt && <p className="text-sm text-muted">{fmtDateTime(q.approvedAt)}</p>}</div></Card>
              )}
              {q.quoteStatus === 'REJECTED' && <Card className="border-bad/40"><p className="font-semibold">Você recusou este orçamento.</p><p className="text-sm text-muted">Se mudar de ideia, fale com a oficina.</p></Card>}
              {q.diagnosis && <Card><p className="text-xs uppercase font-semibold tracking-wide text-muted mb-1">Diagnóstico</p><p className="whitespace-pre-line">{q.diagnosis}</p></Card>}
              <Card className="p-0 sm:p-0 overflow-hidden">
                <table className="w-full text-sm">
                  <thead><tr className="text-left text-muted border-b border-line"><th className="p-3 font-semibold">Item</th><th className="p-3 font-semibold text-right">Valor</th></tr></thead>
                  <tbody>
                    {q.items.map((i, k) => (
                      <tr key={k} className="border-b border-line last:border-0">
                        <td className="p-3"><span className="text-muted text-xs block">{i.type === 'PART' ? 'Peça' : 'Serviço'}{i.quantity > 1 ? ` · ${i.quantity} un.` : ''}</span>{i.description}</td>
                        <td className="p-3 text-right whitespace-nowrap">{i.unitPriceCents ? money(i.unitPriceCents * i.quantity) : 'a definir'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="p-3 border-t border-line grid gap-1 text-sm">
                  <div className="flex justify-between text-muted"><span>Mão de obra</span><span>{money(q.laborCents)}</span></div>
                  {q.partsCents > 0 && <div className="flex justify-between text-muted"><span>Peças</span><span>{money(q.partsCents)}</span></div>}
                  <div className="flex justify-between font-display text-2xl font-bold mt-1"><span>{q.customerParts?.length ? 'Total do serviço' : 'Total'}</span><span className="text-brand-light">{money(q.totalCents)}</span></div>
                </div>
              </Card>
              {q.customerParts?.length > 0 && (
                <Card>
                  <p className="font-display text-2xl font-bold uppercase">Peças para comprar</p>
                  <p className="text-sm text-muted mb-3">A oficina não vende peças. Compre na loja de sua confiança e traga no dia do serviço.</p>
                  <ul className="grid gap-2">
                    {q.customerParts.map((p, k) => (
                      <li key={k} className="flex items-center gap-3 rounded-xl border border-line bg-surface-2 p-2">
                        {p.imageUrl ? <img src={p.imageUrl} alt="" className="h-16 w-16 rounded-xl object-cover bg-[#EEF2FB] shrink-0" /> : null}
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold">{p.quantity > 1 ? `${p.quantity}x ` : ''}{p.description}</p>
                          {p.notes && <p className="text-sm text-muted">{p.notes}</p>}
                        </div>
                        {p.estimatedPriceCents ? <p className="text-sm text-right whitespace-nowrap"><span className="block text-xs text-muted">estimado</span>{money(p.estimatedPriceCents * p.quantity)}</p> : null}
                      </li>
                    ))}
                  </ul>
                  {q.customerPartsEstimateCents > 0 && <p className="text-sm text-muted mt-3">Estimativa das peças: <span className="text-fg font-semibold">{money(q.customerPartsEstimateCents)}</span> (pago na loja de peças, não à oficina).</p>}
                </Card>
              )}
              <PdfButton quote={q} token={token} />
              <LinkButton href={waUrl(q.whatsappNumber, `Olá! Tenho uma dúvida sobre o orçamento nº ${q.number}.`)} target="_blank" rel="noopener noreferrer" icon={MessageCircle}>Tirar dúvida no WhatsApp</LinkButton>
              {pending && (
                <div className="fixed bottom-0 inset-x-0 z-40 glass-bar border-t pb-safe">
                  <div className="mx-auto max-w-2xl px-4 pt-3 grid grid-cols-2 gap-2">
                    <Button variant="danger" size="lg" icon={X} onClick={() => setAsk('reject')}>Recusar</Button>
                    <Button variant="primary" size="lg" icon={Check} onClick={() => setAsk('approve')}>Aprovar</Button>
                  </div>
                </div>
              )}
              <ConfirmModal open={Boolean(ask)} onClose={() => setAsk(null)} loading={busy} onConfirm={decide} danger={ask === 'reject'}
                title={ask === 'approve' ? 'Aprovar orçamento?' : 'Recusar orçamento?'}
                confirmLabel={ask === 'approve' ? `Aprovar ${money(q.totalCents)}` : 'Recusar'}
                message={ask === 'approve' ? 'A oficina começa o serviço e você recebe um aviso quando a moto estiver pronta.' : 'A oficina vai entrar em contato para combinar o que fazer.'} />
            </div>
          );
        })()}
      </main>
    </div>
  );
}

// Customer downloads the quote PDF (opens in the phone's PDF viewer, where it can be saved or shared)
function PdfButton({ quote, token }) {
  if (import.meta.env.VITE_DEMO === '1') {
    return <Button icon={Download} onClick={async () => {
      const { quotePdfPreview } = await import('../../lib/mock.js');
      showDemoModal(quotePdfPreview(token));
    }}>Baixar orçamento em PDF</Button>;
  }
  return <LinkButton href={quote.pdfUrl} target="_blank" rel="noopener" icon={Download}>Baixar orçamento em PDF</LinkButton>;
}
