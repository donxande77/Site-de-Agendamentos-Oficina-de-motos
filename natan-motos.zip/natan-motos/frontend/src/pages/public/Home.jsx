import { Link, useSearchParams } from 'react-router-dom';
import { CalendarDays, Clock, MessageCircle, ShieldCheck, Timer, Wrench, ArrowRight, AtSign } from 'lucide-react';
import { useShopInfo, PublicHeader, PublicFooter, MapCard, PartsToBring } from '../../components/public.jsx';
import logoSrc from '../../assets/logo.png';
import { Card, LinkButton, Skeleton, ErrorBox, Badge } from '../../components/ui.jsx';
import { WEEKDAYS, duration, priceLabel, waUrl, isoDay, weekdayOf, TZ } from '../../lib/format.js';

function openNow(hours) {
  if (!hours?.length) return null;
  const now = new Date();
  const wd = weekdayOf(isoDay(now));
  const h = hours.find((x) => x.weekday === wd);
  if (!h || h.closed) return false;
  const hm = new Intl.DateTimeFormat('pt-BR', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hour12: false }).format(now);
  const inBreak = h.breakStart && hm >= h.breakStart && hm < h.breakEnd;
  return hm >= h.opensAt && hm < h.closesAt && !inBreak;
}

export default function Home() {
  const { data: info, isLoading, error, refetch } = useShopInfo();
  const [params] = useSearchParams();
  const src = params.get('src');
  const bookHref = `/agendar${src ? `?src=${encodeURIComponent(src)}` : ''}`;
  const isOpen = openNow(info?.hours);
  const todayWd = weekdayOf(isoDay());

  return (
    <div className="min-h-dvh backdrop-garage">
      <PublicHeader right={<Link to={bookHref} className="glass-btn glass-btn-primary inline-flex items-center gap-2 min-h-11 px-4 rounded-xl font-semibold text-sm"><CalendarDays className="h-4 w-4" aria-hidden />Agendar</Link>} />

      <main className="mx-auto max-w-5xl px-4">
        {/* Hero */}
        <section className="grid md:grid-cols-[1.2fr_1fr] gap-8 items-center pt-10 pb-12 md:pt-16">
          <div className="animate-rise order-2 md:order-1">
            {isOpen !== null && (
              <Badge tone={isOpen ? 'ok' : 'muted'} className="mb-4">{isOpen ? '● Aberto agora' : '● Fechado agora — agende pelo site'}</Badge>
            )}
            <h1 className="font-display uppercase font-extrabold leading-[0.92] text-[clamp(2.8rem,9vw,5.2rem)]">
              Sua moto em <span className="text-brand-light">boas mãos.</span>
            </h1>
            <p className="mt-4 text-steel text-lg max-w-md">
              Oficina de motos em Santa Cruz, Rio de Janeiro. Agende revisão, troca de óleo e manutenção em menos de 1 minuto, sem cadastro.
            </p>
            <div className="mt-7 flex flex-col sm:flex-row gap-3">
              <Link to={bookHref} className="glass-btn glass-btn-primary inline-flex items-center justify-center gap-2 min-h-14 px-7 rounded-2xl font-semibold text-base">
                Agendar agora <ArrowRight className="h-5 w-5" aria-hidden />
              </Link>
              {info && (
                <LinkButton size="lg" href={waUrl(info.whatsappNumber, `Olá, ${info.shopName}! Quero tirar uma dúvida.`)} target="_blank" rel="noopener noreferrer" icon={MessageCircle}>
                  Falar no WhatsApp
                </LinkButton>
              )}
            </div>
            <ul className="mt-7 grid grid-cols-3 gap-3 max-w-md text-sm">
              {[[Timer, 'Leva 1 minuto'], [ShieldCheck, 'Sem cadastro'], [Wrench, `${info?.bays || 2} elevadores`]].map(([Icon, t]) => (
                <li key={t} className="flex flex-col items-start gap-1.5 text-steel">
                  <Icon className="h-5 w-5 text-brand-light" aria-hidden />{t}
                </li>
              ))}
            </ul>
          </div>
          <div className="order-1 md:order-2 flex justify-center animate-rise">
            <div className="relative">
              <div className="absolute inset-0 rounded-full bg-brand/40 blur-3xl scale-90" aria-hidden />
              <img src={logoSrc} alt="Logo da Natan Motos" width="320" height="320" className="relative w-56 h-56 sm:w-72 sm:h-72 rounded-full ring-1 ring-white/10" />
            </div>
          </div>
        </section>

        {error && <ErrorBox error={error} onRetry={refetch} />}

        {/* Services */}
        <section aria-labelledby="servicos" className="py-6">
          <div className="flex items-end justify-between gap-4 mb-4">
            <h2 id="servicos" className="font-display text-3xl sm:text-4xl font-bold uppercase">Serviços</h2>
            <Link to={bookHref} className="text-brand-light text-sm font-semibold hover:underline focus-ring rounded">Agendar →</Link>
          </div>
          {info?.partsNotice && <div className="mb-4"><PartsToBring notice={info.partsNotice} /></div>}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {isLoading && Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
            {info?.services.map((s) => (
              <Card key={s.id} className="flex flex-col gap-2">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-semibold leading-snug">{s.name}</h3>
                  <span className="text-xs text-muted whitespace-nowrap flex items-center gap-1"><Clock className="h-3.5 w-3.5" aria-hidden />{duration(s.durationMinutes)}</span>
                </div>
                {s.description && <p className="text-sm text-muted">{s.description}</p>}
                {s.partsToBring && <p className="text-xs text-warn">Traga: {s.partsToBring}</p>}
                <p className="mt-auto pt-1 text-sm font-semibold text-brand-light">{priceLabel(s)}</p>
              </Card>
            ))}
          </div>
        </section>

        {/* Hours + location */}
        <section className="grid md:grid-cols-2 gap-4 py-8" aria-label="Horário e localização">
          <Card>
            <h2 className="font-display text-3xl font-bold uppercase mb-3">Horário</h2>
            {isLoading ? <Skeleton className="h-48" /> : (
              <ul className="divide-y divide-line">
                {[1, 2, 3, 4, 5, 6, 0].map((wd) => {
                  const h = info?.hours.find((x) => x.weekday === wd);
                  return (
                    <li key={wd} className={`flex justify-between py-2.5 text-sm ${wd === todayWd ? 'text-fg font-semibold' : 'text-steel'}`}>
                      <span>{WEEKDAYS[wd]}{wd === todayWd && <span className="text-brand-light"> · hoje</span>}</span>
                      <span>{!h || h.closed ? 'Fechado' : `${h.opensAt} às ${h.closesAt}${h.breakStart ? ` (pausa ${h.breakStart}–${h.breakEnd})` : ''}`}</span>
                    </li>
                  );
                })}
              </ul>
            )}
            {info?.instagram && (
              <a href={`https://instagram.com/${info.instagram}`} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-2 text-sm text-steel hover:text-fg focus-ring rounded">
                <AtSign className="h-4 w-4 text-brand-light" aria-hidden /> Siga @{info.instagram}
              </a>
            )}
          </Card>
          <div>
            <h2 className="sr-only">Como chegar</h2>
            {isLoading ? <Skeleton className="h-80" /> : <MapCard info={info} />}
          </div>
        </section>
      </main>

      <PublicFooter info={info} />

      {/* Mobile sticky glass action bar */}
      <div className="md:hidden h-24" aria-hidden />
      <div className="md:hidden fixed bottom-0 inset-x-0 z-40 glass-bar border-t px-4 pt-3 pb-safe">
        <Link to={bookHref} className="glass-btn glass-btn-primary flex items-center justify-center gap-2 min-h-14 rounded-2xl font-semibold text-base">
          <CalendarDays className="h-5 w-5" aria-hidden /> Agendar serviço
        </Link>
      </div>
    </div>
  );
}
