import { useShopInfo, PublicHeader, PublicFooter } from '../../components/public.jsx';

// Privacy notice (LGPD). Plain language. Review with a lawyer before publishing.
export default function Privacy() {
  const { data: info } = useShopInfo();
  const shop = info?.shopName || 'Natan Motos';
  const H = ({ children }) => <h2 className="font-display text-2xl font-bold uppercase mt-8 mb-2">{children}</h2>;
  return (
    <div className="min-h-dvh backdrop-garage">
      <PublicHeader />
      <main className="mx-auto max-w-2xl px-4 py-8 text-steel leading-relaxed [&_strong]:text-fg [&_li]:mt-1.5">
        <h1 className="font-display text-4xl font-bold uppercase text-fg">Aviso de privacidade</h1>
        <p className="text-sm text-muted mt-1">Última atualização: novembro de 2026</p>

        <p className="mt-5">
          Este aviso explica, em linguagem simples, como a <strong>{shop}</strong>
          {info?.address ? <> ({info.address})</> : null} usa os seus dados quando você agenda um serviço ou deixa sua moto com a gente.
        </p>

        <H>Quais dados coletamos e para quê</H>
        <ul className="list-disc pl-5">
          <li><strong>Nome e WhatsApp:</strong> para confirmar o agendamento, avisar sobre orçamento e quando a moto estiver pronta.</li>
          <li><strong>E-mail (opcional):</strong> para enviar a confirmação.</li>
          <li><strong>Dados da moto (marca, modelo, ano, placa e quilometragem):</strong> para fazer o serviço e manter o histórico de manutenção.</li>
          <li><strong>Fotos da moto:</strong> as que você envia e as do check-in, para registrar o estado da moto na entrada.</li>
          <li><strong>Endereço de IP e data</strong> quando você aprova um orçamento pelo link, como prova da aprovação.</li>
          <li><strong>Pagamentos:</strong> valor e forma de pagamento. Não guardamos dados de cartão.</li>
        </ul>

        <H>Por que podemos usar esses dados</H>
        <p>
          Usamos seus dados para <strong>prestar o serviço que você pediu</strong> (execução de contrato, art. 7º, V, da LGPD), para cumprir obrigações legais
          (como registros financeiros) e para nos defender em caso de discordância sobre o serviço (exercício regular de direitos).
          Os <strong>lembretes de revisão</strong> pelo WhatsApp só são enviados se você autorizar, e você pode cancelar quando quiser (consentimento).
        </p>

        <H>Com quem compartilhamos</H>
        <ul className="list-disc pl-5">
          <li><strong>Empresas de hospedagem</strong> do site e do banco de dados, que podem ter servidores fora do Brasil, com cláusulas de proteção previstas pela ANPD.</li>
          <li><strong>Meta (WhatsApp)</strong>, quando as mensagens são enviadas pelo WhatsApp.</li>
          <li><strong>Google</strong>, que exibe o mapa da oficina. O mapa é carregado do Google e pode usar cookies próprios.</li>
        </ul>
        <p className="mt-2">Não vendemos seus dados e não os usamos para propaganda de outras empresas.</p>

        <H>Por quanto tempo guardamos</H>
        <ul className="list-disc pl-5">
          <li>Cadastro e histórico da moto: até 5 anos depois do último serviço. Depois disso, os dados são anonimizados.</li>
          <li>Fotos do check-in: 1 ano depois da entrega da moto.</li>
          <li>Registros financeiros: pelo prazo exigido em lei, sem identificar você depois da anonimização.</li>
        </ul>

        <H>Seus direitos</H>
        <p>
          Você pode pedir a qualquer momento: confirmação de que tratamos seus dados, uma cópia deles, correção, eliminação, informações sobre
          com quem compartilhamos e o cancelamento dos lembretes. Respondemos em até 15 dias.
        </p>
        <p className="mt-2">
          <strong>Canal para pedidos de privacidade:</strong> {info?.privacyContact || 'WhatsApp da oficina'}.
        </p>

        <H>Cookies e armazenamento no aparelho</H>
        <p>
          O site não usa cookies de propaganda nem de rastreamento. Para facilitar o próximo agendamento, ele guarda no seu próprio aparelho
          o nome, o WhatsApp e as motos que você informou. Você pode apagar isso tocando em “Não sou eu” na tela de contato ou limpando os dados do navegador.
        </p>

        <H>Segurança</H>
        <p>
          Usamos conexão criptografada, senhas protegidas, controle de acesso por função da equipe e links privados que não podem ser adivinhados.
          Se acontecer algum incidente que possa trazer risco para você, avisaremos você e a ANPD.
        </p>
      </main>
      <PublicFooter info={info} />
    </div>
  );
}
