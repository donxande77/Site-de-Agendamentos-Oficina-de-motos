import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { MessageCircle, CalendarClock, Ban, FileText, Check } from 'lucide-react';
import { api } from '../../lib/api.js';
import { useShopInfo, PublicHeader, MapCard, PublicFooter, IcsButton, PartsToBring } from '../../components/public.jsx';
import { Button, LinkButton, Card, Spinner, Empty, Badge, ConfirmModal, Modal, useToast, cx } from '../../components/ui.jsx';
import { fmtLong, fmtTime, plateMask, waUrl, BOOKING_STATUS, ORDER_STATUS, WEEKDAYS_SHORT, dayToDate, duration } from '../../lib/format.js';

const TIMELINE = ['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL', 'IN_PROGRESS', 'READY', 'DELIVERED'];

export default function ManageBooking() {
  const { token } = useParams();
  const qc = useQueryClient();
  const toast = useToast();
  const { data: info } = useShopInfo();
  const { data, isLoading, error } = useQuery({ queryKey: ['my-booking', token], queryFn: () => api.get(`/public/bookings/${token}`) });
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [rescheduling, setRescheduling] = useState(false);
  const [busy, setBusy] = useState(false);

  if (isLoading) return <Page info={info}><Spinner /></Page>;
  if (error) return <Page info={info}><Empty title="Agendamento não encontrado">Confira se o link está completo. Se precisar, fale com a oficina pelo WhatsApp.</Empty></Page>;
  const b = data.booking;
  const st = b.orderStatus ? ORDER_STATUS[b.orderStatus] : BOOKING_STATUS[b.status];
  const statusText = b.orderStatus ? ORDER_STATUS[b.orderStatus].customer : BOOKING_STATUS[b.status].label;

  async function cancel() {
    setBusy(true);
    try {
      await api.post(`/public/bookings/${token}/cancel`);
      toast('Agendamento cancelado.');
      qc.invalidateQueries({ queryKey: ['my-booking', token] });
      setConfirmCancel(false);
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }

  async function optOut() {
    try { await api.post(`/public/bookings/${token}/reminders-optout`); toast('Pronto, você não vai mais receber lembretes.'); } catch (e) { toast(e.message, 'bad'); }
  }

  return (
    <Page info={info}>
      <div className="grid gap-4 animate-rise">
        <div>
          <p className="text-xs uppercase font-semibold tracking-wide text-muted">Agendamento {b.code}</p>
          <h1 className="font-display text-4xl font-bold uppercase">Olá, {b.customerName.split(' ')[0]}!</h1>
        </div>
        <Card>
          <div className="flex items-center justify-between gap-3 mb-3">
            <Badge tone={st.tone}>{statusText}</Badge>
            <span className="text-xs text-muted">{b.dropOff ? 'Deixar a moto' : 'Esperar no local'}</span>
          </div>
          <p className="font-semibold text-lg">{fmtLong(b.startAt)} às {fmtTime(b.startAt)}</p>
          <p className="text-steel">{b.services.map((s) => s.name).join(', ')}</p>
          <p className="text-steel">{b.motorcycle.brand} {b.motorcycle.model} · {plateMask(b.motorcycle.plate)}</p>
        </Card>

        {['PENDING', 'CONFIRMED'].includes(b.status) && b.partsNotice && <PartsToBring services={b.services} title="Traga as peças no dia" compact />}
        {b.orderStatus && b.orderStatus !== 'CANCELLED' && (
          <Card>
            <p className="font-semibold mb-3">Andamento da sua moto</p>
            <ol className="grid gap-2.5">
              {TIMELINE.map((s) => {
                const idx = TIMELINE.indexOf(b.orderStatus === 'APPROVED' || b.orderStatus === 'WAITING_PARTS' ? 'IN_PROGRESS' : b.orderStatus);
                const i = TIMELINE.indexOf(s);
                const state = i < idx ? 'done' : i === idx ? 'now' : 'next';
                return (
                  <li key={s} className="flex items-center gap-3 text-sm">
                    <span className={cx('h-6 w-6 rounded-full flex items-center justify-center border', state === 'done' && 'bg-ok/20 border-ok text-ok', state === 'now' && 'bg-brand border-brand text-white', state === 'next' && 'border-line text-muted')}>
                      {state === 'done' ? <Check className="h-3.5 w-3.5" /> : <span className="text-[10px] font-bold">{i + 1}</span>}
                    </span>
                    <span className={state === 'next' ? 'text-muted' : 'text-fg font-medium'}>{ORDER_STATUS[s].customer}{state === 'now' && b.orderStatus === 'WAITING_PARTS' ? ' (aguardando peças)' : ''}</span>
                  </li>
                );
              })}
            </ol>
            {b.quoteToken && (
              <Link to={`/orcamento/${b.quoteToken}`} className="glass-btn glass-btn-primary mt-4 flex items-center justify-center gap-2 min-h-12 rounded-xl font-semibold">
                <FileText className="h-4 w-4" aria-hidden /> Ver orçamento
              </Link>
            )}
          </Card>
        )}

        {b.canChange && (
          <div className="grid grid-cols-2 gap-2">
            <Button icon={CalendarClock} onClick={() => setRescheduling(true)}>Remarcar</Button>
            <Button variant="danger" icon={Ban} onClick={() => setConfirmCancel(true)}>Cancelar</Button>
          </div>
        )}
        {!b.canChange && ['PENDING', 'CONFIRMED'].includes(b.status) && (
          <p className="text-sm text-muted">Remarcar ou cancelar pelo site só até {b.cancelNoticeHours} h antes. Agora, fale com a gente pelo WhatsApp.</p>
        )}
        <div className="grid sm:grid-cols-2 gap-2">
          {['PENDING', 'CONFIRMED'].includes(b.status) && <IcsButton token={token} />}
          {info && <LinkButton href={waUrl(info.whatsappNumber, `Olá! Sobre o meu agendamento ${b.code}…`)} target="_blank" rel="noopener noreferrer" icon={MessageCircle}>Falar no WhatsApp</LinkButton>}
        </div>
        <MapCard info={info} />
        <button type="button" onClick={optOut} className="text-xs text-muted underline justify-self-start focus-ring rounded">Não quero receber lembretes de revisão</button>
      </div>

      <ConfirmModal open={confirmCancel} onClose={() => setConfirmCancel(false)} title="Cancelar agendamento?" danger confirmLabel="Sim, cancelar" loading={busy}
        message="O horário fica livre para outra pessoa. Se quiser, você pode agendar de novo depois." onConfirm={cancel} />
      {rescheduling && <Reschedule token={token} booking={b} onClose={() => setRescheduling(false)} onDone={() => { setRescheduling(false); qc.invalidateQueries({ queryKey: ['my-booking', token] }); toast('Remarcado!'); }} />}
    </Page>
  );
}

function Reschedule({ token, booking, onClose, onDone }) {
  const toast = useToast();
  const [day, setDay] = useState(null);
  const [slot, setSlot] = useState(null);
  const [busy, setBusy] = useState(false);
  const days = useQuery({ queryKey: ['re-days', token], queryFn: () => api.get(`/public/available-days?token=${token}`) });
  const slots = useQuery({ queryKey: ['re-slots', token, day], queryFn: () => api.get(`/public/slots?date=${day}&token=${token}`), enabled: Boolean(day) });
  const minutes = Math.round((new Date(booking.endAt) - new Date(booking.startAt)) / 60000);

  async function save() {
    setBusy(true);
    try { await api.post(`/public/bookings/${token}/reschedule`, { startAt: slot.startAt }); onDone(); } catch (e) { toast(e.message, 'bad'); slots.refetch(); } finally { setBusy(false); }
  }

  return (
    <Modal open onClose={onClose} title="Remarcar" footer={<><Button onClick={onClose}>Voltar</Button><Button variant="primary" disabled={!slot} loading={busy} onClick={save}>Confirmar novo horário</Button></>}>
      <p className="text-sm text-muted mb-3">Duração: {duration(minutes)}</p>
      {days.isLoading && <Spinner />}
      <div className="-mx-5 px-5 flex gap-2 overflow-x-auto no-scrollbar pb-2">
        {days.data?.days.map((d) => {
          const dt = dayToDate(d.date);
          return (
            <button key={d.date} type="button" onClick={() => { setDay(d.date); setSlot(null); }} aria-pressed={day === d.date}
              className={cx('shrink-0 w-[4.4rem] rounded-2xl py-2 flex flex-col items-center border focus-ring', day === d.date ? 'glass-btn glass-btn-primary' : 'card')}>
              <span className="text-xs uppercase font-semibold opacity-80">{WEEKDAYS_SHORT[dt.getUTCDay()]}</span>
              <span className="font-display text-2xl font-bold">{String(dt.getUTCDate()).padStart(2, '0')}</span>
            </button>
          );
        })}
      </div>
      {slots.isLoading && <Spinner />}
      {slots.data && (
        <div className="grid grid-cols-4 gap-2 mt-3">
          {slots.data.slots.map((s) => (
            <button key={s.startAt} type="button" onClick={() => setSlot(s)} aria-pressed={slot?.startAt === s.startAt}
              className={cx('min-h-11 rounded-xl font-semibold border focus-ring', slot?.startAt === s.startAt ? 'glass-btn glass-btn-primary' : 'card')}>{s.time}</button>
          ))}
          {!slots.data.slots.length && <p className="col-span-4 text-sm text-muted">Sem horários nesse dia.</p>}
        </div>
      )}
    </Modal>
  );
}

function Page({ children, info }) {
  return (
    <div className="min-h-dvh backdrop-garage">
      <PublicHeader />
      <main className="mx-auto max-w-2xl px-4 py-6">{children}</main>
      <PublicFooter info={info} />
    </div>
  );
}
