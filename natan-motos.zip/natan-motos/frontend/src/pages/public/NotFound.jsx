import { Link } from 'react-router-dom';
import { PublicHeader } from '../../components/public.jsx';
import { Empty } from '../../components/ui.jsx';

export default function NotFound() {
  return (
    <div className="min-h-dvh backdrop-garage">
      <PublicHeader />
      <Empty title="Página não encontrada" action={<Link to="/" className="glass-btn glass-btn-primary inline-flex min-h-12 px-5 items-center rounded-xl font-semibold">Voltar ao início</Link>}>
        O endereço pode estar errado ou a página mudou de lugar.
      </Empty>
    </div>
  );
}
