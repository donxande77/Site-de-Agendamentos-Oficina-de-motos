import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  ChevronLeft, Check, Clock, Camera, X, MessageCircle, CheckCircle2, Bike, Pencil, ArrowRight, Copy, UserCheck, Search,
} from 'lucide-react';
import { api } from '../../lib/api.js';
import { useShopInfo, PublicHeader, MapCard, IcsButton, PartsToBring } from '../../components/public.jsx';
import { DEMO } from '../../lib/demo.js';
import { Button, Input, Select, Textarea, Checkbox, Card, Spinner, ErrorBox, Empty, useToast, cx, LinkButton } from '../../components/ui.jsx';
import {
  BRANDS, duration, priceLabel, money, phoneMask, plateMask, WEEKDAYS_SHORT, dayToDate, fmtLong, fmtTime, waUrl, store,
} from '../../lib/format.js';

const STEPS = ['Serviço', 'Moto', 'Data e hora', 'Contato', 'Revisão'];
const PROFILE_KEY = 'nm_profile';
const emptyBike = { brand: '', model: '', year: '', plate: '', mileage: '' };

export default function Booking() {
  const [params] = useSearchParams();
  const source = ['instagram', 'whatsapp'].includes(params.get('src')) ? params.get('src') : 'direct';
  const { data: info, isLoading, error, refetch } = useShopInfo();
  const toast = useToast();
  const top = useRef(null);

  const profile = useMemo(() => store.get(PROFILE_KEY), []);
  const [step, setStep] = useState(1);
  const [serviceIds, setServiceIds] = useState(() => (params.get('servico') ? [Number(params.get('servico'))] : []));
  const [bike, setBike] = useState(emptyBike);
  const [problem, setProblem] = useState('');
  const [photos, setPhotos] = useState([]);
  const [day, setDay] = useState(null);
  const [slot, setSlot] = useState(null);
  const [dropOff, setDropOff] = useState(null);
  const [customer, setCustomer] = useState({ name: profile?.name || '', phone: profile?.phone || '', email: profile?.email || '' });
  const [privacyAck, setPrivacyAck] = useState(false);
  const [reminderConsent, setReminderConsent] = useState(false);
  const [website, setWebsite] = useState('');
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(null);
  // "Já sou cliente": WhatsApp + placa puxam o cadastro (nada de cadastro repetido)
  const [lookup, setLookup] = useState({ phone: profile?.phone || '', plate: '' });
  const [recognized, setRecognized] = useState(null);
  const [lookupMsg, setLookupMsg] = useState('');
  const [looking, setLooking] = useState(false);
  const [editBike, setEditBike] = useState(false);

  const services = info?.services || [];
  const selected = services.filter((s) => serviceIds.includes(s.id));
  const totalMin = useMemo(() => {
    const sum = selected.reduce((a, s) => a + s.durationMinutes, 0);
    const slotM = info?.slotMinutes || 30;
    return sum ? Math.ceil(sum / slotM) * slotM : 0;
  }, [selected, info]);
  const forcedDropOff = Boolean(info && (totalMin >= info.forceDropOffMinutes || selected.some((s) => s.dropOffRequired)));
  const priced = selected.filter((s) => s.basePriceCents != null && !s.priceOnEvaluation);
  const priceText = !selected.length ? '' : priced.length === selected.length
    ? `a partir de ${money(priced.reduce((a, s) => a + s.basePriceCents, 0))}`
    : priced.length ? `a partir de ${money(priced.reduce((a, s) => a + s.basePriceCents, 0))} + avaliação` : 'valor sob avaliação';

  const idsKey = [...serviceIds].sort((a, b) => a - b).join(',');
  const daysQ = useQuery({
    queryKey: ['days', idsKey],
    queryFn: () => api.get(`/public/available-days?services=${idsKey}`),
    enabled: step >= 3 && serviceIds.length > 0,
  });
  const slotsQ = useQuery({
    queryKey: ['slots', idsKey, day],
    queryFn: () => api.get(`/public/slots?date=${day}&services=${idsKey}`),
    enabled: Boolean(day) && serviceIds.length > 0,
  });

  useEffect(() => { setSlot(null); }, [day, idsKey]);
  useEffect(() => { if (!day && daysQ.data?.days?.length) setDay(daysQ.data.days[0].date); }, [daysQ.data, day]);
  useEffect(() => { setDay(null); }, [idsKey]);
  useEffect(() => { if (forcedDropOff) setDropOff(true); }, [forcedDropOff]);
  useEffect(() => { window.scrollTo(0, 0); }, [step, done]);

  function validate(s) {
    const e = {};
    if (s === 1 && !serviceIds.length) e.services = 'Escolha pelo menos um serviço.';
    if (s === 2) {
      if (!bike.brand) e.brand = 'Escolha a marca.';
      if (!bike.model.trim()) e.model = 'Informe o modelo.';
      if (!/^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(bike.plate.replace('-', ''))) e.plate = 'Placa no formato ABC1D23 ou ABC-1234.';
      if (bike.year && (Number(bike.year) < 1950 || Number(bike.year) > new Date().getFullYear() + 1)) e.year = 'Ano inválido.';
    }
    if (s === 3) {
      if (!slot) e.slot = 'Escolha um horário.';
      if (dropOff === null) e.dropOff = 'Diga se vai deixar a moto ou esperar.';
    }
    if (s === 4) {
      if (customer.name.trim().length < 2) e.name = 'Informe seu nome.';
      const d = customer.phone.replace(/\D/g, '');
      if (d.length < 10 || d.length > 11) e.phone = 'WhatsApp com DDD, ex.: (21) 98193-9129.';
      if (customer.email && !/^\S+@\S+\.\S+$/.test(customer.email)) e.email = 'E-mail inválido.';
      if (!privacyAck) e.privacy = 'Confirme que leu o aviso de privacidade.';
    }
    setErrors(e);
    return !Object.keys(e).length;
  }

  async function findMe() {
    const d = lookup.phone.replace(/\D/g, '');
    if (d.length < 10 || lookup.plate.replace('-', '').length !== 7) { setLookupMsg('Digite o WhatsApp com DDD e a placa completa.'); return; }
    setLooking(true);
    setLookupMsg('');
    try {
      const r = await api.post('/public/customers/lookup', { phone: lookup.phone, plate: lookup.plate });
      if (r.found) {
        const m = r.motorcycle;
        setBike((b) => ({ ...b, brand: m.brand, model: m.model, year: m.year ? String(m.year) : '', plate: plateMask(m.plate), mileage: b.mileage || '' }));
        setCustomer((c) => ({ ...c, name: r.customer.name, phone: lookup.phone }));
        setRecognized({ name: r.customer.name, lastMileage: m.lastMileage });
        setEditBike(false);
        setErrors({});
      } else {
        setLookupMsg('Não achamos esse WhatsApp com essa placa. Sem problema: preencha abaixo. Se você já é cliente, a moto entra no mesmo cadastro.');
        setCustomer((c) => ({ ...c, phone: c.phone || lookup.phone }));
        setBike((b) => ({ ...b, plate: b.plate || lookup.plate }));
      }
    } catch (e) { setLookupMsg(e.message); } finally { setLooking(false); }
  }
  function notMe() {
    setRecognized(null);
    setBike(emptyBike);
    setCustomer({ name: '', phone: '', email: '' });
    setLookup({ phone: '', plate: '' });
  }

  const next = () => { if (validate(step)) setStep((s) => Math.min(5, s + 1)); };
  const back = () => setStep((s) => Math.max(1, s - 1));

  async function submit() {
    for (const s of [1, 2, 3, 4]) if (!validate(s)) { setStep(s); return; }
    setSubmitting(true);
    try {
      const res = await api.post('/public/bookings', {
        serviceIds,
        startAt: slot.startAt,
        source,
        dropOff: Boolean(dropOff),
        problemDescription: problem.trim() || undefined,
        privacyAck: true,
        reminderConsent,
        website,
        customer: { name: customer.name.trim(), phone: customer.phone, email: customer.email.trim() },
        motorcycle: {
          brand: bike.brand,
          model: bike.model.trim(),
          year: bike.year ? Number(bike.year) : null,
          plate: bike.plate,
          mileage: bike.mileage ? Number(String(bike.mileage).replace(/\D/g, '')) : null,
        },
      });
      if (photos.length) {
        const fd = new FormData();
        photos.forEach((f) => fd.append('photos', f));
        try { await api.upload(`/public/bookings/${res.token}/photos`, fd); } catch { toast('O agendamento foi feito, mas as fotos não subiram. Mande pelo WhatsApp.', 'bad'); }
      }
      const savedBikes = (profile?.bikes || []).filter((b) => b.plate !== bike.plate);
      store.set(PROFILE_KEY, { name: customer.name.trim(), phone: customer.phone, email: customer.email.trim(), bikes: [{ brand: bike.brand, model: bike.model, year: bike.year, plate: bike.plate }, ...savedBikes].slice(0, 5) });
      setDone(res);
    } catch (err) {
      if (err.code === 'SLOT_TAKEN' || err.code === 'SLOT_UNAVAILABLE') {
        toast(err.message, 'bad');
        setSlot(null);
        setStep(3);
        slotsQ.refetch();
        daysQ.refetch();
      } else {
        toast(err.message, 'bad');
      }
    } finally {
      setSubmitting(false);
    }
  }

  if (isLoading) return <Shell top={top}><Spinner /></Shell>;
  if (error) return <Shell top={top}><div className="p-4"><ErrorBox error={error} onRetry={refetch} /></div></Shell>;
  if (done) return <Done top={top} info={info} result={done} />;

  return (
    <Shell top={top} step={step} onBack={step > 1 ? back : null}>
      <div className="mx-auto max-w-2xl px-4 pt-5 pb-40">
        {step === 1 && (
          <section aria-labelledby="h1" className="animate-rise">
            <StepTitle id="h1" title="O que sua moto precisa?" sub="Pode escolher mais de um serviço." />
            {info.partsNotice && <div className="mb-4"><PartsToBring notice={info.partsNotice} /></div>}
            {errors.services && <p className="text-bad text-sm mb-3" role="alert">{errors.services}</p>}
            <div className="grid gap-2.5">
              {services.map((s) => {
                const on = serviceIds.includes(s.id);
                return (
                  <button key={s.id} type="button" aria-pressed={on}
                    onClick={() => setServiceIds((ids) => (on ? ids.filter((i) => i !== s.id) : [...ids, s.id]))}
                    className={cx('card text-left p-4 flex gap-3 items-start transition focus-ring', on ? 'border-brand ring-1 ring-brand bg-brand/10' : 'hover:border-white/25')}>
                    <span className={cx('mt-0.5 h-6 w-6 rounded-md border flex items-center justify-center shrink-0', on ? 'bg-brand border-brand' : 'border-white/30')}>
                      {on && <Check className="h-4 w-4 text-white" aria-hidden />}
                    </span>
                    <span className="flex-1 min-w-0">
                      <span className="flex justify-between gap-3">
                        <span className="font-semibold">{s.name}</span>
                        <span className="text-xs text-muted whitespace-nowrap flex items-center gap-1"><Clock className="h-3.5 w-3.5" aria-hidden />{duration(s.durationMinutes)}</span>
                      </span>
                      {s.description && <span className="block text-sm text-muted mt-0.5">{s.description}</span>}
                      {s.partsToBring && <span className="block text-xs text-warn mt-1">Traga: {s.partsToBring}</span>}
                      <span className="block text-sm font-semibold text-brand-light mt-1">{priceLabel(s)}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </section>
        )}

        {step === 2 && (
          <section aria-labelledby="h2" className="animate-rise">
            <StepTitle id="h2" title="Qual é a moto?" sub="A placa ajuda a gente a puxar o histórico." />
            {recognized ? (
              <div className="card border-ok/50 bg-ok/10 p-4 mb-5 grid gap-1">
                <p className="font-semibold flex items-center gap-2 text-ok"><UserCheck className="h-5 w-5" />Olá, {recognized.name.split(' ')[0]}! Achamos o seu cadastro.</p>
                <p className="text-steel">{bike.brand} {bike.model}{bike.year ? ` ${bike.year}` : ''} · {bike.plate}</p>
                <p className="text-sm text-muted">Seus dados já estão preenchidos. É só seguir.</p>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1 text-sm">
                  <button type="button" className="text-brand-light underline focus-ring rounded" onClick={() => setEditBike((v) => !v)}>{editBike ? 'Fechar' : 'Corrigir dados da moto'}</button>
                  <button type="button" className="text-brand-light underline focus-ring rounded" onClick={notMe}>Não sou eu / outra moto</button>
                </div>
              </div>
            ) : (
              <div className="card p-4 mb-5 grid gap-3">
                <div>
                  <p className="font-semibold">Já trouxe a moto aqui?</p>
                  <p className="text-sm text-muted">Digite seu WhatsApp e a placa que a gente puxa o seu cadastro.</p>
                </div>
                <div className="grid grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)] gap-3">
                  <Input label="WhatsApp" type="tel" inputMode="tel" autoComplete="tel-national" placeholder="(21) 98193-9129" value={lookup.phone} onChange={(e) => setLookup({ ...lookup, phone: phoneMask(e.target.value) })} />
                  <Input label="Placa" placeholder="ABC1D23" value={lookup.plate} autoCapitalize="characters" autoComplete="off" onChange={(e) => setLookup({ ...lookup, plate: plateMask(e.target.value) })}
                    onKeyDown={(e) => { if (e.key === 'Enter') findMe(); }} />
                </div>
                <Button icon={Search} loading={looking} onClick={findMe} className="justify-self-start">Buscar meu cadastro</Button>
                {lookupMsg && <p className="text-sm text-steel" role="status">{lookupMsg}</p>}
              </div>
            )}
            {!recognized && profile?.bikes?.length > 0 && (
              <div className="mb-5">
                <p className="text-sm text-steel mb-2">Suas motos</p>
                <div className="flex flex-wrap gap-2">
                  {profile.bikes.map((b) => (
                    <Button key={b.plate} size="sm" icon={Bike} onClick={() => setBike({ ...emptyBike, ...b })}>{b.model} · {b.plate}</Button>
                  ))}
                </div>
              </div>
            )}
            {!recognized && <p className="text-sm font-semibold text-steel mb-3">Primeira vez? Preencha os dados da moto:</p>}
            <div className="grid gap-4">
              {(!recognized || editBike) && (
                <>
                  <Select label="Marca" required value={bike.brand} error={errors.brand} onChange={(e) => setBike({ ...bike, brand: e.target.value })}>
                    <option value="">Escolha a marca</option>
                    {BRANDS.map((b) => <option key={b}>{b}</option>)}
                  </Select>
                  <Input label="Modelo" required placeholder="Ex.: CG 160 Fan, Fazer 250, Biz 125" value={bike.model} error={errors.model} onChange={(e) => setBike({ ...bike, model: e.target.value })} autoComplete="off" />
                  <div className="grid grid-cols-2 gap-3">
                    <Input label="Placa" required placeholder="ABC1D23" value={bike.plate} error={errors.plate} disabled={Boolean(recognized)} onChange={(e) => setBike({ ...bike, plate: plateMask(e.target.value) })} autoCapitalize="characters" autoComplete="off" />
                    <Input label="Ano" inputMode="numeric" placeholder="2022" value={bike.year} error={errors.year} onChange={(e) => setBike({ ...bike, year: e.target.value.replace(/\D/g, '').slice(0, 4) })} />
                  </div>
                </>
              )}
              <Input label="Quilometragem atual" hint={recognized?.lastMileage ? `Opcional. Da última vez estava com ${recognized.lastMileage.toLocaleString('pt-BR')} km.` : 'Opcional'} inputMode="numeric" placeholder="Ex.: 18500" value={bike.mileage} onChange={(e) => setBike({ ...bike, mileage: e.target.value.replace(/\D/g, '').slice(0, 6) })} />
              <Textarea label="Conte o que está acontecendo" hint="Opcional. Ex.: barulho no motor ao acelerar." maxLength={1000} value={problem} onChange={(e) => setProblem(e.target.value)} />
              <PhotoPicker photos={photos} setPhotos={setPhotos} />
            </div>
          </section>
        )}

        {step === 3 && (
          <section aria-labelledby="h3" className="animate-rise">
            <StepTitle id="h3" title="Quando fica bom?" sub={`Duração estimada: ${duration(totalMin)}.`} />
            {daysQ.isLoading && <Spinner label="Buscando dias livres…" />}
            {daysQ.error && <ErrorBox error={daysQ.error} onRetry={daysQ.refetch} />}
            {daysQ.data && !daysQ.data.days.length && (
              <Empty icon={Clock} title="Sem horários livres nos próximos dias">Chama a gente no WhatsApp que a gente encaixa você.</Empty>
            )}
            {daysQ.data?.days?.length > 0 && (
              <>
                <div className="-mx-4 px-4 flex gap-2 overflow-x-auto no-scrollbar pb-2" role="listbox" aria-label="Dias disponíveis">
                  {daysQ.data.days.map((d) => {
                    const dt = dayToDate(d.date);
                    const on = day === d.date;
                    return (
                      <button key={d.date} type="button" role="option" aria-selected={on} onClick={() => setDay(d.date)}
                        className={cx('shrink-0 w-[4.6rem] rounded-2xl py-2.5 flex flex-col items-center focus-ring border', on ? 'glass-btn glass-btn-primary' : 'card hover:border-white/25')}>
                        <span className="text-xs uppercase font-semibold opacity-80">{WEEKDAYS_SHORT[dt.getUTCDay()]}</span>
                        <span className="font-display text-2xl font-bold leading-tight">{String(dt.getUTCDate()).padStart(2, '0')}</span>
                        <span className="text-[11px] opacity-80">{dt.toLocaleDateString('pt-BR', { month: 'short', timeZone: 'UTC' }).replace('.', '')}</span>
                      </button>
                    );
                  })}
                </div>
                {day && <p className="mt-4 mb-2 text-sm text-steel">{fmtLong(dayToDate(day))}</p>}
                {slotsQ.isLoading && <Spinner label="Carregando horários…" />}
                {slotsQ.data && (
                  slotsQ.data.slots.length ? (
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-2" role="listbox" aria-label="Horários disponíveis">
                      {slotsQ.data.slots.map((s) => (
                        <button key={s.startAt} type="button" role="option" aria-selected={slot?.startAt === s.startAt} onClick={() => setSlot(s)}
                          className={cx('min-h-12 rounded-xl font-semibold focus-ring border', slot?.startAt === s.startAt ? 'glass-btn glass-btn-primary' : 'card hover:border-white/25')}>
                          {s.time}
                        </button>
                      ))}
                    </div>
                  ) : <p className="text-sm text-muted">Esse dia lotou. Escolha outro.</p>
                )}
                {errors.slot && <p className="text-bad text-sm mt-2" role="alert">{errors.slot}</p>}

                <h3 className="mt-7 mb-2 font-semibold">Você vai…</h3>
                <div className="grid sm:grid-cols-2 gap-2.5">
                  {[
                    [true, 'Deixar a moto', 'Deixa e a gente avisa quando estiver pronta.'],
                    [false, 'Esperar no local', 'Para serviços rápidos.'],
                  ].map(([val, title, desc]) => {
                    const disabled = forcedDropOff && !val;
                    const on = dropOff === val;
                    return (
                      <button key={title} type="button" disabled={disabled} aria-pressed={on} onClick={() => setDropOff(val)}
                        className={cx('card text-left p-4 focus-ring', on && 'border-brand ring-1 ring-brand bg-brand/10', disabled && 'opacity-40 cursor-not-allowed')}>
                        <span className="font-semibold block">{title}</span>
                        <span className="text-sm text-muted">{disabled ? 'Esse serviço é demorado, então a moto fica com a gente.' : desc}</span>
                      </button>
                    );
                  })}
                </div>
                {errors.dropOff && <p className="text-bad text-sm mt-2" role="alert">{errors.dropOff}</p>}
              </>
            )}
          </section>
        )}

        {step === 4 && (
          <section aria-labelledby="h4" className="animate-rise">
            <StepTitle id="h4" title="Seus dados" sub="Para confirmar e avisar sobre a sua moto." />
            {recognized && <p className="text-sm text-ok mb-4 flex items-center gap-1.5"><UserCheck className="h-4 w-4" />Dados do seu cadastro. Confira e siga.</p>}
            {!recognized && profile?.name && (
              <p className="text-sm text-muted mb-4">
                Preenchemos com os dados deste aparelho.{' '}
                <button type="button" className="text-brand-light underline focus-ring rounded" onClick={() => { store.remove(PROFILE_KEY); setCustomer({ name: '', phone: '', email: '' }); }}>Não sou eu</button>
              </p>
            )}
            <div className="grid gap-4">
              <Input label="Nome" required autoComplete="name" value={customer.name} error={errors.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} />
              <Input label="WhatsApp" required type="tel" inputMode="tel" autoComplete="tel-national" placeholder="(21) 98193-9129" value={customer.phone} error={errors.phone}
                onChange={(e) => setCustomer({ ...customer, phone: phoneMask(e.target.value) })} />
              <Input label="E-mail" hint="Opcional" type="email" autoComplete="email" value={customer.email} error={errors.email} onChange={(e) => setCustomer({ ...customer, email: e.target.value })} />
              {/* Honeypot: hidden from people, bots fill it */}
              <div className="absolute -left-[9999px] h-0 overflow-hidden" aria-hidden="true">
                <label>Site <input tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} /></label>
              </div>
              <div className="card p-4 grid gap-4">
                <Checkbox checked={privacyAck} onChange={setPrivacyAck}
                  label={<>Li o <Link to="/privacidade" {...(DEMO ? {} : { target: '_blank' })} className="text-brand-light underline">aviso de privacidade</Link> e entendo que meus dados serão usados para este agendamento.</>} />
                {errors.privacy && <p className="text-bad text-sm -mt-2" role="alert">{errors.privacy}</p>}
                <Checkbox checked={reminderConsent} onChange={setReminderConsent}
                  label="Quero receber lembretes de revisão e troca de óleo pelo WhatsApp."
                  description="Opcional. Você pode cancelar quando quiser." />
              </div>
            </div>
          </section>
        )}

        {step === 5 && (
          <section aria-labelledby="h5" className="animate-rise">
            <StepTitle id="h5" title="Confere pra gente" sub="Se estiver tudo certo, é só confirmar." />
            <div className="grid gap-3">
              <ReviewRow title="Serviços" onEdit={() => setStep(1)}>
                {selected.map((s) => <div key={s.id}>{s.name}</div>)}
                <div className="text-muted text-sm mt-1">{duration(totalMin)} · {priceText}</div>
              </ReviewRow>
              <ReviewRow title="Moto" onEdit={() => setStep(2)}>
                {bike.brand} {bike.model}{bike.year ? ` ${bike.year}` : ''} · {bike.plate}
                {photos.length > 0 && <div className="text-muted text-sm">{photos.length} foto(s)</div>}
              </ReviewRow>
              <ReviewRow title="Data e hora" onEdit={() => setStep(3)}>
                <span>{slot && fmtLong(slot.startAt)}</span> às {slot && fmtTime(slot.startAt)}
                <div className="text-muted text-sm">{dropOff ? 'Vou deixar a moto' : 'Vou esperar no local'}</div>
              </ReviewRow>
              {info.partsNotice && <PartsToBring services={selected} compact />}
              <ReviewRow title="Contato" onEdit={() => setStep(4)}>
                {customer.name} · {customer.phone}
                {customer.email && <div className="text-muted text-sm">{customer.email}</div>}
              </ReviewRow>
            </div>
          </section>
        )}
      </div>

      {/* Sticky glass action bar */}
      <div className="fixed bottom-0 inset-x-0 z-40 glass-bar border-t pb-safe">
        <div className="mx-auto max-w-2xl px-4 pt-3 flex items-center gap-3">
          <div className="flex-1 min-w-0 text-sm">
            {selected.length ? (
              <>
                <p className="font-semibold truncate">{selected.length} serviço{selected.length > 1 ? 's' : ''} · {duration(totalMin)}</p>
                <p className="text-muted truncate">{step >= 3 && slot ? `${fmtTime(slot.startAt)} · ` : ''}{priceText}</p>
              </>
            ) : <p className="text-muted">Escolha um serviço</p>}
          </div>
          {step < 5
            ? <Button variant="primary" size="lg" onClick={next} className="min-w-40">Continuar <ArrowRight className="h-5 w-5" aria-hidden /></Button>
            : <Button variant="primary" size="lg" onClick={submit} loading={submitting} className="min-w-40" icon={Check}>Confirmar</Button>}
        </div>
      </div>
    </Shell>
  );
}

function Shell({ children, step, onBack, top }) {
  return (
    <div className="min-h-dvh backdrop-garage" ref={top}>
      <PublicHeader
        right={onBack
          ? <Button size="sm" onClick={onBack} icon={ChevronLeft}>Voltar</Button>
          : <Link to="/" className="glass-btn inline-flex items-center gap-1.5 min-h-9 px-3 rounded-[10px] text-sm font-semibold"><ChevronLeft className="h-4 w-4" aria-hidden />Início</Link>}
      />
      {step && (
        <div className="mx-auto max-w-2xl px-4 pt-4">
          <div className="flex justify-between text-xs text-muted mb-2">
            <span>Passo {step} de {STEPS.length}</span><span className="font-semibold text-steel">{STEPS[step - 1]}</span>
          </div>
          <div className="h-1.5 rounded-full bg-white/10 overflow-hidden" role="progressbar" aria-valuemin={1} aria-valuemax={5} aria-valuenow={step}>
            <div className="h-full bg-brand transition-all duration-300" style={{ width: `${(step / STEPS.length) * 100}%` }} />
          </div>
        </div>
      )}
      {children}
    </div>
  );
}

const StepTitle = ({ id, title, sub }) => (
  <div className="mb-5">
    <h1 id={id} className="font-display text-4xl font-bold uppercase leading-none">{title}</h1>
    {sub && <p className="text-muted mt-2">{sub}</p>}
  </div>
);

const ReviewRow = ({ title, children, onEdit }) => (
  <Card className="flex gap-3 items-start">
    <div className="flex-1 min-w-0">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted mb-1">{title}</p>
      <div>{children}</div>
    </div>
    <Button size="sm" variant="ghost" onClick={onEdit} icon={Pencil} aria-label={`Editar ${title}`}>Editar</Button>
  </Card>
);

function PhotoPicker({ photos, setPhotos }) {
  const input = useRef(null);
  const urls = useMemo(() => photos.map((f) => URL.createObjectURL(f)), [photos]);
  useEffect(() => () => urls.forEach((u) => URL.revokeObjectURL(u)), [urls]);
  const add = (files) => {
    const ok = [...files].filter((f) => /^image\/(jpeg|png|webp)$/.test(f.type) && f.size <= 5 * 1024 * 1024);
    setPhotos((p) => [...p, ...ok].slice(0, 3));
  };
  return (
    <div>
      <p className="text-sm font-medium text-steel mb-1.5">Fotos <span className="text-muted font-normal">(opcional, até 3)</span></p>
      <div className="flex gap-2 flex-wrap">
        {urls.map((u, i) => (
          <div key={u} className="relative h-20 w-20 rounded-xl overflow-hidden border border-line">
            <img src={u} alt={`Foto ${i + 1}`} className="h-full w-full object-cover" />
            <button type="button" aria-label="Remover foto" onClick={() => setPhotos((p) => p.filter((_, j) => j !== i))} className="absolute top-1 right-1 h-6 w-6 rounded-full bg-black/70 flex items-center justify-center"><X className="h-3.5 w-3.5" /></button>
          </div>
        ))}
        {photos.length < 3 && (
          <button type="button" onClick={() => input.current?.click()} className="h-20 w-20 rounded-xl border border-dashed border-white/25 flex flex-col items-center justify-center text-muted text-xs gap-1 focus-ring hover:text-fg">
            <Camera className="h-5 w-5" aria-hidden /> Adicionar
          </button>
        )}
      </div>
      <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" multiple hidden onChange={(e) => { add(e.target.files); e.target.value = ''; }} />
    </div>
  );
}

function Done({ info, result, top }) {
  const b = result.booking;
  const toast = useToast();
  const manage = `${window.location.origin}/meu-agendamento/${result.token}`;
  const msg = `Olá, ${info.shopName}! Acabei de agendar pelo site. Código ${b.code}, ${fmtLong(b.startAt)} às ${fmtTime(b.startAt)} (${b.motorcycle.model}).`;
  return (
    <div className="min-h-dvh backdrop-garage" ref={top}>
      <PublicHeader />
      <main className="mx-auto max-w-2xl px-4 py-8 grid gap-4 animate-rise">
        <div className="text-center">
          <CheckCircle2 className="h-16 w-16 text-ok mx-auto" aria-hidden />
          <h1 className="font-display text-4xl font-bold uppercase mt-3">{b.status === 'PENDING' ? 'Pedido enviado!' : 'Agendado!'}</h1>
          <p className="text-steel mt-1">{b.status === 'PENDING' ? 'A oficina vai confirmar seu horário pelo WhatsApp.' : 'Seu horário está garantido.'}</p>
        </div>
        <Card>
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs uppercase font-semibold tracking-wide text-muted">Código</span>
            <span className="font-display text-2xl font-bold text-brand-light">{b.code}</span>
          </div>
          <p className="font-semibold">{fmtLong(b.startAt)} às {fmtTime(b.startAt)}</p>
          <p className="text-steel text-sm">{b.services.map((s) => s.name).join(', ')}</p>
          <p className="text-steel text-sm">{b.motorcycle.brand} {b.motorcycle.model} · {plateMask(b.motorcycle.plate)}</p>
          <p className="text-muted text-sm mt-1">{b.dropOff ? 'Você vai deixar a moto.' : 'Você vai esperar no local.'}</p>
        </Card>
        <PartsToBring services={b.services} title="Não esqueça de trazer as peças" compact />
        <div className="grid sm:grid-cols-2 gap-2">
          <IcsButton token={result.token} />
          <LinkButton href={waUrl(info.whatsappNumber, msg)} target="_blank" rel="noopener noreferrer" icon={MessageCircle}>Falar no WhatsApp</LinkButton>
        </div>
        <Card className="text-sm">
          <p className="font-semibold mb-1">Guarde este link</p>
          <p className="text-muted mb-3">É por ele que você remarca, cancela e acompanha sua moto. Ele é só seu, não compartilhe.</p>
          <div className="flex gap-2">
            <Link to={`/meu-agendamento/${result.token}`} className="glass-btn glass-btn-primary flex-1 inline-flex items-center justify-center min-h-11 rounded-xl font-semibold">Ver meu agendamento</Link>
            <Button size="icon" aria-label="Copiar link" onClick={async () => { try { await navigator.clipboard.writeText(manage); toast('Link copiado.'); } catch { toast('Não deu para copiar.', 'bad'); } }}><Copy className="h-4 w-4" /></Button>
          </div>
        </Card>
        <MapCard info={info} />
      </main>
    </div>
  );
}
