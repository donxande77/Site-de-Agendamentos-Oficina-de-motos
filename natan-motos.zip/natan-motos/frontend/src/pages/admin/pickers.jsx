import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, UserPlus, Check, Package, AlertTriangle } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Input, Select, Button, cx } from '../../components/ui.jsx';
import { phoneMask, plateMask, BRANDS, fmtPhone } from '../../lib/format.js';

/**
 * Pick an existing customer + motorcycle, or type a new one.
 * value = { customerId, motorcycleId, customer: {name, phone, email}, motorcycle: {brand, model, year, plate, mileage} }
 */
export function CustomerBikePicker({ value, onChange, errors = {} }) {
  const [q, setQ] = useState('');
  const [mode, setMode] = useState(value.customerId ? 'existing' : 'search');
  const search = useQuery({
    queryKey: ['customer-search', q],
    queryFn: () => api.get(`/admin/customers?q=${encodeURIComponent(q)}`),
    enabled: mode === 'search' && q.trim().length >= 2,
  });
  const detail = useQuery({
    queryKey: ['customer', value.customerId],
    queryFn: () => api.get(`/admin/customers/${value.customerId}`),
    enabled: Boolean(value.customerId),
  });
  const set = (patch) => onChange({ ...value, ...patch });
  const setCustomer = (p) => set({ customer: { ...value.customer, ...p } });
  const setBike = (p) => set({ motorcycle: { ...value.motorcycle, ...p } });

  const newBike = mode === 'new' || !value.motorcycleId;
  // Cadastro único: avisa enquanto digita se o WhatsApp ou a placa já existem
  const phoneDigits = value.customer.phone.replace(/\D/g, '');
  const plateClean = value.motorcycle.plate.replace(/[^A-Z0-9]/gi, '');
  const check = useQuery({
    queryKey: ['customer-check', mode === 'new' ? phoneDigits : '', newBike ? plateClean : ''],
    queryFn: () => api.get(`/admin/customers/check?phone=${mode === 'new' ? phoneDigits : ''}&plate=${newBike ? plateClean : ''}`),
    enabled: (mode === 'new' && phoneDigits.length >= 10) || (newBike && plateClean.length === 7),
    staleTime: 30_000,
  });
  const found = check.data || {};
  const pickExisting = (customerId, bike) => {
    const c = found.customer && found.customer.id === customerId ? found.customer : { name: bike?.ownerName, phone: bike?.ownerPhone };
    set({
      customerId,
      motorcycleId: bike?.id || null,
      customer: { name: c.name, phone: phoneMask(c.phone || ''), email: '' },
      motorcycle: bike ? { brand: bike.brand, model: bike.model, year: bike.year || '', plate: plateMask(bike.plate), mileage: bike.lastMileage || '' } : value.motorcycle,
    });
    setMode('existing');
  };
  const dupCustomer = mode === 'new' && found.customer;
  const dupBike = newBike && found.motorcycle;
  const bikeOfOther = dupBike && dupBike.customerId !== (value.customerId || found.customer?.id);

  if (mode === 'search') {
    return (
      <div className="grid gap-2">
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-4 text-muted" aria-hidden />
          <input className="input pl-9" placeholder="Buscar cliente por nome, telefone ou placa" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar cliente" />
        </div>
        {search.data?.customers?.length > 0 && (
          <ul className="card divide-y divide-line max-h-56 overflow-y-auto">
            {search.data.customers.map((c) => (
              <li key={c.id}>
                <button type="button" className="w-full text-left px-3 py-2.5 hover:bg-surface-2 focus-ring"
                  onClick={() => {
                    const m0 = c.motorcycles[0];
                    set({
                      customerId: c.id,
                      motorcycleId: m0?.id || null,
                      customer: { name: c.name, phone: phoneMask(c.phone), email: c.email || '' },
                      motorcycle: m0 ? { brand: m0.brand, model: m0.model, year: '', plate: plateMask(m0.plate), mileage: '' } : { brand: '', model: '', year: '', plate: '', mileage: '' },
                    });
                    setMode('existing');
                  }}>
                  <span className="font-semibold">{c.name}</span> <span className="text-muted text-sm">{fmtPhone(c.phone)}</span>
                  <span className="block text-xs text-muted">{c.motorcycles.map((m) => `${m.model} ${plateMask(m.plate)}`).join(' · ') || 'Sem moto cadastrada'}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
        {q.trim().length >= 2 && search.data?.customers?.length === 0 && <p className="text-sm text-muted">Nenhum cliente encontrado.</p>}
        <Button size="sm" icon={UserPlus} onClick={() => { set({ customerId: null, motorcycleId: null }); setMode('new'); }} className="justify-self-start">Cliente novo</Button>
      </div>
    );
  }

  const bikes = detail.data?.motorcycles || [];
  return (
    <div className="grid gap-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold">{mode === 'existing' ? 'Cliente cadastrado' : 'Cliente novo'}</p>
        <Button size="sm" variant="ghost" onClick={() => { set({ customerId: null, motorcycleId: null, customer: { name: '', phone: '', email: '' } }); setMode('search'); }}>Trocar</Button>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <Input label="Nome" required value={value.customer.name} error={errors.name} onChange={(e) => setCustomer({ name: e.target.value })} />
        <Input label="WhatsApp" required type="tel" value={value.customer.phone} error={errors.phone} onChange={(e) => setCustomer({ phone: phoneMask(e.target.value) })} />
      </div>
      {dupCustomer && (
        <DupHint>
          Esse WhatsApp já é do cliente <b>{found.customer.name}</b>.
          <Button size="sm" onClick={() => pickExisting(found.customer.id, dupBike && !bikeOfOther ? dupBike : null)}>Usar o cadastro dele</Button>
        </DupHint>
      )}
      {mode === 'existing' && bikes.length > 0 && (
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Moto">
          {bikes.map((m) => (
            <button key={m.id} type="button" role="radio" aria-checked={value.motorcycleId === m.id}
              onClick={() => set({ motorcycleId: m.id, motorcycle: { brand: m.brand, model: m.model, year: m.year || '', plate: plateMask(m.plate), mileage: m.lastMileage || '' } })}
              className={cx('min-h-10 px-3 rounded-xl text-sm font-semibold border focus-ring inline-flex items-center gap-1.5', value.motorcycleId === m.id ? 'glass-btn glass-btn-primary' : 'card')}>
              {value.motorcycleId === m.id && <Check className="h-4 w-4" />}{m.model} · {plateMask(m.plate)}
            </button>
          ))}
          <button type="button" onClick={() => set({ motorcycleId: null, motorcycle: { brand: '', model: '', year: '', plate: '', mileage: '' } })}
            className={cx('min-h-10 px-3 rounded-xl text-sm font-semibold border focus-ring', !value.motorcycleId ? 'glass-btn glass-btn-primary' : 'card')}>+ Outra moto</button>
        </div>
      )}
      {newBike && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Select label="Marca" value={value.motorcycle.brand} error={errors.brand} onChange={(e) => setBike({ brand: e.target.value })}>
            <option value="">Marca</option>{BRANDS.map((b) => <option key={b}>{b}</option>)}
          </Select>
          <Input label="Modelo" value={value.motorcycle.model} error={errors.model} onChange={(e) => setBike({ model: e.target.value })} />
          <Input label="Placa" value={value.motorcycle.plate} error={errors.plate} onChange={(e) => setBike({ plate: plateMask(e.target.value) })} />
          <Input label="Ano" inputMode="numeric" value={value.motorcycle.year} onChange={(e) => setBike({ year: e.target.value.replace(/\D/g, '').slice(0, 4) })} />
        </div>
      )}
      {dupBike && !bikeOfOther && (
        <DupHint>
          Essa placa já está no cadastro: <b>{dupBike.brand} {dupBike.model}</b>.
          <Button size="sm" onClick={() => pickExisting(dupBike.customerId, dupBike)}>Usar essa moto</Button>
        </DupHint>
      )}
      {bikeOfOther && (
        <DupHint>
          Essa placa já está cadastrada para <b>{dupBike.ownerName}</b> ({dupBike.brand} {dupBike.model}).
          {mode === 'new' && !dupCustomer && <Button size="sm" onClick={() => pickExisting(dupBike.customerId, dupBike)}>É esse cliente</Button>}
          <span className="block w-full text-xs text-muted">Se a moto foi vendida, o agendamento sai mesmo assim e você transfere a moto no cadastro do cliente quando ela chegar.</span>
        </DupHint>
      )}
    </div>
  );
}

const DupHint = ({ children }) => (
  <div className="flex flex-wrap items-center gap-2 rounded-xl border border-warn/50 bg-warn/10 px-3 py-2 text-sm text-warn">
    <AlertTriangle className="h-4 w-4 shrink-0" />{children}
  </div>
);

export const emptyPick = () => ({ customerId: null, motorcycleId: null, customer: { name: '', phone: '', email: '' }, motorcycle: { brand: '', model: '', year: '', plate: '', mileage: '' } });

export function validatePick(v) {
  const e = {};
  if (v.customer.name.trim().length < 2) e.name = 'Informe o nome.';
  const d = v.customer.phone.replace(/\D/g, '');
  if (d.length < 10) e.phone = 'WhatsApp com DDD.';
  if (!v.motorcycleId) {
    if (!v.motorcycle.brand) e.brand = 'Marca.';
    if (!v.motorcycle.model.trim()) e.model = 'Modelo.';
    if (!/^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(v.motorcycle.plate.replace('-', ''))) e.plate = 'Placa inválida.';
  }
  return e;
}

// Image of a catalog part (illustration or real photo), with a neutral placeholder
export function PartThumb({ url, className = 'h-14 w-14' }) {
  return url
    ? <img src={url} alt="" loading="lazy" className={cx('rounded-xl object-cover bg-[#EEF2FB] shrink-0', className)} />
    : <span className={cx('rounded-xl bg-surface-2 border border-line flex items-center justify-center text-muted shrink-0', className)}><Package className="h-1/2 w-1/2" aria-hidden /></span>;
}

// Searchable grid of motorcycle parts by system (motor, freios, elétrica...)
export function CatalogPicker({ onPick, embedded = false }) {
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('');
  const query = useQuery({
    queryKey: ['parts-catalog', q, category],
    queryFn: () => api.get(`/admin/parts-catalog?q=${encodeURIComponent(q)}${category ? `&category=${encodeURIComponent(category)}` : ''}`),
  });
  const cats = query.data?.categories || [];
  return (
    <div className="grid gap-3">
      <div className="relative">
        <Search className="h-4 w-4 absolute left-3 top-4 text-muted" aria-hidden />
        <input className="input pl-9" placeholder="Buscar peça (ex.: pastilha, vela, corrente)" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar peça" autoFocus={!embedded} />
      </div>
      <div className={cx('flex gap-1.5 overflow-x-auto no-scrollbar', !embedded && '-mx-5 px-5')}>
        {['', ...cats].map((c) => (
          <button key={c || 'all'} type="button" onClick={() => setCategory(c)} aria-pressed={category === c}
            className={cx('shrink-0 min-h-9 px-3 rounded-lg text-sm font-semibold border focus-ring whitespace-nowrap', category === c ? 'glass-btn glass-btn-primary' : 'card')}>{c || 'Todas'}</button>
        ))}
      </div>
      {query.data && query.data.parts.length === 0 && <p className="text-sm text-muted">Nenhuma peça encontrada. Cadastre em Catálogo de peças.</p>}
      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
        {query.data?.parts.map((p) => (
          <button key={p.id} type="button" onClick={() => onPick(p)} className="card p-2 text-left hover:border-brand focus-ring flex flex-col gap-1.5">
            <PartThumb url={p.imageUrl} className="w-full h-auto aspect-square" />
            <span className="text-xs font-semibold leading-tight line-clamp-2">{p.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
