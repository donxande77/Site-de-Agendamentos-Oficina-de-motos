import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ChevronLeft, Download, Trash2, Plus, Pencil, MessageCircle, Phone, ShieldCheck, History, ArrowRightLeft, Combine, Search } from 'lucide-react';
import { api, openFile } from '../../lib/api.js';
import { Button, Card, Spinner, ErrorBox, Badge, Modal, Input, Select, Textarea, useToast, ConfirmModal } from '../../components/ui.jsx';
import { fmtPhone, phoneMask, plateMask, fmtDate, fmtDateTime, money, BRANDS, ORDER_STATUS, BOOKING_STATUS, waUrl } from '../../lib/format.js';
import { useAuth, isStaff, isBusiness } from './shared.jsx';

export default function CustomerDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const staff = isStaff(user);
  const toast = useToast();
  const nav = useNavigate();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['customer', Number(id)], queryFn: () => api.get(`/admin/customers/${id}`) });
  const [editing, setEditing] = useState(false);
  const [bike, setBike] = useState(null);
  const [del, setDel] = useState(false);
  const [transfer, setTransfer] = useState(null);
  const [mergeBike, setMergeBike] = useState(null);
  const [mergeCustomer, setMergeCustomer] = useState(false);
  const [busy, setBusy] = useState(false);
  const refresh = () => qc.invalidateQueries({ queryKey: ['customer', Number(id)] });

  if (q.isLoading) return <Spinner />;
  if (q.error) return <ErrorBox error={q.error} onRetry={q.refetch} />;
  const { customer: c, motorcycles, bookings, orders } = q.data;
  const consent = c.reminderConsentAt && !c.reminderConsentRevokedAt;

  async function toggleConsent() {
    try { await api.post(`/admin/customers/${c.id}/reminder-consent`, { consent: !consent }); toast(consent ? 'Lembretes desativados.' : 'Autorização registrada.'); refresh(); } catch (e) { toast(e.message, 'bad'); }
  }
  async function anonymize() {
    setBusy(true);
    try { await api.del(`/admin/customers/${c.id}`); toast('Dados do cliente apagados.'); nav('/admin/clientes'); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <Link to="/admin/clientes" className="glass-btn inline-flex items-center gap-1 min-h-9 px-3 rounded-[10px] text-sm font-semibold"><ChevronLeft className="h-4 w-4" />Clientes</Link>
        <h1 className="font-display text-4xl font-bold uppercase leading-none">{c.name}</h1>
        {c.anonymizedAt && <Badge tone="bad">Dados apagados</Badge>}
        {c.noShowCount > 0 && <Badge tone="bad">{c.noShowCount} falta(s)</Badge>}
      </div>
      <div className="grid lg:grid-cols-[1fr_1.4fr] gap-4 items-start">
        <div className="grid gap-4">
          <Card className="grid gap-2">
            <p className="text-steel">{fmtPhone(c.phone)}{c.email ? ` · ${c.email}` : ''}</p>
            <p className="text-xs text-muted">Cliente desde {fmtDate(c.createdAt)}{c.privacyAckAt ? ` · aviso de privacidade aceito em ${fmtDate(c.privacyAckAt)}` : ''}</p>
            {c.notes && <p className="text-sm whitespace-pre-line border-t border-line pt-2">{c.notes}</p>}
            <div className="flex flex-wrap gap-2 pt-1">
              <a className="glass-btn inline-flex items-center gap-1.5 min-h-9 px-3 rounded-[10px] text-sm font-semibold" href={`tel:+${c.phone}`}><Phone className="h-4 w-4" />Ligar</a>
              <a className="glass-btn inline-flex items-center gap-1.5 min-h-9 px-3 rounded-[10px] text-sm font-semibold" href={waUrl(c.phone)} target="_blank" rel="noopener noreferrer"><MessageCircle className="h-4 w-4" />WhatsApp</a>
              {staff && <Button size="sm" icon={Pencil} onClick={() => setEditing(true)}>Editar</Button>}
              {isBusiness(user) && !c.anonymizedAt && <Button size="sm" icon={Combine} onClick={() => setMergeCustomer(true)}>Juntar cadastro repetido</Button>}
            </div>
          </Card>
          <Card className="grid gap-2">
            <p className="font-semibold flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-brand-light" />Lembretes de revisão</p>
            <p className="text-sm text-muted">{consent ? `Autorizado em ${fmtDateTime(c.reminderConsentAt)}.` : c.reminderConsentRevokedAt ? `Cancelado em ${fmtDateTime(c.reminderConsentRevokedAt)}.` : 'O cliente não autorizou.'}</p>
            {staff && <Button size="sm" onClick={toggleConsent} className="justify-self-start">{consent ? 'Cliente pediu para parar' : 'Cliente autorizou agora'}</Button>}
          </Card>
          <Card>
            <div className="flex items-center justify-between mb-2">
              <h2 className="font-display text-2xl font-bold uppercase">Motos</h2>
              {staff && <Button size="sm" icon={Plus} onClick={() => setBike({})}>Moto</Button>}
            </div>
            <ul className="divide-y divide-line">
              {motorcycles.map((m) => (
                <li key={m.id} className="py-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold">{m.brand} {m.model}{m.year ? ` ${m.year}` : ''}</p>
                      <p className="text-sm text-muted">{plateMask(m.plate)}{m.lastMileage ? ` · ${m.lastMileage.toLocaleString('pt-BR')} km` : ''}{m.color ? ` · ${m.color}` : ''}</p>
                    </div>
                    {staff && <Button size="sm" variant="ghost" aria-label="Editar moto" onClick={() => setBike(m)}><Pencil className="h-4 w-4" /></Button>}
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <Link to={`/admin/motos/${m.id}`} className="glass-btn inline-flex items-center gap-1.5 min-h-9 px-3 rounded-[10px] text-sm font-semibold"><History className="h-4 w-4" />Prontuário</Link>
                    {staff && <Button size="sm" variant="ghost" icon={ArrowRightLeft} onClick={() => setTransfer(m)}>Moto vendida</Button>}
                    {isBusiness(user) && motorcycles.length > 1 && <Button size="sm" variant="ghost" icon={Combine} onClick={() => setMergeBike(m)}>É a mesma moto que outra</Button>}
                  </div>
                </li>
              ))}
            </ul>
          </Card>
          {isBusiness(user) && !c.anonymizedAt && (
            <Card className="grid gap-2">
              <p className="font-semibold">Pedidos de privacidade (LGPD)</p>
              <p className="text-sm text-muted">Se o cliente pedir uma cópia dos dados ou para apagar o cadastro.</p>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" icon={Download} onClick={() => openFile(`/admin/customers/${c.id}/export`, `dados-${c.name.split(' ')[0].toLowerCase()}.json`).catch((e) => toast(e.message, 'bad'))}>Exportar dados</Button>
                <Button size="sm" variant="danger" icon={Trash2} onClick={() => setDel(true)}>Apagar dados</Button>
              </div>
            </Card>
          )}
        </div>
        <div className="grid gap-4">
          <Card>
            <h2 className="font-display text-2xl font-bold uppercase mb-2">Histórico de serviços</h2>
            {orders.length === 0 ? <p className="text-sm text-muted">Nenhuma OS ainda.</p> : (
              <ul className="divide-y divide-line">
                {orders.map((o) => (
                  <li key={o.id}>
                    <Link to={`/admin/os/${o.id}`} className="flex items-center justify-between gap-3 py-2.5 hover:text-brand-light">
                      <div><p className="font-semibold">OS {o.number} · {o.model} {plateMask(o.plate)}</p><p className="text-sm text-muted">{fmtDate(o.createdAt)}{o.warrantyUntil ? ` · garantia até ${fmtDate(o.warrantyUntil)}` : ''}</p></div>
                      <div className="text-right"><Badge tone={ORDER_STATUS[o.status].tone}>{ORDER_STATUS[o.status].label}</Badge><p className="text-sm font-semibold mt-1">{money(o.totalCents)}</p></div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>
          <Card>
            <h2 className="font-display text-2xl font-bold uppercase mb-2">Agendamentos</h2>
            {bookings.length === 0 ? <p className="text-sm text-muted">Nenhum agendamento.</p> : (
              <ul className="divide-y divide-line text-sm">
                {bookings.map((b) => <li key={b.id} className="flex justify-between py-2"><span>{fmtDateTime(b.startAt)} · {b.code}</span><Badge tone={BOOKING_STATUS[b.status].tone}>{BOOKING_STATUS[b.status].label}</Badge></li>)}
              </ul>
            )}
          </Card>
        </div>
      </div>
      {editing && <EditCustomer customer={c} onClose={() => setEditing(false)} onSaved={() => { setEditing(false); refresh(); }} />}
      {bike && <EditBike customerId={c.id} bike={bike} onClose={() => setBike(null)} onSaved={() => { setBike(null); refresh(); }} />}
      {transfer && <TransferBike bike={transfer} from={c} onClose={() => setTransfer(null)} onDone={() => { setTransfer(null); refresh(); }} />}
      {mergeBike && <MergeBike bike={mergeBike} others={motorcycles.filter((m) => m.id !== mergeBike.id)} onClose={() => setMergeBike(null)} onDone={() => { setMergeBike(null); refresh(); }} />}
      {mergeCustomer && <MergeCustomer keep={c} onClose={() => setMergeCustomer(false)} onDone={() => { setMergeCustomer(false); refresh(); }} />}
      <ConfirmModal open={del} onClose={() => setDel(false)} danger loading={busy} title="Apagar os dados deste cliente?" confirmLabel="Apagar dados"
        message="Nome, telefone, e-mail, placas e fotos serão apagados. As OS e pagamentos continuam no financeiro, mas sem identificar a pessoa. Isso não pode ser desfeito." onConfirm={anonymize} />
    </div>
  );
}

function EditCustomer({ customer, onClose, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState({ name: customer.name, phone: phoneMask(customer.phone), email: customer.email || '', notes: customer.notes || '' });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try { await api.patch(`/admin/customers/${customer.id}`, { ...f, notes: f.notes || null }); toast('Cliente atualizado.'); onSaved(); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title="Editar cliente" footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid gap-3">
        <Input label="Nome" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <Input label="WhatsApp" value={f.phone} onChange={(e) => setF({ ...f, phone: phoneMask(e.target.value) })} />
        <Input label="E-mail" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <Textarea label="Observações internas" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
      </div>
    </Modal>
  );
}

function EditBike({ customerId, bike, onClose, onSaved }) {
  const toast = useToast();
  const [taken, setTaken] = useState(null);
  const [f, setF] = useState({ brand: bike.brand || '', model: bike.model || '', year: bike.year || '', plate: plateMask(bike.plate || ''), color: bike.color || '', lastMileage: bike.lastMileage ?? '' });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    const body = { ...f, year: f.year ? Number(f.year) : null, lastMileage: f.lastMileage === '' ? null : Number(f.lastMileage), color: f.color || null };
    try {
      if (bike.id) await api.patch(`/admin/motorcycles/${bike.id}`, body);
      else await api.post(`/admin/customers/${customerId}/motorcycles`, body);
      toast('Moto salva.');
      onSaved();
    } catch (e) {
      if (e.code === 'PLATE_EXISTS') setTaken(e.data.motorcycle);
      else toast(e.message, 'bad');
    } finally { setBusy(false); }
  }
  async function bringHere() {
    setBusy(true);
    try { await api.post(`/admin/motorcycles/${taken.id}/transfer`, { customerId }); toast('Moto transferida com todo o histórico.'); onSaved(); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title={bike.id ? 'Editar moto' : 'Nova moto'} footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid grid-cols-2 gap-3">
        <Select label="Marca" value={f.brand} onChange={(e) => setF({ ...f, brand: e.target.value })}><option value="">Marca</option>{BRANDS.map((b) => <option key={b}>{b}</option>)}</Select>
        <Input label="Modelo" value={f.model} onChange={(e) => setF({ ...f, model: e.target.value })} />
        <Input label="Placa" value={f.plate} onChange={(e) => setF({ ...f, plate: plateMask(e.target.value) })} />
        <Input label="Ano" inputMode="numeric" value={f.year} onChange={(e) => setF({ ...f, year: e.target.value.replace(/\D/g, '').slice(0, 4) })} />
        <Input label="Cor" value={f.color} onChange={(e) => setF({ ...f, color: e.target.value })} />
        <Input label="KM atual" inputMode="numeric" value={f.lastMileage} onChange={(e) => setF({ ...f, lastMileage: e.target.value.replace(/\D/g, '').slice(0, 7) })} />
      </div>
      {taken && (
        <div className="mt-3 rounded-xl border border-warn/50 bg-warn/10 px-3 py-2 text-sm text-warn grid gap-2">
          {taken.customerId === customerId
            ? <p>Essa placa já está neste cadastro ({taken.brand} {taken.model}). Não precisa cadastrar de novo.</p>
            : <>
              <p>Essa placa já está cadastrada para <b>{taken.ownerName}</b> ({taken.brand} {taken.model}). Se a moto foi vendida para este cliente, transfira: o histórico vai junto.</p>
              {!bike.id && <Button size="sm" icon={ArrowRightLeft} loading={busy} onClick={bringHere} className="justify-self-start">Transferir para este cliente</Button>}
            </>}
        </div>
      )}
    </Modal>
  );
}

// Busca simples de cliente (nome, WhatsApp ou placa)
function CustomerSearch({ exceptId, onPick, picked }) {
  const [q, setQ] = useState('');
  const r = useQuery({ queryKey: ['customer-search', q], queryFn: () => api.get(`/admin/customers?q=${encodeURIComponent(q)}`), enabled: q.trim().length >= 2 });
  const list = (r.data?.customers || []).filter((x) => x.id !== exceptId);
  return (
    <div className="grid gap-2">
      <div className="relative">
        <Search className="h-4 w-4 absolute left-3 top-4 text-muted" aria-hidden />
        <input className="input pl-9" placeholder="Nome, WhatsApp ou placa" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar cliente" autoFocus />
      </div>
      {list.length > 0 && (
        <ul className="card divide-y divide-line max-h-56 overflow-y-auto">
          {list.map((x) => (
            <li key={x.id}>
              <button type="button" onClick={() => onPick(x)} aria-pressed={picked?.id === x.id}
                className={`w-full text-left px-3 py-2.5 focus-ring ${picked?.id === x.id ? 'bg-brand/20' : 'hover:bg-surface-2'}`}>
                <span className="font-semibold">{x.name}</span> <span className="text-muted text-sm">{fmtPhone(x.phone)}</span>
                <span className="block text-xs text-muted">{x.motorcycles.map((m) => `${m.model} ${plateMask(m.plate)}`).join(' · ') || 'Sem moto cadastrada'}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
      {q.trim().length >= 2 && r.data && list.length === 0 && <p className="text-sm text-muted">Nenhum cliente encontrado. Cadastre o novo dono em Clientes primeiro.</p>}
    </div>
  );
}

function TransferBike({ bike, from, onClose, onDone }) {
  const toast = useToast();
  const [to, setTo] = useState(null);
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try { await api.post(`/admin/motorcycles/${bike.id}/transfer`, { customerId: to.id }); toast(`Moto transferida para ${to.name}.`); onDone(); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title="Moto vendida: transferir para o novo dono"
      footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" disabled={!to} loading={busy} onClick={save}>Transferir</Button></>}>
      <div className="grid gap-3">
        <p className="text-sm text-steel"><b>{bike.brand} {bike.model} · {plateMask(bike.plate)}</b> sai do cadastro de {from.name}. O prontuário da moto vai junto; as OS antigas continuam no nome de quem pagou.</p>
        <CustomerSearch exceptId={from.id} onPick={setTo} picked={to} />
      </div>
    </Modal>
  );
}

function MergeBike({ bike, others, onClose, onDone }) {
  const toast = useToast();
  const [keepId, setKeepId] = useState(others[0]?.id || null);
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try { await api.post(`/admin/motorcycles/${keepId}/merge`, { duplicateId: bike.id }); toast('Motos juntadas. O histórico ficou todo numa só.'); onDone(); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title="Juntar motos repetidas"
      footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" disabled={!keepId} loading={busy} onClick={save}>Juntar</Button></>}>
      <div className="grid gap-3">
        <p className="text-sm text-steel">Use quando a mesma moto foi cadastrada duas vezes (placa digitada errada). As OS e agendamentos de <b>{plateMask(bike.plate)}</b> passam para a moto escolhida abaixo, e o cadastro <b>{plateMask(bike.plate)}</b> é apagado.</p>
        <Select label="A placa certa é" value={keepId || ''} onChange={(e) => setKeepId(Number(e.target.value))}>
          {others.map((m) => <option key={m.id} value={m.id}>{m.brand} {m.model} · {plateMask(m.plate)}</option>)}
        </Select>
      </div>
    </Modal>
  );
}

function MergeCustomer({ keep, onClose, onDone }) {
  const toast = useToast();
  const qc = useQueryClient();
  const [dup, setDup] = useState(null);
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      await api.post(`/admin/customers/${keep.id}/merge`, { duplicateId: dup.id });
      qc.invalidateQueries({ queryKey: ['customers'] });
      toast('Cadastros juntados.');
      onDone();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title="Juntar cadastro repetido"
      footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="danger" disabled={!dup} loading={busy} onClick={save}>Juntar e apagar o repetido</Button></>}>
      <div className="grid gap-3">
        <p className="text-sm text-steel">Use quando a mesma pessoa tem dois cadastros (por exemplo, trocou de número). Tudo do cadastro escolhido abaixo (motos, agendamentos e OS) vem para <b>{keep.name}</b>. O WhatsApp que fica é o deste cadastro ({fmtPhone(keep.phone)}); o outro número fica anotado nas observações.</p>
        <CustomerSearch exceptId={keep.id} onPick={setDup} picked={dup} />
        {dup && <p className="rounded-lg border border-warn/50 bg-warn/10 px-3 py-2 text-sm text-warn">O cadastro de <b>{dup.name}</b> ({fmtPhone(dup.phone)}) será apagado depois de juntar. Não dá para desfazer.</p>}
      </div>
    </Modal>
  );
}
