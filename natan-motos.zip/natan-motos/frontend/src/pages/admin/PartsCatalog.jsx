import { useRef, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Camera, RotateCcw } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Button, Spinner, ErrorBox, Badge, Modal, Input, Textarea, Checkbox, useToast, cx } from '../../components/ui.jsx';
import { PageHeader, useAuth, isOwner } from './shared.jsx';
import { PartThumb } from './pickers.jsx';

export default function PartsCatalog() {
  const { user } = useAuth();
  const staff = isOwner(user); // only the system administrator edits the catalog
  const qc = useQueryClient();
  const [q, setQ] = useState('');
  const [category, setCategory] = useState('');
  const [edit, setEdit] = useState(null);
  const query = useQuery({
    queryKey: ['parts-catalog-admin', q, category],
    queryFn: () => api.get(`/admin/parts-catalog?all=1&q=${encodeURIComponent(q)}${category ? `&category=${encodeURIComponent(category)}` : ''}`),
  });
  const cats = query.data?.categories || [];
  const refresh = () => { qc.invalidateQueries({ queryKey: ['parts-catalog-admin'] }); qc.invalidateQueries({ queryKey: ['parts-catalog'] }); };

  return (
    <div>
      <PageHeader title="Catálogo de peças" sub="As peças da moto que aparecem no orçamento, cada uma com imagem. Troque a ilustração por uma foto real quando quiser."
        actions={staff && <Button variant="primary" icon={Plus} onClick={() => setEdit({})}>Nova peça</Button>} />
      <div className="relative mb-3">
        <Search className="h-4 w-4 absolute left-3 top-4 text-muted" aria-hidden />
        <input className="input pl-9" placeholder="Buscar peça" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar peça" />
      </div>
      <div className="-mx-4 px-4 flex gap-1.5 overflow-x-auto no-scrollbar mb-4">
        {['', ...cats].map((c) => (
          <button key={c || 'all'} type="button" onClick={() => setCategory(c)} aria-pressed={category === c}
            className={cx('shrink-0 min-h-9 px-3 rounded-lg text-sm font-semibold border focus-ring whitespace-nowrap', category === c ? 'glass-btn glass-btn-primary' : 'card')}>{c || 'Todas'}</button>
        ))}
      </div>
      {query.isLoading && <Spinner />}
      {query.error && <ErrorBox error={query.error} onRetry={query.refetch} />}
      {query.data && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-3">
          {query.data.parts.map((p) => (
            <button key={p.id} type="button" disabled={!staff} onClick={() => setEdit(p)}
              className={cx('card p-3 text-left flex flex-col gap-2 focus-ring', staff && 'hover:border-brand', !p.active && 'opacity-50')}>
              <PartThumb url={p.imageUrl} className="w-full h-auto aspect-square" />
              <span className="font-semibold text-sm leading-tight">{p.name}</span>
              <span className="text-xs text-muted">{p.category}</span>
              <span className="flex flex-wrap gap-1">
                {p.hasPhoto ? <Badge tone="ok">Foto real</Badge> : <Badge>Ilustração</Badge>}
                {!p.active && <Badge tone="bad">Inativa</Badge>}
              </span>
            </button>
          ))}
        </div>
      )}
      {edit && <PartModal part={edit} categories={cats} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); refresh(); }} onPhoto={(p) => { setEdit(p); refresh(); }} />}
    </div>
  );
}

function PartModal({ part, categories, onClose, onSaved, onPhoto }) {
  const toast = useToast();
  const input = useRef(null);
  const [f, setF] = useState({ name: part.name || '', category: part.category || categories[0] || '', description: part.description || '', active: part.active ?? true });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    const body = { ...f, name: f.name.trim(), category: f.category.trim(), description: f.description.trim() || null };
    try {
      if (part.id) await api.patch(`/admin/parts-catalog/${part.id}`, body); else await api.post('/admin/parts-catalog', body);
      toast('Peça salva.');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  async function upload(file) {
    if (!file) return;
    const fd = new FormData();
    fd.append('photo', file);
    setBusy(true);
    try { const r = await api.upload(`/admin/parts-catalog/${part.id}/photo`, fd); toast('Foto salva.'); onPhoto(r.part); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  async function restore() {
    setBusy(true);
    try { const r = await api.del(`/admin/parts-catalog/${part.id}/photo`); toast('Voltou para a ilustração.'); onPhoto(r.part); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title={part.id ? 'Editar peça' : 'Nova peça'} footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid gap-3">
        {part.id && (
          <div className="flex items-center gap-4">
            <PartThumb url={part.imageUrl} className="h-28 w-28" />
            <div className="grid gap-2">
              <Button size="sm" icon={Camera} onClick={() => input.current?.click()} loading={busy}>{part.hasPhoto ? 'Trocar foto' : 'Usar foto real'}</Button>
              {part.hasPhoto && part.slug && <Button size="sm" variant="ghost" icon={RotateCcw} onClick={restore}>Voltar à ilustração</Button>}
              <p className="text-xs text-muted">JPG ou PNG, até 5 MB. Aparece no orçamento e no PDF.</p>
            </div>
            <input ref={input} type="file" accept="image/jpeg,image/png" hidden onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ''; }} />
          </div>
        )}
        <Input label="Nome" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Ex.: Pastilhas de freio" />
        <Input label="Sistema da moto" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} list="part-categories" />
        <datalist id="part-categories">{categories.map((c) => <option key={c} value={c} />)}</datalist>
        <Textarea label="Dica para o cliente" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} maxLength={300} placeholder="Ex.: confira a medida na lateral do pneu" />
        <Checkbox label="Ativa (aparece na escolha do orçamento)" checked={f.active} onChange={(v) => setF({ ...f, active: v })} />
        {!part.id && <p className="text-xs text-muted">Depois de salvar, abra a peça para colocar a foto.</p>}
      </div>
    </Modal>
  );
}
