import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Plus, Search, ClipboardList } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Button, Spinner, ErrorBox, Badge, Empty, Modal, Segmented, Input, Select, useToast } from '../../components/ui.jsx';
import { money, plateMask, fmtDate, ORDER_STATUS, FUEL_LABEL } from '../../lib/format.js';
import { PageHeader, useAuth, isStaff } from './shared.jsx';
import { CustomerBikePicker, emptyPick, validatePick } from './pickers.jsx';

export default function Orders() {
  const { user } = useAuth();
  const [params, setParams] = useSearchParams();
  const status = params.get('status') || '';
  const [scope, setScope] = useState(status ? 'status' : 'active');
  const [q, setQ] = useState('');
  const [creating, setCreating] = useState(false);
  const qs = new URLSearchParams();
  if (scope === 'status' && status) qs.set('status', status);
  else if (scope === 'mine') { qs.set('scope', 'active'); qs.set('mine', '1'); } else qs.set('scope', scope === 'status' ? 'active' : scope);
  if (q.trim()) qs.set('q', q.trim());
  const query = useQuery({ queryKey: ['orders', qs.toString()], queryFn: () => api.get(`/admin/orders?${qs}`) });

  return (
    <div>
      <PageHeader title="Ordens de serviço" sub="Motos na oficina, orçamentos e entregas."
        actions={isStaff(user) && <Button variant="primary" icon={Plus} onClick={() => setCreating(true)}>Nova OS (balcão)</Button>} />
      <div className="flex flex-wrap gap-2 mb-4 items-center">
        <Segmented value={scope} onChange={(v) => { setScope(v); setParams({}); }} options={[
          { value: 'active', label: 'Na oficina' },
          ...(user.role === 'MECHANIC' ? [{ value: 'mine', label: 'Minhas' }] : []),
          ...(['OWNER', 'MANAGER'].includes(user.role) ? [{ value: 'receivable', label: 'A receber' }] : []),
          { value: 'all', label: 'Todas' },
        ]} />
        {scope === 'status' && status && <Badge tone={ORDER_STATUS[status]?.tone}>Filtro: {ORDER_STATUS[status]?.label}</Badge>}
        <div className="relative flex-1 min-w-52">
          <Search className="h-4 w-4 absolute left-3 top-4 text-muted" aria-hidden />
          <input className="input pl-9" placeholder="Buscar por cliente, placa ou nº da OS" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar OS" />
        </div>
      </div>
      {query.isLoading && <Spinner />}
      {query.error && <ErrorBox error={query.error} onRetry={query.refetch} />}
      {query.data && (query.data.orders.length === 0 ? <Empty icon={ClipboardList} title="Nenhuma OS aqui">As OS são abertas no check-in do agendamento ou pelo botão “Nova OS”.</Empty> : (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
          {query.data.orders.map((o) => {
            const balance = o.totalCents - o.paidCents;
            return (
              <Link key={o.id} to={`/admin/os/${o.id}`} className="card p-4 hover:border-brand focus-ring grid gap-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display text-2xl font-bold">OS {String(o.number).padStart(5, '0')}</span>
                  <Badge tone={ORDER_STATUS[o.status].tone}>{ORDER_STATUS[o.status].label}</Badge>
                </div>
                <p className="font-semibold truncate">{o.customerName}</p>
                <p className="text-sm text-steel truncate">{o.brand} {o.model} · {plateMask(o.plate)}</p>
                <div className="flex justify-between text-sm text-muted pt-1">
                  <span>{o.mechanicName || 'Sem mecânico'} · {fmtDate(o.createdAt)}</span>
                  <span className="font-semibold text-fg">{money(o.totalCents)}</span>
                </div>
                {balance > 0 && ['READY', 'DELIVERED'].includes(o.status) && <p className="text-xs text-warn">Falta receber {money(balance)}</p>}
              </Link>
            );
          })}
        </div>
      ))}
      {creating && <NewOrderModal onClose={() => setCreating(false)} />}
    </div>
  );
}

function NewOrderModal({ onClose }) {
  const toast = useToast();
  const nav = useNavigate();
  const users = useQuery({ queryKey: ['users'], queryFn: () => api.get('/admin/users') });
  const [pick, setPick] = useState(emptyPick());
  const [km, setKm] = useState('');
  const [fuel, setFuel] = useState('');
  const [mechanicId, setMechanicId] = useState('');
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);

  async function save() {
    const e = validatePick(pick);
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      let { customerId, motorcycleId } = pick;
      if (!customerId) {
        const r = await api.post('/admin/customers', { name: pick.customer.name.trim(), phone: pick.customer.phone, email: pick.customer.email || '' });
        customerId = r.customer.id;
      }
      if (!motorcycleId) {
        const r = await api.post(`/admin/customers/${customerId}/motorcycles`, {
          brand: pick.motorcycle.brand, model: pick.motorcycle.model, plate: pick.motorcycle.plate, year: pick.motorcycle.year ? Number(pick.motorcycle.year) : null,
        });
        motorcycleId = r.motorcycle.id;
      }
      const r = await api.post('/admin/orders', {
        customerId, motorcycleId, mechanicId: mechanicId ? Number(mechanicId) : null,
        checkInMileage: km ? Number(km) : null, fuelLevel: fuel || null,
      });
      toast('OS aberta.');
      nav(`/admin/os/${r.orderId}`);
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  }

  return (
    <Modal open onClose={onClose} title="Nova OS" wide footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Abrir OS</Button></>}>
      <div className="grid gap-4">
        <p className="text-sm text-muted">Para moto que chegou sem agendamento. Se tiver agendamento, faça o check-in pela agenda.</p>
        <CustomerBikePicker value={pick} onChange={setPick} errors={errors} />
        <div className="grid sm:grid-cols-3 gap-3">
          <Input label="KM na entrada" inputMode="numeric" value={km} onChange={(e) => setKm(e.target.value.replace(/\D/g, '').slice(0, 7))} />
          <Select label="Combustível" value={fuel} onChange={(e) => setFuel(e.target.value)}>
            <option value="">Não informado</option>{Object.entries(FUEL_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </Select>
          <Select label="Mecânico" value={mechanicId} onChange={(e) => setMechanicId(e.target.value)}>
            <option value="">Não definido</option>
            {users.data?.users.filter((u) => u.active && u.role !== 'ATTENDANT').map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
          </Select>
        </div>
      </div>
    </Modal>
  );
}
