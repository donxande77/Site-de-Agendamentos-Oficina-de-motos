import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ChevronLeft, ChevronRight, Plus, Ban, Phone, MessageCircle, ClipboardList, CalendarClock, UserX, X, Check, Bell, Trash2,
} from 'lucide-react';
import { api } from '../../lib/api.js';
import {
  Button, Card, Spinner, ErrorBox, Badge, Modal, Segmented, Select, Input, Textarea, Checkbox, ConfirmModal, useToast, cx,
} from '../../components/ui.jsx';
import {
  isoDay, addDays, dayToDate, fmtTime, fmtLong, fmtDate, localToIso, plateMask, fmtPhone, duration, weekdayOf,
  WEEKDAYS_SHORT, BOOKING_STATUS, ORDER_STATUS, SOURCE_LABEL, FUEL_LABEL, CHECK_ITEMS, waUrl,
} from '../../lib/format.js';
import { PageHeader, useAuth, isStaff, sendWhatsApp } from './shared.jsx';
import { PendingBox } from './record.jsx';
import MonthPicker from './MonthPicker.jsx';
import { CustomerBikePicker, emptyPick, validatePick } from './pickers.jsx';

const ROW = 52;
const toMin = (hm) => { const [h, m] = hm.split(':').map(Number); return h * 60 + m; };
const toHm = (m) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
const STATUS_STYLE = {
  PENDING: 'border-warn/60 bg-warn/15',
  CONFIRMED: 'border-brand/70 bg-brand/25',
  CHECKED_IN: 'border-ok/60 bg-ok/15',
  NO_SHOW: 'border-bad/50 bg-bad/10 opacity-60',
};

function weekStart(day) {
  const wd = weekdayOf(day);
  return addDays(day, wd === 0 ? -6 : 1 - wd);
}

export default function Agenda() {
  const { user } = useAuth();
  const staff = isStaff(user);
  const qc = useQueryClient();
  const toast = useToast();
  const [day, setDay] = useState(isoDay());
  const [view, setView] = useState('day');
  const [openId, setOpenId] = useState(null);
  const [creating, setCreating] = useState(null);
  const [blocking, setBlocking] = useState(false);
  const from = view === 'day' ? day : weekStart(day);
  const to = view === 'day' ? day : addDays(from, 6);
  const q = useQuery({ queryKey: ['agenda', from, to], queryFn: () => api.get(`/admin/agenda?from=${from}&to=${to}`), refetchInterval: 30_000 });
  const refresh = () => qc.invalidateQueries({ queryKey: ['agenda'] });

  async function move(bookingId, payload) {
    try {
      await api.patch(`/admin/bookings/${bookingId}`, payload);
      toast('Agendamento remarcado.');
      refresh();
    } catch (e) { toast(e.message, 'bad'); }
  }

  const title = view === 'day' ? fmtLong(dayToDate(day)) : `${fmtDate(dayToDate(from))} a ${fmtDate(dayToDate(to))}`;

  return (
    <div>
      <PageHeader title="Agenda" sub={<span>{title}</span>}
        actions={staff && <>
          <Button icon={Ban} onClick={() => setBlocking(true)}>Bloquear horário</Button>
          <Button variant="primary" icon={Plus} onClick={() => setCreating({ day })}>Novo agendamento</Button>
        </>} />

      <div className="flex flex-wrap items-center gap-2 mb-4">
        <Button size="icon" aria-label="Anterior" onClick={() => setDay(addDays(day, view === 'day' ? -1 : -7))}><ChevronLeft className="h-5 w-5" /></Button>
        <Button size="sm" onClick={() => setDay(isoDay())}>Hoje</Button>
        <Button size="icon" aria-label="Próximo" onClick={() => setDay(addDays(day, view === 'day' ? 1 : 7))}><ChevronRight className="h-5 w-5" /></Button>
        <MonthPicker value={day} onChange={setDay} />
        <Segmented className="ml-auto" value={view} onChange={setView} options={[{ value: 'day', label: 'Dia' }, { value: 'week', label: 'Semana' }]} />
      </div>

      {q.isLoading && <Spinner />}
      {q.error && <ErrorBox error={q.error} onRetry={q.refetch} />}
      {q.data && (view === 'day'
        ? <DayGrid data={q.data} day={day} staff={staff} onOpen={setOpenId} onCreate={(p) => setCreating(p)} onMove={move} />
        : <WeekView data={q.data} from={from} onOpen={setOpenId} onPickDay={(d) => { setDay(d); setView('day'); }} />)}

      {openId && <BookingModal id={openId} onClose={() => setOpenId(null)} onChanged={refresh} staff={staff} data={q.data} />}
      {creating && <NewBookingModal initial={creating} data={q.data} onClose={() => setCreating(null)} onSaved={() => { setCreating(null); refresh(); }} />}
      {blocking && <BlockModal day={day} data={q.data} onClose={() => setBlocking(false)} onSaved={() => { setBlocking(false); refresh(); }} />}
    </div>
  );
}

function DayGrid({ data, day, staff, onOpen, onCreate, onMove }) {
  const { bays, hours, bookings, blocks, mechanics, settings } = data;
  const [dragId, setDragId] = useState(null);
  const slot = settings.slotMinutes;
  const h = hours.find((x) => x.weekday === weekdayOf(day));
  const open = hours.filter((x) => !x.closed);
  const start = h && !h.closed ? toMin(h.opensAt) : Math.min(...open.map((x) => toMin(x.opensAt)), 480);
  const end = h && !h.closed ? toMin(h.closesAt) : Math.max(...open.map((x) => toMin(x.closesAt)), 1080);
  const rows = [];
  for (let m = start; m < end; m += slot) rows.push(m);
  const byMechanic = settings.scheduleView === 'mechanic';
  const columns = byMechanic
    ? [...mechanics.map((m) => ({ key: `u${m.id}`, id: m.id, name: m.name })), { key: 'u0', id: null, name: 'Sem mecânico' }]
    : bays.filter((b) => b.active || bookings.some((x) => x.bayId === b.id)).map((b) => ({ key: `b${b.id}`, id: b.id, name: b.name }));
  const visible = bookings.filter((b) => b.status !== 'CANCELLED');
  const inCol = (b, col) => (byMechanic ? (b.mechanicId || null) === col.id : b.bayId === col.id);
  const blockInCol = (bl, col) => (byMechanic ? bl.userId === col.id || (!bl.bayId && !bl.userId) : bl.bayId === col.id || (!bl.bayId && !bl.userId));
  const top = (iso) => ((toMin(fmtTime(iso)) - start) / slot) * ROW;
  const cancelled = bookings.filter((b) => b.status === 'CANCELLED');

  return (
    <>
      {h?.closed && <p className="text-sm text-warn mb-2">A oficina está marcada como fechada neste dia. Você ainda pode encaixar agendamentos.</p>}
      <div className="card overflow-x-auto">
        <div className="grid min-w-[22rem]" style={{ gridTemplateColumns: `3.25rem repeat(${columns.length}, minmax(9.5rem, 1fr))` }}>
          <div className="sticky left-0 z-10 bg-surface border-b border-line" />
          {columns.map((c) => <div key={c.key} className="px-2 py-2.5 border-b border-l border-line text-sm font-semibold text-center">{c.name}</div>)}

          <div className="sticky left-0 z-10 bg-surface">
            {rows.map((m) => <div key={m} style={{ height: ROW }} className="text-[11px] text-muted pr-1.5 text-right -translate-y-1.5">{m % 60 === 0 ? toHm(m) : ''}</div>)}
          </div>
          {columns.map((col) => (
            <div key={col.key} className="relative border-l border-line" style={{ height: rows.length * ROW }}>
              {rows.map((m) => {
                const inBreak = h?.breakStart && m >= toMin(h.breakStart) && m < toMin(h.breakEnd);
                return (
                  <button key={m} type="button" tabIndex={staff ? 0 : -1} aria-label={staff ? `Agendar ${toHm(m)} em ${col.name}` : undefined}
                    disabled={!staff}
                    onClick={() => staff && onCreate({ day, time: toHm(m), bayId: byMechanic ? undefined : col.id, mechanicId: byMechanic ? col.id : undefined })}
                    onDragOver={(e) => { if (dragId) e.preventDefault(); }}
                    onDrop={(e) => {
                      e.preventDefault();
                      if (!dragId) return;
                      const payload = { startAt: localToIso(day, toHm(m)) };
                      if (byMechanic) payload.mechanicId = col.id; else payload.bayId = col.id;
                      onMove(dragId, payload);
                      setDragId(null);
                    }}
                    className={cx('block w-full border-b border-line/60 focus-ring', m % 60 === 0 ? 'border-line' : 'border-dashed', inBreak && 'bg-white/[0.03]', staff && 'hover:bg-brand/10')}
                    style={{ height: ROW }} />
                );
              })}
              {blocks.filter((bl) => blockInCol(bl, col) && isoDay(bl.startAt) <= day && isoDay(bl.endAt) >= day).map((bl) => {
                const s = isoDay(bl.startAt) < day ? start : Math.max(start, toMin(fmtTime(bl.startAt)));
                const e = isoDay(bl.endAt) > day ? end : Math.min(end, toMin(fmtTime(bl.endAt)));
                if (e <= s) return null;
                return (
                  <div key={`bl${bl.id}`} className="absolute inset-x-1 rounded-lg border border-line text-[11px] text-muted p-1.5 pointer-events-none"
                    style={{ top: ((s - start) / slot) * ROW, height: ((e - s) / slot) * ROW - 2, backgroundImage: 'repeating-linear-gradient(135deg, rgba(127,127,127,.18) 0 6px, transparent 6px 12px)' }}>
                    <Ban className="inline h-3 w-3 mr-1" />{bl.reason}
                  </div>
                );
              })}
              {visible.filter((b) => inCol(b, col)).map((b) => {
                const draggable = staff && ['PENDING', 'CONFIRMED'].includes(b.status);
                const height = Math.max(ROW - 4, ((new Date(b.endAt) - new Date(b.startAt)) / 60000 / slot) * ROW - 4);
                return (
                  <button key={b.id} type="button" draggable={draggable}
                    onDragStart={(e) => { setDragId(b.id); e.dataTransfer.effectAllowed = 'move'; }}
                    onDragEnd={() => setDragId(null)}
                    onClick={() => onOpen(b.id)}
                    className={cx('absolute inset-x-1 rounded-lg border text-left px-2 py-1 overflow-hidden focus-ring shadow-lg flex flex-col justify-start items-stretch', STATUS_STYLE[b.status], draggable && 'cursor-grab active:cursor-grabbing')}
                    style={{ top: top(b.startAt) + 2, height }}>
                    {height < 60 ? (
                      <>
                        <p className="text-sm font-semibold truncate leading-tight"><span className="text-steel font-normal text-xs">{fmtTime(b.startAt)}</span> {b.customerName}</p>
                        <p className="text-xs text-steel truncate">{b.model} · {plateMask(b.plate)}{b.noShowCount >= settings.noShowFlagThreshold ? ` · ${b.noShowCount} faltas` : ''}</p>
                      </>
                    ) : (
                      <>
                        <p className="text-[11px] font-semibold text-steel">{fmtTime(b.startAt)}–{fmtTime(b.endAt)}{b.noShowCount >= settings.noShowFlagThreshold && <span className="text-bad"> · {b.noShowCount} faltas</span>}</p>
                        <p className="text-sm font-semibold truncate leading-tight">{b.customerName}</p>
                        <p className="text-xs text-steel truncate">{b.model} · {plateMask(b.plate)}</p>
                        {height > 90 && <p className="text-xs text-muted truncate">{b.services.join(', ')}</p>}
                      </>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>
      <div className="flex flex-wrap gap-3 mt-3 text-xs text-muted">
        {['PENDING', 'CONFIRMED', 'CHECKED_IN', 'NO_SHOW'].map((s) => <span key={s} className="inline-flex items-center gap-1.5"><span className={cx('h-3 w-3 rounded border', STATUS_STYLE[s])} />{BOOKING_STATUS[s].label}</span>)}
        {staff && <span>· Arraste um agendamento para remarcar. Toque num horário vazio para agendar.</span>}
      </div>
      {cancelled.length > 0 && <p className="text-xs text-muted mt-2">{cancelled.length} cancelado(s) neste dia: {cancelled.map((b) => `${fmtTime(b.startAt)} ${b.customerName}`).join(', ')}</p>}
    </>
  );
}

function WeekView({ data, from, onOpen, onPickDay }) {
  const days = Array.from({ length: 7 }, (_, i) => addDays(from, i));
  const today = isoDay();
  return (
    <div className="grid grid-flow-col auto-cols-[minmax(11rem,1fr)] gap-2 overflow-x-auto pb-2">
      {days.map((d) => {
        const list = data.bookings.filter((b) => isoDay(b.startAt) === d && b.status !== 'CANCELLED');
        const h = data.hours.find((x) => x.weekday === weekdayOf(d));
        return (
          <div key={d} className={cx('card p-2 min-h-60', d === today && 'border-brand')}>
            <button type="button" onClick={() => onPickDay(d)} className="w-full text-left px-1.5 py-1 rounded-lg hover:bg-surface-2 focus-ring">
              <span className="text-xs uppercase font-semibold text-muted">{WEEKDAYS_SHORT[weekdayOf(d)]}</span>
              <span className="font-display text-2xl font-bold ml-2">{d.slice(8)}/{d.slice(5, 7)}</span>
              <span className="block text-[11px] text-muted">{h?.closed ? 'Fechado' : `${list.length} agendamento(s)`}</span>
            </button>
            <ul className="grid gap-1.5 mt-2">
              {list.map((b) => (
                <li key={b.id}>
                  <button type="button" onClick={() => onOpen(b.id)} className={cx('w-full text-left rounded-lg border px-2 py-1.5 focus-ring', STATUS_STYLE[b.status])}>
                    <p className="text-xs font-semibold">{fmtTime(b.startAt)} · {data.bays.find((x) => x.id === b.bayId)?.name}</p>
                    <p className="text-sm font-semibold truncate">{b.customerName}</p>
                    <p className="text-xs text-steel truncate">{b.model} · {plateMask(b.plate)}</p>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        );
      })}
    </div>
  );
}

function BookingModal({ id, onClose, onChanged, staff, data }) {
  const toast = useToast();
  const nav = useNavigate();
  const q = useQuery({ queryKey: ['booking', id], queryFn: () => api.get(`/admin/bookings/${id}`) });
  const [mode, setMode] = useState(null); // 'checkin' | 'reschedule' | 'cancel'
  const [busy, setBusy] = useState(false);
  const b = q.data?.booking;

  async function act(fn, msg) {
    setBusy(true);
    try { await fn(); if (msg) toast(msg); onChanged(); q.refetch(); setMode(null); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }

  const active = b && ['PENDING', 'CONFIRMED'].includes(b.status);
  return (
    <Modal open onClose={onClose} title={b ? `Agendamento ${b.code}` : 'Agendamento'} wide>
      {q.isLoading && <Spinner />}
      {q.error && <ErrorBox error={q.error} />}
      {b && !mode && (
        <div className="grid gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={BOOKING_STATUS[b.status].tone}>{BOOKING_STATUS[b.status].label}</Badge>
            {b.order && <Badge tone={ORDER_STATUS[b.order.status].tone}>OS {b.order.number}: {ORDER_STATUS[b.order.status].label}</Badge>}
            <Badge>{SOURCE_LABEL[b.source]}</Badge>
            <Badge>{b.dropOff ? 'Deixa a moto' : 'Espera no local'}</Badge>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <Card className="!p-3">
              <p className="text-xs uppercase font-semibold text-muted">Quando</p>
              <p className="font-semibold">{fmtLong(b.startAt)}</p>
              <p className="text-steel">{fmtTime(b.startAt)} às {fmtTime(b.endAt)} · {b.bay?.name}</p>
              <p className="text-sm text-muted">Mecânico: {b.mechanic?.name || 'não definido'}</p>
            </Card>
            <Card className="!p-3">
              <p className="text-xs uppercase font-semibold text-muted">Cliente</p>
              <button type="button" className="font-semibold hover:text-brand-light text-left" onClick={() => nav(`/admin/clientes/${b.customer.id}`)}>{b.customer.name}</button>
              <p className="text-steel">{fmtPhone(b.customer.phone)}{b.customer.noShowCount > 0 && <span className="text-bad text-sm"> · {b.customer.noShowCount} falta(s)</span>}</p>
              <p className="text-sm text-muted">{b.motorcycle.brand} {b.motorcycle.model}{b.motorcycle.year ? ` ${b.motorcycle.year}` : ''} · {plateMask(b.motorcycle.plate)}</p>
            </Card>
          </div>
          <div>
            <p className="text-xs uppercase font-semibold text-muted mb-1">Serviços</p>
            <ul className="text-sm">{b.services.map((s) => <li key={s.id}>{s.nameSnapshot} <span className="text-muted">({duration(s.durationSnapshot)})</span></li>)}</ul>
          </div>
          <PendingBox history={b.bikeHistory} motorcycleId={b.motorcycle.id} compact />
          {b.problemDescription && <div><p className="text-xs uppercase font-semibold text-muted mb-1">Relato do cliente</p><p className="text-sm whitespace-pre-line">{b.problemDescription}</p></div>}
          {b.notes && <div><p className="text-xs uppercase font-semibold text-muted mb-1">Observações internas</p><p className="text-sm whitespace-pre-line">{b.notes}</p></div>}
          {b.photos.length > 0 && (
            <div className="flex gap-2 flex-wrap">{b.photos.map((p) => <a key={p.id} href={p.url} target="_blank" rel="noopener noreferrer"><img src={p.url} alt="Foto enviada pelo cliente" className="h-20 w-20 object-cover rounded-xl border border-line" /></a>)}</div>
          )}

          <div className="flex flex-wrap gap-2 pt-2 border-t border-line">
            <a className="glass-btn inline-flex items-center gap-1.5 min-h-10 px-3 rounded-[10px] text-sm font-semibold" href={`tel:+${b.customer.phone}`}><Phone className="h-4 w-4" />Ligar</a>
            <a className="glass-btn inline-flex items-center gap-1.5 min-h-10 px-3 rounded-[10px] text-sm font-semibold" href={waUrl(b.customer.phone)} target="_blank" rel="noopener noreferrer"><MessageCircle className="h-4 w-4" />WhatsApp</a>
            {staff && active && <Button size="sm" icon={Check} onClick={() => sendWhatsApp({ template: 'confirmation', bookingId: b.id }, toast)}>Enviar confirmação</Button>}
            {staff && active && <Button size="sm" icon={Bell} onClick={() => sendWhatsApp({ template: 'reminder24h', bookingId: b.id }, toast)}>Enviar lembrete</Button>}
          </div>
          <div className="flex flex-wrap gap-2">
            {b.order && <Button variant="primary" icon={ClipboardList} onClick={() => nav(`/admin/os/${b.order.id}`)}>Abrir OS {b.order.number}</Button>}
            {active && <Button variant="primary" icon={ClipboardList} onClick={() => setMode('checkin')}>Moto chegou (check-in)</Button>}
          </div>
          {staff && (
            <div className="flex flex-wrap gap-2">
              {b.status === 'PENDING' && <Button icon={Check} loading={busy} onClick={() => act(() => api.patch(`/admin/bookings/${b.id}`, { status: 'CONFIRMED' }), 'Confirmado.')}>Confirmar</Button>}
              {active && <Button icon={CalendarClock} onClick={() => setMode('reschedule')}>Remarcar / trocar mecânico</Button>}
              {active && <Button icon={UserX} loading={busy} onClick={() => act(() => api.patch(`/admin/bookings/${b.id}`, { status: 'NO_SHOW' }), 'Marcado como falta.')}>Não veio</Button>}
              {b.status === 'NO_SHOW' && <Button loading={busy} onClick={() => act(() => api.patch(`/admin/bookings/${b.id}`, { status: 'CONFIRMED' }), 'Falta desfeita.')}>Desfazer falta</Button>}
              {active && <Button variant="danger" icon={X} onClick={() => setMode('cancel')}>Cancelar</Button>}
            </div>
          )}
        </div>
      )}
      {b && mode === 'checkin' && <CheckinForm booking={b} onBack={() => setMode(null)} onDone={(orderId) => { onChanged(); nav(`/admin/os/${orderId}`); }} />}
      {b && mode === 'reschedule' && <RescheduleForm booking={b} data={data} onBack={() => setMode(null)} onSave={(payload) => act(() => api.patch(`/admin/bookings/${b.id}`, payload), 'Agendamento atualizado.')} busy={busy} />}
      <ConfirmModal open={mode === 'cancel'} onClose={() => setMode(null)} title="Cancelar agendamento?" danger confirmLabel="Cancelar agendamento" loading={busy}
        message="O horário fica livre. Avise o cliente pelo WhatsApp." onConfirm={() => act(() => api.post(`/admin/bookings/${b.id}/cancel`), 'Agendamento cancelado.')} />
    </Modal>
  );
}

export function CheckinForm({ booking, onBack, onDone }) {
  const toast = useToast();
  const [km, setKm] = useState(booking.motorcycle.lastMileage || '');
  const [fuel, setFuel] = useState('');
  const [items, setItems] = useState([]);
  const [damage, setDamage] = useState('');
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      const r = await api.post(`/admin/bookings/${booking.id}/checkin`, {
        checkInMileage: km ? Number(String(km).replace(/\D/g, '')) : null,
        fuelLevel: fuel || null,
        checklist: { items, damage: damage.trim() || undefined },
      });
      toast(`OS ${r.orderId ? 'aberta' : ''} com sucesso.`);
      onDone(r.orderId);
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <div className="grid gap-4">
      <p className="text-sm text-muted">Registre como a moto chegou. Você pode adicionar fotos na OS em seguida.</p>
      <div className="grid sm:grid-cols-2 gap-3">
        <Input label="KM na entrada" inputMode="numeric" value={km} onChange={(e) => setKm(e.target.value.replace(/\D/g, '').slice(0, 7))} />
        <Select label="Combustível" value={fuel} onChange={(e) => setFuel(e.target.value)}>
          <option value="">Não informado</option>{Object.entries(FUEL_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      </div>
      <div>
        <p className="text-sm font-medium text-steel mb-2">Itens deixados com a moto</p>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(CHECK_ITEMS).map(([k, v]) => <Checkbox key={k} label={v} checked={items.includes(k)} onChange={(on) => setItems((x) => (on ? [...x, k] : x.filter((i) => i !== k)))} />)}
        </div>
      </div>
      <Textarea label="Avarias visíveis" placeholder="Ex.: risco no tanque lado direito, retrovisor quebrado" value={damage} onChange={(e) => setDamage(e.target.value)} maxLength={500} />
      <div className="flex justify-end gap-2"><Button onClick={onBack}>Voltar</Button><Button variant="primary" loading={busy} onClick={save} icon={ClipboardList}>Abrir OS</Button></div>
    </div>
  );
}

function RescheduleForm({ booking, data, onBack, onSave, busy }) {
  const [date, setDate] = useState(isoDay(booking.startAt));
  const [time, setTime] = useState(fmtTime(booking.startAt));
  const [bayId, setBayId] = useState(booking.bayId);
  const [mechanicId, setMechanicId] = useState(booking.mechanicId || '');
  const minutes = Math.round((new Date(booking.endAt) - new Date(booking.startAt)) / 60000);
  const slots = useQuery({ queryKey: ['staff-slots', date, minutes, booking.id], queryFn: () => api.get(`/admin/staff-slots?date=${date}&duration=${minutes}&excludeId=${booking.id}`) });
  return (
    <div className="grid gap-4">
      <div className="grid sm:grid-cols-3 gap-3">
        <Input label="Data" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <Input label="Horário" type="time" step={300} value={time} onChange={(e) => setTime(e.target.value)} />
        <Select label="Elevador" value={bayId} onChange={(e) => setBayId(Number(e.target.value))}>
          {data?.bays.filter((x) => x.active).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
        </Select>
      </div>
      {slots.data && (
        <div>
          <p className="text-sm text-muted mb-2">Horários livres em {fmtDate(dayToDate(date))} ({duration(minutes)}):</p>
          <div className="flex flex-wrap gap-1.5">
            {slots.data.slots.map((s) => (
              <button key={s.startAt} type="button" onClick={() => { setTime(s.time); if (!s.bayIds.includes(bayId)) setBayId(s.bayIds[0]); }}
                className={cx('min-h-9 px-2.5 rounded-lg text-sm font-semibold border focus-ring', time === s.time ? 'glass-btn glass-btn-primary' : 'card')}>{s.time}</button>
            ))}
            {!slots.data.slots.length && <span className="text-sm text-muted">Nenhum horário livre nesse dia.</span>}
          </div>
        </div>
      )}
      <Select label="Mecânico" value={mechanicId} onChange={(e) => setMechanicId(e.target.value)}>
        <option value="">Não definido</option>{data?.mechanics.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
      </Select>
      <div className="flex justify-end gap-2">
        <Button onClick={onBack}>Voltar</Button>
        <Button variant="primary" loading={busy} onClick={() => {
          const payload = { mechanicId: mechanicId ? Number(mechanicId) : null };
          if (date !== isoDay(booking.startAt) || time !== fmtTime(booking.startAt) || bayId !== booking.bayId) Object.assign(payload, { startAt: localToIso(date, time), bayId });
          onSave(payload);
        }}>Salvar</Button>
      </div>
    </div>
  );
}

function NewBookingModal({ initial, data, onClose, onSaved }) {
  const toast = useToast();
  const services = useQuery({ queryKey: ['services'], queryFn: () => api.get('/admin/services') });
  const [pick, setPick] = useState(emptyPick());
  const [serviceIds, setServiceIds] = useState([]);
  const [date, setDate] = useState(initial.day);
  const [time, setTime] = useState(initial.time || '');
  const [bayId, setBayId] = useState(initial.bayId || '');
  const [mechanicId, setMechanicId] = useState(initial.mechanicId || '');
  const [source, setSource] = useState('walk_in');
  const [notes, setNotes] = useState('');
  const [problem, setProblem] = useState('');
  const [consent, setConsent] = useState(false);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const active = (services.data?.services || []).filter((s) => s.active);
  const ids = serviceIds.join(',');
  const minutes = useMemo(() => {
    const sum = active.filter((s) => serviceIds.includes(s.id)).reduce((a, s) => a + s.durationMinutes, 0);
    const slot = data?.settings.slotMinutes || 30;
    return sum ? Math.ceil(sum / slot) * slot : 0;
  }, [active, serviceIds, data]);
  const slots = useQuery({ queryKey: ['staff-slots', date, ids], queryFn: () => api.get(`/admin/staff-slots?date=${date}&services=${ids}`), enabled: serviceIds.length > 0 && Boolean(date) });

  async function save() {
    const e = validatePick(pick);
    if (!serviceIds.length) e.services = 'Escolha pelo menos um serviço.';
    if (!time) e.time = 'Escolha o horário.';
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      await api.post('/admin/bookings', {
        serviceIds,
        startAt: localToIso(date, time),
        source,
        bayId: bayId ? Number(bayId) : undefined,
        mechanicId: mechanicId ? Number(mechanicId) : null,
        notes: notes.trim() || undefined,
        problemDescription: problem.trim() || undefined,
        reminderConsent: consent,
        customer: { name: pick.customer.name.trim(), phone: pick.customer.phone, email: pick.customer.email || '' },
        motorcycle: { brand: pick.motorcycle.brand, model: pick.motorcycle.model, plate: pick.motorcycle.plate, year: pick.motorcycle.year ? Number(pick.motorcycle.year) : null },
      });
      toast('Agendamento criado.');
      onSaved();
    } catch (err) { toast(err.message, 'bad'); } finally { setBusy(false); }
  }

  return (
    <Modal open onClose={onClose} title="Novo agendamento" wide footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save} icon={Check}>Agendar</Button></>}>
      <div className="grid gap-5">
        <section>
          <h3 className="font-semibold mb-2">Cliente e moto</h3>
          <CustomerBikePicker value={pick} onChange={setPick} errors={errors} />
        </section>
        <section>
          <h3 className="font-semibold mb-2">Serviços {minutes > 0 && <span className="text-muted font-normal text-sm">· {duration(minutes)}</span>}</h3>
          {errors.services && <p className="text-bad text-sm mb-2">{errors.services}</p>}
          <div className="flex flex-wrap gap-1.5">
            {active.map((s) => {
              const on = serviceIds.includes(s.id);
              return <button key={s.id} type="button" aria-pressed={on} onClick={() => setServiceIds((x) => (on ? x.filter((i) => i !== s.id) : [...x, s.id]))}
                className={cx('min-h-9 px-3 rounded-lg text-sm font-semibold border focus-ring', on ? 'glass-btn glass-btn-primary' : 'card')}>{s.name}</button>;
            })}
          </div>
        </section>
        <section className="grid sm:grid-cols-4 gap-3">
          <Input label="Data" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          <Input label="Horário" type="time" step={300} value={time} error={errors.time} onChange={(e) => setTime(e.target.value)} />
          <Select label="Elevador" value={bayId} onChange={(e) => setBayId(e.target.value)}>
            <option value="">Automático</option>{data?.bays.filter((x) => x.active).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </Select>
          <Select label="Mecânico" value={mechanicId} onChange={(e) => setMechanicId(e.target.value)}>
            <option value="">Não definido</option>{data?.mechanics.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </Select>
        </section>
        {slots.data && (
          <div className="flex flex-wrap gap-1.5 -mt-2">
            <span className="text-sm text-muted w-full">Livres neste dia:</span>
            {slots.data.slots.map((s) => <button key={s.startAt} type="button" onClick={() => { setTime(s.time); if (bayId && !s.bayIds.includes(Number(bayId))) setBayId(''); }}
              className={cx('min-h-9 px-2.5 rounded-lg text-sm font-semibold border focus-ring', time === s.time ? 'glass-btn glass-btn-primary' : 'card')}>{s.time}</button>)}
            {!slots.data.slots.length && <span className="text-sm text-muted">Nenhum horário livre no expediente. Você ainda pode digitar um horário.</span>}
          </div>
        )}
        <section className="grid sm:grid-cols-2 gap-3">
          <Select label="Como o cliente chegou" value={source} onChange={(e) => setSource(e.target.value)}>
            {Object.entries(SOURCE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </Select>
          <Input label="Relato do cliente" value={problem} onChange={(e) => setProblem(e.target.value)} placeholder="Opcional" />
          <Textarea className="sm:col-span-2" label="Observações internas" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Só a equipe vê." />
          <Checkbox className="sm:col-span-2" label="O cliente autorizou receber lembretes de revisão pelo WhatsApp" checked={consent} onChange={setConsent} />
        </section>
      </div>
    </Modal>
  );
}

function BlockModal({ day, data, onClose, onSaved }) {
  const toast = useToast();
  const [form, setForm] = useState({ startDay: day, startTime: '12:00', endDay: day, endTime: '13:00', reason: '', target: 'all' });
  const [busy, setBusy] = useState(false);
  const blocks = data?.blocks || [];
  const set = (p) => setForm({ ...form, ...p });
  async function save() {
    setBusy(true);
    try {
      const [kind, id] = form.target.split(':');
      await api.post('/admin/blocks', {
        startAt: localToIso(form.startDay, form.startTime),
        endAt: localToIso(form.endDay, form.endTime),
        reason: form.reason.trim(),
        bayId: kind === 'bay' ? Number(id) : null,
        userId: kind === 'user' ? Number(id) : null,
      });
      toast('Horário bloqueado.');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  async function remove(id) {
    try { await api.del(`/admin/blocks/${id}`); toast('Bloqueio removido.'); onSaved(); } catch (e) { toast(e.message, 'bad'); }
  }
  return (
    <Modal open onClose={onClose} title="Bloquear horário" footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save} icon={Ban}>Bloquear</Button></>}>
      <div className="grid gap-3">
        <p className="text-sm text-muted">Use para feriado, folga, manutenção do elevador ou férias. Ninguém consegue agendar nesse período.</p>
        <Input label="Motivo" placeholder="Ex.: Feriado, manutenção do elevador" value={form.reason} onChange={(e) => set({ reason: e.target.value })} />
        <div className="grid grid-cols-2 gap-3">
          <Input label="Início" type="date" value={form.startDay} onChange={(e) => set({ startDay: e.target.value })} />
          <Input label="Hora" type="time" value={form.startTime} onChange={(e) => set({ startTime: e.target.value })} />
          <Input label="Fim" type="date" value={form.endDay} onChange={(e) => set({ endDay: e.target.value })} />
          <Input label="Hora" type="time" value={form.endTime} onChange={(e) => set({ endTime: e.target.value })} />
        </div>
        <Select label="Bloquear" value={form.target} onChange={(e) => set({ target: e.target.value })}>
          <option value="all">A oficina inteira</option>
          {data?.bays.map((b) => <option key={b.id} value={`bay:${b.id}`}>Só o {b.name}</option>)}
          {data?.mechanics.map((m) => <option key={m.id} value={`user:${m.id}`}>Folga de {m.name}</option>)}
        </Select>
        {blocks.length > 0 && (
          <div className="mt-2">
            <p className="text-sm font-semibold mb-1">Bloqueios neste período</p>
            <ul className="divide-y divide-line text-sm">
              {blocks.map((bl) => (
                <li key={bl.id} className="flex items-center justify-between gap-2 py-2">
                  <span>{bl.reason} <span className="text-muted">· {fmtDate(bl.startAt)} {fmtTime(bl.startAt)} a {fmtDate(bl.endAt)} {fmtTime(bl.endAt)}</span></span>
                  <Button size="sm" variant="ghost" aria-label="Remover bloqueio" onClick={() => remove(bl.id)}><Trash2 className="h-4 w-4" /></Button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </Modal>
  );
}
