import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Search, Users, Combine } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Spinner, ErrorBox, Empty, Badge, Button } from '../../components/ui.jsx';
import { fmtPhone, plateMask, fmtDate } from '../../lib/format.js';
import { PageHeader, useAuth, isBusiness } from './shared.jsx';

export default function Customers() {
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const query = useQuery({ queryKey: ['customers', q, page], queryFn: () => api.get(`/admin/customers?q=${encodeURIComponent(q)}&page=${page}`) });
  const pages = query.data ? Math.max(1, Math.ceil(query.data.total / 30)) : 1;
  const { user } = useAuth();
  const dups = useQuery({ queryKey: ['customers', 'duplicates'], queryFn: () => api.get('/admin/customers/duplicates'), enabled: isBusiness(user), staleTime: 60_000 });
  const pairs = dups.data?.pairs || [];
  return (
    <div>
      <PageHeader title="Clientes e motos" sub={query.data ? `${query.data.total} cliente(s)` : ''} />
      {pairs.length > 0 && (
        <div className="mb-4 rounded-xl border border-warn/50 bg-warn/10 px-4 py-3 text-sm">
          <p className="font-semibold text-warn flex items-center gap-1.5"><Combine className="h-4 w-4" />{pairs.length === 1 ? '1 cadastro parece repetido' : `${pairs.length} cadastros parecem repetidos`}</p>
          <p className="text-steel mb-2">Mesmo nome ou mesmo e-mail com WhatsApp diferente. Se for a mesma pessoa, abra o cadastro certo e use "Juntar cadastro repetido".</p>
          <ul className="grid gap-1">
            {pairs.slice(0, 5).map((p) => (
              <li key={`${p.aId}-${p.bId}`} className="flex flex-wrap gap-x-2">
                <Link to={`/admin/clientes/${p.aId}`} className="font-semibold hover:text-brand-light">{p.aName} · {fmtPhone(p.aPhone)}</Link>
                <span className="text-muted">e</span>
                <Link to={`/admin/clientes/${p.bId}`} className="font-semibold hover:text-brand-light">{p.bName} · {fmtPhone(p.bPhone)}</Link>
                {p.reason === 'email' && <span className="text-muted">(mesmo e-mail)</span>}
              </li>
            ))}
          </ul>
        </div>
      )}
      <div className="relative mb-4">
        <Search className="h-4 w-4 absolute left-3 top-4 text-muted" aria-hidden />
        <input className="input pl-9" placeholder="Buscar por nome, telefone ou placa" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} aria-label="Buscar cliente" />
      </div>
      {query.isLoading && <Spinner />}
      {query.error && <ErrorBox error={query.error} onRetry={query.refetch} />}
      {query.data && (query.data.customers.length === 0 ? <Empty icon={Users} title="Nenhum cliente encontrado">Os clientes entram aqui sozinhos quando agendam pelo site.</Empty> : (
        <div className="card divide-y divide-line">
          {query.data.customers.map((c) => (
            <Link key={c.id} to={`/admin/clientes/${c.id}`} className="flex items-center gap-3 px-4 py-3 hover:bg-surface-2 focus-ring">
              <div className="h-10 w-10 rounded-full bg-brand/20 text-brand-light flex items-center justify-center font-display text-lg font-bold shrink-0">{c.name.charAt(0).toUpperCase()}</div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold truncate">{c.name}</p>
                <p className="text-sm text-muted truncate">{fmtPhone(c.phone)} · {c.motorcycles.map((m) => `${m.model} ${plateMask(m.plate)}`).join(', ') || 'sem moto'}</p>
              </div>
              <div className="hidden sm:flex flex-col items-end gap-1 text-xs text-muted">
                {c.lastServiceAt && <span>Último serviço {fmtDate(c.lastServiceAt)}</span>}
                {c.noShowCount > 0 && <Badge tone="bad">{c.noShowCount} falta(s)</Badge>}
              </div>
            </Link>
          ))}
        </div>
      ))}
      {pages > 1 && (
        <div className="flex justify-center gap-2 mt-4">
          <Button size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>Anterior</Button>
          <span className="text-sm text-muted self-center">{page} de {pages}</span>
          <Button size="sm" disabled={page >= pages} onClick={() => setPage(page + 1)}>Próxima</Button>
        </div>
      )}
    </div>
  );
}
