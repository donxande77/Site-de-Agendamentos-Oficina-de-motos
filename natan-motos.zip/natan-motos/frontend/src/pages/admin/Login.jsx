import { useState } from 'react';
import { Link } from 'react-router-dom';
import { DEMO } from '../../lib/demo.js';
import { Lock } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Button, Input, Logo } from '../../components/ui.jsx';
import { useAuth } from './shared.jsx';

export default function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState(DEMO ? 'natan@demo.com' : '');
  const [password, setPassword] = useState(DEMO ? 'demo1234' : '');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      login(await api.post('/auth/login', { email, password }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-dvh backdrop-garage flex items-center justify-center p-4">
      <form onSubmit={submit} className="card w-full max-w-sm p-6 grid gap-4 animate-rise" noValidate>
        <div className="flex flex-col items-center gap-3 mb-2">
          <Logo className="h-24 w-24" />
          <h1 className="font-display text-3xl font-bold uppercase">Área da oficina</h1>
        </div>
        <Input label="E-mail" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <Input label="Senha" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        {error && <p className="text-bad text-sm" role="alert">{error}</p>}
        <Button type="submit" variant="primary" size="lg" loading={busy} icon={Lock}>Entrar</Button>
        {DEMO && <p className="text-xs text-muted text-center -mt-1">Demonstração: login do Natan (dono da oficina) já preenchido. Outros acessos, senha demo1234: admin@demo.com (administrador do sistema) e ze@demo.com (mecânico).</p>}
        <Link to="/" className="text-center text-sm text-muted hover:text-fg">Voltar ao site</Link>
      </form>
    </div>
  );
}
