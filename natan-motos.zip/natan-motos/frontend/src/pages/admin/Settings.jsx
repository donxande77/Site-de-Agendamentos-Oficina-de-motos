import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Copy, QrCode, Save, Plus, Pencil, KeyRound, ShieldCheck, ShieldAlert, CloudUpload, HardDrive } from 'lucide-react';
import { api, openFile, setAccessToken } from '../../lib/api.js';
import { Button, Card, Spinner, ErrorBox, Badge, Modal, Input, Select, Textarea, Checkbox, Segmented, useToast } from '../../components/ui.jsx';
import { WEEKDAYS, phoneMask, ROLE_LABEL, fmtDateTime } from '../../lib/format.js';
import { PageHeader, useAuth, isOwner } from './shared.jsx';

const TEMPLATE_INFO = {
  greeting: ['Saudação automática', 'Resposta para quem manda mensagem. Cole em WhatsApp Business › Ferramentas comerciais › Mensagem de saudação.'],
  away: ['Mensagem de ausência', 'Fora do horário. Cole em WhatsApp Business › Mensagem de ausência.'],
  confirmation: ['Confirmação do agendamento', ''],
  reminder24h: ['Lembrete 24 h antes', ''],
  quoteReady: ['Orçamento pronto', ''],
  bikeReady: ['Moto pronta', ''],
  maintenance: ['Lembrete de revisão', 'Só para clientes que autorizaram.'],
};
const VARS = '{nome} {moto} {data} {hora} {codigo} {servicos} {valor} {link} {oficina} {endereco} {tipo}';

export default function SettingsPage() {
  const { user } = useAuth();
  const owner = isOwner(user);
  const [params] = useSearchParams();
  const [tab, setTab] = useState(owner && params.get('aba') === 'backup' ? 'backup' : owner ? 'shop' : 'whatsapp');
  const q = useQuery({ queryKey: ['settings'], queryFn: () => api.get('/admin/settings') });
  const tabs = owner
    ? [['shop', 'Oficina'], ['hours', 'Horários'], ['booking', 'Agendamento'], ['whatsapp', 'WhatsApp'], ['users', 'Equipe'], ['backup', 'Backup'], ['password', 'Minha senha']]
    : [['whatsapp', 'WhatsApp'], ['password', 'Minha senha']];
  return (
    <div>
      <PageHeader title="Configurações" sub={owner ? 'Tudo aqui pode ser ajustado conforme a realidade da oficina.' : 'Links de agendamento e sua senha.'} />
      <div className="-mx-4 px-4 overflow-x-auto no-scrollbar mb-4">
        <Segmented value={tab} onChange={setTab} options={tabs.map(([value, label]) => ({ value, label }))} />
      </div>
      {q.isLoading && <Spinner />}
      {q.error && <ErrorBox error={q.error} onRetry={q.refetch} />}
      {q.data && (
        <>
          {tab === 'shop' && <ShopTab data={q.data} />}
          {tab === 'hours' && <HoursTab data={q.data} />}
          {tab === 'booking' && <BookingTab data={q.data} />}
          {tab === 'whatsapp' && <WhatsAppTab data={q.data} owner={owner} />}
          {tab === 'users' && <UsersTab data={q.data} />}
        </>
      )}
      {tab === 'backup' && <BackupTab />}
      {tab === 'password' && <PasswordTab />}
    </div>
  );
}

function useSave() {
  const toast = useToast();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const save = async (fn, msg = 'Salvo.') => {
    setBusy(true);
    try { await fn(); toast(msg); qc.invalidateQueries({ queryKey: ['settings'] }); qc.invalidateQueries({ queryKey: ['public-info'] }); qc.invalidateQueries({ queryKey: ['agenda'] }); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  };
  return [save, busy];
}

const RUN_LABEL = { db: 'Banco de dados', full: 'Banco + fotos', verify: 'Teste de restauração', restore: 'Restauração' };
const size = (b) => (b == null ? '' : b < 1024 * 1024 ? `${Math.max(1, Math.round(b / 1024))} KB` : `${(b / 1024 / 1024).toFixed(1).replace('.', ',')} MB`);

function BackupTab() {
  const q = useQuery({ queryKey: ['backups'], queryFn: () => api.get('/admin/system/backups'), refetchInterval: 120_000 });
  if (q.isLoading) return <Spinner />;
  if (q.error) return <ErrorBox error={q.error} onRetry={q.refetch} />;
  const b = q.data;
  if (!b.configured) {
    return (
      <Card className="max-w-3xl grid gap-2">
        <div className="flex items-center gap-2"><HardDrive className="h-5 w-5 text-muted" aria-hidden /><h2 className="font-display text-2xl font-bold uppercase">Backup ainda não ligado</h2></div>
        <p className="text-sm text-steel">Quando o site estiver no servidor com o backup automático, esta tela mostra cada cópia feita: o banco a cada 6 horas, as fotos todo dia e o teste semanal que confirma que a cópia funciona.</p>
        <p className="text-sm text-muted">Quem instala o site liga o backup seguindo o guia <b>docs/BACKUP-E-SEGURANCA.md</b>.</p>
      </Card>
    );
  }
  const rows = [['db', 'Banco de dados', 'a cada 6 horas'], ['full', 'Banco + fotos', 'todo dia de madrugada'], ['verify', 'Teste de restauração', 'todo domingo']];
  return (
    <div className="grid gap-4 max-w-3xl">
      <Card className={b.healthy ? 'border-ok/40' : 'border-warn/50'}>
        <div className="flex items-start gap-3">
          {b.healthy ? <ShieldCheck className="h-7 w-7 text-ok shrink-0" aria-hidden /> : <ShieldAlert className="h-7 w-7 text-warn shrink-0" aria-hidden />}
          <div className="min-w-0">
            <h2 className="font-display text-2xl font-bold uppercase">{b.healthy ? 'Backup em dia' : 'Backup precisa de atenção'}</h2>
            {b.healthy
              ? <p className="text-sm text-steel">As cópias estão sendo feitas, guardadas criptografadas no Google Drive e testadas toda semana.</p>
              : <ul className="text-sm text-steel list-disc pl-5 mt-1 grid gap-1">{b.problems.map((p) => <li key={p}>{p}</li>)}</ul>}
          </div>
        </div>
        <div className="grid sm:grid-cols-3 gap-2 mt-4">
          {rows.map(([k, label, when]) => {
            const ok = b.last[k]?.ok;
            return (
              <div key={k} className="rounded-xl border border-line bg-surface-2 p-3 min-w-0">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted">{label}</p>
                <p className="font-semibold mt-0.5">{ok ? fmtDateTime(ok.finishedAt) : 'ainda não rodou'}</p>
                <p className="text-xs text-muted">{when}{ok?.offsite ? ' · no Drive' : ''}</p>
              </div>
            );
          })}
        </div>
      </Card>
      <Card>
        <h3 className="font-semibold mb-2">Últimas execuções</h3>
        <ul className="divide-y divide-line">
          {b.recent.map((r) => (
            <li key={r.id} className="flex items-center gap-3 py-2 text-sm">
              <Badge tone={r.status === 'ok' ? 'ok' : 'bad'}>{r.status === 'ok' ? 'OK' : 'Falhou'}</Badge>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{RUN_LABEL[r.kind] || r.kind}</p>
                <p className="text-xs text-muted truncate">{[size(r.sizeBytes), r.message].filter(Boolean).join(' · ') || (r.offsite ? 'enviado ao Drive' : 'só no servidor')}</p>
              </div>
              {r.offsite && <CloudUpload className="h-4 w-4 text-brand-light shrink-0" aria-label="Cópia enviada ao Google Drive" />}
              <span className="text-xs text-muted whitespace-nowrap">{fmtDateTime(r.finishedAt)}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function ShopTab({ data }) {
  const s = data.settings;
  const [f, setF] = useState({ shopName: s.shopName, ownerName: s.ownerName, address: s.address, city: s.city, mapQuery: s.mapQuery, whatsappNumber: phoneMask(s.whatsappNumber), instagram: s.instagram, privacyContact: s.privacyContact, publicBaseUrl: s.publicBaseUrl });
  const [save, busy] = useSave();
  const set = (p) => setF({ ...f, ...p });
  return (
    <Card className="grid gap-3 max-w-3xl">
      <div className="grid sm:grid-cols-2 gap-3">
        <Input label="Nome da oficina" value={f.shopName} onChange={(e) => set({ shopName: e.target.value })} />
        <Input label="Nome do dono" value={f.ownerName} onChange={(e) => set({ ownerName: e.target.value })} />
        <Input className="sm:col-span-2" label="Endereço (aparece no site e nos PDFs)" value={f.address} onChange={(e) => set({ address: e.target.value })} />
        <Input label="Cidade" value={f.city} onChange={(e) => set({ city: e.target.value })} />
        <Input label="Endereço para o mapa" hint="Como você buscaria no Google Maps." value={f.mapQuery} onChange={(e) => set({ mapQuery: e.target.value })} />
        <Input label="WhatsApp da oficina" value={f.whatsappNumber} onChange={(e) => set({ whatsappNumber: phoneMask(e.target.value) })} />
        <Input label="Instagram (sem @)" value={f.instagram} onChange={(e) => set({ instagram: e.target.value.replace(/^@/, '') })} />
        <Input label="Canal para pedidos de privacidade" value={f.privacyContact} onChange={(e) => set({ privacyContact: e.target.value })} hint="Aparece no aviso de privacidade." />
        <Input label="Endereço do site" value={f.publicBaseUrl} onChange={(e) => set({ publicBaseUrl: e.target.value })} hint="Ex.: https://natanmotos.com.br — usado nos links enviados." />
      </div>
      <Button variant="primary" icon={Save} loading={busy} className="justify-self-end" onClick={() => save(() => api.patch('/admin/settings', f))}>Salvar</Button>
    </Card>
  );
}

function HoursTab({ data }) {
  const [rows, setRows] = useState(data.hours.map((h) => ({ ...h, breakStart: h.breakStart || '', breakEnd: h.breakEnd || '' })));
  const [bays, setBays] = useState(data.bays);
  const [save, busy] = useSave();
  const [bayEdit, setBayEdit] = useState(null);
  useEffect(() => setBays(data.bays), [data.bays]);
  const upd = (wd, p) => setRows(rows.map((r) => (r.weekday === wd ? { ...r, ...p } : r)));
  return (
    <div className="grid gap-4 max-w-3xl">
      <Card className="grid gap-3">
        <h2 className="font-display text-2xl font-bold uppercase">Horário de funcionamento</h2>
        <p className="text-sm text-muted -mt-2">Os clientes só conseguem agendar dentro desses horários.</p>
        <div className="grid gap-2">
          {[1, 2, 3, 4, 5, 6, 0].map((wd) => {
            const r = rows.find((x) => x.weekday === wd);
            return (
              <div key={wd} className="grid grid-cols-[6.5rem_1fr] sm:grid-cols-[7rem_auto_1fr] gap-2 items-center border-b border-line pb-2">
                <span className="font-semibold">{WEEKDAYS[wd]}</span>
                <Checkbox label="Aberto" checked={!r.closed} onChange={(v) => upd(wd, { closed: !v })} />
                {!r.closed && (
                  <div className="col-span-2 sm:col-span-1 grid grid-cols-4 gap-2">
                    <input type="time" className="input !min-h-10 !px-2" aria-label={`${WEEKDAYS[wd]} abre`} value={r.opensAt} onChange={(e) => upd(wd, { opensAt: e.target.value })} />
                    <input type="time" className="input !min-h-10 !px-2" aria-label={`${WEEKDAYS[wd]} fecha`} value={r.closesAt} onChange={(e) => upd(wd, { closesAt: e.target.value })} />
                    <input type="time" className="input !min-h-10 !px-2" aria-label={`${WEEKDAYS[wd]} início do almoço`} value={r.breakStart} onChange={(e) => upd(wd, { breakStart: e.target.value })} />
                    <input type="time" className="input !min-h-10 !px-2" aria-label={`${WEEKDAYS[wd]} fim do almoço`} value={r.breakEnd} onChange={(e) => upd(wd, { breakEnd: e.target.value })} />
                  </div>
                )}
              </div>
            );
          })}
          <p className="text-xs text-muted">Colunas: abre · fecha · início do almoço · fim do almoço (deixe o almoço vazio se não tiver pausa).</p>
        </div>
        <Button variant="primary" icon={Save} loading={busy} className="justify-self-end"
          onClick={() => save(() => api.put('/admin/settings/hours', { hours: rows.map((r) => ({ weekday: r.weekday, closed: r.closed, opensAt: r.opensAt, closesAt: r.closesAt, breakStart: r.breakStart || null, breakEnd: r.breakEnd || null })) }), 'Horários salvos.')}>Salvar horários</Button>
      </Card>
      <Card className="grid gap-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-bold uppercase">Elevadores</h2>
          <Button size="sm" icon={Plus} onClick={() => setBayEdit({ name: '' })}>Elevador</Button>
        </div>
        <p className="text-sm text-muted -mt-2">Cada elevador recebe uma moto por vez. Mais elevadores = mais horários no site.</p>
        <ul className="divide-y divide-line">
          {bays.map((b) => (
            <li key={b.id} className="flex items-center justify-between py-2">
              <span className="font-semibold">{b.name} {!b.active && <Badge tone="bad">Desativado</Badge>}</span>
              <span className="flex gap-1">
                <Button size="sm" variant="ghost" aria-label="Renomear" onClick={() => setBayEdit(b)}><Pencil className="h-4 w-4" /></Button>
                <Button size="sm" onClick={() => save(() => api.patch(`/admin/bays/${b.id}`, { active: !b.active }))}>{b.active ? 'Desativar' : 'Ativar'}</Button>
              </span>
            </li>
          ))}
        </ul>
      </Card>
      {bayEdit && (
        <BayModal bay={bayEdit} onClose={() => setBayEdit(null)} onSave={(name) => save(() => (bayEdit.id ? api.patch(`/admin/bays/${bayEdit.id}`, { name }) : api.post('/admin/bays', { name }))).then(() => setBayEdit(null))} busy={busy} />
      )}
    </div>
  );
}

function BayModal({ bay, onClose, onSave, busy }) {
  const [name, setName] = useState(bay.name || '');
  return (
    <Modal open onClose={onClose} title={bay.id ? 'Renomear elevador' : 'Novo elevador'} footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={() => onSave(name.trim())}>Salvar</Button></>}>
      <Input label="Nome" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Elevador 3" />
    </Modal>
  );
}

function BookingTab({ data }) {
  const s = data.settings;
  const [f, setF] = useState({
    slotMinutes: s.slotMinutes, minNoticeHours: s.minNoticeHours, maxDaysAhead: s.maxDaysAhead, cancelNoticeHours: s.cancelNoticeHours, noShowAfterMinutes: s.noShowAfterMinutes,
    noShowFlagThreshold: s.noShowFlagThreshold, forceDropOffMinutes: s.forceDropOffMinutes, autoConfirm: s.autoConfirm, defaultWarrantyDays: s.defaultWarrantyDays,
    oilReminderKm: s.oilReminderKm, oilReminderDays: s.oilReminderDays, scheduleView: s.scheduleView,
    sellsParts: s.sellsParts, partsNotice: s.partsNotice || '',
  });
  const [save, busy] = useSave();
  const num = (k) => ({ value: f[k], inputMode: 'numeric', onChange: (e) => setF({ ...f, [k]: e.target.value.replace(/\D/g, '') }) });
  return (
    <Card className="grid gap-4 max-w-3xl">
      <div className="grid sm:grid-cols-2 gap-3">
        <Select label="Intervalo entre horários" value={f.slotMinutes} onChange={(e) => setF({ ...f, slotMinutes: Number(e.target.value) })}>
          <option value={15}>15 minutos</option><option value={30}>30 minutos</option><option value={60}>1 hora</option>
        </Select>
        <Select label="Agenda do painel organizada por" value={f.scheduleView} onChange={(e) => setF({ ...f, scheduleView: e.target.value })}>
          <option value="bay">Elevador</option><option value="mechanic">Mecânico</option>
        </Select>
        <Input label="Antecedência mínima (horas)" hint="Ninguém agenda em cima da hora." {...num('minNoticeHours')} />
        <Input label="Agendar até quantos dias à frente" {...num('maxDaysAhead')} />
        <Input label="Cliente pode remarcar/cancelar até (horas antes)" {...num('cancelNoticeHours')} />
        <Input label="Marcar falta depois de (minutos de atraso)" {...num('noShowAfterMinutes')} />
        <Input label="Destacar cliente com quantas faltas" {...num('noShowFlagThreshold')} />
        <Input label="Serviços a partir de (minutos) exigem deixar a moto" {...num('forceDropOffMinutes')} />
        <Input label="Garantia padrão (dias)" {...num('defaultWarrantyDays')} />
        <Input label="Lembrete de óleo após (km)" {...num('oilReminderKm')} />
        <Input label="Lembrete de óleo após (dias)" {...num('oilReminderDays')} />
      </div>
      <Checkbox label="A oficina vende peças" description="Desmarcado: o cliente traz as peças. O site mostra o aviso abaixo e cada serviço diz o que trazer." checked={f.sellsParts} onChange={(v) => setF({ ...f, sellsParts: v })} />
      {!f.sellsParts && <Textarea label="Aviso de peças no site" value={f.partsNotice} onChange={(e) => setF({ ...f, partsNotice: e.target.value })} maxLength={400} placeholder="A oficina não vende peças. Traga as peças do serviço no dia do agendamento. Se não souber quais comprar, agende um diagnóstico e o mecânico passa a lista." />}
      <Checkbox label="Confirmar agendamentos do site automaticamente" description="Desmarcado: o agendamento entra como “aguardando confirmação” e você confirma na agenda." checked={f.autoConfirm} onChange={(v) => setF({ ...f, autoConfirm: v })} />
      <Button variant="primary" icon={Save} loading={busy} className="justify-self-end"
        onClick={() => save(() => api.patch('/admin/settings', { ...Object.fromEntries(Object.entries(f).map(([k, v]) => [k, typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : v])), partsNotice: f.partsNotice.trim() || null }))}>Salvar regras</Button>
    </Card>
  );
}

function CopyBox({ label, text, hint }) {
  const toast = useToast();
  return (
    <div className="grid gap-1.5">
      <p className="text-sm font-semibold">{label}</p>
      {hint && <p className="text-xs text-muted -mt-1">{hint}</p>}
      <div className="flex gap-2 items-start">
        <p className="input !min-h-0 text-sm whitespace-pre-wrap break-all flex-1">{text}</p>
        <Button size="icon" aria-label={`Copiar ${label}`} onClick={async () => { try { await navigator.clipboard.writeText(text); toast('Copiado.'); } catch { toast('Não deu para copiar.', 'bad'); } }}><Copy className="h-4 w-4" /></Button>
      </div>
    </div>
  );
}

function WhatsAppTab({ data, owner }) {
  const toast = useToast();
  const [texts, setTexts] = useState(data.settings.messageTexts);
  const [save, busy] = useSave();
  return (
    <div className="grid gap-4 max-w-3xl">
      <Card className="grid gap-4">
        <h2 className="font-display text-2xl font-bold uppercase">Links de agendamento</h2>
        <CopyBox label="Link da bio do Instagram" text={data.links.instagram} hint="Cole em Editar perfil › Links." />
        <CopyBox label="Link para o WhatsApp" text={data.links.whatsapp} />
        <div className="flex flex-wrap gap-2">
          <Button icon={QrCode} onClick={() => openFile('/admin/qrcode.png?src=direct', 'qrcode-agendamento.png').catch((e) => toast(e.message, 'bad'))}>Baixar QR code para o balcão</Button>
        </div>
      </Card>
      <Card className="grid gap-4">
        <h2 className="font-display text-2xl font-bold uppercase">Resposta automática do WhatsApp</h2>
        <p className="text-sm text-muted -mt-2">No app WhatsApp Business, cole estes textos. Quem mandar mensagem recebe o link na hora.</p>
        <CopyBox label="Mensagem de saudação" text={data.whatsappBusinessTexts.greeting} hint="WhatsApp Business › Ferramentas comerciais › Mensagem de saudação." />
        <CopyBox label="Mensagem de ausência" text={data.whatsappBusinessTexts.away} hint="WhatsApp Business › Ferramentas comerciais › Mensagem de ausência." />
      </Card>
      {owner && (
        <>
          {(data.whatsappApiConfigured || data.settings.whatsappLevel2Enabled) && <Card className="grid gap-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-2xl font-bold uppercase">API oficial (Nível 2)</h2>
              <Badge tone={data.settings.whatsappLevel2Enabled ? 'ok' : 'muted'}>{data.settings.whatsappLevel2Enabled ? 'Ligado' : 'Desligado'}</Badge>
            </div>
            <p className="text-sm text-muted">Com a API da Meta, o sistema responde e manda confirmações e lembretes sozinho. {data.whatsappApiConfigured ? 'As chaves já estão configuradas no servidor.' : 'Para ligar, configure antes as chaves no servidor (veja o guia de implantação).'}</p>
            <Button className="justify-self-start" loading={busy} disabled={!data.whatsappApiConfigured && !data.settings.whatsappLevel2Enabled}
              onClick={() => save(() => api.patch('/admin/settings', { whatsappLevel2Enabled: !data.settings.whatsappLevel2Enabled }))}>
              {data.settings.whatsappLevel2Enabled ? 'Desligar Nível 2' : 'Ligar Nível 2'}
            </Button>
          </Card>}
          <Card className="grid gap-4">
            <h2 className="font-display text-2xl font-bold uppercase">Textos das mensagens</h2>
            <p className="text-xs text-muted -mt-2">Variáveis que o sistema troca sozinho: {VARS}</p>
            {Object.entries(TEMPLATE_INFO).map(([k, [label, hint]]) => (
              <Textarea key={k} label={label} hint={hint} value={texts[k]} onChange={(e) => setTexts({ ...texts, [k]: e.target.value })} maxLength={1000} />
            ))}
            <Button variant="primary" icon={Save} loading={busy} className="justify-self-end" onClick={() => save(() => api.patch('/admin/settings', { messageTexts: texts }), 'Textos salvos.')}>Salvar textos</Button>
          </Card>
        </>
      )}
    </div>
  );
}

function UsersTab({ data }) {
  const q = useQuery({ queryKey: ['users'], queryFn: () => api.get('/admin/users') });
  const qc = useQueryClient();
  const [edit, setEdit] = useState(null);
  const [canQuote, setCanQuote] = useState(Boolean(data.settings.mechanicCanQuote));
  const [save, busy] = useSave();
  return (
    <div className="grid gap-4 max-w-3xl">
    <Card>
      <h2 className="font-display text-2xl font-bold uppercase mb-2">Quem acessa o quê</h2>
      <div className="grid sm:grid-cols-2 gap-2 text-sm">
        <div className="rounded-xl border border-brand/40 bg-brand/10 p-3">
          <p className="font-semibold">Administrador do sistema</p>
          <p className="text-steel mt-1">Tudo, e é o <b>único</b> que altera o sistema: serviços e preços, dados da oficina, horários, elevadores, regras de agendamento, textos do WhatsApp, equipe e acessos, catálogo de peças e backup.</p>
        </div>
        <div className="rounded-xl border border-line bg-surface-2 p-3">
          <p className="font-semibold">Dono da oficina</p>
          <p className="text-steel mt-1">O dia a dia completo: agenda, OS, valores do orçamento e envio ao cliente, pagamentos, financeiro, clientes e lembretes. Também trabalha como mecânico. Não altera configurações.</p>
        </div>
        <div className="rounded-xl border border-line bg-surface-2 p-3">
          <p className="font-semibold">Mecânico</p>
          <p className="text-steel mt-1">Área <b>Hoje</b> e agenda da oficina. Faz o check-in, diagnóstico, fotos, peças que o cliente compra e o andamento da OS. Não cria nem exclui serviços, não muda valores e não vê o financeiro.</p>
        </div>
        <div className="rounded-xl border border-line bg-surface-2 p-3">
          <p className="font-semibold">Cliente</p>
          <p className="text-steel mt-1">Sem login: agenda pelo link e, pelo link que recebe, acompanha a moto, remarca, cancela e aprova o orçamento.</p>
        </div>
      </div>
      <div className="mt-4 pt-3 border-t border-line grid gap-2">
        <Checkbox checked={canQuote} onChange={setCanQuote}
          label="Mecânico pode lançar serviços e valores no orçamento"
          description="Desligado: só o dono da oficina e o administrador lançam serviços, definem valores e enviam o orçamento ao cliente. Ligado: o mecânico também pode, nas OS dele." />
        {canQuote !== Boolean(data.settings.mechanicCanQuote) && (
          <Button variant="primary" size="sm" icon={Save} loading={busy} className="justify-self-end" onClick={() => save(() => api.patch('/admin/settings', { mechanicCanQuote: canQuote }), 'Permissão salva.')}>Salvar</Button>
        )}
      </div>
    </Card>
    <Card>
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-2xl font-bold uppercase">Equipe</h2>
        <Button size="sm" variant="primary" icon={Plus} onClick={() => setEdit({})}>Pessoa</Button>
      </div>
      <p className="text-sm text-muted mb-3">Cada pessoa entra em <b>/admin</b> com o próprio e-mail e senha e vê só o que a função dela permite. Se alguém sair da oficina, desative o acesso.</p>
      {q.isLoading && <Spinner />}
      <ul className="divide-y divide-line">
        {q.data?.users.map((u) => (
          <li key={u.id} className="flex items-center justify-between gap-2 py-2.5">
            <div className={u.active ? '' : 'opacity-50'}>
              <p className="font-semibold">{u.name} <Badge tone={u.role === 'OWNER' ? 'brand' : u.role === 'MANAGER' ? 'ok' : 'muted'}>{ROLE_LABEL[u.role]}</Badge> {!u.active && <Badge tone="bad">Inativo</Badge>}</p>
              <p className="text-sm text-muted">{u.email}{['MECHANIC', 'MANAGER'].includes(u.role) && u.commissionPercent ? ` · comissão ${u.commissionPercent}%` : ''}</p>
            </div>
            <Button size="sm" variant="ghost" aria-label={`Editar ${u.name}`} onClick={() => setEdit(u)}><Pencil className="h-4 w-4" /></Button>
          </li>
        ))}
      </ul>
      {edit && <UserModal user={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); qc.invalidateQueries({ queryKey: ['users'] }); }} />}
    </Card>
    </div>
  );
}

function UserModal({ user, onClose, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState({ name: user.name || '', email: user.email || '', role: user.role || 'MECHANIC', commissionPercent: user.commissionPercent ?? 0, active: user.active ?? true, password: '' });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    const body = { name: f.name.trim(), email: f.email.trim(), role: f.role, commissionPercent: Number(f.commissionPercent) || 0, active: f.active, ...(f.password ? { password: f.password } : {}) };
    try {
      if (user.id) await api.patch(`/admin/users/${user.id}`, body); else await api.post('/admin/users', body);
      toast('Pessoa salva.');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title={user.id ? 'Editar pessoa' : 'Nova pessoa'} footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid gap-3">
        <Input label="Nome" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <Input label="E-mail (login)" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <Segmented value={f.role} onChange={(v) => setF({ ...f, role: v })} options={[
          { value: 'MECHANIC', label: 'Mecânico' },
          { value: 'MANAGER', label: 'Dono' },
          ...(user.role === 'ATTENDANT' ? [{ value: 'ATTENDANT', label: 'Atendente' }] : []),
          { value: 'OWNER', label: 'Admin. do sistema' },
        ]} />
        <p className="text-xs text-muted -mt-1">{{
          MECHANIC: 'Vê a agenda e o movimento do dia. Faz check-in, diagnóstico, fotos e o andamento da OS. Não mexe em serviços, valores nem no financeiro.',
          MANAGER: 'Dono da oficina: todo o dia a dia, valores do orçamento, pagamentos e financeiro. Não altera serviços, preços, configurações nem a equipe.',
          ATTENDANT: 'Agenda, clientes, OS e recebimentos. Não vê o financeiro.',
          OWNER: 'Acesso total e o único que altera o sistema: serviços, preços, configurações, equipe, catálogo e backup.',
        }[f.role]}</p>
        {['MECHANIC', 'MANAGER'].includes(f.role) && <Input label="Comissão sobre a mão de obra (%)" inputMode="numeric" value={f.commissionPercent} onChange={(e) => setF({ ...f, commissionPercent: e.target.value.replace(/\D/g, '').slice(0, 3) })} />}
        <Input label={user.id ? 'Nova senha (deixe vazio para manter)' : 'Senha inicial'} type="password" autoComplete="new-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} hint="Mínimo de 8 caracteres." />
        {user.id && <Checkbox label="Ativo (pode entrar no sistema)" checked={f.active} onChange={(v) => setF({ ...f, active: v })} />}
      </div>
    </Modal>
  );
}

function PasswordTab() {
  const toast = useToast();
  const { login } = useAuth();
  const [f, setF] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [busy, setBusy] = useState(false);
  async function save() {
    if (f.newPassword !== f.confirm) return toast('As senhas novas não são iguais.', 'bad');
    setBusy(true);
    try {
      const r = await api.post('/auth/change-password', { currentPassword: f.currentPassword, newPassword: f.newPassword });
      setAccessToken(r.accessToken);
      login(r);
      setF({ currentPassword: '', newPassword: '', confirm: '' });
      toast('Senha alterada. Outros aparelhos vão precisar entrar de novo.');
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
    return undefined;
  }
  return (
    <Card className="grid gap-3 max-w-md">
      <h2 className="font-display text-2xl font-bold uppercase">Trocar minha senha</h2>
      <Input label="Senha atual" type="password" autoComplete="current-password" value={f.currentPassword} onChange={(e) => setF({ ...f, currentPassword: e.target.value })} />
      <Input label="Nova senha" type="password" autoComplete="new-password" value={f.newPassword} onChange={(e) => setF({ ...f, newPassword: e.target.value })} hint="Mínimo de 8 caracteres." />
      <Input label="Repita a nova senha" type="password" autoComplete="new-password" value={f.confirm} onChange={(e) => setF({ ...f, confirm: e.target.value })} />
      <Button variant="primary" icon={KeyRound} loading={busy} onClick={save} className="justify-self-end">Trocar senha</Button>
    </Card>
  );
}
