import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { CalendarDays, ClipboardList, Bike, CheckCircle2, Wrench, ChevronRight, UserCheck } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Card, Badge, Button, Spinner, ErrorBox, Empty, Modal, Stat, cx } from '../../components/ui.jsx';
import { fmtTime, fmtLong, plateMask, BOOKING_STATUS, ORDER_STATUS } from '../../lib/format.js';
import { PageHeader } from './shared.jsx';
import { CheckinForm } from './Agenda.jsx';

// Area of the mechanic: the day's movement, without money.
const GROUPS = [
  { key: 'wait', title: 'Esperando diagnóstico', statuses: ['OPEN', 'DIAGNOSIS'] },
  { key: 'approval', title: 'Esperando o cliente aprovar', statuses: ['WAITING_APPROVAL'] },
  { key: 'work', title: 'Em serviço', statuses: ['APPROVED', 'IN_PROGRESS'] },
  { key: 'parts', title: 'Esperando peças', statuses: ['WAITING_PARTS'] },
  { key: 'ready', title: 'Prontas para retirada', statuses: ['READY'] },
];

export default function Today() {
  const q = useQuery({ queryKey: ['today'], queryFn: () => api.get('/admin/today'), refetchInterval: 60_000 });
  const [checkin, setCheckin] = useState(null);
  const qc = useQueryClient();
  const nav = useNavigate();
  if (q.isLoading) return <Spinner />;
  if (q.error) return <ErrorBox error={q.error} onRetry={q.refetch} />;
  const { bookings, orders, me } = q.data;
  const arrived = bookings.filter((b) => b.status === 'CHECKED_IN').length;
  const waiting = bookings.filter((b) => ['PENDING', 'CONFIRMED'].includes(b.status));
  const mine = orders.filter((o) => o.mechanicId === me).length;

  return (
    <div>
      <PageHeader title="Hoje" sub={`${fmtLong(new Date())} · o movimento da oficina`} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Stat label="Agendadas hoje" value={bookings.length} sub={`${waiting.length} ainda não chegaram`} icon={CalendarDays} />
        <Stat label="Chegaram" value={arrived} sub="hoje" icon={Bike} />
        <Stat label="Na oficina" value={orders.length} sub={`${mine} com você`} icon={Wrench} tone="brand" />
        <Stat label="Prontas" value={orders.filter((o) => o.status === 'READY').length} sub="esperando o cliente" icon={CheckCircle2} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4 items-start">
        <Card className="!p-0">
          <div className="flex items-center justify-between p-4 pb-2">
            <h2 className="font-display text-2xl font-bold uppercase">Agenda de hoje</h2>
            <Link to="/admin/agenda" className="text-sm text-brand-light font-semibold hover:underline">Outros dias →</Link>
          </div>
          {bookings.length === 0 ? <Empty icon={CalendarDays} title="Nenhum agendamento hoje" /> : (
            <ul className="divide-y divide-line">
              {bookings.map((b) => (
                <li key={b.id} className="flex items-start gap-3 px-4 py-3">
                  <span className="font-display text-xl font-bold w-14 shrink-0 leading-tight">{fmtTime(b.startAt)}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{b.customerName}</p>
                    <p className="text-sm text-steel truncate">{b.brand} {b.model} · {plateMask(b.plate)}</p>
                    <p className="text-xs text-muted truncate">{b.services}{b.bayName ? ` · ${b.bayName}` : ''}{b.mechanicName ? ` · ${b.mechanicName}` : ''}</p>
                    {b.problemDescription && <p className="text-xs text-muted mt-1 line-clamp-2">“{b.problemDescription}”</p>}
                    {b.pendingFindings > 0 && (
                      <Link to={`/admin/motos/${b.motorcycleId}`} className="inline-flex mt-1"><Badge tone="warn">{b.pendingFindings === 1 ? '1 pendência da última visita' : `${b.pendingFindings} pendências de visitas anteriores`}</Badge></Link>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <Badge tone={BOOKING_STATUS[b.status].tone}>{BOOKING_STATUS[b.status].label}</Badge>
                    {b.orderId
                      ? <Button size="sm" icon={ClipboardList} onClick={() => nav(`/admin/os/${b.orderId}`)}>Abrir OS</Button>
                      : ['PENDING', 'CONFIRMED'].includes(b.status) && <Button size="sm" variant="primary" icon={UserCheck} onClick={() => setCheckin(b.id)}>Moto chegou</Button>}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="grid gap-4">
          {orders.length === 0 && <Card><Empty icon={Wrench} title="Nenhuma moto na oficina" /></Card>}
          {GROUPS.map((g) => {
            const list = orders.filter((o) => g.statuses.includes(o.status));
            if (!list.length) return null;
            return (
              <Card key={g.key} className="!p-0">
                <h2 className="font-display text-xl font-bold uppercase px-4 pt-3 pb-1">{g.title} <span className="text-muted">({list.length})</span></h2>
                <ul className="divide-y divide-line">
                  {list.map((o) => (
                    <li key={o.id}>
                      <Link to={`/admin/os/${o.id}`} className="flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 focus-ring">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold truncate">OS {String(o.number).padStart(5, '0')} · {o.customerName}</p>
                          <p className="text-sm text-steel truncate">{o.brand} {o.model} · {plateMask(o.plate)}</p>
                        </div>
                        <div className="flex flex-col items-end gap-1 shrink-0">
                          <Badge tone={ORDER_STATUS[o.status].tone}>{ORDER_STATUS[o.status].label}</Badge>
                          <span className={cx('text-xs', o.mechanicId === me ? 'text-brand-light font-semibold' : o.mechanicId ? 'text-muted' : 'text-warn')}>
                            {o.mechanicId === me ? 'Com você' : o.mechanicName || 'Sem mecânico'}
                          </span>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted shrink-0" aria-hidden />
                      </Link>
                    </li>
                  ))}
                </ul>
              </Card>
            );
          })}
        </div>
      </div>

      {checkin && <CheckinModal id={checkin} onClose={() => setCheckin(null)} onDone={(orderId) => { qc.invalidateQueries(); nav(`/admin/os/${orderId}`); }} />}
    </div>
  );
}

function CheckinModal({ id, onClose, onDone }) {
  const q = useQuery({ queryKey: ['booking', id], queryFn: () => api.get(`/admin/bookings/${id}`) });
  return (
    <Modal open onClose={onClose} title="Moto chegou">
      {q.isLoading && <Spinner />}
      {q.error && <ErrorBox error={q.error} onRetry={q.refetch} />}
      {q.data && <CheckinForm booking={q.data.booking} onBack={onClose} onDone={onDone} />}
    </Modal>
  );
}
