import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Pencil, Eye, EyeOff } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Button, Card, Spinner, ErrorBox, Badge, Modal, Input, Textarea, Checkbox, Select, useToast } from '../../components/ui.jsx';
import { money, duration, parseMoney, centsToInput } from '../../lib/format.js';
import { PageHeader, useAuth, isOwner } from './shared.jsx';

export default function Services() {
  const { user } = useAuth();
  const owner = isOwner(user);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['services'], queryFn: () => api.get('/admin/services') });
  const [edit, setEdit] = useState(null);
  return (
    <div>
      <PageHeader title="Serviços e preços" sub="O que aparece no site de agendamento, com duração e preço."
        actions={owner && <Button variant="primary" icon={Plus} onClick={() => setEdit({})}>Novo serviço</Button>} />
      {q.isLoading && <Spinner />}
      {q.error && <ErrorBox error={q.error} onRetry={q.refetch} />}
      {q.data && (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
          {q.data.services.map((s) => (
            <Card key={s.id} className={`grid gap-1.5 ${s.active ? '' : 'opacity-50'}`}>
              <div className="flex items-start justify-between gap-2">
                <p className="font-semibold">{s.name}</p>
                {owner && <Button size="sm" variant="ghost" aria-label={`Editar ${s.name}`} onClick={() => setEdit(s)}><Pencil className="h-4 w-4" /></Button>}
              </div>
              <p className="text-sm text-muted">{s.category} · {duration(s.durationMinutes)}{s.dropOffRequired ? ' · deixa a moto' : ''}</p>
              {s.partsToBring && <p className="text-xs text-steel">Traga: {s.partsToBring}</p>}
              <p className="font-semibold text-brand-light">{s.priceOnEvaluation ? 'Sob avaliação' : s.basePriceCents == null ? <span className="text-warn">Sem preço definido</span> : `a partir de ${money(s.basePriceCents)}`}</p>
              <div className="flex flex-wrap gap-1.5">
                {!s.active && <Badge tone="bad">Inativo</Badge>}
                {s.active && (s.onlineVisible ? <Badge tone="ok"><Eye className="h-3 w-3" />No site</Badge> : <Badge><EyeOff className="h-3 w-3" />Só no balcão</Badge>)}
                {s.isOilChange && <Badge tone="brand">Gera lembrete de óleo</Badge>}
              </div>
            </Card>
          ))}
        </div>
      )}
      {edit && <ServiceModal service={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); qc.invalidateQueries({ queryKey: ['services'] }); qc.invalidateQueries({ queryKey: ['public-info'] }); }} />}
    </div>
  );
}

function ServiceModal({ service, onClose, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState({
    name: service.name || '', description: service.description || '', category: service.category || 'Geral', durationMinutes: service.durationMinutes || 60,
    price: centsToInput(service.basePriceCents), priceOnEvaluation: service.priceOnEvaluation || false, dropOffRequired: service.dropOffRequired || false,
    partsToBring: service.partsToBring || '', warrantyDays: service.warrantyDays ?? '', isOilChange: service.isOilChange || false, active: service.active ?? true, onlineVisible: service.onlineVisible ?? true, order: service.order ?? 99,
  });
  const [busy, setBusy] = useState(false);
  const set = (p) => setF({ ...f, ...p });
  async function save() {
    setBusy(true);
    const body = {
      name: f.name.trim(), description: f.description.trim() || null, category: f.category.trim() || 'Geral', durationMinutes: Number(f.durationMinutes),
      basePriceCents: f.priceOnEvaluation ? null : parseMoney(f.price), priceOnEvaluation: f.priceOnEvaluation, dropOffRequired: f.dropOffRequired,
      partsToBring: f.partsToBring.trim() || null,
      warrantyDays: f.warrantyDays === '' ? null : Number(f.warrantyDays), isOilChange: f.isOilChange, active: f.active, onlineVisible: f.onlineVisible, order: Number(f.order) || 0,
    };
    try {
      if (service.id) await api.patch(`/admin/services/${service.id}`, body); else await api.post('/admin/services', body);
      toast('Serviço salvo.');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title={service.id ? 'Editar serviço' : 'Novo serviço'} footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid gap-3">
        <Input label="Nome" value={f.name} onChange={(e) => set({ name: e.target.value })} />
        <Textarea label="Descrição (aparece no site)" value={f.description} onChange={(e) => set({ description: e.target.value })} maxLength={300} />
        <div className="grid grid-cols-2 gap-3">
          <Input label="Categoria" value={f.category} onChange={(e) => set({ category: e.target.value })} />
          <Select label="Duração" value={f.durationMinutes} onChange={(e) => set({ durationMinutes: e.target.value })}>
            {[15, 30, 45, 60, 90, 120, 150, 180, 240, 300, 360, 480].map((m) => <option key={m} value={m}>{duration(m)}</option>)}
          </Select>
          <Input label="Preço a partir de (R$)" inputMode="decimal" disabled={f.priceOnEvaluation} value={f.price} onChange={(e) => set({ price: e.target.value })} placeholder="Ex.: 80,00" />
          <Input label="Garantia (dias)" inputMode="numeric" value={f.warrantyDays} onChange={(e) => set({ warrantyDays: e.target.value.replace(/\D/g, '') })} hint="Vazio = padrão da oficina" />
          <Input label="Ordem no site" inputMode="numeric" value={f.order} onChange={(e) => set({ order: e.target.value.replace(/\D/g, '') })} />
        </div>
        <Textarea label="Peças que o cliente precisa trazer" hint="Aparece no agendamento e na confirmação. Deixe vazio nos serviços de avaliação." value={f.partsToBring} onChange={(e) => set({ partsToBring: e.target.value })} maxLength={300} placeholder="Ex.: Óleo do motor e filtro de óleo" />
        <Checkbox label="Preço sob avaliação (só depois de ver a moto)" checked={f.priceOnEvaluation} onChange={(v) => set({ priceOnEvaluation: v })} />
        <Checkbox label="O cliente precisa deixar a moto" checked={f.dropOffRequired} onChange={(v) => set({ dropOffRequired: v })} />
        <Checkbox label="É troca de óleo (cria lembrete automático)" checked={f.isOilChange} onChange={(v) => set({ isOilChange: v })} />
        <Checkbox label="Aparece no site de agendamento" checked={f.onlineVisible} onChange={(v) => set({ onlineVisible: v })} />
        <Checkbox label="Ativo" checked={f.active} onChange={(v) => set({ active: v })} />
      </div>
    </Modal>
  );
}
