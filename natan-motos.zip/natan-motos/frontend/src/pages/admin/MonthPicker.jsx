// Calendário do mês da agenda: bolinha azul embaixo dos dias que têm agendamento
import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { CalendarDays, ChevronLeft, ChevronRight } from 'lucide-react';
import { api } from '../../lib/api.js';
import { cx } from '../../components/ui.jsx';
import { isoDay } from '../../lib/format.js';

const MONTHS = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const MONTHS_SHORT = ['jan.', 'fev.', 'mar.', 'abr.', 'mai.', 'jun.', 'jul.', 'ago.', 'set.', 'out.', 'nov.', 'dez.'];
const WEEK = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
const pad = (n) => String(n).padStart(2, '0');

function shiftMonth(ym, n) {
  const [y, m] = ym.split('-').map(Number);
  const d = new Date(Date.UTC(y, m - 1 + n, 1));
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}`;
}

export function dayLabel(day) {
  const [y, m, d] = day.split('-').map(Number);
  return `${d} de ${MONTHS_SHORT[m - 1]} de ${y}`;
}

export default function MonthPicker({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const [month, setMonth] = useState(value.slice(0, 7));
  const box = useRef(null);
  const today = isoDay();

  useEffect(() => { if (!open) setMonth(value.slice(0, 7)); }, [value, open]);
  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => { if (box.current && !box.current.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('pointerdown', onDown);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('pointerdown', onDown); document.removeEventListener('keydown', onKey); };
  }, [open]);

  const q = useQuery({
    queryKey: ['agenda-month', month],
    queryFn: () => api.get(`/admin/agenda/month?month=${month}`),
    enabled: open,
    staleTime: 30_000,
  });
  const counts = q.data?.days || {};
  const closed = q.data?.closedWeekdays || [];

  const [y, m] = month.split('-').map(Number);
  const firstWeekday = new Date(Date.UTC(y, m - 1, 1)).getUTCDay();
  const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const cells = [...Array(firstWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => `${month}-${pad(i + 1)}`)];
  const total = Object.values(counts).reduce((a, n) => a + n, 0);

  const pick = (d) => { onChange(d); setOpen(false); };

  return (
    <div className="relative" ref={box}>
      <button type="button" onClick={() => setOpen((v) => !v)} aria-haspopup="dialog" aria-expanded={open}
        className="input !min-h-10 !w-auto !py-1.5 inline-flex items-center gap-2 font-semibold focus-ring">
        <CalendarDays className="h-4 w-4 text-brand-light" aria-hidden />{dayLabel(value)}
      </button>
      {open && <div className="fixed inset-0 z-[80] bg-black/60 sm:hidden" aria-hidden onClick={() => setOpen(false)} />}
      {open && (
        <div role="dialog" aria-label="Escolher data"
          className="fixed z-[90] left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[min(22rem,calc(100vw-2rem))] bg-surface border border-line rounded-2xl p-3 shadow-2xl
            sm:absolute sm:left-auto sm:right-0 sm:top-auto sm:translate-x-0 sm:translate-y-0 sm:mt-2">
          <div className="flex items-center justify-between mb-2">
            <button type="button" className="glass-btn h-9 w-9 rounded-[10px] inline-flex items-center justify-center focus-ring" aria-label="Mês anterior" onClick={() => setMonth(shiftMonth(month, -1))}><ChevronLeft className="h-4 w-4" /></button>
            <p className="font-display text-lg font-bold uppercase">{MONTHS[m - 1]} {y}</p>
            <button type="button" className="glass-btn h-9 w-9 rounded-[10px] inline-flex items-center justify-center focus-ring" aria-label="Próximo mês" onClick={() => setMonth(shiftMonth(month, 1))}><ChevronRight className="h-4 w-4" /></button>
          </div>
          <div className="grid grid-cols-7 text-center text-xs font-semibold text-muted mb-1">
            {WEEK.map((w, i) => <span key={i} className="py-1">{w}</span>)}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((d, i) => {
              if (!d) return <span key={`e${i}`} />;
              const n = counts[d] || 0;
              const selected = d === value;
              const isToday = d === today;
              const isClosed = closed.includes((firstWeekday + Number(d.slice(8)) - 1) % 7);
              return (
                <button key={d} type="button" onClick={() => pick(d)}
                  aria-label={`${Number(d.slice(8))} de ${MONTHS[m - 1]}${n ? `, ${n} ${n === 1 ? 'agendamento' : 'agendamentos'}` : ''}${isClosed ? ', fechado' : ''}`}
                  aria-current={selected ? 'date' : undefined}
                  className={cx('relative h-11 rounded-lg flex flex-col items-center justify-center text-sm font-semibold focus-ring transition-colors',
                    selected ? 'bg-brand text-white' : 'hover:bg-surface-2',
                    !selected && isToday && 'ring-1 ring-brand-light text-brand-light',
                    !selected && isClosed && 'text-muted/60')}>
                  {Number(d.slice(8))}
                  <span className={cx('mt-0.5 h-1.5 w-1.5 rounded-full', n ? (selected ? 'bg-white' : 'bg-brand-light') : 'bg-transparent')} aria-hidden />
                </button>
              );
            })}
          </div>
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-line text-xs text-muted">
            <span className="inline-flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-light" aria-hidden />
              {q.isLoading ? 'Carregando…' : total ? `${total} ${total === 1 ? 'agendamento' : 'agendamentos'} no mês` : 'Nenhum agendamento no mês'}
            </span>
            <button type="button" className="text-brand-light font-semibold hover:underline focus-ring rounded" onClick={() => pick(today)}>Hoje</button>
          </div>
        </div>
      )}
    </div>
  );
}
