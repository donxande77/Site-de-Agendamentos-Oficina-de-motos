// Prontuário da moto: peças de tela usadas na OS, na agenda e na página do prontuário.
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, MessageCircle, History, Undo2 } from 'lucide-react';
import { api } from '../../lib/api.js';
import {
  Button, Badge, Input, Textarea, Checkbox, Segmented, Modal, useToast, cx,
} from '../../components/ui.jsx';
import { fmtDate, SEVERITY, DECISION, VIA_LABEL, waUrl } from '../../lib/format.js';

export const SeverityBadge = ({ severity }) => <Badge tone={SEVERITY[severity].tone}>{SEVERITY[severity].label}</Badge>;

export function findingStatusLine(f, { showOrder = false } = {}) {
  return [
    showOrder && f.orderNumber ? `OS ${String(f.orderNumber).padStart(5, '0')} · ${fmtDate(f.orderDate)}` : null,
    f.checkMileage ? `olhar até ${f.checkMileage.toLocaleString('pt-BR')} km` : null,
    f.informedAt ? `cliente avisado em ${fmtDate(f.informedAt)} ${VIA_LABEL[f.informedVia] || ''}${f.informedByName ? ` por ${f.informedByName}` : ''}`.trim() : 'cliente ainda não foi avisado',
  ].filter(Boolean).join(' · ');
}

/** Message the shop sends when it finds something beyond what was asked */
export function findingMessage(f, customerName, bike) {
  const first = (customerName || '').split(' ')[0];
  const sev = f.severity === 'URGENT' ? ' É importante para a sua segurança.' : '';
  return `Olá, ${first}! Aqui é da Natan Motos. Olhando a sua ${bike}, encontramos também: ${f.description}.${sev} Quer que a gente resolva? Se preferir deixar para depois, sem problema, fica anotado no histórico da moto.`;
}

/** Pending items from earlier visits ("quando a moto volta, já sabe o que ficou para trás") */
export function PendingBox({ history, motorcycleId, onResolve, resolving, compact = false }) {
  const pending = history?.pendingFindings || [];
  const last = history?.lastVisit;
  if (!pending.length && !last) return null;
  return (
    <div className={cx('rounded-xl border px-4 py-3 grid gap-2', pending.length ? 'border-warn/50 bg-warn/10' : 'border-line bg-surface-2')}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className={cx('font-semibold flex items-center gap-1.5', pending.length ? 'text-warn' : 'text-steel')}>
          {pending.length ? <AlertTriangle className="h-4 w-4" /> : <History className="h-4 w-4" />}
          {pending.length ? `${pending.length === 1 ? 'Ficou 1 pendência' : `Ficaram ${pending.length} pendências`} de visitas anteriores` : 'Histórico da moto'}
        </p>
        {motorcycleId && <Link to={`/admin/motos/${motorcycleId}`} className="text-sm text-brand-light font-semibold hover:underline">Prontuário completo ({history.visits} {history.visits === 1 ? 'visita' : 'visitas'}) →</Link>}
      </div>
      {last && (
        <p className="text-sm text-steel">
          <span className="text-muted">Última visita {fmtDate(last.deliveredAt || last.createdAt)}{last.checkInMileage ? ` · ${last.checkInMileage.toLocaleString('pt-BR')} km` : ''}{last.mechanicName ? ` · ${last.mechanicName}` : ''}:</span>{' '}
          {last.workDone || last.diagnosis || 'sem relatório'}
        </p>
      )}
      {pending.length > 0 && (
        <ul className="grid gap-2">
          {pending.slice(0, compact ? 3 : 20).map((f) => (
            <li key={f.id} className="flex flex-wrap items-start gap-2 rounded-lg bg-surface/60 border border-line px-3 py-2">
              <SeverityBadge severity={f.severity} />
              <div className="flex-1 min-w-[12rem]">
                <p className="font-semibold text-sm">{f.description}</p>
                <p className="text-xs text-muted">{DECISION[f.decision].label} · {findingStatusLine(f, { showOrder: true })}</p>
              </div>
              {onResolve && <Button size="sm" icon={CheckCircle2} loading={resolving === f.id} onClick={() => onResolve(f, true)}>Resolvido nesta OS</Button>}
            </li>
          ))}
          {compact && pending.length > 3 && <li className="text-xs text-muted">e mais {pending.length - 3} no prontuário.</li>}
        </ul>
      )}
    </div>
  );
}

const SEVERITY_OPTIONS = Object.entries(SEVERITY).map(([value, s]) => ({ value, label: s.label }));
const VIA_OPTIONS = [{ value: 'IN_PERSON', label: 'Pessoalmente' }, { value: 'WHATSAPP', label: 'WhatsApp' }, { value: 'PHONE', label: 'Telefone' }];

export function FindingModal({ order, finding, onClose, onSaved }) {
  const toast = useToast();
  const [description, setDescription] = useState(finding?.description || '');
  const [severity, setSeverity] = useState(finding?.severity || 'SOON');
  const [decision, setDecision] = useState(finding?.decision || 'OPEN');
  const [informed, setInformed] = useState(Boolean(finding?.informedAt));
  const [via, setVia] = useState(finding?.informedVia || 'IN_PERSON');
  const [km, setKm] = useState(finding?.checkMileage ?? '');
  const [busy, setBusy] = useState(false);
  async function save() {
    if (description.trim().length < 3) { toast('Descreva o que foi encontrado.', 'bad'); return; }
    setBusy(true);
    const body = {
      description: description.trim(), severity, decision, checkMileage: km === '' ? null : Number(km),
      informed: informed || decision !== 'OPEN',
      ...(informed || decision !== 'OPEN' ? (finding?.informedAt && finding.informedVia === via ? {} : { informedVia: via }) : {}),
    };
    try {
      const r = finding
        ? await api.patch(`/admin/orders/${order.id}/findings/${finding.id}`, body)
        : await api.post(`/admin/orders/${order.id}/findings`, body);
      toast('Anotado no prontuário da moto.');
      onSaved(r.order);
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  const told = informed || decision !== 'OPEN';
  return (
    <Modal open onClose={onClose} title={finding ? 'Editar o que foi encontrado' : 'Encontrou mais alguma coisa?'}
      footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid gap-4">
        <Textarea label="O que foi encontrado" required value={description} onChange={(e) => setDescription(e.target.value)} maxLength={500} autoFocus
          placeholder="Ex.: Pneu traseiro no limite do TWI · Relação com folga · Vazamento no retentor da bengala esquerda" />
        <div className="grid gap-1.5">
          <p className="text-sm font-medium text-steel">Gravidade</p>
          <Segmented value={severity} onChange={setSeverity} options={SEVERITY_OPTIONS} className="flex-wrap" />
          <p className="text-xs text-muted">{SEVERITY[severity].hint}</p>
        </div>
        <div className="grid gap-1.5">
          <p className="text-sm font-medium text-steel">O que o cliente decidiu</p>
          <div className="grid sm:grid-cols-2 gap-2">
            {Object.entries(DECISION).map(([k, d]) => (
              <button key={k} type="button" aria-pressed={decision === k} onClick={() => setDecision(k)}
                className={cx('min-h-11 rounded-xl px-3 text-sm font-semibold border text-left focus-ring', decision === k ? 'glass-btn glass-btn-primary' : 'card')}>{d.label}</button>
            ))}
          </div>
        </div>
        <div className="grid gap-2 rounded-xl border border-line bg-surface-2 p-3">
          <Checkbox label="Avisei o cliente" description="Fica registrado quem avisou, quando e como. Protege a oficina se o problema aparecer depois." checked={told} disabled={decision !== 'OPEN'} onChange={setInformed} />
          {told && <Segmented value={via} onChange={setVia} options={VIA_OPTIONS} className="flex-wrap" />}
        </div>
        {decision !== 'FIXED' && (
          <Input label="Olhar de novo com quantos km? (opcional)" inputMode="numeric" value={km} onChange={(e) => setKm(e.target.value.replace(/\D/g, '').slice(0, 7))}
            hint={order.checkInMileage ? `A moto entrou com ${order.checkInMileage.toLocaleString('pt-BR')} km.` : undefined} />
        )}
      </div>
    </Modal>
  );
}

/** List of findings of one OS, with quick "avisar pelo WhatsApp" */
export function FindingList({ order, findings, editable, onEdit, onChanged }) {
  const toast = useToast();
  const bike = `${order.motorcycle.brand} ${order.motorcycle.model}`;
  async function warn(f) {
    window.open(waUrl(order.customer.phone, findingMessage(f, order.customer.name, bike)), '_blank', 'noopener');
    if (!f.informedAt && editable) {
      try { const r = await api.patch(`/admin/orders/${order.id}/findings/${f.id}`, { informed: true, informedVia: 'WHATSAPP' }); onChanged(r.order); toast('Marcado como avisado pelo WhatsApp.'); } catch (e) { toast(e.message, 'bad'); }
    }
  }
  async function undoFix(f) {
    try { const r = await api.patch(`/admin/orders/${order.id}/findings/${f.id}`, { decision: 'LATER' }); onChanged(r.order); } catch (e) { toast(e.message, 'bad'); }
  }
  if (!findings.length) return null;
  return (
    <ul className="grid grid-cols-[minmax(0,1fr)] gap-2">
      {findings.map((f) => (
        <li key={f.id} className="rounded-xl border border-line bg-surface-2 p-3 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <SeverityBadge severity={f.severity} />
            <Badge tone={DECISION[f.decision].tone}>{DECISION[f.decision].short}</Badge>
          </div>
          <button type="button" disabled={!editable} onClick={() => onEdit(f)} className="block text-left mt-1.5 font-semibold focus-ring rounded disabled:cursor-default break-words">{f.description}</button>
          <p className={cx('text-xs mt-0.5', f.informedAt ? 'text-muted' : 'text-warn')}>{findingStatusLine(f)}</p>
          {(f.decision !== 'FIXED' || editable) && (
            <div className="flex flex-wrap gap-2 mt-2">
              {f.decision !== 'FIXED' && <Button size="sm" icon={MessageCircle} onClick={() => warn(f)}>{f.informedAt ? 'Mandar de novo no WhatsApp' : 'Avisar no WhatsApp'}</Button>}
              {editable && f.decision === 'FIXED' && f.resolvedOrderId === order.id && <Button size="sm" variant="ghost" icon={Undo2} onClick={() => undoFix(f)}>Não foi consertado</Button>}
            </div>
          )}
        </li>
      ))}
    </ul>
  );
}
