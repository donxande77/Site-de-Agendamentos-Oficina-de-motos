import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, Search, Package, AlertTriangle } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Button, Spinner, ErrorBox, Empty, Badge, Modal, Input, Checkbox, Segmented, useToast } from '../../components/ui.jsx';
import { money, parseMoney, centsToInput } from '../../lib/format.js';
import { PageHeader, useAuth, isStaff } from './shared.jsx';

export default function Parts() {
  const { user } = useAuth();
  const staff = isStaff(user);
  const qc = useQueryClient();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all');
  const [edit, setEdit] = useState(null);
  const query = useQuery({ queryKey: ['parts', q, filter], queryFn: () => api.get(`/admin/parts?q=${encodeURIComponent(q)}${filter === 'low' ? '&low=1' : ''}`) });
  return (
    <div>
      <PageHeader title="Peças" sub="Estoque simples: quanto tem, custo e preço de venda."
        actions={staff && <Button variant="primary" icon={Plus} onClick={() => setEdit({})}>Nova peça</Button>} />
      <div className="flex flex-wrap gap-2 mb-4">
        <Segmented value={filter} onChange={setFilter} options={[{ value: 'all', label: 'Todas' }, { value: 'low', label: 'Estoque baixo' }]} />
        <div className="relative flex-1 min-w-52">
          <Search className="h-4 w-4 absolute left-3 top-4 text-muted" aria-hidden />
          <input className="input pl-9" placeholder="Buscar peça ou código" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Buscar peça" />
        </div>
      </div>
      {query.isLoading && <Spinner />}
      {query.error && <ErrorBox error={query.error} onRetry={query.refetch} />}
      {query.data && (query.data.parts.length === 0 ? <Empty icon={Package} title={filter === 'low' ? 'Nenhuma peça com estoque baixo' : 'Nenhuma peça cadastrada'}>Cadastre as peças que você mais usa: óleo, filtros, pastilhas, kits relação.</Empty> : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm min-w-[36rem]">
            <thead><tr className="text-left text-muted border-b border-line"><th className="p-3 font-semibold">Peça</th><th className="p-3 font-semibold text-right">Estoque</th><th className="p-3 font-semibold text-right">Custo</th><th className="p-3 font-semibold text-right">Venda</th><th className="p-3 font-semibold text-right">Margem</th></tr></thead>
            <tbody>
              {query.data.parts.map((p) => {
                const low = p.stock <= p.minStock;
                const margin = p.priceCents ? Math.round(((p.priceCents - p.costCents) / p.priceCents) * 100) : null;
                return (
                  <tr key={p.id} className={`border-b border-line last:border-0 ${p.active ? '' : 'opacity-50'} ${staff ? 'hover:bg-surface-2 cursor-pointer' : ''}`} onClick={() => staff && setEdit(p)}>
                    <td className="p-3"><span className="font-semibold">{p.name}</span>{p.code && <span className="text-muted"> · {p.code}</span>}</td>
                    <td className="p-3 text-right">{low ? <Badge tone="warn"><AlertTriangle className="h-3 w-3" />{p.stock}</Badge> : p.stock}<span className="text-muted text-xs block">mín. {p.minStock}</span></td>
                    <td className="p-3 text-right">{money(p.costCents)}</td>
                    <td className="p-3 text-right font-semibold">{money(p.priceCents)}</td>
                    <td className="p-3 text-right text-muted">{margin === null ? '—' : `${margin}%`}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ))}
      {edit && <PartModal part={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); qc.invalidateQueries({ queryKey: ['parts'] }); }} />}
    </div>
  );
}

function PartModal({ part, onClose, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState({ name: part.name || '', code: part.code || '', cost: centsToInput(part.costCents ?? 0), price: centsToInput(part.priceCents ?? 0), stock: part.stock ?? 0, minStock: part.minStock ?? 0, active: part.active ?? true });
  const [busy, setBusy] = useState(false);
  const set = (p) => setF({ ...f, ...p });
  async function save() {
    setBusy(true);
    const body = { name: f.name.trim(), code: f.code.trim() || null, costCents: parseMoney(f.cost) ?? 0, priceCents: parseMoney(f.price) ?? 0, stock: Number(f.stock) || 0, minStock: Number(f.minStock) || 0, active: f.active };
    try {
      if (part.id) await api.patch(`/admin/parts/${part.id}`, body); else await api.post('/admin/parts', body);
      toast('Peça salva.');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title={part.id ? 'Editar peça' : 'Nova peça'} footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid grid-cols-2 gap-3">
        <Input className="col-span-2" label="Nome" value={f.name} onChange={(e) => set({ name: e.target.value })} placeholder="Ex.: Óleo 10W30 semissintético 1L" />
        <Input label="Código" value={f.code} onChange={(e) => set({ code: e.target.value })} />
        <div />
        <Input label="Custo (R$)" inputMode="decimal" value={f.cost} onChange={(e) => set({ cost: e.target.value })} />
        <Input label="Venda (R$)" inputMode="decimal" value={f.price} onChange={(e) => set({ price: e.target.value })} />
        <Input label="Em estoque" inputMode="numeric" value={f.stock} onChange={(e) => set({ stock: e.target.value.replace(/[^\d-]/g, '') })} />
        <Input label="Estoque mínimo" inputMode="numeric" value={f.minStock} onChange={(e) => set({ minStock: e.target.value.replace(/\D/g, '') })} hint="Abaixo disso, aparece alerta." />
        <Checkbox className="col-span-2" label="Ativa" checked={f.active} onChange={(v) => set({ active: v })} />
      </div>
    </Modal>
  );
}
