import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Bell, Send, Check, ShieldAlert } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Button, Spinner, ErrorBox, Empty, Badge, Segmented, useToast } from '../../components/ui.jsx';
import { fmtDay, plateMask, fmtPhone, isoDay } from '../../lib/format.js';
import { PageHeader, sendWhatsApp } from './shared.jsx';

export default function Reminders() {
  const [scope, setScope] = useState('due');
  const toast = useToast();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['reminders', scope], queryFn: () => api.get(`/admin/reminders?scope=${scope}`) });
  const refresh = () => qc.invalidateQueries({ queryKey: ['reminders'] });
  const today = isoDay();

  async function done(r) {
    try { await api.post(`/admin/reminders/${r.id}/done`); toast('Lembrete concluído.'); refresh(); } catch (e) { toast(e.message, 'bad'); }
  }

  return (
    <div>
      <PageHeader title="Lembretes de revisão" sub="Clientes que estão chegando na hora da troca de óleo. Só envie para quem autorizou." />
      <Segmented className="mb-4" value={scope} onChange={setScope} options={[{ value: 'due', label: 'Para enviar' }, { value: 'upcoming', label: 'Próximos' }, { value: 'sent', label: 'Enviados' }]} />
      {q.isLoading && <Spinner />}
      {q.error && <ErrorBox error={q.error} onRetry={q.refetch} />}
      {q.data && (q.data.reminders.length === 0 ? <Empty icon={Bell} title="Nada por aqui">Os lembretes são criados sozinhos quando uma OS com troca de óleo é entregue.</Empty> : (
        <div className="card divide-y divide-line">
          {q.data.reminders.map((r) => (
            <div key={r.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
              <div className="flex-1 min-w-52">
                <Link to={`/admin/clientes/${r.customerId}`} className="font-semibold hover:text-brand-light">{r.customerName}</Link>
                <p className="text-sm text-muted">{r.brand} {r.model} · {plateMask(r.plate)} · {fmtPhone(r.customerPhone)}</p>
                <p className="text-sm">
                  {r.type === 'OIL_CHANGE' ? 'Troca de óleo' : 'Revisão'} em <span className={r.dueDate < today ? 'text-warn font-semibold' : ''}>{fmtDay(r.dueDate)}</span>
                  {r.dueMileage ? ` ou ${r.dueMileage.toLocaleString('pt-BR')} km` : ''}
                </p>
              </div>
              {!r.consent && <Badge tone="warn"><ShieldAlert className="h-3 w-3" />Sem autorização</Badge>}
              {r.sentAt && <Badge tone="ok">Enviado {fmtDay(r.sentAt.slice(0, 10))}</Badge>}
              {scope !== 'sent' && <Button size="sm" variant="primary" icon={Send} disabled={!r.consent} onClick={async () => { await sendWhatsApp({ template: 'maintenance', reminderId: r.id }, toast); refresh(); }}>Enviar</Button>}
              <Button size="sm" icon={Check} onClick={() => done(r)}>Concluir</Button>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
