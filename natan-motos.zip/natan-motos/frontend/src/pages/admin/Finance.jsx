import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { Plus, Download, Check, Trash2, Wallet, Receipt, TrendingUp, Package } from 'lucide-react';
import { api, openFile } from '../../lib/api.js';
import { Button, Card, Stat, Spinner, ErrorBox, Badge, Modal, Input, Select, Segmented, useToast } from '../../components/ui.jsx';
import { money, parseMoney, isoDay, fmtDay, fmtPhone, plateMask, METHOD_LABEL, EXPENSE_LABEL } from '../../lib/format.js';
import { PageHeader, useAuth, CHART } from './shared.jsx';

function monthRange(offset = 0) {
  const [y, m] = isoDay().split('-').map(Number);
  const d = new Date(Date.UTC(y, m - 1 + offset, 1));
  const from = d.toISOString().slice(0, 10);
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).toISOString().slice(0, 10);
  return { from, to: offset === 0 ? isoDay() : last };
}

export default function Finance() {
  const { theme } = useAuth();
  const c = CHART[theme];
  const qc = useQueryClient();
  const toast = useToast();
  const [preset, setPreset] = useState('this');
  const [range, setRange] = useState(monthRange(0));
  const [addingExpense, setAddingExpense] = useState(false);
  const key = `from=${range.from}&to=${range.to}`;
  const summary = useQuery({ queryKey: ['fin-summary', key], queryFn: () => api.get(`/admin/finance/summary?${key}`) });
  const expenses = useQuery({ queryKey: ['expenses', key], queryFn: () => api.get(`/admin/expenses?${key}`) });
  const receivables = useQuery({ queryKey: ['receivables'], queryFn: () => api.get('/admin/finance/receivables') });
  const commissions = useQuery({ queryKey: ['commissions', key], queryFn: () => api.get(`/admin/finance/commissions?${key}`) });
  const refresh = () => qc.invalidateQueries({ predicate: (q) => ['fin-summary', 'expenses', 'receivables'].includes(q.queryKey[0]) });

  function choose(p) {
    setPreset(p);
    if (p === 'this') setRange(monthRange(0));
    if (p === 'last') setRange(monthRange(-1));
  }
  async function payExpense(e) {
    try { await api.patch(`/admin/expenses/${e.id}`, { paidAt: isoDay() }); toast('Despesa marcada como paga.'); refresh(); } catch (err) { toast(err.message, 'bad'); }
  }
  async function delExpense(e) {
    try { await api.del(`/admin/expenses/${e.id}`); toast('Despesa apagada.'); refresh(); } catch (err) { toast(err.message, 'bad'); }
  }

  const s = summary.data;
  const flow = (s?.cashFlow || []).map((d) => ({ day: d.day.slice(8), Entradas: d.inCents / 100, Saídas: d.outCents / 100 }));

  return (
    <div>
      <PageHeader title="Financeiro" sub={`${fmtDay(range.from)} a ${fmtDay(range.to)}`}
        actions={<>
          <Button icon={Download} onClick={() => openFile(`/admin/finance/export.csv?${key}&kind=payments`, `recebimentos-${range.from}.csv`).catch((e) => toast(e.message, 'bad'))}>Recebimentos (CSV)</Button>
          <Button icon={Download} onClick={() => openFile(`/admin/finance/export.csv?${key}&kind=expenses`, `despesas-${range.from}.csv`).catch((e) => toast(e.message, 'bad'))}>Despesas (CSV)</Button>
        </>} />
      <div className="flex flex-wrap gap-2 items-end mb-4">
        <Segmented value={preset} onChange={choose} options={[{ value: 'this', label: 'Este mês' }, { value: 'last', label: 'Mês passado' }, { value: 'custom', label: 'Período' }]} />
        {preset === 'custom' && <>
          <input type="date" className="input !w-auto !min-h-10" value={range.from} onChange={(e) => setRange({ ...range, from: e.target.value })} aria-label="De" />
          <input type="date" className="input !w-auto !min-h-10" value={range.to} onChange={(e) => setRange({ ...range, to: e.target.value })} aria-label="Até" />
        </>}
      </div>

      {summary.isLoading && <Spinner />}
      {summary.error && <ErrorBox error={summary.error} onRetry={summary.refetch} />}
      {s && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Stat label="Recebido" value={money(s.revenueCents)} icon={Wallet} tone="brand" />
            <Stat label="Despesas pagas" value={money(s.expensesCents)} icon={Receipt} sub={s.pendingExpenses.count ? `${s.pendingExpenses.count} em aberto: ${money(s.pendingExpenses.totalCents)}` : 'nenhuma em aberto'} />
            <Stat label="Custo das peças" value={money(s.partsCostCents)} icon={Package} sub="das OS entregues" />
            <Stat label="Lucro" value={money(s.profitCents)} icon={TrendingUp} sub="recebido − despesas − peças" />
          </div>
          <div className="grid lg:grid-cols-[1.6fr_1fr] gap-4 mt-4">
            <Card>
              <h2 className="font-display text-2xl font-bold uppercase">Fluxo de caixa</h2>
              <p className="text-sm text-muted mb-3">Entradas e saídas por dia, em R$</p>
              {flow.length === 0 ? <p className="text-sm text-muted py-10 text-center">Sem movimento no período.</p> : (
                <div className="h-64" role="img" aria-label="Gráfico de entradas e saídas por dia">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={flow} margin={{ top: 8, right: 4, left: 0, bottom: 0 }} barGap={2}>
                      <CartesianGrid vertical={false} stroke={c.grid} />
                      <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fill: c.axis, fontSize: 12 }} />
                      <YAxis tickLine={false} axisLine={false} width={56} tick={{ fill: c.axis, fontSize: 12 }} />
                      <Tooltip cursor={{ fill: c.grid }} contentStyle={{ background: c.surface, border: '1px solid rgba(127,127,127,.3)', borderRadius: 12 }} formatter={(v, n) => [money(v * 100), n]} labelFormatter={(l) => `Dia ${l}`} />
                      <Legend wrapperStyle={{ fontSize: 12, color: c.axis }} />
                      <Bar dataKey="Entradas" fill={c.in} radius={[4, 4, 0, 0]} maxBarSize={22} />
                      <Bar dataKey="Saídas" fill={c.out} radius={[4, 4, 0, 0]} maxBarSize={22} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>
            <Card>
              <h2 className="font-display text-2xl font-bold uppercase mb-3">Por forma de pagamento</h2>
              {s.byMethod.length === 0 ? <p className="text-sm text-muted">Nenhum recebimento.</p> : (
                <ul className="grid gap-2 text-sm">
                  {s.byMethod.map((m) => <li key={m.method} className="flex justify-between"><span>{METHOD_LABEL[m.method]} <span className="text-muted">({m.count})</span></span><span className="font-semibold">{money(m.totalCents)}</span></li>)}
                </ul>
              )}
            </Card>
          </div>
        </>
      )}

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <Card>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display text-2xl font-bold uppercase">Despesas</h2>
            <Button size="sm" variant="primary" icon={Plus} onClick={() => setAddingExpense(true)}>Despesa</Button>
          </div>
          {expenses.data?.expenses.length === 0 && <p className="text-sm text-muted">Nenhuma despesa no período.</p>}
          <ul className="divide-y divide-line text-sm">
            {expenses.data?.expenses.map((e) => (
              <li key={e.id} className="flex items-center gap-2 py-2">
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{e.description}</p>
                  <p className="text-xs text-muted">{EXPENSE_LABEL[e.category]} · vence {fmtDay(e.dueDate)}</p>
                </div>
                <span className="font-semibold">{money(e.amountCents)}</span>
                {e.paidAt ? <Badge tone="ok">Paga {fmtDay(e.paidAt)}</Badge> : <Button size="sm" icon={Check} onClick={() => payExpense(e)}>Pagar</Button>}
                <Button size="sm" variant="ghost" aria-label="Apagar despesa" onClick={() => delExpense(e)}><Trash2 className="h-4 w-4" /></Button>
              </li>
            ))}
          </ul>
        </Card>
        <div className="grid gap-4 content-start">
          <Card>
            <h2 className="font-display text-2xl font-bold uppercase mb-3">A receber</h2>
            {receivables.data?.receivables.length === 0 && <p className="text-sm text-muted">Ninguém devendo.</p>}
            <ul className="divide-y divide-line text-sm">
              {receivables.data?.receivables.map((r) => (
                <li key={r.id}>
                  <Link to={`/admin/os/${r.id}`} className="flex justify-between gap-2 py-2 hover:text-brand-light">
                    <span><span className="font-semibold">OS {r.number} · {r.customerName}</span><span className="block text-xs text-muted">{r.model} {plateMask(r.plate)} · {fmtPhone(r.customerPhone)}</span></span>
                    <span className="font-semibold text-warn">{money(r.balanceCents)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
          <Card>
            <h2 className="font-display text-2xl font-bold uppercase mb-1">Comissões</h2>
            <p className="text-xs text-muted mb-3">Sobre a mão de obra das OS entregues no período. O percentual de cada mecânico fica em Configurações › Equipe.</p>
            {commissions.data?.commissions.length === 0 && <p className="text-sm text-muted">Nenhuma OS entregue com mecânico definido.</p>}
            <ul className="divide-y divide-line text-sm">
              {commissions.data?.commissions.map((m) => (
                <li key={m.id} className="flex justify-between py-2"><span>{m.name} <span className="text-muted">· {m.orders} OS · {m.commissionPercent}% de {money(m.laborCents)}</span></span><span className="font-semibold">{money(m.commissionCents)}</span></li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
      {addingExpense && <ExpenseModal onClose={() => setAddingExpense(false)} onSaved={() => { setAddingExpense(false); refresh(); }} />}
    </div>
  );
}

function ExpenseModal({ onClose, onSaved }) {
  const toast = useToast();
  const [f, setF] = useState({ category: 'OTHER', description: '', amount: '', dueDate: isoDay(), paid: true });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      await api.post('/admin/expenses', { category: f.category, description: f.description.trim(), amountCents: parseMoney(f.amount) || 0, dueDate: f.dueDate, paidAt: f.paid ? f.dueDate : null });
      toast('Despesa registrada.');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Modal open onClose={onClose} title="Nova despesa" footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid gap-3">
        <Select label="Categoria" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>
          {Object.entries(EXPENSE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
        <Input label="Descrição" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} placeholder="Ex.: Aluguel de novembro" />
        <div className="grid grid-cols-2 gap-3">
          <Input label="Valor (R$)" inputMode="decimal" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
          <Input label="Vencimento" type="date" value={f.dueDate} onChange={(e) => setF({ ...f, dueDate: e.target.value })} />
        </div>
        <Segmented value={f.paid ? 'paid' : 'open'} onChange={(v) => setF({ ...f, paid: v === 'paid' })} options={[{ value: 'paid', label: 'Já paga' }, { value: 'open', label: 'Em aberto' }]} />
      </div>
    </Modal>
  );
}
