import { lazy, Suspense, useEffect, useMemo, useState } from 'react';
import { Routes, Route, Navigate, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  LayoutDashboard, CalendarDays, ClipboardList, Users, Bell, Wrench, Package, Wallet, Settings, LogOut, Sun, Moon, MoreHorizontal, ExternalLink, Cog, Sunrise,
} from 'lucide-react';
import { api, refreshSession, setAccessToken, setSessionListener } from '../../lib/api.js';
import { Logo, Spinner, Button, cx, Modal } from '../../components/ui.jsx';
import { ROLE_LABEL, store } from '../../lib/format.js';
import { AuthCtx } from './shared.jsx';
import { DEMO } from '../../lib/demo.js';

const newTab = DEMO ? {} : { target: '_blank', rel: 'noopener' };
import Login from './Login.jsx';

const Dashboard = lazy(() => import('./Dashboard.jsx'));
const Today = lazy(() => import('./Today.jsx'));
const Agenda = lazy(() => import('./Agenda.jsx'));
const Orders = lazy(() => import('./Orders.jsx'));
const OrderDetail = lazy(() => import('./OrderDetail.jsx'));
const Customers = lazy(() => import('./Customers.jsx'));
const CustomerDetail = lazy(() => import('./CustomerDetail.jsx'));
const MotoHistory = lazy(() => import('./MotoHistory.jsx'));
const Services = lazy(() => import('./Services.jsx'));
const Parts = lazy(() => import('./Parts.jsx'));
const PartsCatalog = lazy(() => import('./PartsCatalog.jsx'));
const Finance = lazy(() => import('./Finance.jsx'));
const Reminders = lazy(() => import('./Reminders.jsx'));
const SettingsPage = lazy(() => import('./Settings.jsx'));

const NAV = [
  { to: '/admin', label: 'Painel', icon: LayoutDashboard, roles: ['OWNER', 'MANAGER'], end: true },
  { to: '/admin/hoje', label: 'Hoje', icon: Sunrise, roles: ['MECHANIC', 'ATTENDANT'] },
  { to: '/admin/agenda', label: 'Agenda', icon: CalendarDays, roles: ['OWNER', 'MANAGER', 'ATTENDANT', 'MECHANIC'] },
  { to: '/admin/os', label: 'Ordens de serviço', short: 'OS', icon: ClipboardList, roles: ['OWNER', 'MANAGER', 'ATTENDANT', 'MECHANIC'] },
  { to: '/admin/clientes', label: 'Clientes e motos', short: 'Clientes', icon: Users, roles: ['OWNER', 'MANAGER', 'ATTENDANT', 'MECHANIC'] },
  { to: '/admin/lembretes', label: 'Lembretes', icon: Bell, roles: ['OWNER', 'MANAGER', 'ATTENDANT'] },
  { to: '/admin/servicos', label: 'Serviços e preços', short: 'Serviços', icon: Wrench, roles: ['OWNER'] },
  { to: '/admin/catalogo', label: 'Catálogo de peças', short: 'Peças', icon: Cog, roles: ['OWNER', 'MANAGER', 'ATTENDANT', 'MECHANIC'] },
  { to: '/admin/pecas', label: 'Estoque', icon: Package, roles: ['OWNER', 'MANAGER', 'ATTENDANT', 'MECHANIC'], needsSellsParts: true },
  { to: '/admin/financeiro', label: 'Financeiro', icon: Wallet, roles: ['OWNER', 'MANAGER'] },
  { to: '/admin/configuracoes', label: 'Configurações', icon: Settings, roles: ['OWNER', 'MANAGER', 'ATTENDANT', 'MECHANIC'] },
];

export default function AdminApp() {
  const [user, setUser] = useState(undefined); // undefined = checking session
  const [theme, setTheme] = useState(() => store.get('nm_theme', 'dark'));
  const qc = useQueryClient();

  useEffect(() => {
    setSessionListener(setUser);
    refreshSession().catch(() => setUser(null));
  }, []);

  useEffect(() => {
    document.documentElement.dataset.nmTheme = theme;
    store.set('nm_theme', theme);
    return () => { document.documentElement.dataset.nmTheme = 'dark'; };
  }, [theme]);

  const auth = useMemo(() => ({
    user,
    login: (data) => { setAccessToken(data.accessToken); setUser(data.user); },
    logout: async () => { await api.post('/auth/logout').catch(() => {}); setAccessToken(null); setUser(null); qc.clear(); },
    theme,
    toggleTheme: () => setTheme((t) => (t === 'dark' ? 'light' : 'dark')),
  }), [user, theme, qc]);

  if (user === undefined) return <div className="min-h-dvh"><Spinner className="min-h-dvh" /></div>;
  if (!user) return <AuthCtx.Provider value={auth}><Login /></AuthCtx.Provider>;

  const business = ['OWNER', 'MANAGER'].includes(user.role);
  const home = business ? '/admin' : '/admin/hoje';
  const allowed = (path) => NAV.find((n) => n.to === path)?.roles.includes(user.role);

  return (
    <AuthCtx.Provider value={auth}>
      <Layout>
        <Suspense fallback={<Spinner />}>
          <Routes>
            <Route index element={business ? <Dashboard /> : <Navigate to={home} replace />} />
            <Route path="hoje" element={<Today />} />
            <Route path="agenda" element={<Agenda />} />
            <Route path="os" element={<Orders />} />
            <Route path="os/:id" element={<OrderDetail />} />
            <Route path="clientes" element={<Customers />} />
            <Route path="clientes/:id" element={<CustomerDetail />} />
            <Route path="motos/:id" element={<MotoHistory />} />
            {allowed('/admin/lembretes') && <Route path="lembretes" element={<Reminders />} />}
            {allowed('/admin/servicos') && <Route path="servicos" element={<Services />} />}
            <Route path="pecas" element={<Parts />} />
            <Route path="catalogo" element={<PartsCatalog />} />
            {allowed('/admin/financeiro') && <Route path="financeiro" element={<Finance />} />}
            <Route path="configuracoes" element={<SettingsPage />} />
            <Route path="*" element={<Navigate to={home} replace />} />
          </Routes>
        </Suspense>
      </Layout>
    </AuthCtx.Provider>
  );
}

function Layout({ children }) {
  return (
    <AuthCtx.Consumer>
      {({ user, logout, theme, toggleTheme }) => <Shell user={user} logout={logout} theme={theme} toggleTheme={toggleTheme}>{children}</Shell>}
    </AuthCtx.Consumer>
  );
}

function Shell({ user, logout, theme, toggleTheme, children }) {
  const settingsQ = useQuery({ queryKey: ['settings'], queryFn: () => api.get('/admin/settings'), staleTime: 60_000 });
  const sellsParts = Boolean(settingsQ.data?.settings.sellsParts);
  const items = NAV.filter((n) => n.roles.includes(user.role) && (!n.needsSellsParts || sellsParts));
  const mobileMain = items.slice(0, 4);
  const [more, setMore] = useState(false);
  const loc = useLocation();
  const nav = useNavigate();
  useEffect(() => { setMore(false); window.scrollTo(0, 0); }, [loc.pathname]);

  return (
    <div className="min-h-dvh backdrop-garage">
      {/* Top glass bar */}
      <header className="glass-bar sticky top-0 z-40 border-b">
        <div className="flex items-center justify-between gap-3 px-4 h-16 lg:pl-[17rem]">
          <button type="button" onClick={() => nav(items[0].to)} className="flex items-center gap-2.5 lg:hidden focus-ring rounded-full">
            <Logo className="h-9 w-9" />
            <span className="text-left leading-none">
              <span className="block font-display text-lg font-extrabold uppercase">Natan <span className="text-brand-light">Motos</span></span>
              <span className="block text-[11px] font-semibold uppercase tracking-wide text-muted">{{ OWNER: 'Administração do sistema', MANAGER: 'Dono da oficina' }[user.role] || `Área do ${ROLE_LABEL[user.role].toLowerCase()}`}</span>
            </span>
          </button>
          <div className="hidden lg:block text-sm text-muted">Olá, <span className="text-fg font-semibold">{user.name.split(' ')[0]}</span> · {ROLE_LABEL[user.role]}</div>
          <div className="flex items-center gap-2">
            <NavLink to="/" {...newTab} className="glass-btn hidden sm:inline-flex items-center gap-1.5 min-h-9 px-3 rounded-[10px] text-sm font-semibold"><ExternalLink className="h-4 w-4" aria-hidden />Ver site</NavLink>
            <Button size="icon" onClick={toggleTheme} aria-label={theme === 'dark' ? 'Usar tema claro' : 'Usar tema escuro'}>{theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}</Button>
            <Button size="icon" onClick={logout} aria-label="Sair"><LogOut className="h-5 w-5" /></Button>
          </div>
        </div>
      </header>

      {/* Desktop sidebar (solid — glass is only for bars and buttons) */}
      <aside className="hidden lg:flex fixed inset-y-0 left-0 z-50 w-64 flex-col border-r border-line bg-surface">
        <div className="flex items-center gap-3 px-5 h-16 border-b border-line">
          <Logo className="h-10 w-10" />
          <span className="font-display text-xl font-extrabold uppercase leading-none">Natan <span className="text-brand-light">Motos</span></span>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 grid content-start gap-1" aria-label="Menu">
          {items.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end}
              className={({ isActive }) => cx('flex items-center gap-3 px-3 min-h-11 rounded-xl text-sm font-semibold focus-ring', isActive ? 'glass-btn glass-btn-primary' : 'text-steel hover:text-fg hover:bg-surface-2')}>
              <n.icon className="h-5 w-5" aria-hidden />{n.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      <main className="px-4 py-6 lg:pl-[17.5rem] lg:pr-8 pb-28 lg:pb-10 max-w-[1500px]">{children}</main>

      {/* Mobile bottom glass navigation */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 glass-bar border-t pb-safe" aria-label="Menu">
        <div className="grid grid-cols-5 gap-1 px-2 pt-2">
          {mobileMain.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end}
              className={({ isActive }) => cx('flex flex-col items-center justify-center gap-0.5 min-h-14 rounded-xl text-[11px] font-semibold focus-ring', isActive ? 'glass-btn glass-btn-primary' : 'text-steel')}>
              <n.icon className="h-5 w-5" aria-hidden />{n.short || n.label}
            </NavLink>
          ))}
          <button type="button" onClick={() => setMore(true)} className="flex flex-col items-center justify-center gap-0.5 min-h-14 rounded-xl text-[11px] font-semibold text-steel focus-ring">
            <MoreHorizontal className="h-5 w-5" aria-hidden />Mais
          </button>
        </div>
      </nav>
      <Modal open={more} onClose={() => setMore(false)} title="Menu">
        <div className="grid gap-2">
          {items.slice(4).map((n) => (
            <NavLink key={n.to} to={n.to} className="glass-btn flex items-center gap-3 px-4 min-h-12 rounded-xl font-semibold"><n.icon className="h-5 w-5" aria-hidden />{n.label}</NavLink>
          ))}
          <NavLink to="/" {...newTab} className="glass-btn flex items-center gap-3 px-4 min-h-12 rounded-xl font-semibold"><ExternalLink className="h-5 w-5" aria-hidden />Ver site de agendamento</NavLink>
        </div>
      </Modal>
    </div>
  );
}
