// Prontuário da moto: todas as visitas, do mais recente para o mais antigo
import { Link, useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ChevronLeft, Bike, Gauge, CalendarDays, Wallet, Wrench, Lock, CheckCircle2, AlertTriangle, Bell, ClipboardList } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Card, Spinner, ErrorBox, Badge, Stat, Empty } from '../../components/ui.jsx';
import { money, plateMask, fmtDate, fmtPhone, ORDER_STATUS, DECISION } from '../../lib/format.js';
import { SeverityBadge, findingStatusLine } from './record.jsx';

const REMINDER_LABEL = { OIL_CHANGE: 'Troca de óleo', REVIEW: 'Revisão' };

export default function MotoHistory() {
  const { id } = useParams();
  const nav = useNavigate();
  const q = useQuery({ queryKey: ['moto-history', id], queryFn: () => api.get(`/admin/motorcycles/${id}/history`) });
  if (q.isLoading) return <Spinner />;
  if (q.error) return <ErrorBox error={q.error} onRetry={q.refetch} />;
  const { motorcycle: m, customer: c, visits, pendingFindings, reminders, stats } = q.data;
  const showMoney = stats.totalCents !== undefined;

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <button type="button" onClick={() => nav(-1)} className="glass-btn inline-flex items-center gap-1 min-h-9 px-3 rounded-[10px] text-sm font-semibold"><ChevronLeft className="h-4 w-4" />Voltar</button>
        <div className="min-w-0">
          <p className="text-xs uppercase font-semibold text-muted">Prontuário da moto</p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold uppercase leading-none break-words">{m.brand} {m.model}{m.year ? ` ${m.year}` : ''}</h1>
        </div>
        <Badge tone="brand">{plateMask(m.plate)}</Badge>
      </div>
      <p className="text-sm text-steel -mt-2">
        Dono: {c.anonymizedAt ? 'cliente removido' : <Link to={`/admin/clientes/${c.id}`} className="font-semibold text-fg hover:text-brand-light">{c.name}</Link>}
        {!c.anonymizedAt && <span className="text-muted"> · {fmtPhone(c.phone)}</span>}
      </p>

      <div className={`grid grid-cols-2 ${showMoney ? 'lg:grid-cols-4' : 'lg:grid-cols-3'} gap-3`}>
        <Stat label="Visitas" value={stats.visits} sub={stats.firstVisit ? `desde ${fmtDate(stats.firstVisit)}` : 'nenhuma ainda'} icon={Wrench} />
        <Stat label="Última visita" value={stats.lastVisit ? fmtDate(stats.lastVisit) : '—'} icon={CalendarDays} />
        <Stat label="KM" value={stats.lastMileage ? stats.lastMileage.toLocaleString('pt-BR') : '—'} sub="último registrado" icon={Gauge} />
        {showMoney && <Stat label="Já gastou" value={money(stats.totalCents)} sub="em OS entregues" icon={Wallet} tone="brand" />}
      </div>

      {(pendingFindings.length > 0 || reminders.length > 0) && (
        <div className="grid lg:grid-cols-2 gap-4 items-start">
          {pendingFindings.length > 0 && (
            <Card className="border-warn/50">
              <h2 className="font-display text-xl font-bold uppercase flex items-center gap-2 text-warn"><AlertTriangle className="h-5 w-5" />Pendências ({pendingFindings.length})</h2>
              <p className="text-xs text-muted mb-3">Encontrado em visitas anteriores e ainda não resolvido.</p>
              <ul className="grid gap-2">
                {pendingFindings.map((f) => (
                  <li key={f.id} className="rounded-xl border border-line bg-surface-2 p-3">
                    <div className="flex flex-wrap gap-2"><SeverityBadge severity={f.severity} /><Badge tone={DECISION[f.decision].tone}>{DECISION[f.decision].short}</Badge></div>
                    <p className="font-semibold mt-1.5">{f.description}</p>
                    <p className="text-xs text-muted">{findingStatusLine(f, { showOrder: true })}</p>
                  </li>
                ))}
              </ul>
            </Card>
          )}
          {reminders.length > 0 && (
            <Card>
              <h2 className="font-display text-xl font-bold uppercase flex items-center gap-2"><Bell className="h-5 w-5" />Próximas manutenções</h2>
              <ul className="divide-y divide-line mt-2 text-sm">
                {reminders.map((r) => (
                  <li key={r.id} className="py-2 flex justify-between gap-3">
                    <span className="font-semibold">{REMINDER_LABEL[r.type] || r.type}</span>
                    <span className="text-steel text-right">{r.dueDate ? fmtDate(r.dueDate) : ''}{r.dueMileage ? ` · ${r.dueMileage.toLocaleString('pt-BR')} km` : ''}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>
      )}

      <h2 className="font-display text-2xl font-bold uppercase mt-2">Histórico de visitas</h2>
      {visits.length === 0 ? <Card><Empty icon={Bike} title="Esta moto ainda não passou pela oficina" /></Card> : (
        <ol className="relative grid gap-4 border-l-2 border-line ml-2 pl-5">
          {visits.map((v) => <Visit key={v.id} v={v} />)}
        </ol>
      )}
    </div>
  );
}

function Block({ title, children, icon: Icon }) {
  return (
    <div>
      <p className="text-xs uppercase font-semibold text-muted flex items-center gap-1">{Icon && <Icon className="h-3.5 w-3.5" />}{title}</p>
      <div className="text-sm whitespace-pre-line break-words">{children}</div>
    </div>
  );
}

function Visit({ v }) {
  const status = ORDER_STATUS[v.status];
  return (
    <li className="relative">
      <span className="absolute -left-[1.85rem] top-4 h-4 w-4 rounded-full border-2 border-brand bg-surface" aria-hidden />
      <Card className="grid gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <p className="font-display text-xl font-bold">{fmtDate(v.deliveredAt || v.createdAt)}</p>
          <Link to={`/admin/os/${v.id}`} className="inline-flex items-center gap-1 text-sm font-semibold text-brand-light hover:underline"><ClipboardList className="h-4 w-4" />OS {String(v.number).padStart(5, '0')}</Link>
          <Badge tone={status.tone}>{status.label}</Badge>
          {v.totalCents !== undefined && v.totalCents > 0 && <span className="ml-auto font-semibold">{money(v.totalCents)}</span>}
        </div>
        <p className="text-xs text-muted -mt-2">
          {[v.checkInMileage ? `${v.checkInMileage.toLocaleString('pt-BR')} km` : null, v.mechanicName ? `Mecânico: ${v.mechanicName}` : null,
            v.warrantyUntil ? `garantia até ${fmtDate(v.warrantyUntil)}` : null].filter(Boolean).join(' · ')}
        </p>
        {v.problemDescription && <Block title="O cliente relatou">{v.problemDescription}</Block>}
        {v.diagnosis && <Block title="Diagnóstico">{v.diagnosis}</Block>}
        {v.workDone
          ? <Block title="O que foi feito">{v.workDone}</Block>
          : v.services.length > 0 && <Block title="Serviços">{v.services.join(', ')}</Block>}
        {v.workDone && v.services.length > 0 && <p className="text-xs text-muted">Serviços cobrados: {v.services.join(', ')}</p>}
        {v.customerParts.length > 0 && <p className="text-xs text-muted">Peças trazidas pelo cliente: {v.customerParts.join(', ')}</p>}

        {v.findings.length > 0 && (
          <div className="grid gap-2">
            <p className="text-xs uppercase font-semibold text-muted">Encontrado além do pedido</p>
            {v.findings.map((f) => (
              <div key={f.id} className="flex flex-wrap items-start gap-2 rounded-lg border border-line bg-surface-2 px-3 py-2">
                <SeverityBadge severity={f.severity} />
                <div className="flex-1 min-w-[12rem]">
                  <p className="font-semibold text-sm">{f.description}</p>
                  <p className="text-xs text-muted">
                    {f.resolvedOrderId && f.resolvedOrderId !== v.id ? `Resolvido depois, na OS ${String(f.resolvedOrderNumber).padStart(5, '0')}` : DECISION[f.decision].label} · {findingStatusLine(f)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
        {v.resolvedHere.length > 0 && (
          <div className="rounded-lg border border-ok/40 bg-ok/10 px-3 py-2 text-sm">
            <p className="font-semibold text-ok flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4" />Resolveu pendências de antes</p>
            <ul className="text-steel list-disc pl-5">{v.resolvedHere.map((f) => <li key={f.id}>{f.description} <span className="text-muted">(da OS {String(f.orderNumber).padStart(5, '0')})</span></li>)}</ul>
          </div>
        )}
        {v.internalNotes && (
          <div className="rounded-lg border border-line bg-surface-2 px-3 py-2">
            <Block title="Observações internas" icon={Lock}>{v.internalNotes}</Block>
          </div>
        )}
        {v.photos.length > 0 && (
          <div className="flex gap-2 flex-wrap">
            {v.photos.slice(0, 8).map((p) => <a key={p.id} href={p.url} target="_blank" rel="noopener noreferrer"><img src={p.url} alt="Foto da moto" className="h-16 w-16 object-cover rounded-lg border border-line" loading="lazy" /></a>)}
          </div>
        )}
      </Card>
    </li>
  );
}
