import { createContext, useContext } from 'react';
import { api } from '../../lib/api.js';
import { DEMO, showDemoModal } from '../../lib/demo.js';

export const AuthCtx = createContext({ user: null });
export const useAuth = () => useContext(AuthCtx);
// OWNER = administrador do sistema (configurações) · MANAGER = dono da oficina (dia a dia + dinheiro)
export const isStaff = (u) => ['OWNER', 'MANAGER', 'ATTENDANT'].includes(u?.role);
export const isBusiness = (u) => ['OWNER', 'MANAGER'].includes(u?.role);
export const isOwner = (u) => u?.role === 'OWNER';

/**
 * Sends a customer message. Level 2 → sent by the API. Level 1 → opens WhatsApp with the text ready.
 * A blank tab is opened synchronously so mobile browsers don't block the pop-up.
 */
export async function sendWhatsApp(payload, toast, before) {
  if (DEMO) {
    try {
      if (before) await before();
      const r = await api.post('/admin/notify', payload);
      showDemoModal({ title: 'Mensagem pronta no WhatsApp', text: r.text, waUrl: r.waUrl, note: 'No sistema publicado, o WhatsApp abre sozinho com esta mensagem já escrita para o cliente. É só tocar em enviar.' });
      return r;
    } catch (e) { toast(e.message, 'bad'); return null; }
  }
  const tab = window.open('', '_blank');
  try {
    if (before) await before();
    const r = await api.post('/admin/notify', payload);
    if (r.mode === 'sent') {
      tab?.close();
      toast('Mensagem enviada pelo WhatsApp.');
    } else {
      if (r.mode === 'failed') toast(r.error, 'bad');
      if (tab) tab.location.href = r.waUrl;
      else window.location.href = r.waUrl;
    }
    return r;
  } catch (e) {
    tab?.close();
    toast(e.message, 'bad');
    return null;
  }
}

export function PageHeader({ title, sub, actions }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
      <div>
        <h1 className="font-display text-4xl font-bold uppercase leading-none">{title}</h1>
        {sub && <p className="text-muted mt-1.5 text-sm">{sub}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

// Chart colors validated for colour-blind separation and contrast (dark surface #1C1C1C / light #FFFFFF)
export const CHART = {
  dark: { in: '#5B7BE8', out: '#C9782E', grid: 'rgba(255,255,255,0.08)', axis: '#9A9A9A', surface: '#1C1C1C' },
  light: { in: '#3358D4', out: '#C26A1E', grid: 'rgba(12,12,12,0.08)', axis: '#5E5E5E', surface: '#FFFFFF' },
};
