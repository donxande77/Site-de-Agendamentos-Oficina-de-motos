import { useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ChevronLeft, FileText, Camera, Trash2, Plus, Wallet, Copy, CheckCircle2, Bike, MessageCircle, Save, Phone, Share2, History, Lock,
} from 'lucide-react';
import { api, openFile } from '../../lib/api.js';
import {
  Button, Card, Spinner, ErrorBox, Badge, Input, Select, Textarea, Checkbox, Segmented, ConfirmModal, Modal, useToast, cx,
} from '../../components/ui.jsx';
import {
  money, parseMoney, centsToInput, plateMask, fmtPhone, fmtDate, fmtDateTime, ORDER_STATUS, METHOD_LABEL, FUEL_LABEL, CHECK_ITEMS, waUrl,
} from '../../lib/format.js';
import { useAuth, isStaff, isBusiness, sendWhatsApp } from './shared.jsx';
import { CatalogPicker, PartThumb } from './pickers.jsx';
import { DEMO, showDemoModal } from '../../lib/demo.js';
import { PendingBox, FindingModal, FindingList } from './record.jsx';

const NEXT_LABEL = {
  DIAGNOSIS: 'Iniciar diagnóstico', APPROVED: 'Cliente aprovou (balcão)', IN_PROGRESS: 'Iniciar serviço', WAITING_PARTS: 'Aguardando peças',
  READY: 'Moto pronta', DELIVERED: 'Entregar moto', CANCELLED: 'Cancelar OS', WAITING_APPROVAL: 'Aguardar aprovação',
};
const MECHANIC_ALLOWED = ['DIAGNOSIS', 'IN_PROGRESS', 'WAITING_PARTS', 'READY'];

export default function OrderDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const staff = isStaff(user);
  const toast = useToast();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ['order', id], queryFn: () => api.get(`/admin/orders/${id}`) });
  const settingsQ = useQuery({ queryKey: ['settings'], queryFn: () => api.get('/admin/settings'), staleTime: 60_000 });
  const [confirm, setConfirm] = useState(null);
  const [busy, setBusy] = useState(false);
  const [resolving, setResolving] = useState(null);
  const refresh = () => { qc.invalidateQueries({ queryKey: ['order', id] }); qc.invalidateQueries({ queryKey: ['orders'] }); };

  if (q.isLoading) return <Spinner />;
  if (q.error) return <ErrorBox error={q.error} onRetry={q.refetch} />;
  const { order: o, flow, publicBaseUrl } = q.data;
  const perms = q.data.permissions || { work: true, quote: true };
  const open = !['DELIVERED', 'CANCELLED'].includes(o.status);
  const canWork = open && perms.work;
  const canQuote = open && perms.quote;
  const quoteLink = `${publicBaseUrl.replace(/\/$/, '')}/orcamento/${o.approvalToken}`;
  const nexts = perms.work ? (flow[o.status] || []).filter((s) => staff || MECHANIC_ALLOWED.includes(s)) : [];
  // Relatório: o mecânico escreve enquanto a OS está aberta; depois de entregue, só o dono corrige
  const canReport = perms.work && o.status !== 'CANCELLED' && (open || staff);
  const notTold = (o.findings || []).filter((f) => f.decision === 'OPEN' && !f.informedAt).length;
  const reportGaps = [
    !o.workDone && 'o campo "O que foi feito" está vazio',
    notTold && `${notTold === 1 ? '1 item encontrado ainda não foi avisado' : `${notTold} itens encontrados ainda não foram avisados`} ao cliente`,
  ].filter(Boolean);
  async function resolvePending(f, resolved) {
    setResolving(f.id);
    try { await api.post(`/admin/orders/${o.id}/findings/${f.id}/resolve`, { resolved }); toast('Pendência marcada como resolvida nesta OS.'); refresh(); } catch (e) { toast(e.message, 'bad'); } finally { setResolving(null); }
  }

  async function setStatus(status, receivable) {
    setBusy(true);
    try {
      await api.post(`/admin/orders/${o.id}/status`, { status, receivable });
      toast(`Status: ${ORDER_STATUS[status].label}.`);
      setConfirm(null);
      refresh();
      if (status === 'READY' && staff) setConfirm({ type: 'notifyReady' });
    } catch (e) {
      if (e.code === 'UNPAID') setConfirm({ type: 'receivable' });
      else toast(e.message, 'bad');
    } finally { setBusy(false); }
  }

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <Link to="/admin/os" className="glass-btn inline-flex items-center gap-1 min-h-9 px-3 rounded-[10px] text-sm font-semibold"><ChevronLeft className="h-4 w-4" />OS</Link>
        <h1 className="font-display text-4xl font-bold uppercase leading-none">OS {String(o.number).padStart(5, '0')}</h1>
        <Badge tone={ORDER_STATUS[o.status].tone}>{ORDER_STATUS[o.status].label}</Badge>
        {o.quoteStatus === 'SENT' && <Badge tone="warn">Orçamento enviado</Badge>}
        {o.quoteStatus === 'APPROVED' && <Badge tone="ok">Aprovado {o.approvedAt ? fmtDateTime(o.approvedAt) : ''}</Badge>}
        {o.quoteStatus === 'REJECTED' && <Badge tone="bad">Orçamento recusado</Badge>}
      </div>

      {!staff && !perms.work && (
        <p className="rounded-xl border border-line bg-surface-2 px-4 py-3 text-sm text-steel">Esta OS é do <b>{o.mechanic?.name || 'outro mecânico'}</b>. Você pode ver, mas não alterar.</p>
      )}
      {!staff && perms.claim && open && (
        <p className="rounded-xl border border-warn/40 bg-warn/10 px-4 py-3 text-sm text-warn">Esta OS ainda não tem mecânico. Quando você começar a trabalhar nela, ela fica no seu nome.</p>
      )}

      <PendingBox history={o.bikeHistory} motorcycleId={o.motorcycle.id} onResolve={canReport && open ? resolvePending : null} resolving={resolving} />

      {/* Actions bar */}
      <Card className="flex flex-wrap gap-2 !p-3">
        {nexts.filter((s) => s !== 'CANCELLED' && s !== 'WAITING_APPROVAL').map((s) => (
          <Button key={s} variant={['READY', 'DELIVERED', 'IN_PROGRESS'].includes(s) ? 'primary' : 'secondary'} size="sm" loading={busy}
            onClick={() => (s === 'DELIVERED' ? setConfirm({ type: 'deliver' }) : s === 'READY' && reportGaps.length ? setConfirm({ type: 'readyGaps' }) : setStatus(s))}>{NEXT_LABEL[s]}</Button>
        ))}
        {staff && o.status === 'READY' && <Button size="sm" icon={MessageCircle} onClick={() => sendWhatsApp({ template: 'bikeReady', orderId: o.id }, toast)}>Avisar que está pronta</Button>}
        <Button size="sm" icon={FileText} onClick={() => openFile(`/admin/orders/${o.id}/pdf?type=os`).catch((e) => toast(e.message, 'bad'))}>PDF da OS</Button>
        {staff && nexts.includes('CANCELLED') && <Button size="sm" variant="danger" onClick={() => setConfirm({ type: 'cancel' })}>Cancelar OS</Button>}
      </Card>

      <div className="grid lg:grid-cols-[1fr_1.4fr] gap-4 items-start">
        <div className="grid gap-4">
          <Card>
            <p className="text-xs uppercase font-semibold text-muted mb-1">Cliente</p>
            <Link to={`/admin/clientes/${o.customer.id}`} className="font-semibold hover:text-brand-light">{o.customer.name}</Link>
            <p className="text-steel text-sm">{fmtPhone(o.customer.phone)}</p>
            <div className="flex gap-2 mt-2">
              <a className="glass-btn inline-flex items-center gap-1.5 min-h-9 px-3 rounded-[10px] text-sm font-semibold" href={`tel:+${o.customer.phone}`}><Phone className="h-4 w-4" />Ligar</a>
              <a className="glass-btn inline-flex items-center gap-1.5 min-h-9 px-3 rounded-[10px] text-sm font-semibold" href={waUrl(o.customer.phone)} target="_blank" rel="noopener noreferrer"><MessageCircle className="h-4 w-4" />WhatsApp</a>
            </div>
            <p className="text-xs uppercase font-semibold text-muted mt-4 mb-1 flex items-center gap-1"><Bike className="h-3.5 w-3.5" />Moto</p>
            <p className="font-semibold">{o.motorcycle.brand} {o.motorcycle.model}{o.motorcycle.year ? ` ${o.motorcycle.year}` : ''}</p>
            <p className="text-steel text-sm">{plateMask(o.motorcycle.plate)}</p>
            <Link to={`/admin/motos/${o.motorcycle.id}`} className="inline-flex items-center gap-1.5 text-sm text-brand-light font-semibold hover:underline mt-1"><History className="h-4 w-4" />Prontuário da moto</Link>
            {o.booking && <p className="text-xs text-muted mt-3">Agendamento {o.booking.code} · {fmtDateTime(o.booking.startAt)}</p>}
            {o.warrantyUntil && <p className="text-xs text-muted mt-1">Garantia até {fmtDate(o.warrantyUntil)}</p>}
          </Card>
          <CheckinCard order={o} editable={canWork} staff={staff} onSaved={refresh} />
          <Photos order={o} editable={canWork} staff={staff} onChanged={refresh} />
        </div>
        <div className="grid gap-4">
          <Diagnosis order={o} editable={canWork} onSaved={refresh} />
          <Report order={o} editable={canReport} closed={!open} onSaved={refresh} />
          <Items order={o} editable={canQuote} onChanged={refresh} sellsParts={Boolean(settingsQ.data?.settings.sellsParts)}
            note={open && perms.work && !perms.quote ? 'Os serviços e os valores são lançados pelo dono da oficina. O valor do diagnóstico você coloca no quadro Diagnóstico, acima.' : null} />
          <CustomerParts order={o} editable={canWork} onChanged={refresh} />
          {o.items.length > 0 && perms.quote && <SendQuote order={o} quoteLink={quoteLink} onChanged={refresh} />}
          {staff && <Payments order={o} onChanged={refresh} canDelete={isBusiness(user)} />}
        </div>
      </div>

      <ConfirmModal open={confirm?.type === 'deliver'} onClose={() => setConfirm(null)} loading={busy} title="Entregar a moto?" confirmLabel="Entregar"
        message={`${o.balanceCents > 0 ? `Ainda falta receber ${money(o.balanceCents)}. Registre o pagamento antes ou confirme para marcar como "a receber".` : 'A OS será finalizada e a garantia começa a contar hoje.'}${reportGaps.length ? ` Atenção: ${reportGaps.join(' e ')}.` : ''}`}
        onConfirm={() => setStatus('DELIVERED', o.balanceCents > 0)} />
      <ConfirmModal open={confirm?.type === 'receivable'} onClose={() => setConfirm(null)} loading={busy} title="Entregar com valor em aberto?" confirmLabel="Entregar e marcar a receber"
        message={`Falta receber ${money(o.balanceCents)}. A OS vai para a lista "A receber" do financeiro.`} onConfirm={() => setStatus('DELIVERED', true)} />
      <ConfirmModal open={confirm?.type === 'readyGaps'} onClose={() => setConfirm(null)} loading={busy} title="Falta completar o relatório" confirmLabel="Marcar pronta mesmo assim"
        message={`Antes de liberar a moto: ${reportGaps.join(' e ')}. O relatório fica no prontuário e ajuda quando a moto voltar.`} onConfirm={() => setStatus('READY')} />
      <ConfirmModal open={confirm?.type === 'cancel'} onClose={() => setConfirm(null)} loading={busy} danger title="Cancelar esta OS?" confirmLabel="Cancelar OS"
        message="A OS será encerrada sem cobrança. Essa ação não pode ser desfeita." onConfirm={() => setStatus('CANCELLED')} />
      <ConfirmModal open={confirm?.type === 'notifyReady'} onClose={() => setConfirm(null)} title="Avisar o cliente?" confirmLabel="Avisar pelo WhatsApp"
        message="A moto está pronta. Quer mandar a mensagem para o cliente buscar?" onConfirm={() => { setConfirm(null); sendWhatsApp({ template: 'bikeReady', orderId: o.id }, toast); }} />
    </div>
  );
}

function CheckinCard({ order: o, editable, staff, onSaved }) {
  const toast = useToast();
  const [km, setKm] = useState(o.checkInMileage ?? '');
  const [fuel, setFuel] = useState(o.fuelLevel || '');
  const [items, setItems] = useState(o.checklist?.items || []);
  const [damage, setDamage] = useState(o.checklist?.damage || '');
  const [mechanicId, setMechanicId] = useState(o.mechanicId || '');
  const users = useQuery({ queryKey: ['users'], queryFn: () => api.get('/admin/users'), enabled: staff });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      await api.patch(`/admin/orders/${o.id}`, {
        checkInMileage: km === '' ? null : Number(km), fuelLevel: fuel || null, checklist: { items, damage: damage.trim() || undefined },
        ...(staff ? { mechanicId: mechanicId ? Number(mechanicId) : null } : {}),
      });
      toast('Check-in salvo.');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Card className="grid gap-3">
      <h2 className="font-display text-2xl font-bold uppercase">Check-in</h2>
      <div className="grid grid-cols-2 gap-3">
        <Input label="KM na entrada" inputMode="numeric" disabled={!editable} value={km} onChange={(e) => setKm(e.target.value.replace(/\D/g, '').slice(0, 7))} />
        <Select label="Combustível" disabled={!editable} value={fuel} onChange={(e) => setFuel(e.target.value)}>
          <option value="">—</option>{Object.entries(FUEL_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {Object.entries(CHECK_ITEMS).map(([k, v]) => <Checkbox key={k} label={v} disabled={!editable} checked={items.includes(k)} onChange={(on) => setItems((x) => (on ? [...x, k] : x.filter((i) => i !== k)))} />)}
      </div>
      <Textarea label="Avarias visíveis" disabled={!editable} value={damage} onChange={(e) => setDamage(e.target.value)} maxLength={500} />
      {staff && (
        <Select label="Mecânico responsável" disabled={!editable} value={mechanicId} onChange={(e) => setMechanicId(e.target.value)}>
          <option value="">Não definido</option>{users.data?.users.filter((u) => u.active && u.role !== 'ATTENDANT').map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
        </Select>
      )}
      {editable && <Button size="sm" icon={Save} loading={busy} onClick={save} className="justify-self-end">Salvar check-in</Button>}
    </Card>
  );
}

function Photos({ order: o, editable, staff, onChanged }) {
  const toast = useToast();
  const input = useRef(null);
  const [busy, setBusy] = useState(false);
  async function upload(files) {
    if (!files.length) return;
    const fd = new FormData();
    [...files].slice(0, 10).forEach((f) => fd.append('photos', f));
    setBusy(true);
    try { await api.upload(`/admin/orders/${o.id}/photos`, fd); toast('Fotos enviadas.'); onChanged(); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  async function remove(pid) {
    try { await api.del(`/admin/orders/${o.id}/photos/${pid}`); onChanged(); } catch (e) { toast(e.message, 'bad'); }
  }
  return (
    <Card>
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-2xl font-bold uppercase">Fotos</h2>
        {editable && <Button size="sm" icon={Camera} loading={busy} onClick={() => input.current?.click()}>Adicionar</Button>}
      </div>
      {o.photos.length === 0 ? <p className="text-sm text-muted">Tire fotos da moto na entrada para registrar o estado dela.</p> : (
        <div className="grid grid-cols-3 gap-2">
          {o.photos.map((p) => (
            <div key={p.id} className="relative aspect-square">
              <a href={p.url} target="_blank" rel="noopener noreferrer"><img src={p.url} alt="Foto da moto" className="h-full w-full object-cover rounded-xl border border-line" loading="lazy" /></a>
              {staff && editable && <button type="button" onClick={() => remove(p.id)} aria-label="Apagar foto" className="absolute top-1 right-1 h-7 w-7 rounded-full bg-black/70 flex items-center justify-center"><Trash2 className="h-3.5 w-3.5 text-white" /></button>}
            </div>
          ))}
        </div>
      )}
      <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" capture="environment" multiple hidden onChange={(e) => { upload(e.target.files); e.target.value = ''; }} />
    </Card>
  );
}

function Diagnosis({ order: o, editable, onSaved }) {
  const toast = useToast();
  const [text, setText] = useState(o.diagnosis || '');
  const [busy, setBusy] = useState(false);
  useEffect(() => setText(o.diagnosis || ''), [o.diagnosis]);
  async function save() {
    setBusy(true);
    try { await api.patch(`/admin/orders/${o.id}`, { diagnosis: text.trim() || null }); toast('Diagnóstico salvo.'); onSaved(); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  return (
    <Card className="grid gap-3">
      <h2 className="font-display text-2xl font-bold uppercase">Diagnóstico</h2>
      <Textarea value={text} disabled={!editable} onChange={(e) => setText(e.target.value)} placeholder="O que foi encontrado na moto. O cliente vê este texto no orçamento." maxLength={4000} />
      {editable && text !== (o.diagnosis || '') && <Button size="sm" icon={Save} loading={busy} onClick={save} className="justify-self-end">Salvar diagnóstico</Button>}
      <DiagnosisFee order={o} editable={editable && o.diagnosisFeeEditable} onSaved={onSaved} />
    </Card>
  );
}

// Relatório técnico (prontuário): o que foi feito, observações internas e o que foi encontrado além do pedido
function Report({ order: o, editable, closed, onSaved }) {
  const toast = useToast();
  const [workDone, setWorkDone] = useState(o.workDone || '');
  const [notes, setNotes] = useState(o.internalNotes || '');
  const [busy, setBusy] = useState(false);
  const [modal, setModal] = useState(null);
  useEffect(() => setWorkDone(o.workDone || ''), [o.workDone]);
  useEffect(() => setNotes(o.internalNotes || ''), [o.internalNotes]);
  const dirty = workDone !== (o.workDone || '') || notes !== (o.internalNotes || '');
  async function save() {
    setBusy(true);
    try { await api.patch(`/admin/orders/${o.id}`, { workDone: workDone.trim() || null, internalNotes: notes.trim() || null }); toast('Relatório salvo no prontuário.'); onSaved(); } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  const findings = o.findings || [];
  return (
    <Card className="grid gap-3">
      <div>
        <h2 className="font-display text-2xl font-bold uppercase">Relatório do serviço</h2>
        <p className="text-xs text-muted">Fica no prontuário da moto. Quando ela voltar, todo mundo sabe o que já foi feito.</p>
      </div>
      {closed && editable && <p className="rounded-lg border border-line bg-surface-2 px-3 py-2 text-sm text-steel">OS finalizada: só o dono da oficina corrige o relatório.</p>}
      {o.booking?.problemDescription && (
        <div className="rounded-lg border border-line bg-surface-2 px-3 py-2">
          <p className="text-xs uppercase font-semibold text-muted">O cliente relatou</p>
          <p className="text-sm whitespace-pre-line">{o.booking.problemDescription}</p>
        </div>
      )}
      <Textarea label="O que foi feito" value={workDone} disabled={!editable} onChange={(e) => setWorkDone(e.target.value)} maxLength={4000}
        placeholder="Ex.: Troquei as pastilhas dianteiras, regulei o freio traseiro e lubrifiquei a corrente. Testei a moto na rua." hint="Sai no PDF da OS que o cliente recebe." />
      <Textarea label="Observações internas" value={notes} disabled={!editable} onChange={(e) => setNotes(e.target.value)} maxLength={4000}
        placeholder="Ex.: Parafuso do cárter com rosca espanada, cuidado no próximo aperto. Cliente prefere peça original." hint="Só a oficina vê. Não vai para o cliente." />
      {editable && dirty && <Button size="sm" icon={Save} loading={busy} onClick={save} className="justify-self-end">Salvar relatório</Button>}

      <div className="border-t border-line pt-3 grid gap-2">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <p className="font-semibold">Encontrado além do que foi pedido</p>
            <p className="text-xs text-muted">Defeitos e pontos de atenção. Registre se o cliente foi avisado e o que ele decidiu.</p>
          </div>
          {editable && <Button size="sm" variant="primary" icon={Plus} onClick={() => setModal({})}>Registrar</Button>}
        </div>
        {findings.length === 0
          ? <p className="text-sm text-muted">{editable ? 'Nada registrado. Achou algum outro problema na moto? Toque em "Registrar".' : 'Nada registrado.'}</p>
          : <FindingList order={o} findings={findings} editable={editable} onEdit={(f) => setModal({ finding: f })} onChanged={onSaved} />}
        {findings.some((f) => f.decision !== 'FIXED') && (
          <p className="text-xs text-muted flex items-center gap-1.5"><Lock className="h-3.5 w-3.5" />Os itens não consertados saem no PDF da OS e do orçamento como "Outros pontos encontrados na moto".</p>
        )}
      </div>
      {modal && <FindingModal order={o} finding={modal.finding} onClose={() => setModal(null)} onSaved={() => { setModal(null); onSaved(); }} />}
    </Card>
  );
}

// "Valor do diagnóstico": typed on the spot, goes into the quote as the "Diagnóstico" line
function DiagnosisFee({ order: o, editable, onSaved }) {
  const toast = useToast();
  const fromServer = o.diagnosisFeeCents ? centsToInput(o.diagnosisFeeCents) : '';
  const [val, setVal] = useState(fromServer);
  const [busy, setBusy] = useState(false);
  useEffect(() => { setVal(fromServer); }, [fromServer]);
  async function commit() {
    const cents = val.trim() ? parseMoney(val) : null;
    if (val.trim() && cents == null) { toast('Valor inválido. Ex.: 80,00', 'bad'); return; }
    if ((cents || null) === (o.diagnosisFeeCents || null)) return;
    setBusy(true);
    try { await api.put(`/admin/orders/${o.id}/diagnosis-fee`, { amountCents: cents }); toast('Valor do diagnóstico salvo. Ele já está no orçamento.'); onSaved(); } catch (e) { toast(e.message, 'bad'); setVal(fromServer); } finally { setBusy(false); }
  }
  if (!editable) {
    if (!o.diagnosisFeeCents) return null;
    return <p className="text-sm text-steel border-t border-line pt-3">Valor do diagnóstico: <b className="text-fg">{money(o.diagnosisFeeCents)}</b></p>;
  }
  return (
    <div className="border-t border-line pt-3 grid gap-1.5">
      <label htmlFor={`diag-fee-${o.id}`} className="text-sm font-medium text-steel">Valor do diagnóstico (R$)</label>
      <div className="flex items-center gap-2">
        <div className={cx('flex items-center gap-1 rounded-xl border px-3 min-h-12 flex-1 max-w-[14rem]', o.diagnosisFeeCents ? 'border-line bg-surface-2' : 'border-warn bg-warn/10')}>
          <span className="text-muted">R$</span>
          <input id={`diag-fee-${o.id}`} inputMode="decimal" enterKeyHint="done" placeholder="0,00" value={val}
            onChange={(e) => setVal(e.target.value.replace(/[^\d.,]/g, ''))} onBlur={commit}
            onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
            className="w-full bg-transparent outline-none text-[16px] font-semibold" />
        </div>
        {busy && <span className="text-xs text-muted">salvando…</span>}
      </div>
      <p className="text-xs text-muted">Entra no orçamento do cliente como "{o.items.find((i) => i.isDiagnosisFee)?.description || 'Diagnóstico'}". Deixe vazio se não for cobrar.</p>
    </div>
  );
}

function Items({ order: o, editable, onChanged, sellsParts, note }) {
  const toast = useToast();
  const [adding, setAdding] = useState(false);
  const [edit, setEdit] = useState(null);
  const charged = o.items.filter((i) => i.type !== 'CUSTOMER_PART');
  async function remove(itemId) {
    try { await api.del(`/admin/orders/${o.id}/items/${itemId}`); onChanged(); } catch (e) { toast(e.message, 'bad'); }
  }
  return (
    <Card className="!p-0 overflow-hidden">
      <div className="flex items-center justify-between p-4 pb-2">
        <div>
          <h2 className="font-display text-2xl font-bold uppercase">Serviços</h2>
          <p className="text-xs text-muted">O que a oficina vai fazer e cobrar.</p>
        </div>
        {editable && <Button size="sm" variant="primary" icon={Plus} onClick={() => setAdding(true)}>Serviço</Button>}
      </div>
      {note && <p className="mx-4 mb-2 rounded-lg border border-line bg-surface-2 px-3 py-2 text-sm text-steel">{note}</p>}
      {editable && charged.some((i) => !i.unitPriceCents) && (
        <p className="mx-4 mb-2 rounded-lg border border-warn/40 bg-warn/10 px-3 py-2 text-sm text-warn">Toque no valor marcado em amarelo e digite quanto vai cobrar.</p>
      )}
      {charged.length === 0 ? <p className="text-sm text-muted px-4 pb-4">Nenhum serviço lançado ainda.</p> : (
        <table className="w-full text-sm">
          <thead><tr className="text-left text-muted border-y border-line"><th className="px-4 py-2 font-semibold">Item</th><th className="px-2 py-2 font-semibold text-right">Qtd</th><th className="px-2 py-2 font-semibold text-right">Valor (R$)</th><th className="w-10" /></tr></thead>
          <tbody>
            {charged.map((i) => (
              <tr key={i.id} className="border-b border-line">
                <td className="px-4 py-2.5">
                  <button type="button" disabled={!editable} onClick={() => setEdit(i)} className="text-left focus-ring rounded disabled:cursor-default">
                    <span className="text-xs text-muted block">{i.type === 'PART' ? 'Peça do estoque' : 'Mão de obra'}</span>{i.description}
                  </button>
                </td>
                <td className="px-2 py-2.5 text-right">{i.quantity}</td>
                <td className="px-2 py-2 text-right whitespace-nowrap">
                  {editable ? <PriceCell order={o} item={i} onSaved={onChanged} /> : (i.unitPriceCents ? money(i.unitPriceCents * i.quantity) : 'a definir')}
                  {i.quantity > 1 && i.unitPriceCents > 0 && <span className="block text-xs text-muted">= {money(i.unitPriceCents * i.quantity)}</span>}
                </td>
                <td className="pr-2">{editable && <Button size="sm" variant="ghost" aria-label="Remover item" onClick={() => remove(i.id)}><Trash2 className="h-4 w-4" /></Button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <div className="p-4 grid gap-1 text-sm">
        {o.partsCents > 0 && <div className="flex justify-between text-muted"><span>Mão de obra</span><span>{money(o.laborCents)}</span></div>}
        {o.partsCents > 0 && <div className="flex justify-between text-muted"><span>Peças do estoque</span><span>{money(o.partsCents)}</span></div>}
        <div className="flex justify-between font-display text-2xl font-bold"><span>Total do serviço</span><span className="text-brand-light">{money(o.totalCents)}</span></div>
      </div>
      {adding && <ItemModal order={o} sellsParts={sellsParts} onClose={() => setAdding(false)} onSaved={() => { setAdding(false); onChanged(); }} />}
      {edit && <ItemModal order={o} item={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); onChanged(); }} />}
    </Card>
  );
}

// Price typed right in the list (e.g. the diagnosis value the mechanic tells the customer)
function PriceCell({ order, item, onSaved }) {
  const toast = useToast();
  const fromItem = item.unitPriceCents ? centsToInput(item.unitPriceCents) : '';
  const [val, setVal] = useState(fromItem);
  const [saving, setSaving] = useState(false);
  useEffect(() => { setVal(fromItem); }, [fromItem]);
  async function commit() {
    const cents = parseMoney(val) ?? 0;
    if (cents === item.unitPriceCents) { setVal(fromItem); return; }
    setSaving(true);
    try {
      await api.patch(`/admin/orders/${order.id}/items/${item.id}`, { unitPriceCents: cents });
      toast('Valor salvo.');
      onSaved();
    } catch (e) { toast(e.message, 'bad'); setVal(fromItem); } finally { setSaving(false); }
  }
  return (
    <label className={cx('inline-flex items-center gap-1 rounded-lg border bg-surface-2 px-2 min-h-11 focus-within:border-brand-light', item.unitPriceCents ? 'border-line' : 'border-warn bg-warn/10', saving && 'opacity-60')}>
      <input inputMode="decimal" enterKeyHint="done" value={val} placeholder="definir" disabled={saving}
        onChange={(e) => setVal(e.target.value.replace(/[^\d,.]/g, ''))}
        onBlur={commit}
        onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
        aria-label={`Valor de ${item.description}`}
        className="w-20 bg-transparent text-right outline-none text-[16px] font-semibold placeholder:text-warn placeholder:font-normal" />
    </label>
  );
}

function ItemModal({ order, item, sellsParts, onClose, onSaved }) {
  const toast = useToast();
  const services = useQuery({ queryKey: ['services'], queryFn: () => api.get('/admin/services'), enabled: !item });
  const parts = useQuery({ queryKey: ['parts', ''], queryFn: () => api.get('/admin/parts'), enabled: !item && sellsParts });
  const [type, setType] = useState(item?.type || 'LABOR');
  const [ref, setRef] = useState('');
  const [description, setDescription] = useState(item?.description || '');
  const [qty, setQty] = useState(item?.quantity || 1);
  const [price, setPrice] = useState(item ? centsToInput(item.unitPriceCents) : '');
  const [cost, setCost] = useState(item ? centsToInput(item.unitCostCents) : '');
  const [busy, setBusy] = useState(false);

  function pickRef(v) {
    setRef(v);
    if (!v) return;
    if (type === 'LABOR') {
      const s = services.data?.services.find((x) => x.id === Number(v));
      if (s) { setDescription(s.name); setPrice(centsToInput(s.basePriceCents)); }
    } else {
      const p = parts.data?.parts.find((x) => x.id === Number(v));
      if (p) { setDescription(p.name); setPrice(centsToInput(p.priceCents)); setCost(centsToInput(p.costCents)); }
    }
  }

  async function save() {
    const unitPriceCents = parseMoney(price);
    if (!description.trim()) return toast('Descreva o serviço.', 'bad');
    if (unitPriceCents === null) return toast('Informe o valor.', 'bad');
    setBusy(true);
    try {
      const body = { description: description.trim(), quantity: Number(qty) || 1, unitPriceCents, unitCostCents: parseMoney(cost) ?? 0 };
      if (item) await api.patch(`/admin/orders/${order.id}/items/${item.id}`, body);
      else await api.post(`/admin/orders/${order.id}/items`, { ...body, type, ...(ref ? (type === 'LABOR' ? { serviceId: Number(ref) } : { partId: Number(ref) }) : {}) });
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
    return undefined;
  }

  return (
    <Modal open onClose={onClose} title={item ? 'Editar item' : 'Adicionar serviço'} footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Salvar</Button></>}>
      <div className="grid gap-3">
        {!item && sellsParts && <Segmented value={type} onChange={(v) => { setType(v); setRef(''); }} options={[{ value: 'LABOR', label: 'Mão de obra' }, { value: 'PART', label: 'Peça do estoque' }]} />}
        {!item && type === 'LABOR' && (
          <Select label="Serviço da tabela" value={ref} onChange={(e) => pickRef(e.target.value)}>
            <option value="">Outro (digitar)</option>{services.data?.services.filter((s) => s.active).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        )}
        {!item && type === 'PART' && (
          <Select label="Peça do estoque" value={ref} onChange={(e) => pickRef(e.target.value)} hint="Peças do estoque saem automaticamente quando o orçamento é aprovado.">
            <option value="">Outra (digitar)</option>{parts.data?.parts.filter((p) => p.active).map((p) => <option key={p.id} value={p.id}>{p.name} · {p.stock} em estoque</option>)}
          </Select>
        )}
        <Input label="Descrição" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={200} placeholder="Ex.: Troca das pastilhas dianteiras" />
        <div className="grid grid-cols-3 gap-3">
          <Input label="Qtd" inputMode="numeric" value={qty} onChange={(e) => setQty(e.target.value.replace(/\D/g, '').slice(0, 3))} />
          <Input label="Valor unit. (R$)" inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="0,00" />
          {(type === 'PART' || item?.type === 'PART') && <Input label="Custo unit. (R$)" inputMode="decimal" value={cost} onChange={(e) => setCost(e.target.value)} placeholder="0,00" />}
        </div>
      </div>
    </Modal>
  );
}

// Parts the customer buys at a parts store and brings to the shop (not charged by the shop)
function CustomerParts({ order: o, editable, onChanged }) {
  const toast = useToast();
  const [picked, setPicked] = useState(null);
  const [edit, setEdit] = useState(null);
  const list = o.customerParts || [];
  // While the quote is being built, the catalog stays open; after it is sent it folds away
  const [showCatalog, setShowCatalog] = useState(['OPEN', 'DIAGNOSIS'].includes(o.status) || o.quoteStatus === 'DRAFT');
  async function remove(itemId) {
    try { await api.del(`/admin/orders/${o.id}/items/${itemId}`); onChanged(); } catch (e) { toast(e.message, 'bad'); }
  }
  return (
    <Card>
      <div className="flex items-start justify-between gap-3 mb-3">
        <div>
          <h2 className="font-display text-2xl font-bold uppercase">Peças para o cliente comprar</h2>
          <p className="text-xs text-muted">Vão no orçamento com foto. Não entram no valor do serviço.</p>
        </div>
        {editable && !showCatalog && <Button size="sm" variant="primary" icon={Plus} onClick={() => setShowCatalog(true)}>Peça</Button>}
      </div>
      {list.length === 0 ? <p className="text-sm text-muted">{editable ? 'Nenhuma peça ainda. Escolha no catálogo abaixo.' : 'Nenhuma peça.'}</p> : (
        <ul className="grid grid-cols-[minmax(0,1fr)] gap-2">
          {list.map((i) => (
            <li key={i.id} className="flex items-center gap-3 rounded-xl border border-line bg-surface-2 p-2 min-w-0">
              <PartThumb url={i.imageUrl} className="h-14 w-14" />
              <button type="button" disabled={!editable} onClick={() => setEdit(i)} className="flex-1 min-w-0 text-left focus-ring rounded disabled:cursor-default">
                <span className="font-semibold block truncate">{i.quantity > 1 ? `${i.quantity}x ` : ''}{i.description}</span>
                {i.notes && <span className="text-xs text-muted block truncate">{i.notes}</span>}
                {i.estimatedPriceCents ? <span className="text-xs text-steel">estimado {money(i.estimatedPriceCents * i.quantity)}</span> : null}
              </button>
              {editable && <Button size="sm" variant="ghost" aria-label="Remover peça" onClick={() => remove(i.id)}><Trash2 className="h-4 w-4" /></Button>}
            </li>
          ))}
        </ul>
      )}
      {o.customerPartsEstimateCents > 0 && <p className="text-sm text-muted mt-3">Estimativa das peças (o cliente paga na loja): <span className="text-fg font-semibold">{money(o.customerPartsEstimateCents)}</span></p>}
      {editable && showCatalog && (
        <div className="mt-4 pt-4 border-t border-line">
          <div className="flex items-center justify-between mb-2">
            <p className="font-semibold">Catálogo de peças</p>
            <Button size="sm" variant="ghost" onClick={() => setShowCatalog(false)}>Fechar catálogo</Button>
          </div>
          <p className="text-xs text-muted mb-3">Toque na peça que o cliente precisa comprar.</p>
          <div className="max-h-[28rem] overflow-y-auto pr-1">
            <CatalogPicker onPick={setPicked} embedded />
          </div>
        </div>
      )}
      {picked && <CustomerPartModal order={o} part={picked} onClose={() => setPicked(null)} onSaved={() => { setPicked(null); onChanged(); }} />}
      {edit && <CustomerPartModal order={o} item={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); onChanged(); }} />}
    </Card>
  );
}

function CustomerPartModal({ order, item, part: initialPart, onClose, onSaved }) {
  const toast = useToast();
  const [part, setPart] = useState(item ? { id: item.catalogPartId, name: item.description, imageUrl: item.imageUrl } : initialPart || null);
  const [qty, setQty] = useState(item?.quantity || 1);
  const [notes, setNotes] = useState(item?.notes || '');
  const [estimate, setEstimate] = useState(item?.estimatedPriceCents ? centsToInput(item.estimatedPriceCents) : '');
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      const body = { quantity: Number(qty) || 1, notes: notes.trim() || null, estimatedPriceCents: parseMoney(estimate) };
      if (item) await api.patch(`/admin/orders/${order.id}/items/${item.id}`, body);
      else await api.post(`/admin/orders/${order.id}/items`, { ...body, type: 'CUSTOMER_PART', catalogPartId: part.id });
      onSaved();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
  }
  if (!part) {
    return (
      <Modal open onClose={onClose} title="Escolher peça" wide>
        <CatalogPicker onPick={setPart} />
      </Modal>
    );
  }
  return (
    <Modal open onClose={onClose} title={item ? 'Editar peça' : 'Peça para comprar'} footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>{item ? 'Salvar' : 'Adicionar ao orçamento'}</Button></>}>
      <div className="grid gap-4">
        <div className="flex items-center gap-3">
          <PartThumb url={part.imageUrl} className="h-20 w-20" />
          <div className="flex-1">
            <p className="font-semibold">{part.name}</p>
            {part.description && <p className="text-xs text-muted">{part.description}</p>}
          </div>
          {!item && <Button size="sm" onClick={() => setPart(null)}>Trocar</Button>}
        </div>
        <div className="grid grid-cols-3 gap-3">
          <Input label="Quantidade" inputMode="numeric" value={qty} onChange={(e) => setQty(e.target.value.replace(/\D/g, '').slice(0, 3))} />
          <Input className="col-span-2" label="Valor estimado (opcional)" inputMode="decimal" value={estimate} onChange={(e) => setEstimate(e.target.value)} placeholder="Ex.: 45,00" hint="Só para o cliente ter uma ideia. Não soma no serviço." />
        </div>
        <Input label="Observação para o cliente" value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={200} placeholder="Ex.: dianteira, medida 90/90-18, original ou paralela" />
      </div>
    </Modal>
  );
}

// Share the quote: PDF through the phone's share menu (WhatsApp, e-mail...) or a link in WhatsApp
function SendQuote({ order: o, quoteLink, onChanged }) {
  const toast = useToast();
  const [file, setFile] = useState(null);
  const version = `${o.updatedAt}-${o.items.length}-${o.totalCents}`;
  useEffect(() => {
    if (DEMO) return undefined;
    let alive = true;
    setFile(null);
    api.raw(`/admin/orders/${o.id}/pdf?type=quote`).then((r) => r.blob()).then((b) => {
      if (alive) setFile(new File([b], `orcamento-${String(o.number).padStart(5, '0')}-natan-motos.pdf`, { type: 'application/pdf' }));
    }).catch(() => {});
    return () => { alive = false; };
  }, [o.id, o.number, version]);

  const markSent = async () => {
    if (['OPEN', 'DIAGNOSIS'].includes(o.status) || o.quoteStatus === 'DRAFT') {
      try { await api.post(`/admin/orders/${o.id}/send-quote`); onChanged(); } catch { /* already decided */ }
    }
  };
  const canDecide = ['OPEN', 'DIAGNOSIS', 'WAITING_APPROVAL'].includes(o.status);

  function sharePdf() {
    if (DEMO) {
      showDemoModal({ title: 'Enviar PDF', note: 'No celular, abre o menu de compartilhar com o PDF já anexado. Você escolhe o WhatsApp e a conversa do cliente, e toca em enviar.', html: null, text: `Arquivo: orcamento-${String(o.number).padStart(5, '0')}-natan-motos.pdf` });
      markSent();
      return;
    }
    if (!file) { toast('Preparando o PDF, tente de novo em um instante.', 'bad'); return; }
    const data = { files: [file], title: `Orçamento ${o.number}`, text: `Orçamento da sua moto ${o.motorcycle.brand} ${o.motorcycle.model}. Qualquer dúvida, é só chamar.` };
    if (navigator.canShare?.(data)) {
      navigator.share(data).then(markSent).catch(() => {});
    } else {
      const url = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = url; a.download = file.name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
      toast('PDF baixado. Anexe na conversa do cliente no WhatsApp.');
      markSent();
    }
  }

  return (
    <Card className="grid gap-3 border-brand/50">
      <div>
        <h2 className="font-display text-2xl font-bold uppercase">Enviar orçamento ao cliente</h2>
        <p className="text-sm text-muted">
          {o.quoteStatus === 'DRAFT' && 'Ainda não enviado.'}
          {o.quoteStatus === 'SENT' && `Enviado${o.quoteSentAt ? ` em ${fmtDateTime(o.quoteSentAt)}` : ''}. Aguardando o cliente aprovar.`}
          {o.quoteStatus === 'APPROVED' && 'O cliente aprovou.'}
          {o.quoteStatus === 'REJECTED' && 'O cliente recusou. Ajuste e envie de novo, se for o caso.'}
        </p>
      </div>
      <div className="grid sm:grid-cols-2 gap-2">
        <Button variant="primary" icon={Share2} onClick={sharePdf} disabled={!DEMO && !file}>{!DEMO && !file ? 'Preparando PDF…' : 'Enviar PDF'}</Button>
        {canDecide && <Button icon={MessageCircle} onClick={() => sendWhatsApp({ template: 'quoteReady', orderId: o.id }, toast, () => api.post(`/admin/orders/${o.id}/send-quote`)).then(onChanged)}>Enviar link no WhatsApp</Button>}
        <Button icon={FileText} onClick={() => openFile(`/admin/orders/${o.id}/pdf?type=quote`).catch((e) => toast(e.message, 'bad'))}>Ver PDF</Button>
        {o.quoteStatus !== 'DRAFT' && <Button icon={Copy} onClick={async () => { try { await navigator.clipboard.writeText(quoteLink); toast('Link do orçamento copiado.'); } catch { toast('Não deu para copiar.', 'bad'); } }}>Copiar link</Button>}
      </div>
      <p className="text-xs text-muted">“Enviar PDF” abre o compartilhar do celular com o arquivo anexado: escolha o WhatsApp e o cliente. “Enviar link” abre a conversa do cliente com o link do orçamento, onde ele vê as peças, baixa o PDF e aprova.</p>
    </Card>
  );
}

function Payments({ order: o, onChanged, canDelete }) {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('PIX');
  const [installments, setInstallments] = useState(1);
  const [busy, setBusy] = useState(false);
  async function save() {
    const cents = parseMoney(amount);
    if (!cents) return toast('Informe o valor.', 'bad');
    setBusy(true);
    try {
      await api.post(`/admin/orders/${o.id}/payments`, { amountCents: cents, method, installments: Number(installments) });
      toast('Pagamento registrado.');
      setOpen(false);
      onChanged();
    } catch (e) { toast(e.message, 'bad'); } finally { setBusy(false); }
    return undefined;
  }
  async function remove(pid) {
    try { await api.del(`/admin/orders/${o.id}/payments/${pid}`); onChanged(); } catch (e) { toast(e.message, 'bad'); }
  }
  return (
    <Card>
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-2xl font-bold uppercase">Pagamentos</h2>
        {o.status !== 'CANCELLED' && <Button size="sm" variant="primary" icon={Wallet} onClick={() => { setAmount(centsToInput(Math.max(0, o.balanceCents))); setOpen(true); }}>Receber</Button>}
      </div>
      {o.payments.length === 0 ? <p className="text-sm text-muted">Nenhum pagamento registrado.</p> : (
        <ul className="divide-y divide-line text-sm">
          {o.payments.map((p) => (
            <li key={p.id} className="flex items-center justify-between gap-2 py-2">
              <span>{METHOD_LABEL[p.method]}{p.method === 'CREDIT' && p.installments > 1 ? ` ${p.installments}x` : ''} <span className="text-muted">· {fmtDateTime(p.paidAt)}{p.receivedByName ? ` · ${p.receivedByName}` : ''}</span></span>
              <span className="flex items-center gap-1 font-semibold">{money(p.amountCents)}{canDelete && <Button size="sm" variant="ghost" aria-label="Apagar pagamento" onClick={() => remove(p.id)}><Trash2 className="h-4 w-4" /></Button>}</span>
            </li>
          ))}
        </ul>
      )}
      <div className="mt-3 pt-3 border-t border-line flex justify-between text-sm">
        <span className="text-muted">Pago {money(o.paidCents)} de {money(o.totalCents)}</span>
        <span className={cx('font-semibold', o.balanceCents > 0 ? 'text-warn' : 'text-ok')}>{o.balanceCents > 0 ? `Falta ${money(o.balanceCents)}` : <span className="inline-flex items-center gap-1"><CheckCircle2 className="h-4 w-4" />Quitado</span>}</span>
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Registrar pagamento" footer={<><Button onClick={() => setOpen(false)}>Cancelar</Button><Button variant="primary" loading={busy} onClick={save}>Registrar</Button></>}>
        <div className="grid gap-3">
          <Input label="Valor (R$)" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)}
            hint={o.totalCents === 0 ? 'Esta OS ainda não tem serviços com valor. Lance os serviços antes de receber.' : `Falta receber ${money(Math.max(0, o.balanceCents))}.`} />
          <div className="grid grid-cols-4 gap-2">
            {Object.entries(METHOD_LABEL).map(([k, v]) => (
              <button key={k} type="button" aria-pressed={method === k} onClick={() => setMethod(k)} className={cx('min-h-11 rounded-xl text-sm font-semibold border focus-ring', method === k ? 'glass-btn glass-btn-primary' : 'card')}>{v}</button>
            ))}
          </div>
          {method === 'CREDIT' && (
            <Select label="Parcelas" value={installments} onChange={(e) => setInstallments(e.target.value)}>
              {Array.from({ length: 12 }, (_, i) => <option key={i + 1} value={i + 1}>{i + 1}x</option>)}
            </Select>
          )}
        </div>
      </Modal>
    </Card>
  );
}
