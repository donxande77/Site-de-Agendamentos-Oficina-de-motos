import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { CalendarDays, Wallet, TrendingUp, Receipt, Gauge, AlertTriangle, Bell, Package, Wrench, UserX, ShieldAlert } from 'lucide-react';
import { api } from '../../lib/api.js';
import { Card, Stat, Spinner, ErrorBox, Badge, Empty } from '../../components/ui.jsx';
import { money, fmtTime, plateMask, BOOKING_STATUS, ORDER_STATUS, SOURCE_LABEL } from '../../lib/format.js';
import { PageHeader, useAuth, CHART } from './shared.jsx';

const MONTHS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const pct = (v) => `${Math.round(v * 100)}%`;

export default function Dashboard() {
  const { theme, user } = useAuth();
  const admin = user.role === 'OWNER';
  const c = CHART[theme];
  const { data: d, isLoading, error, refetch } = useQuery({ queryKey: ['dashboard'], queryFn: () => api.get('/admin/dashboard'), refetchInterval: 60_000 });
  if (isLoading) return <Spinner />;
  if (error) return <ErrorBox error={error} onRetry={refetch} />;

  const diff = d.revenueLastMonthCents ? (d.revenueMonthCents - d.revenueLastMonthCents) / d.revenueLastMonthCents : null;
  const inShopTotal = Object.values(d.inShop).reduce((a, b) => a + b, 0);
  const sources = ['instagram', 'whatsapp', 'direct', 'walk_in'];
  const totalSrc = sources.reduce((a, s) => a + (d.bySource[s] || 0), 0);
  const backupAlert = admin && d.backup?.configured && !d.backup.healthy;
  const priceAlert = admin && d.servicesWithoutPrice > 0;
  const history = d.revenueHistory.map((h) => ({ ...h, label: MONTHS[Number(h.month.slice(5)) - 1], value: h.totalCents / 100 }));

  return (
    <div>
      <PageHeader title="Painel" sub="Como está a oficina hoje e no mês." />

      {(priceAlert || d.lowStock > 0 || d.remindersDue > 0 || backupAlert) && (
        <div className="grid sm:grid-cols-3 gap-2 mb-4">
          {backupAlert && <Alert to="/admin/configuracoes?aba=backup" icon={ShieldAlert}>Backup precisa de atenção: {d.backup.problems[0]}</Alert>}
          {priceAlert && <Alert to="/admin/servicos" icon={Wrench}>{d.servicesWithoutPrice} serviço(s) sem preço no site. Defina os valores.</Alert>}
          {d.lowStock > 0 && <Alert to="/admin/pecas" icon={Package}>{d.lowStock} peça(s) com estoque baixo.</Alert>}
          {d.remindersDue > 0 && <Alert to="/admin/lembretes" icon={Bell}>{d.remindersDue} lembrete(s) de revisão para enviar.</Alert>}
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Stat label="Hoje" value={money(d.revenueTodayCents)} sub="recebido hoje" icon={Wallet} />
        <Stat label="No mês" value={money(d.revenueMonthCents)} icon={TrendingUp} tone="brand"
          sub={diff === null ? 'sem dados do mês passado' : `${diff >= 0 ? '▲' : '▼'} ${pct(Math.abs(diff))} vs. mesmo período do mês passado (${money(d.revenueLastMonthCents)})`} />
        <Stat label="Lucro do mês" value={money(d.profitMonthCents)} sub="recebido − peças − despesas" icon={Receipt} />
        <Stat label="Ticket médio" value={money(d.avgTicketCents)} sub={`${d.deliveredThisMonth} OS entregue(s) no mês`} icon={Gauge} />
      </div>

      <div className="grid lg:grid-cols-[1.3fr_1fr] gap-4 mt-4">
        <Card>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display text-2xl font-bold uppercase">Agenda de hoje</h2>
            <Link to="/admin/agenda" className="text-sm text-brand-light font-semibold hover:underline">Abrir agenda →</Link>
          </div>
          {d.todayBookings.length === 0 ? <Empty icon={CalendarDays} title="Nenhum agendamento hoje" /> : (
            <ul className="divide-y divide-line">
              {d.todayBookings.map((b) => (
                <li key={b.id} className="flex items-center gap-3 py-2.5">
                  <span className="font-display text-xl font-bold w-14">{fmtTime(b.startAt)}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{b.customerName}</p>
                    <p className="text-sm text-muted truncate">{b.brand} {b.model} · {plateMask(b.plate)} · {b.bayName}</p>
                  </div>
                  <Badge tone={BOOKING_STATUS[b.status].tone}>{BOOKING_STATUS[b.status].label}</Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display text-2xl font-bold uppercase">Motos na oficina</h2>
            <span className="font-display text-3xl font-bold text-brand-light">{inShopTotal}</span>
          </div>
          {inShopTotal === 0 ? <p className="text-sm text-muted">Nenhuma moto em serviço agora.</p> : (
            <ul className="grid gap-2">
              {Object.entries(d.inShop).map(([s, n]) => (
                <li key={s}><Link to={`/admin/os?status=${s}`} className="flex justify-between items-center text-sm hover:text-brand-light"><Badge tone={ORDER_STATUS[s].tone}>{ORDER_STATUS[s].label}</Badge><span className="font-semibold">{n}</span></Link></li>
              ))}
            </ul>
          )}
          <div className="grid grid-cols-2 gap-3 mt-5 pt-4 border-t border-line">
            <div><p className="text-xs text-muted uppercase font-semibold">Ocupação da semana</p><p className="font-display text-2xl font-bold">{pct(d.occupancy)}</p><p className="text-xs text-muted">dos elevadores</p></div>
            <div><p className="text-xs text-muted uppercase font-semibold flex items-center gap-1"><UserX className="h-3.5 w-3.5" />Faltas (30 dias)</p><p className="font-display text-2xl font-bold">{pct(d.noShowRate)}</p><p className="text-xs text-muted">dos agendamentos</p></div>
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-[1.3fr_1fr] gap-4 mt-4">
        <Card>
          <h2 className="font-display text-2xl font-bold uppercase">Recebido por mês</h2>
          <p className="text-sm text-muted mb-3">Últimos 6 meses, em R$</p>
          {history.every((h) => !h.totalCents) ? <p className="h-64 flex items-center justify-center text-sm text-muted text-center">Os recebimentos aparecem aqui conforme você registra os pagamentos nas OS.</p> : <div className="h-64" role="img" aria-label={`Recebido por mês: ${history.map((h) => `${h.label} ${money(h.totalCents)}`).join(', ')}`}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={history} margin={{ top: 8, right: 4, left: 0, bottom: 0 }} barCategoryGap="28%">
                <CartesianGrid vertical={false} stroke={c.grid} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: c.axis, fontSize: 12 }} />
                <YAxis allowDecimals={false} domain={[0, 'auto']} tickLine={false} axisLine={false} width={56} tick={{ fill: c.axis, fontSize: 12 }} tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mil` : v)} />
                <Tooltip cursor={{ fill: c.grid }} contentStyle={{ background: c.surface, border: '1px solid rgba(127,127,127,.3)', borderRadius: 12 }}
                  formatter={(v) => [money(v * 100), 'Recebido']} labelStyle={{ color: c.axis }} />
                <Bar dataKey="value" fill={c.in} radius={[4, 4, 0, 0]} maxBarSize={44} />
              </BarChart>
            </ResponsiveContainer>
          </div>}
        </Card>

        <div className="grid gap-4">
          <Card>
            <h2 className="font-display text-2xl font-bold uppercase mb-3">De onde vêm os clientes</h2>
            <p className="text-xs text-muted -mt-2 mb-3">Agendamentos criados nos últimos 30 dias</p>
            <ul className="grid gap-2.5">
              {sources.map((s) => {
                const n = d.bySource[s] || 0;
                const w = totalSrc ? (n / totalSrc) * 100 : 0;
                return (
                  <li key={s} className="text-sm">
                    <div className="flex justify-between mb-1"><span>{SOURCE_LABEL[s]}</span><span className="font-semibold">{n} <span className="text-muted font-normal">({Math.round(w)}%)</span></span></div>
                    <div className="h-2 rounded-full bg-surface-2 overflow-hidden"><div className="h-full rounded-full" style={{ width: `${w}%`, background: c.in }} /></div>
                  </li>
                );
              })}
            </ul>
          </Card>
          <Card>
            <h2 className="font-display text-2xl font-bold uppercase mb-3">Serviços mais pedidos</h2>
            {d.topServices.length === 0 ? <p className="text-sm text-muted">Ainda sem agendamentos neste mês.</p> : (
              <ol className="grid grid-cols-[minmax(0,1fr)] gap-2 text-sm">
                {d.topServices.map((s, i) => (
                  <li key={s.name} className="flex items-start justify-between gap-3 min-w-0">
                    <span className="min-w-0 break-words"><span className="text-muted">{i + 1}.</span> {s.name}</span>
                    <span className="font-semibold shrink-0">{s.n}</span>
                  </li>
                ))}
              </ol>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

const Alert = ({ to, icon: Icon, children }) => (
  <Link to={to} className="card flex items-center gap-3 p-3 text-sm border-warn/40 hover:border-warn">
    <AlertTriangle className="h-5 w-5 text-warn shrink-0" aria-hidden /><span className="flex-1">{children}</span><Icon className="h-4 w-4 text-muted" aria-hidden />
  </Link>
);
