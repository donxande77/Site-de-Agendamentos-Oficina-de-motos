import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { MessageCircle, Copy } from 'lucide-react';
import { Modal, Button, useToast } from './ui.jsx';

// Demo-only chrome: a slim banner to jump between site and panel, and a preview modal
// for things the real app does outside the page (WhatsApp, PDFs, downloads).
export default function DemoChrome() {
  const nav = useNavigate();
  const loc = useLocation();
  const qc = useQueryClient();
  const toast = useToast();
  const [modal, setModal] = useState(null);
  const inAdmin = loc.pathname.startsWith('/admin');
  // Links inside a message (quote, booking page) can be opened right here in the demo
  const linkMatch = modal?.text?.match(/https?:\/\/\S+?\/(orcamento|meu-agendamento)\/([\w-]+)/);
  const customerPath = linkMatch ? `/${linkMatch[1]}/${linkMatch[2]}` : null;

  useEffect(() => {
    const on = (e) => setModal(e.detail);
    window.addEventListener('nm-demo-modal', on);
    return () => window.removeEventListener('nm-demo-modal', on);
  }, []);

  async function reset() {
    if (import.meta.env.VITE_DEMO !== '1') return;
    const { resetDemo } = await import('../lib/mock.js');
    resetDemo();
    qc.clear();
    nav('/');
    toast('Demonstração reiniciada com os dados de exemplo.');
  }

  return (
    <>
      <div data-demo-banner className="bg-brand-deep text-white text-xs sm:text-sm">
        <div className="mx-auto max-w-5xl px-4 py-2 flex flex-wrap items-center justify-between gap-x-4 gap-y-1">
          <span><strong>Demonstração</strong> · dados de exemplo, nada é enviado de verdade</span>
          <span className="flex gap-3 font-semibold">
            <button type="button" className="underline underline-offset-2 focus-ring rounded" onClick={() => nav(inAdmin ? '/' : '/admin')}>{inAdmin ? 'Ver site do cliente' : 'Abrir painel da oficina'}</button>
            <button type="button" className="underline underline-offset-2 opacity-80 focus-ring rounded" onClick={reset}>Recomeçar</button>
          </span>
        </div>
      </div>
      <Modal open={Boolean(modal)} onClose={() => setModal(null)} title={modal?.title || ''} wide={Boolean(modal?.html)}
        footer={<>
          {modal?.text && !modal?.html && (
            <Button icon={Copy} onClick={async () => { try { await navigator.clipboard.writeText(modal.text); toast('Texto copiado.'); } catch { toast('Não deu para copiar.', 'bad'); } }}>Copiar</Button>
          )}
          {customerPath && <Button onClick={() => { setModal(null); nav(customerPath); }}>Ver como o cliente vê</Button>}
          {modal?.waUrl && <a href={modal.waUrl} target="_blank" rel="noopener noreferrer" className="glass-btn glass-btn-primary inline-flex items-center gap-2 min-h-12 px-5 rounded-xl font-semibold"><MessageCircle className="h-4 w-4" />Abrir no WhatsApp</a>}
          <Button onClick={() => setModal(null)}>Fechar</Button>
        </>}>
        {modal?.note && <p className="text-sm text-muted mb-3">{modal.note}</p>}
        {modal?.image && <img src={modal.image} alt={modal.title} className="mx-auto w-64 h-64 rounded-xl bg-white p-2" />}
        {modal?.html && <div className="rounded-xl overflow-hidden bg-white text-black" dangerouslySetInnerHTML={{ __html: modal.html }} />}
        {modal?.text && !modal?.html && <p className="whitespace-pre-wrap rounded-xl bg-surface-2 border border-line p-4 text-sm">{modal.text}</p>}
        {modal?.pre && <pre className="text-xs whitespace-pre-wrap break-all rounded-xl bg-surface-2 border border-line p-3 max-h-80 overflow-auto">{modal.pre}</pre>}
      </Modal>
    </>
  );
}
