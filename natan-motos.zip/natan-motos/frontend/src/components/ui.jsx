import { createContext, useCallback, useContext, useEffect, useId, useRef, useState } from 'react';
import { Loader2, X, CheckCircle2, AlertTriangle, Info } from 'lucide-react';
import logoSrc from '../assets/logo.png';

const cx = (...c) => c.filter(Boolean).join(' ');
export { cx };

// ---------- Buttons (glass) ----------
export function Button({ variant = 'secondary', size = 'md', loading, className, children, icon: Icon, ...props }) {
  const sizes = { sm: 'min-h-9 px-3 text-sm rounded-[10px] gap-1.5', md: 'min-h-12 px-5 text-[15px] rounded-xl gap-2', lg: 'min-h-14 px-6 text-base rounded-2xl gap-2.5', icon: 'h-11 w-11 rounded-full' };
  const variants = { primary: 'glass-btn glass-btn-primary', secondary: 'glass-btn', danger: 'glass-btn glass-btn-danger', ghost: 'text-steel hover:text-fg hover:bg-white/5 rounded-xl focus-ring' };
  return (
    <button
      type="button"
      className={cx('inline-flex items-center justify-center font-semibold select-none cursor-pointer', sizes[size], variants[variant], className)}
      disabled={loading || props.disabled}
      {...props}
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : Icon ? <Icon className="h-[1.1em] w-[1.1em] shrink-0" aria-hidden /> : null}
      {children}
    </button>
  );
}

export function LinkButton({ variant = 'secondary', size = 'md', className, children, icon: Icon, ...props }) {
  const sizes = { sm: 'min-h-9 px-3 text-sm rounded-[10px] gap-1.5', md: 'min-h-12 px-5 text-[15px] rounded-xl gap-2', lg: 'min-h-14 px-6 text-base rounded-2xl gap-2.5' };
  const variants = { primary: 'glass-btn glass-btn-primary', secondary: 'glass-btn' };
  return (
    <a className={cx('inline-flex items-center justify-center font-semibold no-underline', sizes[size], variants[variant], className)} {...props}>
      {Icon ? <Icon className="h-[1.1em] w-[1.1em] shrink-0" aria-hidden /> : null}
      {children}
    </a>
  );
}

// ---------- Form fields ----------
export function Field({ label, hint, error, children, className, required }) {
  const id = useId();
  const child = typeof children === 'function' ? children({ id, 'aria-invalid': error ? 'true' : undefined, 'aria-describedby': error || hint ? `${id}-d` : undefined }) : children;
  return (
    <div className={cx('flex flex-col gap-1.5', className)}>
      {label && (
        <label htmlFor={id} className="text-sm font-medium text-steel">
          {label}{required && <span className="text-brand-light"> *</span>}
        </label>
      )}
      {child}
      {(error || hint) && (
        <p id={`${id}-d`} className={cx('text-xs', error ? 'text-bad' : 'text-muted')}>{error || hint}</p>
      )}
    </div>
  );
}

export const Input = ({ label, hint, error, className, required, ...props }) => (
  <Field label={label} hint={hint} error={error} className={className} required={required}>
    {(a) => <input className="input" required={required} {...a} {...props} />}
  </Field>
);

export const Textarea = ({ label, hint, error, className, ...props }) => (
  <Field label={label} hint={hint} error={error} className={className}>
    {(a) => <textarea className="input min-h-24 resize-y" {...a} {...props} />}
  </Field>
);

export const Select = ({ label, hint, error, className, children, ...props }) => (
  <Field label={label} hint={hint} error={error} className={className}>
    {(a) => <select className="input" {...a} {...props}>{children}</select>}
  </Field>
);

export function Checkbox({ label, description, checked, onChange, className, ...props }) {
  const id = useId();
  return (
    <label htmlFor={id} className={cx('flex items-start gap-3 cursor-pointer select-none', className)}>
      <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="mt-0.5 h-5 w-5 shrink-0 accent-[#3358D4] focus-ring" {...props} />
      <span className="text-sm leading-snug">
        <span className="text-fg">{label}</span>
        {description && <span className="block text-muted mt-0.5">{description}</span>}
      </span>
    </label>
  );
}

// ---------- Display ----------
export const Card = ({ className, children, ...props }) => <div className={cx('card p-4 sm:p-5 min-w-0', className)} {...props}>{children}</div>;

const TONES = {
  brand: 'bg-brand/20 text-brand-light border-brand/40',
  ok: 'bg-ok/15 text-ok border-ok/40',
  warn: 'bg-warn/15 text-warn border-warn/40',
  bad: 'bg-bad/15 text-bad border-bad/40',
  muted: 'bg-white/5 text-steel border-line',
};
export const Badge = ({ tone = 'muted', children, className }) => (
  <span className={cx('inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap', TONES[tone], className)}>{children}</span>
);

export const Spinner = ({ className, label = 'Carregando…' }) => (
  <div className={cx('flex items-center justify-center gap-2 py-10 text-muted', className)} role="status">
    <Loader2 className="h-5 w-5 animate-spin" aria-hidden /> <span className="text-sm">{label}</span>
  </div>
);

export function Skeleton({ className }) {
  return <div className={cx('animate-pulse rounded-xl bg-white/5', className)} aria-hidden />;
}

export const Empty = ({ icon: Icon = Info, title, children, action }) => (
  <div className="flex flex-col items-center text-center gap-2 py-10 px-4">
    <div className="h-12 w-12 rounded-full bg-brand/15 text-brand-light flex items-center justify-center"><Icon className="h-6 w-6" aria-hidden /></div>
    <p className="font-semibold">{title}</p>
    {children && <p className="text-sm text-muted max-w-sm">{children}</p>}
    {action && <div className="mt-2">{action}</div>}
  </div>
);

export const ErrorBox = ({ error, onRetry }) => (
  <div className="card p-4 flex items-start gap-3 border-bad/40" role="alert">
    <AlertTriangle className="h-5 w-5 text-bad shrink-0 mt-0.5" aria-hidden />
    <div className="flex-1 text-sm">
      <p className="font-semibold">Não deu para carregar.</p>
      <p className="text-muted">{error?.message || 'Tente de novo em instantes.'}</p>
    </div>
    {onRetry && <Button size="sm" onClick={onRetry}>Tentar de novo</Button>}
  </div>
);

// ---------- Modal (solid panel; only its buttons are glass) ----------
export function Modal({ open, onClose, title, children, footer, wide }) {
  const ref = useRef(null);
  // Keep the latest onClose without re-running the effect: parents pass a new function on every
  // render, and re-running it moved focus away on each keystroke (closing the phone keyboard).
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  useEffect(() => {
    if (!open) return undefined;
    const prev = document.activeElement;
    const onKey = (e) => { if (e.key === 'Escape') onCloseRef.current?.(); };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    const t = setTimeout(() => ref.current?.querySelector('input, select, textarea, button')?.focus(), 30);
    return () => { clearTimeout(t); document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; prev?.focus?.(); };
  }, [open]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 p-0 sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose?.()}>
      <div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={cx('card w-full max-h-[92dvh] flex flex-col rounded-b-none sm:rounded-b-[18px] animate-rise', wide ? 'sm:max-w-3xl' : 'sm:max-w-lg')}>
        <div className="flex items-center justify-between gap-3 px-5 pt-4 pb-3 border-b border-line">
          <h2 className="font-display text-2xl font-bold uppercase">{title}</h2>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Fechar"><X className="h-5 w-5" /></Button>
        </div>
        <div className="overflow-y-auto px-5 py-4 flex-1">{children}</div>
        {footer && <div className="px-5 py-3 border-t border-line flex flex-wrap justify-end gap-2 pb-safe">{footer}</div>}
      </div>
    </div>
  );
}

export function ConfirmModal({ open, title, message, confirmLabel = 'Confirmar', danger, onConfirm, onClose, loading }) {
  return (
    <Modal open={open} onClose={onClose} title={title} footer={<>
      <Button onClick={onClose}>Voltar</Button>
      <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm} loading={loading}>{confirmLabel}</Button>
    </>}>
      <p className="text-steel">{message}</p>
    </Modal>
  );
}

// ---------- Toasts ----------
const ToastCtx = createContext(() => {});
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((message, tone = 'ok') => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, message, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed z-[60] top-3 inset-x-0 flex flex-col items-center gap-2 px-4 pointer-events-none" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className="card pointer-events-auto flex items-center gap-2 px-4 py-3 shadow-2xl animate-rise max-w-md w-full">
            {t.tone === 'ok' ? <CheckCircle2 className="h-5 w-5 text-ok shrink-0" /> : <AlertTriangle className="h-5 w-5 text-bad shrink-0" />}
            <span className="text-sm">{t.message}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function Segmented({ options, value, onChange, className }) {
  return (
    <div className={cx('inline-flex rounded-xl border border-line bg-surface-2 p-1 gap-1', className)} role="tablist">
      {options.map((o) => (
        <button key={o.value} type="button" role="tab" aria-selected={value === o.value} onClick={() => onChange(o.value)}
          className={cx('px-3 min-h-9 rounded-[10px] text-sm font-semibold focus-ring', value === o.value ? 'glass-btn glass-btn-primary' : 'text-steel hover:text-fg')}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Stat({ label, value, sub, icon: Icon, tone }) {
  return (
    <Card className="flex flex-col gap-1">
      <div className="flex items-center justify-between text-muted text-xs font-semibold uppercase tracking-wide">
        {label}{Icon && <Icon className="h-4 w-4" aria-hidden />}
      </div>
      <div className={cx('font-display text-[1.6rem] sm:text-3xl font-bold whitespace-nowrap leading-tight', tone === 'brand' && 'text-brand-light')}>{value}</div>
      {sub && <div className="text-xs text-muted">{sub}</div>}
    </Card>
  );
}

export const Logo = ({ className = 'h-10 w-10' }) => <img src={logoSrc} alt="Natan Motos" className={cx('rounded-full', className)} width="320" height="320" />;
