import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { MapPin, Navigation, AtSign, MessageCircle, CalendarPlus, PackageOpen } from 'lucide-react';
import { DEMO, showDemoModal } from '../lib/demo.js';
import { api } from '../lib/api.js';
import { Logo, LinkButton, Button } from './ui.jsx';
import { waUrl } from '../lib/format.js';

export function useShopInfo() {
  return useQuery({ queryKey: ['public-info'], queryFn: () => api.get('/public/info'), staleTime: 60_000 });
}

// Sticky glass header used on every public page
export function PublicHeader({ right, title }) {
  return (
    <header className="glass-bar sticky top-0 z-40 border-b">
      <div className="mx-auto max-w-5xl flex items-center justify-between gap-3 px-4 h-16">
        <Link to="/" className="flex items-center gap-2.5 focus-ring rounded-full">
          <Logo className="h-10 w-10" />
          <span className="font-display text-xl font-extrabold uppercase tracking-wide leading-none">
            {title || <>Natan <span className="text-brand-light">Motos</span></>}
          </span>
        </Link>
        {right}
      </div>
    </header>
  );
}

// Google Maps embed (no API key). Loads lazily; listed in the privacy notice as a third party.
export function MapCard({ info, className = '' }) {
  if (!info) return null;
  const q = encodeURIComponent(info.mapQuery);
  return (
    <div className={`card overflow-hidden ${className}`}>
      {DEMO ? (
        <div className="h-56 sm:h-64 relative flex items-center justify-center" style={{ backgroundImage: 'repeating-linear-gradient(0deg, rgb(255 255 255 / 0.05) 0 1px, transparent 1px 28px), repeating-linear-gradient(90deg, rgb(255 255 255 / 0.05) 0 1px, transparent 1px 28px), radial-gradient(circle at 50% 45%, rgb(51 88 212 / 0.35), transparent 60%)' }}>
          <div className="flex flex-col items-center gap-2 text-center px-6">
            <MapPin className="h-10 w-10 text-brand-light" aria-hidden />
            <p className="text-sm text-steel">No site publicado, o mapa do Google aparece aqui.</p>
          </div>
        </div>
      ) : <iframe
        title={`Mapa: ${info.address}`}
        src={`https://www.google.com/maps?q=${q}&output=embed&hl=pt-BR`}
        className="block w-full h-56 sm:h-64 border-0 grayscale-[35%] contrast-[1.05]"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        allowFullScreen
      />}
      <div className="p-4 flex flex-col gap-3">
        <p className="flex items-start gap-2 text-sm">
          <MapPin className="h-5 w-5 text-brand-light shrink-0" aria-hidden /> <span>{info.address}</span>
        </p>
        <div className="grid grid-cols-2 gap-2">
          <LinkButton size="sm" href={`https://www.google.com/maps/search/?api=1&query=${q}`} target="_blank" rel="noopener noreferrer" icon={MapPin}>Google Maps</LinkButton>
          <LinkButton size="sm" href={`https://waze.com/ul?q=${q}&navigate=yes`} target="_blank" rel="noopener noreferrer" icon={Navigation}>Waze</LinkButton>
        </div>
      </div>
    </div>
  );
}

export function PublicFooter({ info }) {
  return (
    <footer className="border-t border-line mt-12">
      <div className="mx-auto max-w-5xl px-4 py-8 flex flex-col sm:flex-row gap-6 sm:items-center sm:justify-between text-sm text-muted">
        <div className="flex items-center gap-3">
          <Logo className="h-9 w-9" />
          <div>
            <p className="text-fg font-semibold">{info?.shopName || 'Natan Motos'}</p>
            <p>{info?.city}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-5 gap-y-2">
          {info?.instagram && (
            <a className="inline-flex items-center gap-1.5 hover:text-fg focus-ring rounded" href={`https://instagram.com/${info.instagram}`} target="_blank" rel="noopener noreferrer">
              <AtSign className="h-4 w-4" aria-hidden /> @{info.instagram}
            </a>
          )}
          {info?.whatsappNumber && (
            <a className="inline-flex items-center gap-1.5 hover:text-fg focus-ring rounded" href={waUrl(info.whatsappNumber)} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="h-4 w-4" aria-hidden /> WhatsApp
            </a>
          )}
          <Link to="/privacidade" className="hover:text-fg focus-ring rounded">Privacidade</Link>
          <Link to="/admin" className="hover:text-fg focus-ring rounded">Área da oficina</Link>
        </div>
      </div>
    </footer>
  );
}

// "Add to calendar": a real .ics download on the live site; explained in the demo.
export function IcsButton({ token }) {
  if (DEMO) {
    return <Button icon={CalendarPlus} onClick={() => showDemoModal({ title: 'Adicionar à agenda', text: 'No site publicado, este botão baixa um arquivo .ics que o celular abre direto no Google Agenda ou no calendário do iPhone, com lembrete 2 horas antes.' })}>Adicionar à agenda</Button>;
  }
  return <LinkButton href={`/api/v1/public/bookings/${token}/ics`} icon={CalendarPlus}>Adicionar à agenda</LinkButton>;
}

// "Bring your parts" box: the shop's notice plus what each chosen service needs
export function PartsToBring({ notice, services = [], title = 'Traga as peças', compact = false }) {
  const hints = services.filter((s) => s.partsToBring);
  if (!notice && !hints.length) return null;
  return (
    <div className="rounded-2xl border border-warn/40 bg-warn/10 p-4 flex gap-3">
      <PackageOpen className="h-6 w-6 text-warn shrink-0" aria-hidden />
      <div className="text-sm min-w-0">
        <p className="font-semibold text-fg">{hints.length ? title : 'Sobre as peças'}</p>
        {hints.length > 0 && (
          <ul className="mt-1 grid gap-1 text-steel">
            {hints.map((s) => <li key={s.id || s.serviceId || s.name}><span className="text-fg">{s.name}:</span> {s.partsToBring}</li>)}
          </ul>
        )}
        {notice && !compact && <p className="mt-1.5 text-muted">{notice}</p>}
      </div>
    </div>
  );
}
