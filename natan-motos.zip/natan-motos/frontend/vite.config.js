import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// `npm run build:demo` → one self-contained HTML file with sample data (no server).
export default defineConfig(({ mode }) => {
  const demo = mode === 'demo';
  return {
    plugins: [react(), tailwindcss(), ...(demo ? [viteSingleFile()] : [])],
    server: {
      port: 5173,
      proxy: {
        '/api': 'http://localhost:3333',
        '/uploads': 'http://localhost:3333',
      },
    },
    build: demo
      ? { outDir: 'dist-demo', assetsInlineLimit: 1_000_000, chunkSizeWarningLimit: 3000 }
      : {
        chunkSizeWarningLimit: 900,
        rollupOptions: {
          output: {
            manualChunks: { charts: ['recharts'], vendor: ['react', 'react-dom', 'react-router-dom', '@tanstack/react-query'] },
          },
        },
      },
  };
});
