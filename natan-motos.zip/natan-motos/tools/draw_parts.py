"""Draws an original illustration for every part in backend/db/data/catalog-parts.json.

Outputs:
  backend/assets/parts/<slug>.svg and <slug>.png (256 px, used by the site and the PDFs)
  frontend/src/lib/partImages.js (SVG data for the demo build)

Run:  python tools/draw_parts.py   (needs: pip install cairosvg)
"""
import json
import math
from pathlib import Path

import cairosvg

ROOT = Path(__file__).resolve().parent.parent
PARTS = json.loads((ROOT / 'backend/db/data/catalog-parts.json').read_text(encoding='utf-8'))
OUT = ROOT / 'backend/assets/parts'
OUT.mkdir(parents=True, exist_ok=True)

# Palette (logo colours on a light tile so it reads on dark screens and white PDFs)
TILE = '#EEF2FB'
INK = '#1D2A57'
BLUE = '#3358D4'
LBLUE = '#8FA6F0'
STEEL = '#B9C1D1'
DSTEEL = '#7C869B'
RUBBER = '#2B2F36'
WHITE = '#FFFFFF'
AMBER = '#F2B84B'
RED = '#E25555'
GREEN = '#3FBF7F'
COPPER = '#C98A4B'
SW = 4  # stroke width


def S(**kw):
    """attributes helper: stroke ink by default"""
    a = {'stroke': INK, 'stroke-width': SW, 'stroke-linejoin': 'round', 'stroke-linecap': 'round'}
    a.update({k.replace('_', '-'): v for k, v in kw.items()})
    return ' '.join(f'{k}="{v}"' for k, v in a.items())


def rect(x, y, w, h, r=6, fill=STEEL, **kw):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" {S(fill=fill, **kw)}/>'


def circ(cx, cy, r, fill=STEEL, **kw):
    return f'<circle cx="{cx}" cy="{cy}" r="{r}" {S(fill=fill, **kw)}/>'


def path(d, fill='none', **kw):
    return f'<path d="{d}" {S(fill=fill, **kw)}/>'


def line(x1, y1, x2, y2, **kw):
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" {S(**kw)}/>'


def poly(points, fill=STEEL, **kw):
    pts = ' '.join(f'{x:.1f},{y:.1f}' for x, y in points)
    return f'<polygon points="{pts}" {S(fill=fill, **kw)}/>'


def gear(cx, cy, r_out, r_in, teeth, fill=STEEL, hole=0.35, bolts=0):
    pts = []
    for i in range(teeth * 2):
        a = math.pi * i / teeth
        r = r_out if i % 2 == 0 else r_in
        a0 = a - math.pi / teeth * 0.35
        a1 = a + math.pi / teeth * 0.35
        pts += [(cx + r * math.cos(a0), cy + r * math.sin(a0)), (cx + r * math.cos(a1), cy + r * math.sin(a1))]
    g = poly(pts, fill=fill)
    g += circ(cx, cy, r_in * hole, fill=TILE)
    for i in range(bolts):
        a = 2 * math.pi * i / bolts
        g += circ(cx + r_in * 0.62 * math.cos(a), cy + r_in * 0.62 * math.sin(a), r_in * 0.09, fill=TILE, stroke_width=3)
    return g


def chain_links(x0, y0, x1, n, h=16):
    out = ''
    w = (x1 - x0) / n
    for i in range(n):
        x = x0 + i * w
        out += rect(x, y0 - h / 2, w + 4, h, r=h / 2, fill=DSTEEL if i % 2 else STEEL, stroke_width=3)
        out += circ(x + w / 2 + 2, y0, 2.6, fill=INK, stroke_width=0)
    return out


def bottle(label, cap=BLUE, body=WHITE, band=BLUE, handle=True, drop=False):
    g = ''
    if handle:
        g += path('M104 52 h12 a8 8 0 0 1 8 8 v24 a8 8 0 0 1 -8 8 h-12', stroke_width=5)
    g += path('M52 58 Q52 44 66 42 L72 34 h16 L94 42 Q108 44 108 58 V132 a8 8 0 0 1 -8 8 H60 a8 8 0 0 1 -8 -8 Z', fill=body)
    g += rect(70, 22, 20, 14, r=3, fill=cap)
    g += rect(52, 78, 56, 34, r=0, fill=band)
    size = 15 if len(label) <= 6 else 11
    g += f'<text x="80" y="100" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="{size}" fill="{WHITE}">{label}</text>'
    if drop:
        g += path('M128 104 q8 12 0 18 q-8 -6 0 -18 Z', fill=AMBER, stroke_width=3)
    return g


def cable(color=RUBBER):
    g = path('M30 120 C 30 60, 80 140, 90 80 S 130 30, 132 52', stroke=color, stroke_width=7)
    g += path('M30 120 C 30 60, 80 140, 90 80 S 130 30, 132 52', stroke=STEEL, stroke_width=2)
    g += rect(20, 116, 20, 18, r=4, fill=STEEL)
    g += circ(136, 50, 8, fill=STEEL)
    return g


def lever():
    g = path('M30 70 Q60 62 132 92 Q138 96 132 102 Q66 84 36 88 Z', fill=STEEL)
    g += rect(18, 62, 30, 32, r=8, fill=DSTEEL)
    g += circ(33, 78, 6, fill=TILE)
    return g


def tire(wide=False):
    r = 56 if not wide else 58
    g = circ(80, 80, r, fill=RUBBER)
    n = 22
    for i in range(n):
        a = 2 * math.pi * i / n
        x1, y1 = 80 + (r - 2) * math.cos(a), 80 + (r - 2) * math.sin(a)
        x2, y2 = 80 + (r - 12) * math.cos(a + 0.12), 80 + (r - 12) * math.sin(a + 0.12)
        g += line(x1, y1, x2, y2, stroke='#5A606B', stroke_width=4 if not wide else 6)
    g += circ(80, 80, r - 20, fill=TILE)
    g += circ(80, 80, r - 26, fill=STEEL)
    g += circ(80, 80, 10, fill=DSTEEL)
    return g


def bearing():
    g = circ(80, 80, 52, fill=STEEL)
    g += circ(80, 80, 40, fill=TILE)
    for i in range(10):
        a = 2 * math.pi * i / 10
        g += circ(80 + 33 * math.cos(a), 80 + 33 * math.sin(a), 7, fill=WHITE, stroke_width=3)
    g += circ(80, 80, 25, fill=STEEL)
    g += circ(80, 80, 14, fill=TILE)
    return g


def seal(small=False):
    r = 50 if not small else 46
    g = circ(80, 80, r, fill=RUBBER)
    g += circ(80, 80, r - 10, fill=STEEL, stroke_width=3)
    g += circ(80, 80, r - 22, fill=TILE)
    g += circ(80, 80, r - 26, fill='none', stroke=DSTEEL, stroke_width=3)
    return g


def bulb(big=True):
    if big:
        g = path('M80 22 a34 34 0 0 1 22 60 q-6 6 -6 16 h-32 q0 -10 -6 -16 a34 34 0 0 1 22 -60 Z', fill=WHITE)
        g += path('M70 64 q10 -16 20 0', stroke=AMBER, stroke_width=3)
        g += rect(62, 98, 36, 22, r=3, fill=STEEL)
        g += line(62, 106, 98, 106, stroke_width=3) + line(62, 113, 98, 113, stroke_width=3)
        g += rect(70, 120, 20, 14, r=3, fill=DSTEEL)
        g += path('M52 30 l-10 -8 M108 30 l10 -8 M44 56 h-14 M116 56 h14', stroke=AMBER, stroke_width=4)
    else:
        g = path('M80 40 a20 20 0 0 1 14 34 q-4 4 -4 10 h-20 q0 -6 -4 -10 a20 20 0 0 1 14 -34 Z', fill=AMBER)
        g += rect(68, 84, 24, 26, r=3, fill=STEEL)
        g += line(68, 92, 92, 92, stroke_width=3) + line(68, 100, 92, 100, stroke_width=3)
        g += rect(74, 110, 12, 12, r=2, fill=DSTEEL)
    return g


def box_fins(color=DSTEEL):
    g = rect(36, 44, 88, 72, r=8, fill=color)
    for x in range(48, 124, 12):
        g += line(x, 50, x, 110, stroke=INK, stroke_width=3)
    g += rect(60, 116, 40, 14, r=3, fill=RUBBER)
    for x in (68, 80, 92):
        g += line(x, 130, x, 140, stroke=COPPER, stroke_width=4)
    return g


def draw(slug):
    d = {
        # --- engine
        'oleo-motor': lambda: bottle('10W30', drop=True),
        'filtro-oleo': lambda: rect(46, 36, 68, 92, r=12, fill=BLUE) + ''.join(line(50, y, 110, y, stroke=WHITE, stroke_width=3) for y in range(52, 116, 10)) + rect(54, 26, 52, 14, r=4, fill=STEEL) + circ(80, 33, 4, fill=INK, stroke_width=0),
        'filtro-ar': lambda: rect(28, 40, 104, 80, r=8, fill=STEEL) + path('M36 50 ' + ''.join(f'L{40 + i * 8} {110 if i % 2 else 50} ' for i in range(12)), stroke=INK, stroke_width=3) + rect(28, 40, 104, 80, r=8, fill='none', stroke_width=5),
        'vela-ignicao': lambda: rect(72, 18, 16, 22, r=3, fill=STEEL) + rect(64, 40, 32, 36, r=6, fill=WHITE) + ''.join(line(64, y, 96, y, stroke_width=2) for y in (50, 58, 66)) + poly([(60, 76), (100, 76), (104, 88), (100, 100), (60, 100), (56, 88)], fill=DSTEEL) + rect(70, 100, 20, 28, r=2, fill=STEEL) + ''.join(line(70, y, 90, y, stroke_width=2) for y in (106, 112, 118, 124)) + path('M80 128 v8 h10', stroke_width=4),
        'junta-cabecote': lambda: rect(26, 40, 108, 80, r=14, fill=COPPER) + circ(80, 80, 26, fill=TILE) + ''.join(circ(x, y, 6, fill=TILE) for x, y in ((40, 54), (120, 54), (40, 106), (120, 106))) + circ(80, 80, 30, fill='none', stroke=WHITE, stroke_width=2),
        'pistao-aneis': lambda: path('M44 46 Q44 30 80 30 Q116 30 116 46 V100 H44 Z', fill=STEEL) + ''.join(line(44, y, 116, y, stroke=INK, stroke_width=3) for y in (46, 54, 62)) + circ(80, 82, 9, fill=TILE) + rect(70, 100, 20, 40, r=4, fill=DSTEEL) + circ(80, 132, 8, fill=TILE),
        'valvulas': lambda: path('M48 118 Q80 100 112 118 Z', fill=STEEL) + rect(76, 26, 8, 86, r=3, fill=STEEL) + rect(72, 24, 16, 8, r=2, fill=DSTEEL) + rect(28, 120, 104, 6, r=3, fill=DSTEEL, stroke_width=0),
        'corrente-comando': lambda: path('M48 40 h64 a28 28 0 0 1 0 56 h-64 a28 28 0 0 1 0 -56 Z', stroke=DSTEEL, stroke_width=12, stroke_dasharray='8 4') + gear(48, 68, 22, 17, 12, hole=0.4) + gear(112, 68, 22, 17, 12, hole=0.4, fill=LBLUE),
        'retentor-motor': lambda: seal(),
        'discos-embreagem': lambda: circ(88, 84, 48, fill=STEEL) + circ(80, 76, 48, fill=COPPER) + ''.join(rect(80 + 36 * math.cos(2 * math.pi * i / 8) - 6, 76 + 36 * math.sin(2 * math.pi * i / 8) - 6, 12, 12, r=2, fill='#8F5E2F', stroke_width=2) for i in range(8)) + circ(80, 76, 22, fill=TILE),
        'aditivo-radiador': lambda: bottle('ARREF.', cap=GREEN, band=GREEN, handle=False),
        # --- transmission
        'kit-relacao': lambda: path('M44 44 L118 30 M44 116 L118 130', stroke=DSTEEL, stroke_width=10, stroke_dasharray='7 4') + gear(44, 80, 30, 24, 14, fill=STEEL) + gear(112, 80, 50, 43, 34, fill=LBLUE, hole=0.32, bolts=5),
        'corrente-transmissao': lambda: chain_links(18, 64, 142, 7, h=20) + chain_links(18, 98, 142, 7, h=20),
        'coroa': lambda: gear(80, 80, 58, 50, 38, fill=LBLUE, hole=0.3, bolts=6),
        'pinhao': lambda: gear(80, 80, 44, 34, 14, fill=STEEL, hole=0.42),
        'borracha-cubo': lambda: ''.join(path(f'M{x} 50 h22 l8 30 l-8 30 h-22 l-8 -30 Z', fill=RUBBER) for x in (34, 82)) + rect(28, 120, 104, 6, r=3, fill=DSTEEL, stroke_width=0),
        'lubrificante-corrente': lambda: rect(54, 46, 52, 92, r=10, fill=BLUE) + rect(62, 30, 36, 18, r=4, fill=STEEL) + rect(72, 20, 16, 12, r=3, fill=RUBBER) + path('M92 26 h22', stroke_width=4) + path('M118 18 l10 -4 M120 26 h12 M118 34 l10 4', stroke=AMBER, stroke_width=4) + f'<text x="80" y="96" text-anchor="middle" font-family="Arial" font-weight="700" font-size="13" fill="{WHITE}">CHAIN</text>',
        # --- brakes
        'pastilha-freio': lambda: ''.join(path(f'M{x} 40 q22 -10 44 0 v70 q-22 14 -44 0 Z', fill=STEEL) + path(f'M{x + 6} 54 q16 -6 32 0 v46 q-16 10 -32 0 Z', fill=RUBBER, stroke_width=3) for x in (24, 92)),
        'lona-freio': lambda: path('M30 84 A50 50 0 0 1 130 84 L118 84 A38 38 0 0 0 42 84 Z', fill=STEEL) + path('M38 84 A42 42 0 0 1 122 84', stroke=RUBBER, stroke_width=10) + path('M44 96 A40 40 0 0 0 116 96', stroke=DSTEEL, stroke_width=6) + circ(36, 96, 6, fill=TILE) + circ(124, 96, 6, fill=TILE),
        'disco-freio': lambda: circ(80, 80, 58, fill=STEEL) + ''.join(circ(80 + 44 * math.cos(2 * math.pi * i / 16), 80 + 44 * math.sin(2 * math.pi * i / 16), 3.5, fill=TILE, stroke_width=2) for i in range(16)) + circ(80, 80, 30, fill=DSTEEL) + ''.join(circ(80 + 20 * math.cos(2 * math.pi * i / 5), 80 + 20 * math.sin(2 * math.pi * i / 5), 4, fill=TILE, stroke_width=2) for i in range(5)) + circ(80, 80, 9, fill=TILE),
        'fluido-freio': lambda: bottle('DOT 4', cap=RED, band=RED, handle=False),
        'pinca-freio': lambda: path('M40 48 h64 a20 20 0 0 1 20 20 v24 a20 20 0 0 1 -20 20 h-64 Z', fill=RED) + rect(28, 62, 30, 36, r=6, fill=STEEL) + circ(100, 80, 10, fill=TILE) + circ(70, 60, 4, fill=WHITE, stroke_width=0),
        'cabo-freio': lambda: cable(),
        'manete-freio': lambda: lever(),
        # --- suspension
        'oleo-bengala': lambda: bottle('GARFO', cap=DSTEEL, band=INK, handle=False),
        'retentor-bengala': lambda: seal(small=True) + circ(80, 80, 18, fill='none', stroke=BLUE, stroke_width=4),
        'amortecedor': lambda: rect(70, 18, 20, 20, r=10, fill=STEEL) + circ(80, 28, 5, fill=TILE) + rect(74, 38, 12, 86, r=3, fill=STEEL) + ''.join(f'<ellipse cx="80" cy="{y}" rx="24" ry="6" {S(fill="none", stroke=BLUE, stroke_width=6)}/>' for y in range(50, 112, 10)) + rect(70, 120, 20, 22, r=10, fill=STEEL) + circ(80, 132, 5, fill=TILE),
        'rolamento-direcao': lambda: bearing() + path('M28 132 h104', stroke=BLUE, stroke_width=6),
        # --- wheels
        'pneu-dianteiro': lambda: tire(),
        'pneu-traseiro': lambda: tire(wide=True),
        'camara-ar': lambda: circ(80, 80, 54, fill='none', stroke=RUBBER, stroke_width=20) + rect(74, 120, 12, 22, r=3, fill=STEEL) + circ(80, 80, 54, fill='none', stroke='#4A505A', stroke_width=2),
        'rolamento-roda': lambda: bearing(),
        'raios': lambda: circ(80, 80, 58, fill='none', stroke=STEEL, stroke_width=10) + ''.join(line(80 + 12 * math.cos(a), 80 + 12 * math.sin(a), 80 + 54 * math.cos(a + 0.5), 80 + 54 * math.sin(a + 0.5), stroke=DSTEEL, stroke_width=3) for a in [2 * math.pi * i / 18 for i in range(18)]) + circ(80, 80, 14, fill=STEEL),
        # --- electrical
        'bateria': lambda: rect(30, 50, 100, 78, r=8, fill=RUBBER) + rect(30, 50, 100, 18, r=6, fill=DSTEEL) + rect(42, 38, 18, 14, r=2, fill=RED) + rect(100, 38, 18, 14, r=2, fill=STEEL) + f'<text x="80" y="104" text-anchor="middle" font-family="Arial" font-weight="700" font-size="20" fill="{WHITE}">12V</text>' + path('M48 30 v-0', stroke_width=0),
        'lampada-farol': lambda: bulb(True),
        'lampada-pisca': lambda: bulb(False),
        'regulador-retificador': lambda: box_fins(),
        'estator': lambda: circ(80, 80, 54, fill=STEEL) + ''.join(rect(80 + 40 * math.cos(2 * math.pi * i / 12) - 8, 80 + 40 * math.sin(2 * math.pi * i / 12) - 8, 16, 16, r=3, fill=COPPER, stroke_width=2) for i in range(12)) + circ(80, 80, 22, fill=TILE),
        'rele-partida': lambda: rect(44, 40, 72, 70, r=10, fill=RUBBER) + rect(56, 110, 48, 16, r=3, fill=DSTEEL) + ''.join(line(x, 126, x, 140, stroke=COPPER, stroke_width=5) for x in (64, 80, 96)) + path('M74 58 l-10 22 h16 l-10 22', stroke=AMBER, stroke_width=4),
        'motor-partida': lambda: rect(30, 52, 80, 56, r=12, fill=DSTEEL) + rect(110, 66, 22, 28, r=4, fill=STEEL) + ''.join(line(x, 52, x, 108, stroke=INK, stroke_width=3) for x in (50, 70, 90)) + gear(138, 80, 10, 7, 8),
        'bobina-ignicao': lambda: rect(40, 46, 60, 68, r=10, fill=RUBBER) + path('M100 70 C 126 70, 120 120, 138 124', stroke=RUBBER, stroke_width=8) + rect(126, 118, 16, 22, r=6, fill=RED) + rect(30, 60, 12, 40, r=3, fill=STEEL),
        'cdi': lambda: rect(36, 44, 88, 64, r=10, fill=RUBBER) + rect(56, 108, 48, 18, r=4, fill='#E8E8E8') + ''.join(rect(x, 112, 6, 10, r=1, fill=COPPER, stroke_width=0) for x in (62, 72, 82, 92)) + f'<text x="80" y="84" text-anchor="middle" font-family="Arial" font-weight="700" font-size="18" fill="{WHITE}">CDI</text>',
        'fusivel': lambda: rect(58, 40, 44, 56, r=6, fill=BLUE) + rect(64, 96, 10, 34, r=2, fill=STEEL) + rect(86, 96, 10, 34, r=2, fill=STEEL) + f'<text x="80" y="76" text-anchor="middle" font-family="Arial" font-weight="700" font-size="20" fill="{WHITE}">15</text>',
        'buzina': lambda: circ(80, 84, 46, fill=DSTEEL) + circ(80, 84, 34, fill=STEEL) + circ(80, 84, 12, fill=RUBBER) + rect(74, 26, 12, 16, r=2, fill=STEEL) + path('M124 50 q10 10 0 20 M134 42 q16 18 0 36', stroke=AMBER, stroke_width=4),
        'pisca': lambda: rect(30, 74, 48, 12, r=6, fill=RUBBER) + path('M78 56 h28 a24 24 0 0 1 0 48 h-28 Z', fill=AMBER) + path('M110 72 q8 8 0 16', stroke=WHITE, stroke_width=3) + path('M132 64 l12 -6 M136 80 h12 M132 96 l12 6', stroke=AMBER, stroke_width=4),
        'farol': lambda: circ(80, 80, 54, fill=RUBBER) + circ(80, 80, 44, fill=WHITE) + circ(80, 80, 30, fill='#FFF3C4', stroke=AMBER, stroke_width=3) + path('M60 70 q20 -20 40 0', stroke=STEEL, stroke_width=3),
        # --- fuel
        'reparo-carburador': lambda: rect(44, 52, 72, 52, r=10, fill=STEEL) + rect(20, 64, 26, 28, r=4, fill=DSTEEL) + rect(114, 64, 26, 28, r=4, fill=DSTEEL) + rect(60, 104, 40, 30, r=8, fill=STEEL) + rect(66, 30, 28, 24, r=4, fill=DSTEEL) + circ(80, 78, 10, fill=TILE),
        'bico-injetor': lambda: rect(66, 20, 28, 26, r=4, fill=RUBBER) + rect(70, 46, 20, 60, r=3, fill=STEEL) + f'<ellipse cx="80" cy="66" rx="16" ry="6" {S(fill=GREEN)}/>' + poly([(70, 106), (90, 106), (84, 126), (76, 126)], fill=DSTEEL) + path('M80 132 l-10 12 M80 132 v14 M80 132 l10 12', stroke=BLUE, stroke_width=3),
        'bomba-combustivel': lambda: rect(48, 30, 64, 96, r=14, fill=DSTEEL) + rect(56, 18, 48, 16, r=4, fill=RUBBER) + path('M112 60 h20 v40', stroke=RUBBER, stroke_width=6) + rect(60, 70, 40, 40, r=6, fill=STEEL),
        'filtro-combustivel': lambda: line(16, 80, 46, 80, stroke=RUBBER, stroke_width=10) + line(114, 80, 144, 80, stroke=RUBBER, stroke_width=10) + rect(46, 56, 68, 48, r=20, fill='#F7F0D8') + ''.join(line(x, 62, x, 98, stroke=AMBER, stroke_width=3) for x in range(60, 104, 8)) + rect(46, 56, 68, 48, r=20, fill='none'),
        'mangueira-combustivel': lambda: path('M24 116 C 40 40, 120 140, 136 44', stroke=RUBBER, stroke_width=16) + path('M24 116 C 40 40, 120 140, 136 44', stroke='#4A505A', stroke_width=2) + rect(14, 112, 20, 14, r=3, fill=STEEL) + rect(128, 36, 18, 14, r=3, fill=STEEL),
        # --- controls
        'cabo-acelerador': lambda: cable(BLUE),
        'cabo-embreagem': lambda: cable(),
        'manete-embreagem': lambda: lever(),
        'retrovisor': lambda: path('M86 30 h28 a18 18 0 0 1 18 18 v14 a18 18 0 0 1 -18 18 h-28 a18 18 0 0 1 -18 -18 v-14 a18 18 0 0 1 18 -18 Z', fill=RUBBER) + path('M90 38 h20 a10 10 0 0 1 10 10 v12 a10 10 0 0 1 -10 10 h-20 a10 10 0 0 1 -10 -10 v-12 a10 10 0 0 1 10 -10 Z', fill=LBLUE, stroke_width=2) + path('M86 80 L50 132', stroke=DSTEEL, stroke_width=8) + rect(38, 128, 26, 12, r=4, fill=STEEL),
        'manoplas': lambda: ''.join(rect(30, y, 100, 26, r=13, fill=RUBBER) + ''.join(line(x, y + 4, x, y + 22, stroke='#5A606B', stroke_width=3) for x in range(44, 124, 8)) for y in (46, 92)),
        'pedaleira': lambda: rect(26, 64, 92, 30, r=10, fill=RUBBER) + ''.join(line(x, 70, x, 88, stroke='#5A606B', stroke_width=3) for x in range(36, 112, 9)) + rect(112, 70, 30, 18, r=4, fill=STEEL) + circ(130, 79, 4, fill=TILE),
    }
    return d[slug]()


def svg(slug):
    inner = draw(slug)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160" width="160" height="160">'
            f'<rect width="160" height="160" rx="22" fill="{TILE}"/>{inner}</svg>')


js = {}
for p in PARTS:
    s = svg(p['slug'])
    (OUT / f"{p['slug']}.svg").write_text(s, encoding='utf-8')
    cairosvg.svg2png(bytestring=s.encode(), write_to=str(OUT / f"{p['slug']}.png"), output_width=256, output_height=256)
    js[p['slug']] = s

out_js = ROOT / 'frontend/src/lib/partImages.js'
out_js.write_text(
    '// Generated by tools/draw_parts.py — original illustrations of each part (used by the demo build).\n'
    'export const PART_SVGS = ' + json.dumps(js, ensure_ascii=False) + ';\n'
    "export const partImage = (slug) => (PART_SVGS[slug] ? `data:image/svg+xml;charset=utf-8,${encodeURIComponent(PART_SVGS[slug])}` : null);\n",
    encoding='utf-8')
print(len(PARTS), 'parts drawn')
