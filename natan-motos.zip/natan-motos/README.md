# Natan Motos: agendamento e gestão da oficina

Sistema web da oficina **Natan Motos** (Santa Cruz, Rio de Janeiro), no ar em **natanmotos.com.br**. Versão atual: **1.6.0** (veja o [CHANGELOG](CHANGELOG.md)).

## Os 4 acessos

| Acesso | Onde entra | O que faz |
|---|---|---|
| **Cliente** | link da bio do Instagram, resposta automática do WhatsApp ou QR code do balcão | Agenda em 5 passos, sem criar conta. Pelo link privado, acompanha a moto, remarca, cancela e aprova o orçamento. |
| **Administrador do sistema** | `/admin` | Tudo, e é o único que altera o sistema: serviços e preços, configurações da oficina, equipe e acessos, catálogo de peças e backup. |
| **Dono da oficina** | `/admin` | O dia a dia completo: agenda, OS, valores do orçamento, pagamentos, financeiro, clientes e lembretes. Não altera configurações. |
| **Mecânico** | `/admin`, que abre na tela **Hoje** | Movimento do dia e agenda de todos os dias. Faz check-in, diagnóstico com o **valor do diagnóstico**, fotos, peças que o cliente compra e o andamento da OS. Não altera serviços e valores nem vê o financeiro. |

As permissões são conferidas no servidor, não só na tela.

## O que o sistema tem
- **Agenda:** por elevador (2), sem conflito de horário. O calendário do mês marca com uma bolinha azul os dias com agendamento.
- **OS:** ordens de serviço com check-in, fotos, diagnóstico e relatório do que foi feito.
- **Prontuário da moto:** todas as visitas, o que foi encontrado além do pedido, se o cliente foi avisado e as pendências quando a moto volta.
- **Cadastro único:** um cliente por WhatsApp, uma moto por placa. O cliente que volta é reconhecido no site pelo WhatsApp + placa; a oficina transfere moto vendida e junta cadastros repetidos.
- **Orçamento:** PDF e aprovação online pelo cliente.
- **Peças:** catálogo com 57 peças ilustradas, para o mecânico indicar o que o cliente deve comprar. A oficina não vende peças; o estoque só aparece se isso mudar.
- **Pagamentos:** Pix, dinheiro e cartão, inclusive parcial. Valores a receber, financeiro e comissões.
- **Lembretes:** de troca de óleo e revisão, com textos prontos para o WhatsApp.
- **Backup:** automático, criptografado no Google Drive com chave própria do Google, testado toda semana e com status no painel.
- **LGPD:** exportação e eliminação dos dados do cliente e retenção automática.

Tudo que depende da realidade da oficina o administrador do sistema ajusta no painel: horários, preços, serviços, elevadores, equipe, regras de agendamento e textos do WhatsApp.

## Tecnologias

| Parte | Tecnologia |
|---|---|
| Site e painel | React 19 + Vite 7, Tailwind CSS 4, TanStack Query, Recharts |
| API | Node.js 22 + Express 5, Knex + PostgreSQL 16, Zod, JWT |
| Testes | Vitest + Supertest (62 testes da API), ESLint |
| Produção | Docker Compose em VPS (Hostinger): site + PostgreSQL + Caddy (HTTPS) + backup (rclone) |

## Estrutura

```
natan-motos/
├── backend/            API, banco (db/migrations, db/seeds), testes
├── frontend/           site público + painel
├── deploy/             produção: docker-compose, Caddyfile, backup/, servidor/ (scripts) e restaurar.sh
├── docs/               hospedagem, backup e segurança, manual, LGPD, decisões técnicas
├── Dockerfile          imagem do site + API
├── docker-compose.yml  PostgreSQL local para desenvolvimento (opcional)
├── CHANGELOG.md        histórico de versões
└── LICENSE.md          licença de uso
```

## Rodar no Windows (VS Code + PowerShell)

### Pré-requisitos
1. **Node.js 22 LTS** ou mais novo: <https://nodejs.org>. Confira com `node -v`.
2. **PostgreSQL 16**: instale pelo <https://www.postgresql.org/download/windows/> e anote a senha do usuário `postgres`.
   Se você usa Docker Desktop, pode rodar `docker compose up -d` na pasta do projeto em vez de instalar.

### 1. Criar o banco
No PowerShell:
```powershell
& "C:\Program Files\PostgreSQL\16\bin\psql.exe" -U postgres -c "CREATE DATABASE natanmotos;"
```

### 2. Configurar e subir a API
```powershell
cd backend
npm install
Copy-Item .env.example .env
code .env      # preencha DATABASE_URL, JWT_SECRET, JWT_REFRESH_SECRET e SEED_OWNER_PASSWORD
npm run db:migrate
npm run db:seed
npm run dev
```
O seed mostra o e-mail do administrador do sistema. A senha é a que você colocou em `SEED_OWNER_PASSWORD`. Para testar os outros acessos, crie um **Dono** e um **Mecânico** em *Configurações › Equipe*.

### 3. Subir o site (em outro terminal)
```powershell
cd frontend
npm install
npm run dev
```
Abra <http://localhost:5173> para ver o site e <http://localhost:5173/admin> para entrar no painel.

### Versão de demonstração (sem servidor)
```powershell
cd frontend
npm run build:demo   # gera dist-demo/index.html: um arquivo só, com dados de exemplo no navegador
```

### Testes e verificação
```powershell
# precisa de um banco vazio chamado natanmotos_test
& "C:\Program Files\PostgreSQL\16\bin\psql.exe" -U postgres -c "CREATE DATABASE natanmotos_test;"
cd backend
$env:TEST_DATABASE_URL="postgresql://postgres:SUA_SENHA@localhost:5432/natanmotos_test"
npm test
npm run lint
cd ..\frontend
npm run lint
npm run build
```

## Colocar no ar
- **Hostinger VPS + natanmotos.com.br (escolhido):** [docs/HOSPEDAGEM-HOSTINGER.md](docs/HOSPEDAGEM-HOSTINGER.md). Os arquivos de produção ficam em `deploy/`: Docker Compose, HTTPS automático, backup e scripts do servidor.
- **Backup e segurança:** [docs/BACKUP-E-SEGURANCA.md](docs/BACKUP-E-SEGURANCA.md).
- **Alternativa sem servidor (Railway):** [docs/IMPLANTACAO.md](docs/IMPLANTACAO.md).

## Documentos
- [docs/MANUAL-DO-DONO.md](docs/MANUAL-DO-DONO.md): o dia a dia da oficina no sistema e os 4 acessos.
- [docs/HOSPEDAGEM-HOSTINGER.md](docs/HOSPEDAGEM-HOSTINGER.md) e [docs/BACKUP-E-SEGURANCA.md](docs/BACKUP-E-SEGURANCA.md): colocar no ar, backup, restauração e segurança do servidor.
- [docs/LGPD.md](docs/LGPD.md): inventário de dados, bases legais, retenção, direitos do titular e plano de incidentes.
- [docs/DECISOES.md](docs/DECISOES.md): decisões técnicas e onde o sistema difere do prompt original.
- [CHANGELOG.md](CHANGELOG.md)

## Licença

Software proprietário. Copyright © 2026 Alexandre, todos os direitos reservados. A Natan Motos tem licença de uso sem prazo, para a própria oficina; a marca e os dados são da oficina. Termos completos em [LICENSE.md](LICENSE.md).
