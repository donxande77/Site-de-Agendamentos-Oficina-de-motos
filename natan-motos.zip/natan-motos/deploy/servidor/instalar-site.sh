#!/usr/bin/env bash
# Instala (ou atualiza) o site no servidor. Rode como o usuário administrador,
# de dentro da pasta deploy:
#
#   bash servidor/instalar-site.sh
#
# Na primeira vez: cria o deploy/.env com senhas aleatórias, sobe tudo e mostra o login do dono.
# Nas próximas: só reconstrói e reinicia com o código novo (o .env e os dados ficam).
set -euo pipefail
cd "$(dirname "$0")/.."

say() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mERRO: %s\033[0m\n' "$*" >&2; exit 1; }

docker info >/dev/null 2>&1 || die "sem acesso ao Docker. Saia e entre de novo no SSH (o grupo docker só vale num login novo)."

rand() { openssl rand -base64 64 | tr -dc 'A-Za-z0-9' | head -c "$1"; }

if [[ ! -f .env ]]; then
  say "Primeira instalação"
  read -r -p "Domínio do site [natanmotos.com.br]: " DOMAIN
  DOMAIN="${DOMAIN:-natanmotos.com.br}"
  DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN#http://}"; DOMAIN="${DOMAIN%/}"
  read -r -p "Seu e-mail (avisos do certificado HTTPS): " ADMIN_EMAIL
  [[ "$ADMIN_EMAIL" == *@*.* ]] || die "e-mail inválido"
  # O primeiro login é o do ADMINISTRADOR DO SISTEMA (quem configura). O Natan (dono da oficina)
  # é cadastrado depois, no painel, em Configurações › Equipe.
  read -r -p "Seu e-mail de login no painel (administrador do sistema) [$ADMIN_EMAIL]: " OWNER_EMAIL
  OWNER_EMAIL="${OWNER_EMAIL:-$ADMIN_EMAIL}"
  OWNER_PASS="$(rand 14)"

  umask 077
  cat > .env <<EOF
# Gerado em $(date '+%d/%m/%Y %H:%M') por instalar-site.sh. Guarde uma cópia em local seguro.
DOMAIN=$DOMAIN
ADMIN_EMAIL=$ADMIN_EMAIL
POSTGRES_PASSWORD=$(rand 40)
JWT_SECRET=$(rand 64)
JWT_REFRESH_SECRET=$(rand 64)
SEED_OWNER_EMAIL=$OWNER_EMAIL
SEED_OWNER_PASSWORD=$OWNER_PASS
BACKUP_REMOTE=natan-backup:
HEALTHCHECK_URL=
HEALTHCHECK_VERIFY_URL=
WHATSAPP_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_VERIFY_TOKEN=
WHATSAPP_APP_SECRET=
EOF
  chmod 600 .env
  umask 022
fi
mkdir -p secrets/rclone && chmod 700 secrets secrets/rclone

DOMAIN="$(grep -E '^DOMAIN=' .env | cut -d= -f2-)"

say "Conferindo o DNS de $DOMAIN"
MYIP="$(curl -fsS -m 10 https://api.ipify.org || true)"
for host in "$DOMAIN" "www.$DOMAIN"; do
  got="$(getent ahostsv4 "$host" | awk 'NR==1{print $1}' || true)"
  if [[ -z "$got" ]]; then
    echo "  $host: ainda não aponta para lugar nenhum"
  elif [[ -n "$MYIP" && "$got" != "$MYIP" ]]; then
    echo "  $host aponta para $got, mas este servidor é $MYIP"
  else
    echo "  $host → $got ✓"
    continue
  fi
  DNS_BAD=1
done
if [[ -n "${DNS_BAD:-}" ]]; then
  echo
  echo "Sem o DNS certo o HTTPS não é emitido (e tentativas demais bloqueiam por 1 hora)."
  echo "No Registro.br crie: registro A '@' → $MYIP e registro A 'www' → $MYIP. Leva de minutos a algumas horas."
  read -r -p "Continuar mesmo assim? [s/N] " ok
  [[ "$ok" =~ ^[sS]$ ]] || exit 1
fi

say "Construindo e subindo (a primeira vez leva uns 5 minutos)"
docker compose up -d --build --remove-orphans

say "Esperando o site responder em https://$DOMAIN"
for _ in $(seq 1 60); do
  if curl -fsS -m 5 "https://$DOMAIN/api/health" >/dev/null 2>&1; then OK=1; break; fi
  sleep 5
done
docker compose ps

if [[ -z "${OK:-}" ]]; then
  echo
  echo "O site ainda não respondeu pelo HTTPS. Veja o que está acontecendo com:"
  echo "  docker compose logs --tail 50 caddy app"
  exit 1
fi

say "Site no ar: https://$DOMAIN"
if grep -q "^SEED_OWNER_PASSWORD=." .env; then
  OWNER_EMAIL="$(grep -E '^SEED_OWNER_EMAIL=' .env | cut -d= -f2-)"
  OWNER_PASS="$(grep -E '^SEED_OWNER_PASSWORD=' .env | cut -d= -f2-)"
  cat <<EOF

  Seu login de administrador do sistema (https://$DOMAIN/admin)
    e-mail: $OWNER_EMAIL
    senha:  $OWNER_PASS

  1. Entre, troque a senha em Configurações › Minha senha.
  2. Em Configurações › Equipe, cadastre o Natan com a função "Dono" e os mecânicos.
  3. Apague a senha inicial do .env:  sed -i 's/^SEED_OWNER_PASSWORD=.*/SEED_OWNER_PASSWORD=/' .env

  Próximo passo: o backup →  bash servidor/configurar-backup.sh
EOF
fi
