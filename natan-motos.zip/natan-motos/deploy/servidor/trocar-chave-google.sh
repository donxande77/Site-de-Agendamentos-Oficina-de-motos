#!/usr/bin/env bash
# Troca a chave compartilhada do rclone pela chave PRÓPRIA do Google (ID do cliente + chave secreta),
# porque a compartilhada vai parar de funcionar. O backup continua com as mesmas senhas de criptografia.
#
# Conecte ao servidor COM O TÚNEL (no Windows):  ssh -L 53682:127.0.0.1:53682 natan
# e rode, dentro da pasta deploy:                bash servidor/trocar-chave-google.sh
set -euo pipefail
cd "$(dirname "$0")/.."

say() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mERRO: %s\033[0m\n' "$*" >&2; exit 1; }

command -v rclone >/dev/null || die "falta o rclone no servidor: sudo apt-get install -y rclone"
rc() { docker compose run --rm --no-deps -T --entrypoint rclone backup "$@"; }
rc listremotes 2>/dev/null | grep -x 'gdrive:' >/dev/null || die "o backup ainda não foi configurado (rode servidor/configurar-backup.sh)"

say "1/3 Chave do app (Google Cloud › Clientes › rclone servidor)"
read -r -p "ID do cliente (termina em .apps.googleusercontent.com): " CID
[[ "$CID" == *.apps.googleusercontent.com ]] || die "o ID do cliente termina em .apps.googleusercontent.com"
read -r -s -p "Chave secreta do cliente (começa com GOCSPX-; não aparece ao digitar): " CSEC; echo
[[ ${#CSEC} -ge 10 ]] || die "chave secreta vazia ou curta demais"
export CID CSEC
CFG="$(python3 -c 'import base64, json, os
c = {"client_id": os.environ["CID"], "client_secret": os.environ["CSEC"], "scope": "drive.file"}
print(base64.urlsafe_b64encode(json.dumps(c).encode()).decode().rstrip("="))')"

say "2/3 Autorizar no Google"
echo "Vai aparecer um endereço http://127.0.0.1:53682/auth?... — abra no navegador do SEU computador,"
echo "entre com a conta dos backups e clique em Permitir (pode aparecer 'app não verificado': clique em"
echo "Avançado › Acessar Natan Motos Backup)."
OUT="$(mktemp)"; trap 'rm -f "$OUT"' EXIT
# a autorização vai para o arquivo; na tela aparecem só os avisos (sem o bloco secreto)
rclone authorize "drive" "$CFG" --auth-no-open-browser 2>&1 | tee "$OUT" | sed -u '/--->/,/<---/d'
# O resultado fica entre as linhas "--->" e "<---End paste": {…} (rclone antigo) ou eyJ… (novo)
BLOB="$(sed -n '/--->/,/<---/p' "$OUT" | grep -v -e '--->' -e '<---' | tr -d ' \r\n')"
TOKEN="$(python3 -c 'import base64, json, sys
s = sys.stdin.read().strip()
if not s.startswith("{"):
    s = json.loads(base64.urlsafe_b64decode(s + "=" * (-len(s) % 4)))["token"]
print(s)' <<<"$BLOB" 2>/dev/null)" || TOKEN=""
[[ "$TOKEN" == \{*access_token*refresh_token*\} ]] || die "não consegui ler a autorização do Google. Rode de novo."

say "3/3 Gravando e testando"
rc config update gdrive client_id "$CID" client_secret "$CSEC" token "$TOKEN" --non-interactive >/dev/null
# A chave própria só enxerga as pastas que ela mesma criou (acesso restrito do Google): cria a pasta do backup
rc mkdir natan-backup: || die "o Google Drive não aceitou a chave nova"
echo "teste $(date -Iseconds)" | rc rcat natan-backup:.teste-de-escrita
rc deletefile natan-backup:.teste-de-escrita
docker compose restart backup >/dev/null
./restaurar.sh backup-agora
echo
echo "Pronto: o backup agora usa a chave própria do Google."
echo "Pode remover o acesso antigo 'rclone' em https://myaccount.google.com/permissions (conta dos backups)."
