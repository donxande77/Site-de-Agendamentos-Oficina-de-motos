#!/usr/bin/env bash
# Blindagem do VPS (Ubuntu 22.04 ou 24.04, Hostinger). Rode UMA vez, como root, logo
# depois de criar o servidor:
#
#   bash preparar-servidor.sh
#
# O que faz:
#   - cria o usuário administrador (com sudo) e copia a sua chave SSH para ele
#   - SSH: só entra com chave; root e senha bloqueados; no máximo 3 tentativas
#   - firewall (UFW): só abre SSH, 80 e 443
#   - fail2ban: bloqueia por 1 h quem erra o login do SSH 5 vezes (cresce a cada reincidência)
#   - atualizações de segurança automáticas, com reinício às 05:00 quando o sistema pedir
#   - fuso de Brasília, memória swap de 2 GB e Docker com logs limitados
set -euo pipefail

say() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mERRO: %s\033[0m\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "rode como root (ex.: sudo bash preparar-servidor.sh)"
# shellcheck source=/dev/null
. /etc/os-release
[[ "${ID:-}" == ubuntu ]] || die "este script é para Ubuntu (encontrei: ${PRETTY_NAME:-desconhecido})"

ADMIN_USER="${1:-}"
if [[ -z "$ADMIN_USER" ]]; then
  read -r -p "Nome do usuário administrador [alexandre]: " ADMIN_USER
  ADMIN_USER="${ADMIN_USER:-alexandre}"
fi
[[ "$ADMIN_USER" =~ ^[a-z][a-z0-9_-]{1,30}$ ]] || die "nome de usuário inválido: use letras minúsculas, números, - ou _"

# Sem chave SSH, desligar a senha trancaria você para fora. Conferimos antes de tudo.
KEYS=/root/.ssh/authorized_keys
if [[ -f "/home/$ADMIN_USER/.ssh/authorized_keys" && -s "/home/$ADMIN_USER/.ssh/authorized_keys" ]]; then
  KEYS="/home/$ADMIN_USER/.ssh/authorized_keys"
fi
[[ -s "$KEYS" ]] || die "nenhuma chave SSH encontrada em /root/.ssh/authorized_keys.
Adicione a sua chave pública no painel da Hostinger (VPS › Configurações › Chaves SSH)
ou rode no seu computador: ssh-copy-id root@IP_DO_SERVIDOR. Depois rode este script de novo."

say "Atualizando o sistema (pode levar alguns minutos)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get -y -q -o Dpkg::Options::=--force-confold upgrade
apt-get -y -q install ufw fail2ban unattended-upgrades ca-certificates curl git openssl

say "Fuso horário: America/Sao_Paulo"
timedatectl set-timezone America/Sao_Paulo

say "Usuário administrador: $ADMIN_USER"
if ! id "$ADMIN_USER" >/dev/null 2>&1; then
  adduser --disabled-password --gecos "" "$ADMIN_USER"
  echo "Crie a senha do $ADMIN_USER (ela é pedida ao usar sudo; o login continua sendo só por chave):"
  until passwd "$ADMIN_USER"; do echo "Tente de novo."; done
fi
usermod -aG sudo "$ADMIN_USER"
install -d -m 700 -o "$ADMIN_USER" -g "$ADMIN_USER" "/home/$ADMIN_USER/.ssh"
if [[ "$KEYS" != "/home/$ADMIN_USER/.ssh/authorized_keys" ]]; then
  cat "$KEYS" >> "/home/$ADMIN_USER/.ssh/authorized_keys"
  sort -u -o "/home/$ADMIN_USER/.ssh/authorized_keys" "/home/$ADMIN_USER/.ssh/authorized_keys"
fi
chown "$ADMIN_USER:$ADMIN_USER" "/home/$ADMIN_USER/.ssh/authorized_keys"
chmod 600 "/home/$ADMIN_USER/.ssh/authorized_keys"

say "Memória swap de 2 GB"
if ! swapon --show | grep -q .; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
  grep -q '^/swapfile ' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  echo 'vm.swappiness=10' > /etc/sysctl.d/99-natan-swap.conf && sysctl -q -p /etc/sysctl.d/99-natan-swap.conf
else
  echo "já existe swap; mantido"
fi

say "SSH: só com chave, sem root, sem senha"
# Arquivo com prefixo 00: o sshd usa o primeiro valor que encontra, então ele vence o 50-cloud-init.conf
cat > /etc/ssh/sshd_config.d/00-natan-seguranca.conf <<EOF
PermitRootLogin no
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
AuthenticationMethods publickey
MaxAuthTries 3
LoginGraceTime 30
X11Forwarding no
AllowUsers $ADMIN_USER
EOF
sshd -t || die "configuração do SSH inválida; nada foi aplicado"
systemctl reload ssh 2>/dev/null || systemctl restart ssh 2>/dev/null || systemctl restart sshd

say "Firewall (UFW): só SSH, 80 e 443"
ufw --force reset >/dev/null
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw limit OpenSSH >/dev/null
ufw allow 80/tcp >/dev/null
ufw allow 443/tcp >/dev/null
ufw allow 443/udp >/dev/null
ufw --force enable >/dev/null
ufw status verbose | sed -n '1,20p'

say "fail2ban: bloqueio de quem erra o login"
cat > /etc/fail2ban/jail.d/natan.local <<'EOF'
[DEFAULT]
bantime = 1h
bantime.increment = true
bantime.maxtime = 1w
findtime = 10m
maxretry = 5

[sshd]
enabled = true
backend = systemd
EOF
systemctl enable --now fail2ban >/dev/null
systemctl restart fail2ban

say "Atualizações de segurança automáticas"
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF
cat > /etc/apt/apt.conf.d/52natan-unattended <<'EOF'
Unattended-Upgrade::Automatic-Reboot "true";
Unattended-Upgrade::Automatic-Reboot-Time "05:00";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
EOF
systemctl enable --now unattended-upgrades >/dev/null

say "Docker"
if ! command -v docker >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -q
  apt-get -y -q install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
else
  echo "Docker já instalado: $(docker --version)"
fi
mkdir -p /etc/docker
cat > /etc/docker/daemon.json <<'EOF'
{
  "log-driver": "local",
  "log-opts": { "max-size": "10m", "max-file": "3" },
  "live-restore": true
}
EOF
systemctl enable docker >/dev/null
systemctl restart docker
usermod -aG docker "$ADMIN_USER"

IP="$(curl -fsS -m 10 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')"
say "Pronto!"
cat <<EOF

  IMPORTANTE: NÃO feche esta janela ainda.
  Abra OUTRO terminal no seu computador e teste:

      ssh $ADMIN_USER@$IP

  Se entrar, está tudo certo e pode fechar esta. O root não entra mais por SSH.
  Se não entrar, use esta janela para corrigir (ou o terminal de emergência da Hostinger).

  Próximo passo (já como $ADMIN_USER):
      git clone <seu repositório> natan-motos   (ou envie o zip)
      cd natan-motos/deploy && bash servidor/instalar-site.sh
EOF
