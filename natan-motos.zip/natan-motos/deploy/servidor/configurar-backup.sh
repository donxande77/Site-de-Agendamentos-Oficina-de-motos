#!/usr/bin/env bash
# Liga a cópia externa do backup no Google Drive, criptografada. Rode de dentro da pasta deploy:
#
#   bash servidor/configurar-backup.sh
#
# Antes, no SEU computador (Windows), baixe o rclone em https://rclone.org/downloads/
# e rode no PowerShell, dentro da pasta onde está o rclone.exe:
#
#   .\rclone.exe authorize "drive" "eyJzY29wZSI6ImRyaXZlLmZpbGUifQ"
#
# Vai abrir o navegador: entre com a conta Google que vai guardar os backups e autorize.
# O rclone mostra um texto entre chaves {...} ou um bloco que começa com eyJ: copie tudo para colar aqui.
# (Esse código pede acesso só aos arquivos que o próprio rclone criar, não ao Drive inteiro.)
set -euo pipefail
cd "$(dirname "$0")/.."

say() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mERRO: %s\033[0m\n' "$*" >&2; exit 1; }

[[ -f .env ]] || die "rode primeiro: bash servidor/instalar-site.sh"
mkdir -p secrets/rclone && chmod 700 secrets secrets/rclone
docker compose build backup >/dev/null
rc() { docker compose run --rm --no-deps -T --entrypoint rclone backup "$@"; }

FOLDER="natan-motos-backup"
CONF=secrets/rclone/rclone.conf

if rc listremotes 2>/dev/null | grep -qx 'natan-backup:'; then
  read -r -p "O backup já está configurado. Configurar de novo (ex.: trocar a conta Google)? [s/N] " again
  [[ "$again" =~ ^[sS]$ ]] || { echo "Nada mudou."; exit 0; }
fi

say "1/4 Conta Google"
echo "Cole o texto que o rclone authorize mostrou (começa com { ou com eyJ) e tecle Enter:"
read -r TOKEN
# Versões novas do rclone entregam o token embrulhado em base64 (começa com "eyJ"): desembrulha
if [[ "$TOKEN" != \{* ]]; then
  TOKEN="$(python3 -c 'import base64, json, sys
s = sys.stdin.read().strip()
print(json.loads(base64.urlsafe_b64decode(s + "=" * (-len(s) % 4)))["token"])' <<<"$TOKEN" 2>/dev/null)" || TOKEN=""
fi
[[ "$TOKEN" == \{*access_token*\} ]] || die "isso não parece o token do rclone (deve começar com { ou eyJ e ter access_token)"

say "2/4 Senhas da criptografia"
echo "Se você já tem um KIT DE RECUPERAÇÃO de uma instalação anterior (mesmo backup), use as senhas dele."
read -r -p "Tem um kit de recuperação? [s/N] " haskit
if [[ "$haskit" =~ ^[sS]$ ]]; then
  read -r -s -p "Senha 1 do kit: " PASS1; echo
  read -r -s -p "Senha 2 do kit: " PASS2; echo
  read -r -p "Pasta no Drive [$FOLDER]: " f; FOLDER="${f:-$FOLDER}"
else
  PASS1="$(openssl rand -base64 48 | tr -dc 'A-Za-z0-9' | head -c 32)"
  PASS2="$(openssl rand -base64 48 | tr -dc 'A-Za-z0-9' | head -c 32)"
fi
[[ ${#PASS1} -ge 16 && ${#PASS2} -ge 16 ]] || die "senhas curtas demais"

say "3/4 Gravando a configuração"
rm -f "$CONF"
rc config create gdrive drive scope=drive.file token="$TOKEN" --non-interactive >/dev/null
rc config create natan-backup crypt remote="gdrive:$FOLDER" filename_encryption=standard directory_name_encryption=true \
  password="$PASS1" password2="$PASS2" --obscure --non-interactive >/dev/null
rc mkdir natan-backup: || die "não consegui criar a pasta no Google Drive. O token está certo?"
echo "teste $(date -Iseconds)" | rc rcat natan-backup:.teste-de-escrita
rc cat natan-backup:.teste-de-escrita >/dev/null
rc deletefile natan-backup:.teste-de-escrita
echo "Google Drive conectado. Pasta: $FOLDER (o conteúdo aparece embaralhado no Drive: é a criptografia)."

KIT="$HOME/KIT-DE-RECUPERACAO-natanmotos.txt"
if [[ ! "$haskit" =~ ^[sS]$ ]]; then
  umask 077
  cat > "$KIT" <<EOF
KIT DE RECUPERAÇÃO — BACKUP NATAN MOTOS
Criado em $(date '+%d/%m/%Y %H:%M') no servidor $(hostname)

Sem estas duas senhas os backups do Google Drive NÃO podem ser abertos por ninguém,
nem por você. Guarde em dois lugares seguros FORA do servidor (gerenciador de senhas
e uma cópia impressa, por exemplo) e NÃO guarde no mesmo Google Drive dos backups.

Conta Google dos backups: (anote aqui qual é)
Pasta no Drive:           $FOLDER
Tipo:                     rclone crypt (nomes de arquivo e pastas criptografados)
Senha 1 (password):       $PASS1
Senha 2 (password2/salt): $PASS2

Para restaurar num servidor novo: preparar-servidor.sh → instalar-site.sh →
configurar-backup.sh (responda "s" para "Tem um kit de recuperação?") →
./restaurar.sh banco ultimo → ./restaurar.sh fotos
EOF
  umask 022
fi

say "4/4 Avisos por e-mail (opcional, recomendado)"
cat <<'EOF'
Crie uma conta grátis em https://healthchecks.io com o SEU e-mail e crie dois "checks":
  - "Natan Motos backup":   Period 6 horas, Grace 2 horas
  - "Natan Motos teste":    Period 7 dias,  Grace 1 dia
Cada um tem um endereço (Ping URL) como https://hc-ping.com/xxxxxxxx-....
Se o backup falhar ou parar de rodar (servidor desligado, por exemplo), você recebe um e-mail.
EOF
read -r -p "Ping URL do backup (Enter para pular): " HC1
read -r -p "Ping URL do teste semanal (Enter para pular): " HC2
setenv() { if grep -q "^$1=" .env; then sed -i "s#^$1=.*#$1=$2#" .env; else echo "$1=$2" >> .env; fi; }
[[ -z "$HC1" || "$HC1" == https://* ]] && setenv HEALTHCHECK_URL "$HC1"
[[ -z "$HC2" || "$HC2" == https://* ]] && setenv HEALTHCHECK_VERIFY_URL "$HC2"

say "Ligando o backup e fazendo a primeira cópia"
docker compose up -d backup
sleep 3
./restaurar.sh backup-agora
./restaurar.sh testar

cat <<EOF

Backup ligado. Agenda: banco às 03h, 09h, 15h e 21h; fotos às 03h; teste aos domingos 04h30.
O Natan vê o status em Configurações › Backup no painel.
EOF
if [[ -f "$KIT" ]]; then
  cat <<EOF

  >>> AGORA: copie o kit de recuperação para fora do servidor e apague-o daqui.
      No seu computador (PowerShell):
        scp $(whoami)@SEU_IP:$KIT .
      Depois, aqui no servidor:
        shred -u $KIT
EOF
fi
