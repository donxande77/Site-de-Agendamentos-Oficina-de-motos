#!/usr/bin/env bash
# Atalho de restauração (rode no servidor, dentro da pasta deploy):
#   ./restaurar.sh listar            mostra as cópias disponíveis
#   ./restaurar.sh banco             volta o banco para a cópia mais recente
#   ./restaurar.sh banco <arquivo>   volta para uma cópia específica (veja "listar")
#   ./restaurar.sh fotos             traz as fotos de volta do Google Drive
#   ./restaurar.sh backup-agora      faz um backup completo agora
#   ./restaurar.sh testar            roda o teste de restauração agora
set -euo pipefail
cd "$(dirname "$0")"

case "${1:-}" in
  listar)
    docker compose run --rm -T restore listar ;;
  banco)
    echo "Parando o site durante a restauração…"
    docker compose stop app
    trap 'echo "Ligando o site de novo…"; docker compose start app' EXIT
    docker compose run --rm restore banco "${2:-ultimo}" "${@:3}" ;;
  fotos)
    docker compose run --rm restore fotos "${@:2}" ;;
  backup-agora)
    docker compose exec backup /bin/bash -c '. /run/backup.env; backup.sh full' ;;
  testar)
    docker compose exec backup /bin/bash -c '. /run/backup.env; verify.sh' ;;
  *)
    sed -n '2,8p' "$0" | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
