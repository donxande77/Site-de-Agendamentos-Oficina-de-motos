#!/usr/bin/env bash
# Funções comuns dos scripts de backup. Lido por backup.sh, verify.sh e restore.sh.
# Variáveis esperadas (vêm do docker-compose): PG*, BACKUP_DIR, UPLOADS_DIR,
# RCLONE_CONFIG, BACKUP_REMOTE, HEALTHCHECK_URL, HEALTHCHECK_VERIFY_URL.

BACKUP_DIR="${BACKUP_DIR:-/backups}"
UPLOADS_DIR="${UPLOADS_DIR:-/data/uploads}"
BACKUP_REMOTE="${BACKUP_REMOTE:-}"
LOCAL_DIR="$BACKUP_DIR/local"
# shellcheck disable=SC2034  # usado pelos scripts que leem este arquivo
RCLONE_FLAGS=(--retries 5 --low-level-retries 10 --stats 0 --drive-use-trash=false)

log() { printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "${JOB:-backup}" "$*"; }

# true quando a cópia externa (Google Drive criptografado) está configurada
remote_configured() {
  [[ -n "$BACKUP_REMOTE" && -f "${RCLONE_CONFIG:-}" ]] || return 1
  rclone listremotes 2>/dev/null | grep -qx "${BACKUP_REMOTE%%:*}:"
}

# Grava o resultado na tabela backup_runs (aparece em Configurações › Backup no painel).
# record <kind> <ok|error> <tamanho em bytes|""> <true|false> <mensagem> [started_at]
record() {
  local kind="$1" status="$2" size="${3:-}" offsite="${4:-false}" message="${5:-}" started="${6:-}"
  message="${message:0:480}"
  psql -X -q -v ON_ERROR_STOP=1 \
    -v kind="$kind" -v status="$status" -v size="$size" -v offsite="$offsite" \
    -v message="$message" -v started="$started" >/dev/null 2>&1 <<'SQL' || log "aviso: não consegui gravar o status no painel (o site já criou a tabela backup_runs?)"
INSERT INTO backup_runs (kind, status, "sizeBytes", offsite, message, "startedAt")
VALUES (:'kind', :'status', NULLIF(:'size', '')::bigint, :'offsite'::boolean,
        NULLIF(:'message', ''), NULLIF(:'started', '')::timestamptz);
SQL
}

# Avisa o healthchecks.io (se configurado). ping <url> [""|/fail|/start] [mensagem]
ping_hc() {
  local url="${1:-}" suffix="${2:-}" body="${3:-}"
  [[ -n "$url" ]] || return 0
  curl -fsS -m 15 --retry 3 --data-raw "$body" "${url}${suffix}" >/dev/null 2>&1 || log "aviso: não consegui avisar o healthchecks.io"
}

# Uma execução por vez (o backup de 6 h não atropela o completo das 03:00).
# Trava por diretório (mkdir é atômico): não depende do flock, que no contêiner (busybox) é limitado.
LOCK_DIR=""
take_lock() {
  mkdir -p "$BACKUP_DIR"
  local lock="$BACKUP_DIR/.lock.d" waited=0
  until mkdir "$lock" 2>/dev/null; do
    # trava esquecida por um processo que morreu: mais de 3 h → descarta
    if [[ -n "$(find "$lock" -maxdepth 0 -mmin +180 2>/dev/null)" ]]; then rmdir "$lock" 2>/dev/null || true; continue; fi
    if (( waited >= 1800 )); then
      log "outro backup ainda está rodando há 30 min; desistindo desta vez"
      return 1
    fi
    sleep 5; waited=$((waited + 5))
  done
  LOCK_DIR="$lock"
}
release_lock() { [[ -n "$LOCK_DIR" ]] && rmdir "$LOCK_DIR" 2>/dev/null; LOCK_DIR=""; return 0; }

# Mais recente primeiro: nomes têm data/hora (banco_AAAA-MM-DD_HHMM.dump)
newest_local() { find "$LOCAL_DIR" -maxdepth 1 -name 'banco_*.dump' -printf '%f\n' 2>/dev/null | sort | tail -n 1; }
newest_remote() { rclone lsf --files-only "${BACKUP_REMOTE}banco/$1/" 2>/dev/null | grep -E '^banco_.*\.dump$' | sort | tail -n 1; }

human() { numfmt --to=iec --suffix=B "${1:-0}" 2>/dev/null || echo "${1:-0} bytes"; }
