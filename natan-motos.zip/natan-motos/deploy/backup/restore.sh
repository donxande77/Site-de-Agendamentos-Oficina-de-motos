#!/usr/bin/env bash
# Restauração. Use pelo atalho deploy/restaurar.sh (ele para o site antes e liga depois).
#   restore.sh listar                 mostra as cópias do servidor e do Google Drive
#   restore.sh banco ultimo           volta o banco para a cópia mais recente
#   restore.sh banco <arquivo>        ex.: banco_2026-11-05_0300.dump (local)
#                                     ou banco/diario/banco_2026-11-01_0300.dump (Drive)
#   restore.sh fotos                  traz de volta as fotos do Drive (não apaga as que já estão)
# Acrescente --sim para não pedir confirmação.
set -Eeuo pipefail
# shellcheck source=lib.sh
source "$(dirname "$0")/lib.sh"

JOB=restaurar
CMD="${1:-}"; ARG="${2:-}"
YES=false
for a in "$@"; do [[ "$a" == --sim ]] && YES=true; done
[[ "$ARG" == --sim ]] && ARG=""

confirm() {
  $YES && return 0
  if [[ ! -t 0 ]]; then echo "Sem terminal para confirmar. Rode de novo com --sim." >&2; exit 2; fi
  echo
  echo "ATENÇÃO: $1"
  read -r -p "Digite RESTAURAR para continuar: " ans
  [[ "$ans" == RESTAURAR ]] || { echo "Cancelado."; exit 1; }
}

list() {
  echo "== No servidor ($LOCAL_DIR) =="
  find "$LOCAL_DIR" -maxdepth 1 -name '*.dump' -printf '%f\t%s bytes\n' 2>/dev/null | sort -r || true
  if remote_configured; then
    for d in 6h diario mensal; do
      echo "== Google Drive: banco/$d =="
      rclone lsf --files-only "${BACKUP_REMOTE}banco/$d/" 2>/dev/null | sort -r | head -n 30 || true
    done
    echo "== Google Drive: fotos =="
    rclone size "${RCLONE_FLAGS[@]}" "${BACKUP_REMOTE}fotos/atual" 2>/dev/null || true
  else
    echo "(Google Drive não configurado)"
  fi
}

restore_db() {
  local pick="${1:-ultimo}" src=""
  mkdir -p "$BACKUP_DIR/restaurar" "$LOCAL_DIR"
  if [[ "$pick" == ultimo ]]; then
    local lf rf=""
    lf="$(newest_local)"
    remote_configured && rf="$(newest_remote 6h)"
    # o nome tem data e hora: o maior é o mais novo
    if [[ -n "$rf" && ( -z "$lf" || "$rf" > "$lf" ) ]]; then pick="banco/6h/$rf"; else pick="$lf"; fi
    [[ -n "$pick" ]] || { echo "Nenhuma cópia encontrada." >&2; exit 1; }
  fi
  if [[ "$pick" == */* ]]; then
    remote_configured || { echo "Google Drive não configurado." >&2; exit 1; }
    log "baixando do Google Drive: $pick"
    rclone copy "${RCLONE_FLAGS[@]}" "${BACKUP_REMOTE}${pick}" "$BACKUP_DIR/restaurar/"
    src="$BACKUP_DIR/restaurar/$(basename "$pick")"
  else
    src="$LOCAL_DIR/$(basename "$pick")"
  fi
  [[ -f "$src" ]] || { echo "Arquivo não encontrado: $pick" >&2; exit 1; }
  pg_restore --list "$src" >/dev/null || { echo "O arquivo $pick está corrompido." >&2; exit 1; }

  confirm "o banco ${PGDATABASE} vai voltar para a cópia $(basename "$src"). Tudo o que foi feito depois dela será perdido (fica guardado numa cópia de segurança antes)."

  local safety
  safety="$LOCAL_DIR/antes-da-restauracao_$(date +%Y-%m-%d_%H%M).dump"
  log "guardando o banco atual em $(basename "$safety")…"
  pg_dump --format=custom --no-owner --no-privileges --file="$safety" 2>/dev/null || log "aviso: banco atual vazio ou inacessível; seguindo"

  log "restaurando $(basename "$src")…"
  psql -X -q -v ON_ERROR_STOP=1 -d postgres -v db="$PGDATABASE" <<'SQL'
DROP DATABASE IF EXISTS :"db" WITH (FORCE);
CREATE DATABASE :"db";
SQL
  pg_restore --no-owner --no-privileges --exit-on-error --dbname="$PGDATABASE" "$src"
  record restore ok "$(stat -c %s "$src")" false "Banco restaurado da cópia $(basename "$src")."
  rm -rf "$BACKUP_DIR/restaurar"
  log "pronto: banco restaurado de $(basename "$src")"
}

restore_photos() {
  remote_configured || { echo "Google Drive não configurado." >&2; exit 1; }
  confirm "as fotos do Google Drive serão copiadas para o site (as que já existem ficam como estão)."
  mkdir -p "$UPLOADS_DIR"
  rclone copy "${RCLONE_FLAGS[@]}" --stats 30s "${BACKUP_REMOTE}fotos/atual" "$UPLOADS_DIR"
  # o site roda como usuário node (uid 1000) dentro do contêiner
  chown -R 1000:1000 "$UPLOADS_DIR" 2>/dev/null || true
  log "pronto: $(find "$UPLOADS_DIR" -type f | wc -l) fotos no servidor"
}

case "$CMD" in
  listar) list ;;
  banco) restore_db "$ARG" ;;
  fotos) restore_photos ;;
  *) sed -n '2,9p' "$0" | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
