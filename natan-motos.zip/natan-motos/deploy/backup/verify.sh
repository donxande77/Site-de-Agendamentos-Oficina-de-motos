#!/usr/bin/env bash
# Teste semanal: prova que o backup volta de verdade.
#   1. baixa a cópia mais recente do Google Drive (isso testa download + descriptografia);
#      sem Drive configurado, usa a cópia local
#   2. restaura num banco separado (natanmotos_teste), sem tocar no banco do site
#   3. confere tabelas, migrações e quantidade de registros contra o banco do site
#   4. confere se as fotos do Drive batem com as do servidor
#   5. apaga o banco de teste e registra o resultado no painel
set -Eeuo pipefail
# shellcheck source=lib.sh
source "$(dirname "$0")/lib.sh"

JOB=verificar
STARTED="$(date -Iseconds)"
LIVE="${PGDATABASE:?PGDATABASE não definido}"
TEST_DB="${LIVE}_teste"
WORK="$BACKUP_DIR/verificar"
ERRLOG="$(mktemp)"
exec 2> >(tee -a "$ERRLOG" >&2)

cleanup() {
  release_lock
  dropdb --if-exists --force "$TEST_DB" >/dev/null 2>&1 || true
  rm -rf "$WORK" "$ERRLOG"
}
fail() {
  sleep 0.3
  local detail
  detail="$(grep -v '^\s*$' "$ERRLOG" | tail -n 2 | tr '\n' ' ' | sed 's/[[:space:]]\+/ /g')"
  log "ERRO: ${1} ${detail}"
  record verify error "" false "${1}${detail:+: $detail}" "$STARTED"
  ping_hc "${HEALTHCHECK_VERIFY_URL:-}" /fail "${1} ${detail}"
  exit 1
}
trap 'fail "falhou em: $BASH_COMMAND"' ERR
trap cleanup EXIT

take_lock
ping_hc "${HEALTHCHECK_VERIFY_URL:-}" /start
mkdir -p "$WORK"
chmod 700 "$WORK"

OFFSITE=false
if remote_configured; then
  FILE="$(newest_remote 6h)"
  [[ -n "$FILE" ]] || fail "não há nenhuma cópia em banco/6h no Google Drive"
  log "baixando do Google Drive: $FILE"
  rclone copy "${RCLONE_FLAGS[@]}" "${BACKUP_REMOTE}banco/6h/$FILE" "$WORK/"
  SRC="$WORK/$FILE"
  OFFSITE=true
else
  FILE="$(newest_local)"
  [[ -n "$FILE" ]] || fail "não há nenhuma cópia local para testar"
  SRC="$LOCAL_DIR/$FILE"
  log "Drive não configurado; testando a cópia local $FILE"
fi

# Idade da cópia (pelo nome: banco_AAAA-MM-DD_HHMM.dump)
TS="${FILE#banco_}"; TS="${TS%.dump}"
AGE_H=$(( ( $(date +%s) - $(date -d "${TS:0:10} ${TS:11:2}:${TS:13:2}" +%s) ) / 3600 ))
(( AGE_H <= 26 )) || fail "a cópia mais recente tem ${AGE_H} horas; o backup parou de rodar?"

log "restaurando em $TEST_DB…"
dropdb --if-exists --force "$TEST_DB" 2>/dev/null
createdb "$TEST_DB"
pg_restore --no-owner --no-privileges --exit-on-error --dbname="$TEST_DB" "$SRC"

q() { psql -X -At -d "$1" -c "$2"; }
TABLES="$(q "$TEST_DB" "SELECT count(*) FROM information_schema.tables WHERE table_schema='public'")"
(( TABLES >= 10 )) || fail "só ${TABLES} tabelas na cópia"
MIG_T="$(q "$TEST_DB" 'SELECT count(*) FROM knex_migrations')"
MIG_L="$(q "$LIVE" 'SELECT count(*) FROM knex_migrations')"
[[ "$MIG_T" == "$MIG_L" ]] || log "aviso: a cópia tem ${MIG_T} migrações e o site ${MIG_L} (normal logo depois de uma atualização)"

declare -A COUNT
for t in customers bookings service_orders payments; do
  ct="$(q "$TEST_DB" "SELECT count(*) FROM $t")"
  cl="$(q "$LIVE" "SELECT count(*) FROM $t")"
  # A cópia pode ter menos (é de algumas horas atrás), nunca bem menos que a metade
  (( ct <= cl + 5 )) || fail "a cópia tem mais registros em $t (${ct}) que o site (${cl}); banco errado?"
  if (( cl >= 20 && ct * 2 < cl )); then fail "a cópia tem ${ct} registros em $t e o site ${cl}"; fi
  COUNT[$t]="$ct"
done
if [[ "$OFFSITE" == true ]]; then MSG="Cópia do Google Drive"; else MSG="Cópia local"; fi
MSG="$MSG restaurada num banco de teste: ${TABLES} tabelas, ${COUNT[customers]} clientes, ${COUNT[bookings]} agendamentos, ${COUNT[service_orders]} OS."

# Fotos: o Drive deve ter pelo menos 90% das fotos do servidor (as de hoje sobem às 03h)
if [[ "$OFFSITE" == true && -d "$UPLOADS_DIR" ]]; then
  LOCAL_N="$(find "$UPLOADS_DIR" -type f | wc -l)"
  REMOTE_N="$(rclone lsf --files-only -R "${RCLONE_FLAGS[@]}" "${BACKUP_REMOTE}fotos/atual" | wc -l)"
  if (( LOCAL_N > 0 && REMOTE_N * 10 < LOCAL_N * 9 )); then
    fail "o Drive tem ${REMOTE_N} fotos e o servidor ${LOCAL_N}"
  fi
  MSG="$MSG Fotos no Drive: ${REMOTE_N} de ${LOCAL_N}."
fi

record verify ok "$(stat -c %s "$SRC")" "$OFFSITE" "$MSG" "$STARTED"
ping_hc "${HEALTHCHECK_VERIFY_URL:-}" "" "$MSG"
log "$MSG"
