#!/usr/bin/env bash
# Agenda do backup (horário de Brasília):
#   03:00 todo dia      backup completo (banco + fotos) e limpeza das cópias antigas
#   09:00, 15:00, 21:00 backup do banco
#   domingo 04:30       teste de restauração
set -euo pipefail

# O cron não herda as variáveis do contêiner: guardamos as necessárias num arquivo só do root
umask 077
export -p | grep -E '^declare -x (PG[A-Z]*|BACKUP_[A-Z_]*|UPLOADS_DIR|RCLONE_CONFIG|HEALTHCHECK_[A-Z_]*|TZ)=' > /run/backup.env

run() { echo ". /run/backup.env; /usr/local/bin/$1 >> /proc/1/fd/1 2>> /proc/1/fd/2"; }
cat > /etc/crontabs/root <<EOF
0 3 * * * /bin/bash -c '$(run "backup.sh full")'
0 9,15,21 * * * /bin/bash -c '$(run "backup.sh db")'
30 4 * * 0 /bin/bash -c '$(run "verify.sh")'
EOF

echo "backup: agenda carregada (fuso ${TZ:-UTC})"
cat /etc/crontabs/root
exec crond -f -l 8
