#!/usr/bin/env bash
# Backup da Natan Motos.
#   backup.sh db    → só o banco (roda às 09h, 15h e 21h)
#   backup.sh full  → banco + fotos (roda às 03h) e faz a limpeza das cópias antigas
#
# Onde fica cada cópia:
#   servidor:      /backups/local (últimos 3 dias, para restaurar rápido)
#   Google Drive (criptografado pelo rclone crypt; nomes de arquivo também):
#     banco/6h/       todas as cópias dos últimos 8 dias
#     banco/diario/   a cópia das 03h dos últimos 40 dias
#     banco/mensal/   a cópia das 03h do dia 1º, por 13 meses
#     fotos/atual/    espelho das fotos
#     fotos/apagadas/ fotos removidas do site, guardadas por 40 dias e depois apagadas (LGPD)
set -Eeuo pipefail
# shellcheck source=lib.sh
source "$(dirname "$0")/lib.sh"

MODE="${1:-db}"
[[ "$MODE" == db || "$MODE" == full ]] || { echo "uso: backup.sh db|full" >&2; exit 2; }
JOB="backup-$MODE"
KIND="$MODE"
STARTED="$(date -Iseconds)"
STAMP="$(date +%Y-%m-%d_%H%M)"
ERRLOG="$(mktemp)"
exec 2> >(tee -a "$ERRLOG" >&2)

fail() {
  local where="$1"
  sleep 0.3
  local detail
  detail="$(grep -v '^\s*$' "$ERRLOG" | tail -n 2 | tr '\n' ' ' | sed 's/[[:space:]]\+/ /g')"
  log "ERRO: $where ${detail}"
  record "$KIND" error "" false "${detail:-$where}" "$STARTED"
  ping_hc "${HEALTHCHECK_URL:-}" /fail "$JOB: ${detail:-$where}"
  exit 1
}
trap 'fail "falhou em: $BASH_COMMAND"' ERR
trap 'rm -f "$ERRLOG"; release_lock' EXIT

take_lock
ping_hc "${HEALTHCHECK_URL:-}" /start
mkdir -p "$LOCAL_DIR"
chmod 700 "$BACKUP_DIR" "$LOCAL_DIR"
umask 077

# 1) Banco: formato custom do pg_dump (já comprimido) + conferência de que o arquivo abre
DUMP="$LOCAL_DIR/banco_${STAMP}.dump"
log "copiando o banco ${PGDATABASE:-}…"
pg_dump --format=custom --compress=6 --no-owner --no-privileges --file="$DUMP.part"
pg_restore --list "$DUMP.part" >/dev/null
mv "$DUMP.part" "$DUMP"
SIZE="$(stat -c %s "$DUMP")"
log "banco ok: $(human "$SIZE")"

# 2) Cópia externa
OFFSITE=false
if remote_configured; then
  R="$BACKUP_REMOTE"
  rclone copy "${RCLONE_FLAGS[@]}" "$DUMP" "${R}banco/6h/"
  if [[ "$MODE" == full ]]; then
    for d in banco/diario banco/mensal fotos/atual fotos/apagadas; do rclone mkdir "${RCLONE_FLAGS[@]}" "${R}${d}"; done
    rclone copy "${RCLONE_FLAGS[@]}" "$DUMP" "${R}banco/diario/"
    if [[ "$(date +%d)" == 01 ]]; then rclone copy "${RCLONE_FLAGS[@]}" "$DUMP" "${R}banco/mensal/"; fi

    if [[ -d "$UPLOADS_DIR" ]]; then
      log "enviando fotos novas…"
      rclone sync "${RCLONE_FLAGS[@]}" "$UPLOADS_DIR" "${R}fotos/atual" --backup-dir "${R}fotos/apagadas/${STAMP}"
      PHOTOS="$(du -sb "$UPLOADS_DIR" | cut -f1)"
      SIZE=$((SIZE + PHOTOS))
    fi

    log "apagando cópias antigas no Drive…"
    rclone delete "${RCLONE_FLAGS[@]}" --min-age 8d "${R}banco/6h/"
    rclone delete "${RCLONE_FLAGS[@]}" --min-age 40d "${R}banco/diario/"
    rclone delete "${RCLONE_FLAGS[@]}" --min-age 400d "${R}banco/mensal/"
    # Fotos apagadas: a pasta tem a data em que saíram do site (a foto mantém a data original,
    # por isso a idade é contada pelo nome da pasta, não pelo arquivo)
    LIMIT="$(date -d '-40 days' +%Y-%m-%d)"
    while IFS= read -r dir; do
      dir="${dir%/}"
      if [[ "$dir" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{4}$ && "${dir:0:10}" < "$LIMIT" ]]; then
        rclone purge "${RCLONE_FLAGS[@]}" "${R}fotos/apagadas/${dir}"
      fi
    done < <(rclone lsf --dirs-only "${RCLONE_FLAGS[@]}" "${R}fotos/apagadas/")
  fi
  OFFSITE=true
  log "cópia enviada ao Google Drive"
else
  log "AVISO: cópia externa não configurada; o backup ficou só no servidor (rode servidor/configurar-backup.sh)"
fi

# 3) Limpeza local: 3 dias no servidor (a cópia de antes de uma restauração fica 30 dias)
find "$LOCAL_DIR" -maxdepth 1 -name 'banco_*.dump' -mtime +3 -delete
find "$LOCAL_DIR" -maxdepth 1 -name 'antes-da-restauracao_*.dump' -mtime +30 -delete
find "$LOCAL_DIR" -maxdepth 1 -name '*.part' -mmin +120 -delete
if [[ "$MODE" == full ]]; then
  psql -X -q -c "DELETE FROM backup_runs WHERE \"finishedAt\" < now() - interval '180 days'" >/dev/null 2>&1 || true
fi

record "$KIND" ok "$SIZE" "$OFFSITE" "" "$STARTED"
ping_hc "${HEALTHCHECK_URL:-}" "" "$JOB ok: $(human "$SIZE") offsite=$OFFSITE"
log "pronto ($(human "$SIZE"), cópia externa: $OFFSITE)"
