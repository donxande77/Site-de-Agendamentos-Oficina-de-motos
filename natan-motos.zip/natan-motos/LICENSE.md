# Licença de uso: Sistema Natan Motos

Copyright © 2026 Alexandre. Todos os direitos reservados.

O código-fonte, o banco de dados (estrutura), os scripts de implantação e backup, a documentação e o design deste sistema ("o Sistema") pertencem ao autor, Alexandre ("o Autor").

## 1. O que a oficina pode fazer

O Autor concede à **Natan Motos** (Natanael de Arruda Freitas, CNPJ 68.204.192/0001-91), "a Oficina", uma licença de uso:

- **sem prazo**: vale enquanto a Oficina cumprir esta licença;
- **sem exclusividade**;
- **intransferível**: a Oficina não pode passar para outra pessoa ou empresa;
- **para a própria oficina**: usar o Sistema no seu negócio, no domínio natanmotos.com.br ou em outro que escolher, com quantos funcionários e clientes precisar.

A Oficina pode hospedar o Sistema no servidor que quiser e pedir alterações ao Autor ou, com autorização escrita dele, a outro profissional.

## 2. O que a oficina não pode fazer

Sem autorização escrita do Autor, a Oficina não pode:

- copiar, vender, alugar, emprestar ou distribuir o Sistema, no todo ou em parte;
- dar acesso ao código-fonte a terceiros, exceto a quem for contratado para manter o Sistema da própria Oficina, sob sigilo;
- usar o Sistema, ou uma cópia dele, para outra empresa, filial com outro CNPJ ou outro negócio;
- remover este aviso de autoria.

## 3. O que continua sendo da oficina

- **Marca:** o nome Natan Motos, o logotipo, as fotos e os textos próprios da oficina são da Oficina. O Autor não os usa em outros projetos.
- **Dados:** os dados de clientes, motos, agendamentos, ordens de serviço e financeiro são da Oficina. Ela é a controladora desses dados pela LGPD (Lei 13.709/2018) e pode exportá-los a qualquer momento. O Autor atua apenas como operador, para manter o Sistema funcionando.

## 4. O que o Autor pode fazer

O Autor pode reutilizar o código do Sistema em outros projetos e para outros clientes, **sem** a marca, os dados e o conteúdo próprio da Oficina.

## 5. Componentes de terceiros

O Sistema usa bibliotecas de código aberto (React, Express, PostgreSQL, Caddy, rclone, entre outras). Cada uma continua sob a sua própria licença; esta licença não muda os termos delas. A lista completa está nos arquivos `package.json` do `backend/` e do `frontend/`.

## 6. Garantia e responsabilidade

O Sistema é entregue no estado em que se encontra. O Autor faz o possível para mantê-lo correto e seguro, e os backups automáticos estão descritos em `docs/BACKUP-E-SEGURANCA.md`. Ainda assim, o Autor não garante que o Sistema funcione sem nenhuma falha ou interrupção, e não responde por prejuízos indiretos, como lucros cessantes, decorrentes do uso.

Condições de manutenção, suporte, hospedagem e valores, quando houver, são combinadas em contrato à parte.

## 7. Fim da licença

A licença termina se a Oficina descumprir o item 2 e não corrigir em até 30 dias depois de avisada por escrito. Nesse caso, a Oficina continua com os seus dados (item 3) e o Autor entrega uma exportação completa deles.

---

Dúvidas sobre esta licença: fale com o Autor.
