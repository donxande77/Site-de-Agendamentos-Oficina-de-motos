# Decisões técnicas (ADRs)

## ADR-01: Knex no lugar do Prisma
- **Contexto:** o prompt pedia Prisma. Na instalação, o Prisma baixa motores binários de um servidor próprio, e esse servidor estava bloqueado no ambiente onde o sistema foi construído e testado.
- **Decisão:** usar **Knex** (construtor de SQL em JavaScript puro) com PostgreSQL. Migrações em `backend/db/migrations`.
- **Consequências:**
  - todo o código foi testado de verdade (31 testes);
  - a garantia contra agendamento duplo é feita no próprio banco, com uma restrição de exclusão (`EXCLUDE USING gist`), mais forte do que validar na aplicação;
  - para voltar ao Prisma no futuro, basta reescrever a camada de consultas, sem mudar o banco.

## ADR-02: um único serviço em produção
- **Decisão:** a API (Express) também entrega o site já compilado. Um contêiner, um domínio.
- **Por quê:** é mais simples e mais barato. O cookie de sessão fica no mesmo domínio (`SameSite=Strict`) e não há problema de CORS.
- **Alternativa descartada:** site no Vercel e API no Railway, como sugeria o prompt. Seriam dois deploys, CORS e cookies entre domínios.

## ADR-03: efeito de vidro em CSS, não `expo-glass-effect`
- O `expo-glass-effect` só funciona em apps nativos no iOS 26+ e não roda no navegador.
- O vidro foi feito em CSS (`.glass-bar`, `.glass-btn`, `.glass-btn-primary`), **só nas barras e nos botões**. O resto é sólido para facilitar a leitura.
- Tem versão sólida para navegadores sem `backdrop-filter`, para quem ativa "reduzir transparência" e para o modo de alto contraste.

## ADR-04: cores da logo
| Token | Cor | Uso |
|---|---|---|
| brand | `#3358D4` | botões principais, vidro azul |
| brand-deep | `#243C9C` | hover / bordas |
| brand-light | `#7B96FF` | texto azul sobre fundo escuro (contraste 7:1) |
| ink | `#0C0C0C` | fundo |
| surface | `#1C1C1C` | cards |
| steel | `#CCCCCC` | texto secundário |

O azul `#3358D4` sobre o preto tem contraste 3,2:1, então é usado só em ícones e títulos grandes. As cores dos gráficos (`#5B7BE8` e `#C9782E` no escuro) foram validadas para daltonismo.

## ADR-05: privacidade acima do conforto em dois pontos do prompt
1. **Busca de cliente pelo telefone no site:** removida, porque expunha nome e placas de terceiros. O pré-preenchimento usa o armazenamento local do próprio aparelho.
2. **Caixa "LGPD consent" obrigatória:** trocada por ciência do aviso (obrigatória) e consentimento separado, opcional e desmarcado, para lembretes.

## ADR-06: formulários sem React Hook Form
Os formulários são pequenos. Estado simples do React com validação manual (e Zod no servidor) cobre tudo com menos código. A validação que vale de verdade é sempre a do servidor.

## ADR-07: fotos em disco com nomes impossíveis de adivinhar
As fotos ficam no volume `/data/uploads` com nomes aleatórios de 192 bits, sem indexação (`X-Robots-Tag: noindex`). A interface `storage` (`save`/`remove`) permite trocar por S3 ou Cloudflare R2 depois, sem mexer nas regras de negócio.

## ADR-08: VPS da Hostinger com backup próprio
**Escolha:** VPS KVM 1 da Hostinger, em São Paulo, com preço fixo em reais. O backup fica num contêiner próprio (`deploy/backup`), não no backup da Hostinger.

**Por que não o backup da Hostinger:**
- ele é semanal;
- ele restaura o servidor inteiro, sobrescrevendo tudo;
- ele fica na mesma conta do servidor.

**Como o backup próprio funciona:**
- `pg_dump` a cada 6 horas;
- `rclone sync` das fotos, com as apagadas guardadas por 40 dias;
- `rclone crypt` sobre o Google Drive com escopo `drive.file`;
- teste de restauração semanal num banco separado;
- status gravado na tabela `backup_runs` e mostrado no painel;
- aviso por e-mail via healthchecks.io.

**Criptografia:** ficou o rclone crypt em vez do age com chave pública. Ele permite enviar as fotos de forma incremental e testar a descriptografia no próprio servidor. A troca é que as chaves ficam no servidor. Se ele for invadido, é preciso revogar o acesso do rclone no Google.

**Caddy:** escolhido em vez de Nginx com Certbot porque faz o HTTPS e a renovação sem configuração extra.

## Pendências conhecidas
- WhatsApp Nível 2 implementado, mas **não testado contra a API real da Meta**.
- Os testes de ponta a ponta das telas foram feitos com Playwright durante o desenvolvimento, mas ainda não estão no repositório.
- Os scripts de produção foram testados assim:
  - backup, teste e restauração rodaram de verdade contra PostgreSQL 16, com o rclone crypt sobre uma pasta local no lugar do Google Drive;
  - Compose e Caddyfile foram validados.
- Ainda não foram testados:
  - a construção das imagens Docker e o `preparar-servidor.sh`. O ambiente de desenvolvimento não tinha acesso ao Docker Hub nem a um Ubuntu com systemd. Rode a primeira instalação acompanhando a saída.
  - a conexão com o Google Drive real.
- Arrastar e soltar na agenda funciona com mouse. No celular, o caminho é tocar no agendamento e usar **Remarcar**.
