# Colocar no ar na Hostinger (natanmotos.com.br)

Guia para quem administra o site (Alexandre). São 7 etapas. Na primeira vez leva perto de 1 hora, contando a espera do DNS.

| O quê | Onde | Custo aproximado |
|---|---|---|
| Servidor | Hostinger VPS **KVM 1** (1 vCPU, 4 GB, 50 GB), 24 meses, São Paulo | R$ 30/mês na promoção (renova perto de R$ 60) |
| Domínio | **natanmotos.com.br** no Registro.br | R$ 40/ano |
| Backup externo | Google Drive (15 GB grátis) | grátis |
| Avisos por e-mail | healthchecks.io e UptimeRobot | grátis |

Confira os preços na hora de pagar: eles mudam com as promoções.

> **Não contrate o backup diário pago da Hostinger.** O projeto já faz backup a cada 6 horas, criptografado, fora da Hostinger e testado toda semana. Os detalhes estão em [BACKUP-E-SEGURANCA.md](BACKUP-E-SEGURANCA.md).

---

## 1. Registrar o domínio
1. Em <https://registro.br>, pesquise **natanmotos.com.br**.
2. Registre no **CPF ou CNPJ do Natan**: o domínio é da oficina.
3. No cadastro, coloque você como **contato técnico**, para receber os avisos.
4. Ative a renovação automática. Domínio vencido derruba o site e o e-mail.

## 2. Criar a chave SSH no seu Windows
No PowerShell:
```powershell
ssh-keygen -t ed25519 -C "alexandre-natanmotos"
```
Aceite o local padrão e crie uma senha para a chave. A chave pública fica em `C:\Users\SEU_USUARIO\.ssh\id_ed25519.pub`. Para copiar:
```powershell
Get-Content $env:USERPROFILE\.ssh\id_ed25519.pub | Set-Clipboard
```

## 3. Contratar o VPS
1. **VPS › KVM 1 › 24 meses.**
2. **Local:** São Paulo, Brasil.
3. **Sistema operacional:** **Ubuntu 24.04** puro, sem painel e sem aplicativo.
4. **Chave SSH:** cole a chave pública da etapa 2. Se o assistente não pedir, adicione depois em *VPS › Configurações › Chaves SSH*.
5. Anote o **IP** do servidor.

## 4. Apontar o domínio para o servidor
No Registro.br, abra **natanmotos.com.br › DNS › Editar zona** e crie:

| Tipo | Nome | Valor |
|---|---|---|
| A | *(vazio, ou @)* | IP do servidor |
| A | www | IP do servidor |

A propagação leva de alguns minutos a algumas horas. Para conferir no PowerShell:
```powershell
Resolve-DnsName natanmotos.com.br
```

## 5. Blindar o servidor (uma vez)
1. No PowerShell:
   ```powershell
   scp natan-motos.zip root@IP_DO_SERVIDOR:/root/
   ssh root@IP_DO_SERVIDOR
   ```
2. Já dentro do servidor:
   ```bash
   apt-get update && apt-get install -y unzip
   unzip natan-motos.zip -d /opt && cd /opt/natan-motos/deploy
   bash servidor/preparar-servidor.sh alexandre
   ```
3. **Antes de fechar a janela**, abra outro PowerShell e teste `ssh alexandre@IP_DO_SERVIDOR`. A partir daqui o root não entra mais por SSH, e só funciona login com chave.
4. Já como `alexandre`, passe a pasta para o seu usuário:
   ```bash
   sudo mv /opt/natan-motos ~/ && sudo chown -R alexandre: ~/natan-motos
   ```

## 6. Instalar o site
```bash
cd ~/natan-motos/deploy
bash servidor/instalar-site.sh
```
- O script pergunta o domínio (Enter aceita `natanmotos.com.br`), o seu e-mail e o seu login no painel. Esse primeiro login é o seu, de **administrador do sistema**.
- Ele confere o DNS, sobe tudo e espera o HTTPS ficar pronto.
- No final, o script mostra **o seu login e a senha inicial**. Entre e troque a senha em *Configurações › Minha senha*.
- Em *Configurações › Equipe*, cadastre o **Natan** com a função **Dono** e os mecânicos. Entregue a cada um o e-mail e a senha inicial.

Depois do primeiro login, entre no painel e confira *Configurações › Oficina*. O endereço do site já vem `https://natanmotos.com.br`.

## 7. Ligar o backup
Siga a seção **Ligar o backup** de [BACKUP-E-SEGURANCA.md](BACKUP-E-SEGURANCA.md). Ela leva uns 10 minutos.

## Por último: Instagram e WhatsApp
- **Instagram:** cole na bio o link de *Configurações › WhatsApp*: `https://natanmotos.com.br/agendar?src=instagram`.
- **WhatsApp Business:** cole o texto da mensagem de saudação da mesma tela.

---

## Dia a dia de quem administra

| Tarefa | Comando (em `~/natan-motos/deploy`) |
|---|---|
| Ver se está tudo de pé | `docker compose ps` |
| Ver erros do site | `docker compose logs --tail 100 app` |
| Atualizar o site com código novo | substitua os arquivos (zip ou `git pull`) e rode `bash servidor/instalar-site.sh` |
| Backup agora | `./restaurar.sh backup-agora` |
| Testar o backup agora | `./restaurar.sh testar` |
| Ver as cópias | `./restaurar.sh listar` |
| Atualizar o Docker e o sistema (uma vez por mês) | `sudo apt-get update && sudo apt-get -y upgrade` |
| Atualizar as imagens base (uma vez por mês) | `docker compose pull && docker compose up -d --build` |
| Ver IPs bloqueados por erro de senha | `sudo fail2ban-client status sshd` |
| Administrador esqueceu a senha do painel | `docker compose exec app node scripts/redefinir-senha.js email@da.pessoa` (mostra uma senha nova) |

As atualizações de segurança do Ubuntu já instalam sozinhas. Quando o sistema pede, o servidor reinicia às 05:00 e o site volta sozinho.

### Voltar uma versão (rollback)
1. Guarde o zip de cada versão que você instalar.
2. Antes de atualizar, rode `./restaurar.sh backup-agora`.
3. Se a versão nova der problema, coloque os arquivos da versão anterior de volta e rode `bash servidor/instalar-site.sh`.
4. Se a atualização mexeu no banco, rode também `./restaurar.sh banco` para voltar à cópia feita antes de atualizar.

### Senhas e segredos
Ficam todos em `deploy/.env`, que só o seu usuário consegue ler. Guarde uma cópia no seu gerenciador de senhas. Se perder o servidor, você precisa só de:
- o **kit de recuperação** do backup;
- a **conta Google** dos backups.

O `.env` novo é gerado de novo na reinstalação.
