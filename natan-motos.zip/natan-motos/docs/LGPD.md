# LGPD: Natan Motos

Avaliação técnica feita durante o desenvolvimento. **Não substitui parecer jurídico.** Valide os prazos de guarda com o contador e o aviso de privacidade com um advogado antes de publicar.

## Papéis
- **Controlador:** Natan Motos.
- **Operadores:**
  - Hostinger: servidor VPS no datacenter de São Paulo.
  - Google: backups criptografados no Google Drive e mapa incorporado no navegador do visitante.
  - Meta: WhatsApp Nível 2.
  - Administrador do site: Alexandre, que cuida do servidor e dos backups.
  - Registre por escrito, mesmo de forma simples, o que o administrador pode fazer com os dados: só manter o sistema e os backups, com sigilo (art. 39).
- **Encarregado:** a oficina é agente de tratamento de pequeno porte e pode dispensar a indicação (Res. CD/ANPD 2/2022). Mesmo assim, mantém um canal com o titular: o WhatsApp da oficina, informado no aviso de privacidade e editável em Configurações.

## Inventário de dados (art. 37)
| Dado | Titular | Finalidade | Base legal | Onde fica | Retenção |
|---|---|---|---|---|---|
| Nome, WhatsApp | Cliente | Agendar, avisar sobre o serviço | Execução de contrato (art. 7º, V) | `customers` | 5 anos após o último serviço, depois anonimização automática |
| E-mail (opcional) | Cliente | Confirmação | Execução de contrato | `customers` | Igual |
| Marca, modelo, ano, placa, km | Cliente | Prestar o serviço, histórico | Execução de contrato | `motorcycles` | Igual (placa substituída na anonimização) |
| Relato do problema | Cliente | Diagnóstico | Execução de contrato | `bookings` | Apagado na anonimização |
| Fotos (cliente e check-in) | Cliente | Registrar estado da moto | Exercício regular de direitos (art. 7º, VI) | disco/volume `uploads` | 1 ano após a entrega (rotina diária) |
| IP + data da aprovação | Cliente | Provar a aprovação do orçamento | Exercício regular de direitos | `service_orders` | 5 anos |
| Pagamentos (valor, forma) | Cliente | Financeiro | Execução de contrato e obrigação legal | `payments` | 5 anos; após anonimização não identifica a pessoa |
| Consentimento de lembretes | Cliente | Marketing de retorno | Consentimento (art. 7º, I) | `customers.reminderConsentAt` | Até revogar |
| Nome, e-mail, senha protegida (hash), comissão | Equipe | Acesso e pagamento | Execução de contrato | `users` | Enquanto houver vínculo + 5 anos |
| Logs de mensagens | Cliente | Diagnóstico de envio | Legítimo interesse | `notification_logs` | 180 dias |

O sistema **não coleta** dados sensíveis (art. 5º, II), dados de crianças, CPF, endereço do cliente ou dados de cartão. Por isso não é exigido o RIPD (art. 38).

## Decisões de privacidade no produto
- **Consentimento separado:** o aceite do aviso de privacidade é obrigatório para agendar e serve como ciência, não como base legal. A caixa de lembretes é opcional e vem **desmarcada**.
- **Sem busca de cliente por telefone no site público:** o prompt previa preencher nome e motos ao digitar o telefone. Isso permitiria a qualquer pessoa descobrir o nome e as placas de outra. O pré-preenchimento usa o próprio aparelho do cliente (armazenamento local), e o botão "Não sou eu" apaga esses dados.
- **Links privados** de agendamento e orçamento com 192 bits aleatórios. Nenhum id sequencial é exposto.
- **Logs sem dados pessoais:** os erros registram só método, rota e código. A auditoria guarda ids e nomes de campos, nunca os valores.
- **Retenção automática:** a rotina diária roda às 03:30.
- **Backups:**
  - criptografados antes de sair do servidor;
  - guardados no máximo **13 meses**: o banco por 8 dias, 40 dias ou 13 meses, conforme o tipo, e as fotos apagadas por 40 dias;
  - quando um cliente é apagado, ele some dos backups conforme essas cópias vencem;
  - ao restaurar uma cópia antiga, refaça as eliminações feitas depois dela (veja `BACKUP-E-SEGURANCA.md`).

## Direitos do titular (art. 18)
| Direito | Como atender |
|---|---|
| Confirmação e acesso, portabilidade | Painel › Clientes › **Exportar dados** (JSON com tudo do cliente) |
| Correção | Painel › Clientes › **Editar** |
| Eliminação | Painel › Clientes › **Apagar dados**: anonimiza o cadastro e apaga as fotos. O financeiro fica, sem identificar a pessoa (obrigação legal). |
| Revogar consentimento | Link no "Meu agendamento" ou Painel › Clientes › **Cliente pediu para parar** |
| Informação sobre compartilhamento | Aviso de privacidade (`/privacidade`) |

Prazo de resposta: até 15 dias (art. 19, II). Registre a data de cada pedido atendido. O painel já grava a exportação e a eliminação na auditoria.

## Transferência internacional (arts. 33 a 36)
O servidor da Hostinger fica no Brasil, em São Paulo. Os backups no Google Drive e a Meta podem processar dados fora do Brasil. Os backups vão criptografados, e só a oficina tem as senhas. Use os termos de tratamento de dados dos provedores com as cláusulas-padrão contratuais da ANPD (Res. CD/ANPD 19/2024). O aviso de privacidade já informa essa transferência.

## Plano de resposta a incidentes (art. 48, Res. CD/ANPD 15/2024)
1. **Detectar:** alerta do monitor de saúde, aviso do provedor ou comportamento estranho no painel.
2. **Conter:**
   - troque `JWT_SECRET` e `JWT_REFRESH_SECRET` (todas as sessões caem);
   - troque as senhas da equipe;
   - desative os usuários suspeitos;
   - se preciso, gere uma nova chave do WhatsApp.
3. **Avaliar** quais dados e quantos titulares foram afetados, usando a auditoria (`audit_logs`) e os logs do Railway.
4. **Comunicar:** se houver risco ou dano relevante, avise a ANPD e os titulares em até 3 dias úteis. Agente de pequeno porte tem prazo em dobro.
5. **Registrar** todo incidente, mesmo os não comunicados, e guardar o registro por no mínimo 5 anos.

Antes de afirmar prazos, confira em <https://www.gov.br/anpd> se as resoluções continuam vigentes.
