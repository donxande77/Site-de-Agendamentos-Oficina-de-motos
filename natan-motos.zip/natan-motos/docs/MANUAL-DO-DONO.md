# Manual do dono: Natan Motos

Endereço do painel: **natanmotos.com.br/admin**. No celular, abra o painel no navegador e use *Adicionar à tela inicial*: ele fica como um aplicativo.

## Os 4 acessos
| Acesso | Quem | Onde entra | O que faz |
|---|---|---|---|
| **Administrador do sistema** | Alexandre | `/admin` | Tudo, e é o **único** que altera o sistema: serviços e preços, dados da oficina, horários, elevadores, regras de agendamento, textos do WhatsApp, equipe e acessos, catálogo de peças e backup. |
| **Dono da oficina** | Natan | `/admin` (abre no **Painel**) | O dia a dia completo: agenda, OS, valores do orçamento e envio ao cliente, pagamentos, financeiro, clientes e lembretes. Também trabalha como mecânico. **Não** altera configurações. Para mudar preço, horário ou equipe, pede ao administrador. |
| **Mecânico** | cada mecânico, com o próprio login | `/admin` (abre na área **Hoje**) | Vê a agenda e o movimento do dia. Faz o check-in (**Moto chegou**), diagnóstico, fotos, as peças que o cliente compra e o andamento da OS. **Não** cria nem exclui serviços, **não** muda valores, **não** envia orçamento, **não** recebe pagamento e **não** vê o financeiro. |
| **Cliente** | qualquer pessoa | link da bio, do WhatsApp ou o QR code | Agenda sem cadastro. Pelo link que recebe, acompanha a moto, remarca, cancela e aprova o orçamento. |

**Detalhes do acesso do mecânico:**
- Ele vê a agenda de **todos os dias**, passados e futuros. Na tela Agenda, use as setas, o calendário ou o modo **Semana**.
- O **valor do diagnóstico** é o mecânico quem coloca. Ele digita no quadro *Diagnóstico* da OS, e o valor entra sozinho no orçamento do cliente. Depois que o cliente aprova, só o dono ou o administrador mudam.
- Ele vê todas as OS, mas só altera as dele.
- Se uma OS está sem mecânico, ela passa para o nome de quem começar a trabalhar nela.
- Para o mecânico também lançar serviços e valores, ligue em **Configurações › Equipe › Mecânico pode lançar serviços e valores no orçamento**. Essa opção vem desligada.

## Primeiro acesso do administrador do sistema (uma vez só)
0. **Configurações › Equipe:** cadastre o Natan com a função **Dono** e cada mecânico.
1. **Configurações › Oficina:** confira endereço, WhatsApp, Instagram e o endereço do site.
2. **Configurações › Horários:** ajuste o horário real de cada dia e o almoço. O sistema veio com seg–sex 08:00–18:00 (almoço 12:00–13:00) e sáb 08:00–12:00. Esses horários são só um ponto de partida.
3. **Serviços e preços:** coloque o preço de cada serviço. Enquanto não tiver preço, o site mostra "sob consulta". Marque "sob avaliação" nos serviços que dependem de ver a moto.
4. **Configurações › Equipe:** cadastre cada mecânico, com e-mail, senha inicial e comissão, se houver. Se alguém sair da oficina, desative o acesso.
5. **Configurações › WhatsApp:** copie o link da bio e cole no Instagram. Copie a mensagem de saudação e cole no WhatsApp Business.
6. **Minha senha:** troque a senha inicial.

## O dia a dia
| Momento | Onde | O que fazer |
|---|---|---|
| Começo do dia | **Painel** | Veja a agenda de hoje, as motos na oficina e os alertas. |
| Cliente chegou | **Agenda** › toque no agendamento › **Moto chegou** | Anote o km, o combustível e os itens deixados. Isso abre a OS. |
| Moto sem agendamento | **OS › Nova OS (balcão)** | Busque o cliente ou cadastre na hora. |
| Ligação ou balcão | **Agenda › Novo agendamento** | Marque o horário pelo cliente. |
| Fotos da entrada | **OS › Fotos › Adicionar** | Tire 3 ou 4 fotos da moto. Elas protegem você em caso de reclamação. |
| Diagnóstico pronto | **OS** | O mecânico escreve o diagnóstico e escolhe as peças. O administrador lança os **Serviços** com valor. Em **Peças para o cliente comprar**, toque nas peças do catálogo (com foto), coloque quantidade e observação. Depois, em **Enviar orçamento ao cliente**: **Enviar PDF** (abre o compartilhar do celular com o PDF, escolha o WhatsApp e o cliente) ou **Enviar link no WhatsApp**. |
| Cliente aprovou | automático | Quando o cliente aprova pelo link, a OS vira "Aprovada" e as peças saem do estoque. Se ele aprovou por telefone, toque em **Cliente aprovou (balcão)**. |
| Serviço feito | **OS › Relatório do serviço** | Escreva **O que foi feito** (sai no PDF da OS) e, se quiser, **Observações internas** (só a oficina vê). Achou outro problema na moto? Toque em **Registrar**, diga a gravidade, se avisou o cliente e o que ele decidiu. |
| Moto pronta | **OS › Moto pronta** | O sistema pergunta se quer avisar o cliente pelo WhatsApp. |
| Cliente pagou | **OS › Receber** | Pix, dinheiro, débito ou crédito. Pode registrar pagamento parcial. |
| Entrega | **OS › Entregar moto** | Se faltar dinheiro, a OS vai para "A receber" no Financeiro. |

## Prontuário da moto
Cada moto tem um prontuário com todas as visitas: data, km, mecânico, o que o cliente relatou, o diagnóstico, **o que foi feito**, os serviços, as fotos e tudo o que foi **encontrado além do pedido**.
- **Onde abrir:** na OS (**Prontuário da moto**, embaixo da placa), no cadastro do cliente (botão **Prontuário** em cada moto) ou pelo aviso na agenda.
- **Encontrado além do pedido:** para cada defeito ou ponto de atenção, registre:
  - a gravidade: **Urgente** (segurança), **Em breve** ou **Acompanhar**;
  - o que o cliente decidiu: consertado agora, vai fazer depois, não quis fazer, ou ainda não falou com ele;
  - se ele foi avisado, e como (pessoalmente, WhatsApp, telefone). Fica gravado quem avisou e quando.
- O botão **Avisar no WhatsApp** abre a conversa do cliente com a mensagem pronta e já marca como avisado.
- O que não foi consertado sai no **PDF da OS e do orçamento** como "Outros pontos encontrados na moto", e o cliente assina que foi informado. Isso protege a oficina se o problema aparecer depois.
- **Quando a moto volta:** a agenda, a tela Hoje e a OS nova mostram a última visita e as **pendências**. Se resolver uma delas na visita nova, toque em **Resolvido nesta OS**.
- O mecânico escreve o relatório enquanto a OS está aberta. Depois de entregue, só o dono da oficina corrige. O mecânico não vê valores no prontuário.

## Cadastro único de clientes e motos
- Um cliente por WhatsApp e uma moto por placa. O sistema não cria cadastro repetido.
- **No site:** o cliente que já veio toca em **Já trouxe a moto aqui?**, digita o WhatsApp e a placa, e os dados dele e da moto aparecem preenchidos. Só reconhece quando **os dois** batem com o mesmo cadastro; só o telefone ou só a placa não mostram nada (proteção dos dados).
- Pelo site, o nome já cadastrado não é trocado. Correções de nome são feitas pela oficina, em **Clientes › Editar**.
- **Na oficina:** ao agendar ou cadastrar, o sistema avisa na hora se o WhatsApp ou a placa já existem e oferece **Usar o cadastro dele**.
- **Moto vendida:** se alguém agenda com uma placa que está no cadastro de outra pessoa, o sistema não troca o dono sozinho. O agendamento entra com um aviso nas observações. Confira na chegada e use **Clientes › moto › Moto vendida** para transferir (o prontuário vai junto).
- **Placa digitada errada** (a mesma moto ficou duas vezes no cliente): **É a mesma moto que outra** junta as duas. Só o dono da oficina faz isso.
- **Cliente trocou de número** e ficou com dois cadastros: abra o cadastro certo e use **Juntar cadastro repetido**. A lista de clientes avisa quando há cadastros com o mesmo nome ou e-mail. Só o dono da oficina junta cadastros.

## Peças
- A oficina não vende peças: o site avisa e cada serviço diz o que o cliente deve trazer (edite em **Serviços e preços › Peças que o cliente precisa trazer**). Serviços de avaliação ficam sem peças.
- **Catálogo de peças:** 57 peças da moto com ilustração. Abra uma peça e toque em **Usar foto real** para trocar pela foto de verdade.
- Se um dia a oficina passar a vender peças, marque **Configurações › Agendamento › A oficina vende peças**: o aviso some e o **Estoque** aparece no menu.

## Agenda
- Cada coluna é um elevador. Toque num horário vazio para agendar e arraste um agendamento para remarcar (no computador).
- **Bloquear horário:** use para feriado, folga de mecânico ou manutenção do elevador.
- Se a moto não chegar 30 minutos depois do horário, o sistema marca "Não compareceu". Se ela chegar atrasada, toque em **Desfazer falta**.

## Financeiro (só o dono vê)
- **Recebido**, **despesas**, **custo das peças** e **lucro** do período.
- Lance as despesas fixas (aluguel, luz, internet) para o lucro ficar real.
- **A receber:** quem levou a moto e ainda deve.
- **Comissões:** calculadas sobre a mão de obra das OS entregues.
- Os botões CSV baixam planilhas que abrem no Excel.

## Lembretes de revisão
Quando uma OS com troca de óleo é entregue, o sistema cria um lembrete para daqui a 90 dias ou 3.000 km. Na tela **Lembretes**, toque em **Enviar** e o WhatsApp abre com a mensagem pronta. O botão só funciona para clientes que autorizaram receber lembretes.

## Backup
Em **Configurações › Backup** você vê a última cópia de cada tipo:
- o banco, a cada 6 horas;
- as fotos, todo dia;
- o teste semanal, que confirma que a cópia abre de verdade.

Tudo verde: não precisa fazer nada. Se aparecer um alerta amarelo no **Painel**, avise o Alexandre: ele recebe o mesmo aviso por e-mail.

## Pedidos de privacidade
Se um cliente pedir uma cópia dos dados ou para apagar o cadastro, vá em **Clientes › nome do cliente** e use **Exportar dados** ou **Apagar dados**. Responda em até 15 dias.
