# Implantação (colocar o site no ar)

> **Escolha atual: Hostinger VPS com o domínio natanmotos.com.br.** Siga [HOSPEDAGEM-HOSTINGER.md](HOSPEDAGEM-HOSTINGER.md) e [BACKUP-E-SEGURANCA.md](BACKUP-E-SEGURANCA.md). Este arquivo fica como alternativa: Railway, sem servidor para administrar.

O sistema roda como **um único serviço** (o `Dockerfile` na raiz) mais **um banco PostgreSQL**. A API entrega o site, então só existe um endereço.

Recomendação: **Railway**. Ele tem PostgreSQL integrado e volume para guardar as fotos. Plano Hobby: cerca de US$ 5/mês (confira o preço atual no site).

## 1. Subir o código para o GitHub
```powershell
cd natan-motos
git init
git add .
git commit -m "feat: sistema Natan Motos"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/natan-motos.git
git push -u origin main
```
O arquivo `.gitignore` já impede que o `.env` (com as senhas) vá para o GitHub.

## 2. Criar o projeto no Railway
1. Em <https://railway.app>, clique em **New Project › Deploy from GitHub repo** e escolha `natan-motos`. O Railway detecta o `Dockerfile` sozinho.
2. No mesmo projeto, clique em **New › Database › PostgreSQL**.
3. No serviço do site, abra **Variables** e crie:

| Variável | Valor |
|---|---|
| `DATABASE_URL` | `${{Postgres.DATABASE_URL}}` (referência ao banco) |
| `JWT_SECRET` | texto aleatório de 48+ caracteres |
| `JWT_REFRESH_SECRET` | outro texto aleatório de 48+ caracteres |
| `PUBLIC_BASE_URL` | `https://natanmotos.com.br` (ou o domínio do Railway) |
| `SEED_OWNER_EMAIL` | e-mail de login do Natan |
| `SEED_OWNER_PASSWORD` | senha inicial do Natan (troque depois no painel) |
| `PORT` | `3333` |

Para gerar textos aleatórios: `node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"`.

4. **Volume para as fotos:** em **Settings › Volumes**, crie um volume montado em `/data`. Sem ele, as fotos somem a cada nova versão.
5. **Região:** escolha a região mais próxima disponível. Os dados vão ficar fora do Brasil, e isso já está descrito no aviso de privacidade.
6. Faça o deploy. Na primeira subida, o contêiner cria as tabelas e o login do dono sozinho.
7. Confira se `https://SEU-DOMINIO/api/health` responde `{"ok":true}`.

### Domínio próprio
Em **Settings › Networking › Custom Domain**, adicione `natanmotos.com.br` e crie o registro CNAME que o Railway indicar no Registro.br. Depois atualize `PUBLIC_BASE_URL` e o endereço do site em **Painel › Configurações › Oficina**.

## 3. Instagram e WhatsApp
- **Bio do Instagram:** copie o link em **Configurações › WhatsApp › Link da bio do Instagram** (termina em `?src=instagram`) e cole em *Editar perfil › Links*.
- **WhatsApp Nível 1 (grátis):** no app **WhatsApp Business**, vá em *Ferramentas comerciais*:
  - em *Mensagem de saudação*, cole o texto de saudação da tela **Configurações › WhatsApp**;
  - em *Mensagem de ausência*, cole o texto de ausência.

  Com isso, quem mandar mensagem recebe o link na hora.
- **QR code para o balcão:** botão *Baixar QR code* na mesma tela.

### WhatsApp Nível 2 (opcional, API oficial da Meta)
Use quando quiser que confirmações e lembretes saiam sozinhos.
1. Crie um app em <https://developers.facebook.com>, adicione o produto **WhatsApp** e registre o número da oficina. O número não pode continuar no app WhatsApp Business comum.
2. Gere um token permanente com *System User* no Business Manager.
3. Configure as variáveis no Railway: `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_APP_SECRET` e `WHATSAPP_VERIFY_TOKEN` (um texto que você inventa).
4. No app da Meta, em *Webhooks*, use a URL `https://SEU-DOMINIO/api/v1/webhooks/whatsapp` com o mesmo verify token e assine o campo `messages`.
5. Mensagens fora da janela de 24 h exigem **modelos aprovados** pela Meta. Crie os modelos e informe os nomes nas variáveis `WHATSAPP_TEMPLATE_*` (veja o `.env.example`).
6. No painel, em **Configurações › WhatsApp**, clique em **Ligar Nível 2**.

A Meta cobra por conversa iniciada pela empresa. Confira a tabela atual antes de ligar.
> O Nível 2 foi implementado conforme a documentação da API, mas não foi testado contra a Meta durante o desenvolvimento. Faça um teste com seu próprio número antes de usar com clientes.

## 4. Backups
> Na Hostinger, o backup automático já vem pronto (pasta `deploy/backup`). As instruções abaixo valem só para o Railway.

- No PostgreSQL do Railway, ative os backups em **Backups** (plano pago) ou rode `pg_dump` uma vez por semana:
  ```powershell
  pg_dump "URL_DO_BANCO" -Fc -f natanmotos-AAAA-MM-DD.dump
  ```
- Guarde os backups por no máximo 6 meses e apague os mais antigos. Isso segue a política de retenção descrita em `docs/LGPD.md`.

## 5. Atualizar e voltar versão (rollback)
- Cada `git push` para `main` gera uma nova versão automaticamente.
- Se algo der errado, em **Deployments**, clique nos três pontos da versão anterior e escolha **Redeploy**.
- As migrações de banco só adicionam estrutura. Antes de qualquer migração que apague colunas, faça um backup.

## Alternativa: Render
O Render também roda o `Dockerfile`, mas o disco persistente para fotos só existe em planos pagos. O PostgreSQL gratuito do Render expira depois de algumas semanas, então não use o banco gratuito em produção.

## Monitoramento
- **Saúde:** `GET /api/health`. Use um monitor gratuito, como o UptimeRobot, para receber um alerta se o site cair.
- **Logs:** ficam na aba *Logs* do Railway. Eles não registram dados pessoais dos clientes.
