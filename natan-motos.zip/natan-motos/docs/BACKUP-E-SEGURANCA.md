# Backup e segurança

## Resumo

| Proteção | Como funciona |
|---|---|
| **Backup do banco** | 4 vezes por dia: 03h, 09h, 15h e 21h. No pior caso, perde-se até 6 horas. |
| **Backup das fotos** | Todo dia às 03h, só as fotos novas. |
| **Fora da Hostinger** | Cópia no Google Drive. Se o servidor ou a conta da Hostinger sumirem, os dados continuam lá. |
| **Criptografia** | O rclone crypt criptografa o conteúdo, os nomes dos arquivos e as pastas antes de sair do servidor. Quem abrir o Drive vê só nomes embaralhados. |
| **Acesso mínimo ao Drive** | O servidor só enxerga os arquivos que ele mesmo criou (permissão `drive.file`), e não o resto do Drive. |
| **Teste semanal** | Todo domingo às 04h30, a última cópia é baixada do Drive, descriptografada e restaurada num banco separado. Depois o sistema confere tabelas, clientes, agendamentos, OS e fotos. |
| **Aviso para o Natan** | Painel › Configurações › **Backup**, com o status de cada cópia. Se algo atrasar ou falhar, aparece um alerta no Painel. |
| **Aviso para o administrador** | E-mail do healthchecks.io quando o backup falha **ou para de rodar**, por exemplo com o servidor desligado. |
| **Site fora do ar** | E-mail do UptimeRobot (veja "Monitorar o site"). |

### Quanto tempo cada cópia fica guardada

| Onde | O quê | Por quanto tempo |
|---|---|---|
| Servidor | Cópias do banco | 3 dias (servem para restaurar rápido) |
| Drive `banco/6h` | Todas as cópias do banco | 8 dias |
| Drive `banco/diario` | A cópia das 03h | 40 dias |
| Drive `banco/mensal` | A cópia do dia 1º | 13 meses |
| Drive `fotos/atual` | Espelho das fotos do site | enquanto a foto existir no site |
| Drive `fotos/apagadas` | Fotos que saíram do site | 40 dias, depois são apagadas (LGPD) |

O banco da oficina é pequeno: alguns MB. As fotos crescem perto de 0,5 a 1 GB por ano. Os 15 GB grátis do Google Drive aguentam muitos anos.

---

## Ligar o backup (uma vez, uns 10 minutos)

**Antes de começar:** use uma conta Google **só para os backups**, por exemplo `natanmotos.backup@gmail.com`. Ative a verificação em duas etapas nela. Assim os backups não dependem da conta pessoal de ninguém.

1. **No seu Windows:** baixe o rclone em <https://rclone.org/downloads/> (Windows, Intel/AMD 64 bits) e extraia o zip. No PowerShell, entre na pasta extraída e rode:
   ```powershell
   .\rclone.exe authorize "drive" "eyJzY29wZSI6ImRyaXZlLmZpbGUifQ"
   ```
   O navegador abre. Entre com a conta dos backups e autorize. O PowerShell mostra um texto que começa com `{"access_token"`: copie a linha inteira.

2. **No servidor**, dentro de `~/natan-motos/deploy`:
   ```bash
   bash servidor/configurar-backup.sh
   ```
   - Cole o texto do passo 1.
   - Responda **N** em "Tem um kit de recuperação?". Isso cria as senhas da criptografia.
   - Opcional, mas recomendado: cole as URLs do healthchecks.io (próxima seção).
   - No final, o script faz o primeiro backup e o primeiro teste.

3. **Guarde o kit de recuperação.** O script cria `~/KIT-DE-RECUPERACAO-natanmotos.txt` com as 2 senhas da criptografia.
   ```powershell
   scp alexandre@IP_DO_SERVIDOR:~/KIT-DE-RECUPERACAO-natanmotos.txt .
   ```
   - Guarde em **dois lugares**: no gerenciador de senhas e numa cópia impressa com o Natan.
   - **Não** guarde no mesmo Google Drive dos backups.
   - Depois apague do servidor: `shred -u ~/KIT-DE-RECUPERACAO-natanmotos.txt`.

> **Sem o kit, ninguém abre os backups, nem você.** Esse é o preço da criptografia.

### Avisos por e-mail (healthchecks.io, grátis)
1. Crie uma conta em <https://healthchecks.io> com o **seu** e-mail.
2. Crie dois *checks*:
   - **Natan Motos backup:** Period **6 horas**, Grace **2 horas**.
   - **Natan Motos teste:** Period **7 dias**, Grace **1 dia**.
3. Cole as *Ping URLs* quando o `configurar-backup.sh` pedir.
4. Para mudar depois, edite `HEALTHCHECK_URL` e `HEALTHCHECK_VERIFY_URL` no `deploy/.env` e rode `docker compose up -d backup`.

### Monitorar o site (UptimeRobot, grátis)
Em <https://uptimerobot.com>, crie um monitor **HTTP(s)** para `https://natanmotos.com.br/api/health`, a cada 5 minutos, com alerta para o seu e-mail.

---

## Restaurar

Tudo roda no servidor, em `~/natan-motos/deploy`.

| Situação | Comando |
|---|---|
| Ver as cópias disponíveis | `./restaurar.sh listar` |
| Alguém apagou algo importante e é preciso voltar o banco | `./restaurar.sh banco` (usa a cópia mais recente) |
| Voltar para um momento específico | `./restaurar.sh banco banco/diario/banco_2026-11-01_0300.dump` |
| Fotos sumiram | `./restaurar.sh fotos` |

- O `restaurar.sh banco` para o site, guarda o banco atual em `antes-da-restauracao_*.dump` (fica 30 dias), restaura e liga o site de novo.
- Ele pede para você digitar `RESTAURAR` antes de mexer.
- Tudo o que foi feito depois da cópia escolhida se perde. Combine com o Natan antes.

### O servidor sumiu (servidor novo do zero)
1. Contrate o VPS e siga as etapas 3 a 6 de [HOSPEDAGEM-HOSTINGER.md](HOSPEDAGEM-HOSTINGER.md). O site novo sobe vazio.
2. Rode `bash servidor/configurar-backup.sh`, autorize **a mesma conta Google** e responda **s** em "Tem um kit de recuperação?". Use as senhas do kit.
3. Rode `./restaurar.sh banco` e depois `./restaurar.sh fotos`.
4. O Natan entra com a senha que ele já usava, porque ela volta junto com o banco.

### LGPD depois de restaurar
Se você restaurar uma cópia antiga, clientes que pediram para apagar os dados **depois** daquela data voltam a aparecer.
- Em *Clientes*, refaça o **Apagar dados** dessas pessoas.
- A auditoria do banco atual guarda quem foi apagado e quando. Ela fica salva em `antes-da-restauracao_*.dump`.

---

## Segurança do servidor (o que o `preparar-servidor.sh` faz)

| Medida | Detalhe |
|---|---|
| Login | Só com **chave SSH**. Senha e root bloqueados, no máximo 3 tentativas, e só o usuário administrador entra. |
| Firewall (UFW) | Abertas só as portas **22** (com limite de tentativas), **80** e **443**. O banco não tem porta aberta para a internet. |
| fail2ban | Quem erra o login do SSH 5 vezes em 10 minutos fica bloqueado 1 hora. O tempo cresce a cada reincidência, até 1 semana. |
| Atualizações | As de segurança do Ubuntu instalam sozinhas. Se precisar, o servidor reinicia às 05:00. |
| HTTPS | Feito pelo Caddy (Let's Encrypt), com renovação automática e www redirecionado para o domínio sem www. |
| Contêineres | Cada serviço roda com `no-new-privileges`, e o site roda com um usuário sem privilégios. Os logs têm tamanho limitado, para não encher o disco. |
| Segredos | Senhas geradas aleatoriamente em `deploy/.env` (permissão 600). A configuração do Drive fica em `deploy/secrets/` (permissão 700). Nenhum dos dois vai para o GitHub. |
| Site | Já vinha com a política de segurança de conteúdo (helmet), limite de tentativas de login, cookies `httpOnly` e senhas com bcrypt. |

### Se suspeitar de invasão
1. Siga o plano de incidentes de [LGPD.md](LGPD.md).
2. Troque `JWT_SECRET` e `JWT_REFRESH_SECRET` no `.env`. Todas as sessões caem.
3. Rode `bash servidor/instalar-site.sh`.
4. No Google, revogue o acesso do rclone em *Conta Google › Segurança › Apps com acesso*. Depois rode `configurar-backup.sh` de novo, **com o mesmo kit**.
