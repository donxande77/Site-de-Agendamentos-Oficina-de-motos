# Changelog

## 1.6.0 (2026-11-09)
- **Prontuário da moto:**
  - cada moto tem o histórico de todas as visitas (relato do cliente, diagnóstico, o que foi feito, serviços, peças, fotos, km e mecânico);
  - a OS ganhou o quadro **Relatório do serviço**, com "O que foi feito" (sai no PDF da OS) e "Observações internas" (só a oficina vê);
  - **Encontrado além do pedido:** defeitos e pontos de atenção com gravidade, a decisão do cliente e o registro de quem avisou, quando e como. O botão "Avisar no WhatsApp" manda a mensagem pronta;
  - os itens não consertados saem no PDF da OS e do orçamento, e o cliente assina que foi informado;
  - quando a moto volta, a agenda, a tela Hoje e a OS mostram a última visita e as pendências. Elas podem ser marcadas como resolvidas na OS nova;
  - ao marcar "Moto pronta" ou entregar sem o relatório preenchido, o sistema avisa;
  - o mecânico escreve enquanto a OS está aberta; depois de entregue, só o dono corrige. O mecânico não vê valores no prontuário;
  - a exportação LGPD inclui o relatório e os itens encontrados.
- **Cadastro único:**
  - no site, **"Já trouxe a moto aqui?"**: o WhatsApp e a placa puxam o cadastro. Só reconhece quando os dois batem;
  - pelo site, o nome cadastrado não é trocado;
  - uma placa de outro cliente não troca mais o dono sozinha: o agendamento entra com um aviso para a oficina conferir;
  - no painel, avisos na hora de WhatsApp ou placa já cadastrados;
  - novas ações: **Moto vendida** (transfere com o histórico), **É a mesma moto que outra** e **Juntar cadastro repetido**;
  - a lista de clientes aponta cadastros com o mesmo nome ou e-mail.
- **Agenda:** o calendário do mês mostra uma bolinha azul nos dias com agendamento e o total do mês; os dias em que a oficina fecha aparecem apagados.
- **Painel:** nomes de serviço compridos em "Serviços mais pedidos" quebram linha em vez de alargar a tela no celular.
- **Licença:** LICENSE.md (software proprietário de Alexandre, com licença de uso para a Natan Motos); README atualizado.
- 62 testes da API.

## 1.5.0 (2026-11-06)
- Quatro acessos:
  - **Administrador do sistema**: o único que altera o sistema;
  - **Dono da oficina**: o dia a dia completo, com o dinheiro;
  - **Mecânico**;
  - **Cliente**.
- Ficam só com o administrador do sistema: serviços e preços, configurações da oficina (dados, horários, elevadores, regras, textos do WhatsApp), equipe e acessos, catálogo de peças e backup.
- O dono da oficina usa painel, agenda, OS (valores do orçamento, envio, aprovação), pagamentos, financeiro, despesas, clientes e pedidos LGPD e lembretes. Aparece como mecânico na agenda.
- A instalação cria primeiro o login do administrador do sistema. O Natan é cadastrado depois em Equipe, com a função "Dono".
- Os alertas de backup e de serviço sem preço aparecem só para o administrador do sistema.
- Demonstração com os três logins: natan@demo.com (dono), admin@demo.com (administrador do sistema) e ze@demo.com (mecânico).

## 1.4.0 (2026-11-05)
- Mecânico: agenda de todos os dias, anteriores e futuras (dia ou semana, setas e calendário). O atalho "Outros dias" fica na tela Hoje.
- **Valor do diagnóstico:**
  - o mecânico digita no quadro Diagnóstico da OS e o valor entra no orçamento do cliente, no link e no PDF, como a linha "Diagnóstico";
  - vale mesmo com a opção "mecânico lança valores" desligada;
  - depois que o cliente aprova o orçamento, só o administrador ajusta;
  - se o cliente agendou um serviço de diagnóstico, essa linha vira o valor do diagnóstico no check-in, sem duplicar.
- A demonstração tem agendamentos de dias passados.

## 1.3.0 (2026-11-05)
- Três acessos: **administrador da oficina**, **mecânico** e **cliente**. A função "Dono" passa a se chamar "Administrador".
- Área do mecânico:
  - nova tela **Hoje**, com o movimento do dia, a agenda e as motos na oficina por etapa, sem valores;
  - o mecânico vê a agenda inteira, inclusive o que chegou pelo link sem mecânico, e pode marcar **Moto chegou**;
  - ele vê todas as OS e trabalha nas dele. Uma OS sem mecânico passa para o nome de quem começar nela.
- O mecânico não lança, não altera e não exclui serviços e valores, nem envia o orçamento. A opção em **Configurações › Equipe** libera, se o administrador quiser (vem desligada).
- Tudo isso é conferido no servidor, não só escondido na tela. São 8 testes novos (47 no total).

## 1.2.0 (2026-11-05)
- Pacote de produção para VPS (Hostinger) em `deploy/`:
  - Docker Compose com site, PostgreSQL sem porta aberta, Caddy com HTTPS automático (www redireciona para natanmotos.com.br) e serviço de backup.
- Backup automático:
  - banco 4 vezes por dia e fotos todo dia;
  - cópia criptografada (rclone crypt) no Google Drive, com acesso só aos arquivos do próprio backup;
  - retenção de 8 dias, 40 dias e 13 meses;
  - fotos apagadas somem do backup em 40 dias.
- Teste de restauração automático aos domingos: a cópia do Drive é restaurada num banco separado e conferida.
- `restaurar.sh`: listar, voltar o banco (com cópia de segurança antes), trazer fotos de volta, backup e teste sob demanda.
- Painel do dono: aba **Configurações › Backup** e alerta no Painel quando o backup atrasa ou falha.
- Avisos por e-mail para o administrador (healthchecks.io) quando o backup falha ou para.
- Scripts do servidor:
  - `preparar-servidor.sh`: SSH só com chave, firewall, fail2ban, atualizações automáticas, swap e Docker;
  - `instalar-site.sh`: segredos aleatórios, conferência do DNS e login inicial;
  - `configurar-backup.sh`: Google Drive e kit de recuperação.
- Guias: `docs/HOSPEDAGEM-HOSTINGER.md` e `docs/BACKUP-E-SEGURANCA.md`.

## 1.1.0 (2026-11-05)
- Oficina sem venda de peças (padrão): aviso no site e, em cada serviço, quais peças o cliente deve trazer. Serviços de avaliação não pedem peças.
- Confirmação e lembrete pelo WhatsApp incluem as peças a trazer.
- Catálogo de peças da moto (57 peças em 8 sistemas), cada uma com ilustração própria; dá para trocar por foto real.
- Orçamento com "Peças para o cliente comprar": foto, quantidade, observação e valor estimado. Não somam no valor do serviço.
- O catálogo fica aberto dentro do orçamento para o mecânico escolher as peças. Mecânico pode montar e enviar o orçamento das OS dele.
- Envio do orçamento sem API do WhatsApp: "Enviar PDF" abre o compartilhar do celular com o PDF anexado; "Enviar link" abre a conversa do cliente com o link.
- Página do orçamento do cliente mostra as peças com foto e tem "Baixar orçamento em PDF".
- PDF do orçamento com seção "Peças para comprar" e imagens.
- Estoque fica escondido enquanto a oficina não vende peças (Configurações › Agendamento).
- Fontes do site embutidas (sem Google Fonts).

## 1.0.0 (2026-11-05)
Primeira versão.

- Site público: página inicial com serviços, horário, mapa (Google Maps e Waze) e agendamento em 5 passos sem cadastro.
- Origem de cada agendamento registrada (Instagram, WhatsApp, link direto, balcão).
- Link privado do cliente para remarcar, cancelar, adicionar à agenda e acompanhar a moto.
- Aprovação de orçamento online, com registro de data e IP.
- Painel: agenda por elevador ou mecânico, arrastar para remarcar, bloqueios, check-in, OS com fotos, orçamento, peças, pagamentos e PDFs.
- Financeiro: fluxo de caixa, despesas, valores a receber, comissões e exportação em CSV.
- Dashboard com faturamento, ocupação, faltas e origem dos clientes.
- WhatsApp Nível 1 (textos prontos e links wa.me) e Nível 2 (API oficial, opcional).
- Lembretes de troca de óleo, faltas automáticas e retenção LGPD automática.
- Exportação e eliminação dos dados do cliente.
- Identidade visual com as cores da logo e vidro só em barras e botões.
- Tema claro e escuro no painel; o painel pode ser instalado no celular (PWA).
